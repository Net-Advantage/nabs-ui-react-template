import { n as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=b28e66a1";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=b28e66a1";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom.js?v=b28e66a1";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=b28e66a1";
//#region node_modules/@net-advantage/nabs-ui-layout/dist/nabs-ui-layout.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function n$27(e) {
	if (e == null) return;
	if (typeof e == "number") return `${e}px`;
	let t = e.trim();
	return t.length > 0 ? t : void 0;
}
function r$27({ as: t = "div", className: n = "", children: r, ...i }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(t, {
		className: n,
		...i,
		children: r
	});
}
function i$1({ header: i, footer: a, leftSidePanel: o, rightSidePanel: s, leftSidePanelWidth: c, rightSidePanelWidth: l, children: u, className: d = "", headerClassName: f = "", footerClassName: p = "", leftSidePanelClassName: m = "", rightSidePanelClassName: h = "", contentClassName: g = "", style: _, ...v }) {
	let y = i != null && i !== !1, b = a != null && a !== !1, x = o != null && o !== !1, S = s != null && s !== !1, C = [
		"nabs-ui-layout__body",
		x && S ? "nabs-ui-layout__body--with-both-panels" : "",
		x && !S ? "nabs-ui-layout__body--with-left-panel" : "",
		!x && S ? "nabs-ui-layout__body--with-right-panel" : ""
	].filter(Boolean).join(" "), w = ["nabs-ui-layout", d].filter(Boolean).join(" "), T = n$27(c), E = n$27(l);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: w,
		style: {
			..._ ?? {},
			...T ? { "--nabs-ui-layout-left-panel-width": T } : {},
			...E ? { "--nabs-ui-layout-right-panel-width": E } : {}
		},
		...v,
		children: [
			y ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(r$27, {
				as: "header",
				className: "nabs-ui-layout__headerWrapper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: ["nabs-ui-layout__header", f].filter(Boolean).join(" "),
					children: i
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: C,
				children: [
					x ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(r$27, {
						as: "aside",
						className: [
							"nabs-ui-layout__panel",
							"nabs-ui-layout__panel--left",
							m
						].filter(Boolean).join(" "),
						children: o
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(r$27, {
						as: "section",
						className: ["nabs-ui-layout__content", g].filter(Boolean).join(" "),
						children: u
					}),
					S ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(r$27, {
						as: "aside",
						className: [
							"nabs-ui-layout__panel",
							"nabs-ui-layout__panel--right",
							h
						].filter(Boolean).join(" "),
						children: s
					}) : null
				]
			}),
			b ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(r$27, {
				as: "footer",
				className: "nabs-ui-layout__footerWrapper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: ["nabs-ui-layout__footer", p].filter(Boolean).join(" "),
					children: a
				})
			}) : null
		]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-accordion/dist/nabs-ui-accordion.js
function s$13(e, t, n) {
	let r = e ?? [], i = new Set(t.map((e) => e.id)), a = r.filter((e, t, n) => i.has(e) && n.indexOf(e) === t);
	return n === "single" ? a.slice(0, 1) : a;
}
function c$12(e, t, n) {
	let r = e.includes(t);
	return n === "single" ? r ? [] : [t] : r ? e.filter((e) => e !== t) : [...e, t];
}
function l$11(e) {
	return ["nabs-ui-accordion", e].filter(Boolean).join(" ");
}
var u = (0, import_react.forwardRef)(function({ items: e, mode: u = "multiple", expandedItemIds: d, defaultExpandedItemIds: f, onExpandedItemIdsChange: p, className: m = "", itemClassName: h = "", triggerClassName: g = "", panelClassName: _ = "", id: v, ...y }, b) {
	let x = (0, import_react.useId)(), S = v ?? `nabs-ui-accordion-${x.replace(/:/g, "")}`, [C, w] = (0, import_react.useState)((0, import_react.useMemo)(() => s$13(f, e, u), [
		f,
		e,
		u
	]));
	(0, import_react.useEffect)(() => {
		w((t) => s$13(t, e, u));
	}, [e, u]);
	let T = (0, import_react.useMemo)(() => s$13(d === void 0 ? C : d, e, u), [
		d,
		C,
		e,
		u
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		ref: b,
		id: S,
		className: l$11(m),
		...y,
		children: e.map((e) => {
			let t = T.includes(e.id), n = `${S}-panel-${e.id}`, r = `${S}-trigger-${e.id}`, i = [
				"nabs-ui-accordion__item",
				t ? "nabs-ui-accordion__item--expanded" : "",
				h
			].filter(Boolean).join(" "), s = ["nabs-ui-accordion__trigger", g].filter(Boolean).join(" "), l = ["nabs-ui-accordion__panel", _].filter(Boolean).join(" "), f = (t) => {
				let n = c$12(T, e.id, u);
				d === void 0 && w(n), p?.({
					itemId: e.id,
					expandedItemIds: n,
					event: t
				});
			};
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: i,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "m-0",
					children: t ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						id: r,
						type: "button",
						className: s,
						"aria-expanded": "true",
						"aria-controls": n,
						disabled: e.disabled,
						onClick: f,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.header }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nabs-ui-accordion__triggerIcon",
							"aria-hidden": "true",
							children: "+"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						id: r,
						type: "button",
						className: s,
						"aria-expanded": "false",
						"aria-controls": n,
						disabled: e.disabled,
						onClick: f,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.header }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nabs-ui-accordion__triggerIcon",
							"aria-hidden": "true",
							children: "+"
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: n,
					className: l,
					role: "region",
					"aria-labelledby": r,
					hidden: !t,
					children: e.content
				})]
			}, e.id);
		})
	});
});
u.displayName = "Accordion";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-avatar/dist/nabs-ui-avatar.js
var import_react_dom = require_react_dom();
function u$9(e) {
	return !!(e && "type" in e && e.type === "divider");
}
function d$8(e) {
	return e.label ?? e.children ?? "Menu item";
}
function f$7(e, t) {
	return e.value ?? e.label ?? `item-${t}`;
}
function p$6({ label: e = "Menu", triggerContent: p, triggerAriaLabel: m, menuAlign: h = "start", items: g = [], className: _ = "", triggerClassName: v = "", menuClassName: y = "", itemClassName: b = "", dividerClassName: x = "", id: S, onItemSelect: C, ...w }) {
	let [T, E] = (0, import_react.useState)(!1), D = (0, import_react.useRef)(null), O = (0, import_react.useRef)(null), k = (0, import_react.useRef)(null), A = (0, import_react.useId)(), j = S ?? `nabs-ui-dropdownmenu-${A.replace(/:/g, "")}`, M = ["nabs-ui-dropdownmenu", _].filter(Boolean).join(" "), N = ["nabs-ui-dropdownmenu__trigger", v].filter(Boolean).join(" "), P = ["nabs-ui-dropdownmenu__menu", y].filter(Boolean).join(" "), F = ["nabs-ui-dropdownmenu__item", b].filter(Boolean).join(" "), I = ["nabs-ui-dropdownmenu__divider", x].filter(Boolean).join(" ");
	(0, import_react.useEffect)(() => {
		let e = (e) => {
			e.target instanceof Node && D.current && !D.current.contains(e.target) && k.current && !k.current.contains(e.target) && E(!1);
		}, t = (e) => {
			e.key === "Escape" && E(!1);
		};
		return document.addEventListener("pointerdown", e), document.addEventListener("keydown", t), () => {
			document.removeEventListener("pointerdown", e), document.removeEventListener("keydown", t);
		};
	}, []), (0, import_react.useLayoutEffect)(() => {
		if (!T || !O.current) return;
		let e = () => {
			let e = O.current?.getBoundingClientRect(), t = k.current;
			if (!e || !t) return;
			let n = e.width, r = window.innerWidth - n - 8, i = h === "end" ? e.right - n : e.left, a = Math.max(8, Math.min(i, r)), o = Math.max(8, e.bottom + 10);
			t.style.position = "fixed", t.style.top = `${o}px`, t.style.left = `${a}px`, t.style.right = "auto", t.style.minWidth = `${n}px`, t.style.visibility = "visible";
		};
		return k.current && (k.current.style.visibility = "hidden"), e(), window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0);
		};
	}, [h, T]);
	let L = (e, t) => {
		if (E(!1), e.disabled) {
			t.preventDefault();
			return;
		}
		C?.(e, t), e.onSelect?.(e, t);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: D,
		className: M,
		...w,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			ref: O,
			type: "button",
			className: N,
			"aria-haspopup": "menu",
			"aria-controls": j,
			"aria-label": m ?? e,
			onClick: () => E((e) => !e),
			children: p ?? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-dropdownmenu__triggerLabel",
				children: e
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-dropdownmenu__triggerChevron",
				"aria-hidden": "true",
				children: "▾"
			})] })
		}), T && typeof document < "u" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: k,
			id: j,
			className: P,
			"aria-label": e,
			children: g.map((e, t) => {
				if (u$9(e)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: I,
					role: "separator",
					"aria-hidden": "true"
				}, `divider-${t}`);
				let n = d$8(e), r = [
					F,
					e.disabled ? "nabs-ui-dropdownmenu__item--disabled" : "",
					e.danger ? "nabs-ui-dropdownmenu__item--danger" : ""
				].filter(Boolean).join(" "), i = {
					className: r,
					"aria-disabled": e.disabled || void 0
				};
				return e.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					...i,
					href: e.disabled ? void 0 : e.href,
					onClick: (t) => L(e, t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemLabel",
						children: n
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemDescription",
						children: e.description
					}) : null]
				}, f$7(e, t)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: r,
					disabled: e.disabled,
					onClick: (t) => L(e, t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemLabel",
						children: n
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemDescription",
						children: e.description
					}) : null]
				}, f$7(e, t));
			})
		}), document.body) : null]
	});
}
function m$5(e) {
	let t = e.trim().split(/\s+/).filter(Boolean);
	return t.length === 0 ? "?" : t.slice(0, 2).map((e) => e[0]?.toUpperCase() ?? "").join("");
}
var h = (0, import_react.forwardRef)(function({ authenticated: e = !1, name: t = "Guest user", avatarUrl: n = "", loginHref: r, profileHref: i = "#", logoutHref: a = "#", onLoginClick: o, onProfileClick: u, onLogoutClick: d, className: f = "", menuLabel: h, ...g }, _) {
	let v = t.trim() || "Guest user", y = m$5(v), b = [
		"nabs-ui-avatar",
		e ? "nabs-ui-avatar--authenticated" : "nabs-ui-avatar--unauthenticated",
		f
	].filter(Boolean).join(" "), x = (e) => {
		o && (e.preventDefault(), o(e));
	}, S = (e) => {
		u && (e.preventDefault(), u(e));
	}, C = (e) => {
		d && (e.preventDefault(), d(e));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: _,
		className: b,
		...g,
		children: e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(p$6, {
			className: "nabs-ui-avatar__menuRoot",
			label: `${v} account menu`,
			triggerAriaLabel: h ?? `${v} account menu`,
			menuAlign: "end",
			triggerContent: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "nabs-ui-avatar__avatar",
					"aria-hidden": "true",
					children: n ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						className: "nabs-ui-avatar__image",
						src: n,
						alt: ""
					}) : y
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "nabs-ui-avatar__name",
					children: v
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "nabs-ui-avatar__chevron",
					"aria-hidden": "true",
					children: "▾"
				})
			] }),
			triggerClassName: "nabs-ui-avatar__trigger",
			menuClassName: "nabs-ui-avatar__menu",
			itemClassName: "nabs-ui-avatar__menuItem",
			items: [{
				label: "Profile",
				href: i,
				onSelect: (e, t) => S(t)
			}, {
				label: "Logout",
				href: a,
				danger: !0,
				onSelect: (e, t) => C(t)
			}]
		}) : r ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			className: "nabs-ui-avatar__login",
			href: r,
			onClick: x,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-avatar__avatar nabs-ui-avatar__avatar--placeholder",
				"aria-hidden": "true",
				children: y
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-avatar__loginText",
				children: "Login"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "nabs-ui-avatar__login",
			onClick: x,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-avatar__avatar nabs-ui-avatar__avatar--placeholder",
				"aria-hidden": "true",
				children: y
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-avatar__loginText",
				children: "Login"
			})]
		})
	});
});
h.displayName = "Avatar";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-buttons/dist/nabs-ui-buttons.js
var n$24 = {
	primary: "nabs-ui-button--primary",
	secondary: "nabs-ui-button--secondary",
	ghost: "nabs-ui-button--ghost"
};
var r = (0, import_react.forwardRef)(function({ children: e, className: r = "", variant: i = "primary", type: a = "button", ...o }, s) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref: s,
		className: [
			"nabs-ui-button",
			n$24[i] ?? n$24.primary,
			r
		].filter(Boolean).join(" "),
		type: a,
		...o,
		children: e
	});
});
r.displayName = "Button";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-cards/dist/nabs-ui-cards.js
function r$24(e) {
	return e === void 0 ? 1 : Number.isFinite(e) ? Math.min(12, Math.max(1, Math.floor(e))) : 1;
}
function i$22(e, t, n) {
	return t === "Z" ? [...e].sort((t, r) => {
		let i = e.findIndex((e) => e.id === t.id), a = e.findIndex((e) => e.id === r.id), o = Math.floor(i / n), s = Math.floor(a / n);
		if (o !== s) return o - s;
		let c = i % n, l = a % n;
		return (o % 2 == 0 ? c : n - 1 - c) - (s % 2 == 0 ? l : n - 1 - l);
	}) : e;
}
var a$1 = (0, import_react.forwardRef)(({ items: e, layout: a = "N", columns: o, className: s = "", itemClassName: c = "", headerClassName: l = "", contentClassName: u = "", actionsClassName: d = "", ...f }, p) => {
	let m = r$24(o), h = ["nabs-ui-cards", s].filter(Boolean).join(" "), g = ["nabs-ui-cards__grid", `nabs-ui-cards__grid--columns-${m}`].filter(Boolean).join(" "), _ = i$22(e, a, m);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		ref: p,
		className: h,
		...f,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: g,
			children: _.map((e) => {
				let r = ["nabs-ui-cards__card", c].filter(Boolean).join(" "), i = e.header != null && e.header !== !1, a = e.content != null && e.content !== !1, o = e.actions != null && e.actions !== !1;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: r,
					children: [
						i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
							className: ["nabs-ui-cards__header", l].filter(Boolean).join(" "),
							children: e.header
						}) : null,
						a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: ["nabs-ui-cards__content", u].filter(Boolean).join(" "),
							children: e.content
						}) : null,
						o ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: ["nabs-ui-cards__actions", d].filter(Boolean).join(" "),
							children: e.actions
						}) : null
					]
				}, e.id);
			})
		})
	});
});
a$1.displayName = "Cards";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-checkbox/dist/nabs-ui-checkbox.js
var i$21 = {
	right: "nabs-ui-checkbox--label-right",
	left: "nabs-ui-checkbox--label-left",
	top: "nabs-ui-checkbox--label-top",
	bottom: "nabs-ui-checkbox--label-bottom"
};
var a$2 = (0, import_react.forwardRef)(function({ label: e = "Checkbox", labelPosition: a = "right", className: o = "", inputClassName: s = "", labelClassName: c = "", id: l, disabled: u, ...d }, f) {
	let p = (0, import_react.useId)(), m = l ?? `nabs-ui-checkbox-${p.replace(/:/g, "")}`, h = [
		"nabs-ui-checkbox",
		u ? "nabs-ui-checkbox--disabled" : "",
		i$21[a] ?? i$21.right,
		o
	].filter(Boolean).join(" "), g = ["nabs-ui-checkbox__input", s].filter(Boolean).join(" "), _ = ["nabs-ui-checkbox__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: h,
		htmlFor: m,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: f,
			id: m,
			className: g,
			type: "checkbox",
			disabled: u,
			...d
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: _,
			children: e
		})]
	});
});
a$2.displayName = "Checkbox";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-code/dist/nabs-ui-code.js
var r$22 = {
	html: "HTML",
	css: "CSS",
	json: "JSON",
	csharp: "C#"
};
var i = (0, import_react.forwardRef)(({ code: e, language: i = "html", showLineNumbers: a = !1, wrap: o = !1, title: s, className: c = "", preClassName: l = "", codeClassName: u = "", ...d }, f) => {
	let p = ["nabs-ui-code", c].filter(Boolean).join(" "), m = [
		"nabs-ui-code__pre",
		o ? "nabs-ui-code__pre--wrap" : "",
		a ? "nabs-ui-code__pre--lineNumbers" : "",
		l
	].filter(Boolean).join(" "), h = [
		"nabs-ui-code__snippet",
		`nabs-ui-code__snippet--${i}`,
		u
	].filter(Boolean).join(" "), g = e.replace(/\r\n/g, "\n"), _ = g.split("\n");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref: f,
		className: p,
		...d,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "nabs-ui-code__header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-code__language",
				children: r$22[i]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-code__title",
				children: s ?? "Snippet"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: m,
			children: a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
				className: h,
				children: _.map((e, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "nabs-ui-code__line",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-code__lineNumber",
						children: r + 1
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-code__lineText",
						children: e || " "
					})]
				}, r))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
				className: h,
				children: g
			})
		})]
	});
});
i.displayName = "Code";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-combobox/dist/nabs-ui-combobox.js
function c$10(e) {
	return e.label ?? e.children ?? e.value;
}
function l$9(e) {
	let t = c$10(e);
	return typeof t == "string" || typeof t == "number" ? `${t}` : e.value;
}
function u$8(e, t) {
	return e.value || `item-${t}`;
}
function d$7(e, t) {
	return t == null ? null : e.find((e) => e.value === t) ?? null;
}
function f$6(e) {
	return e.trim().toLowerCase();
}
var p = (0, import_react.forwardRef)(function({ items: e = [], value: p, defaultValue: m, allowNull: h = !1, nullLabel: g = "None", className: _ = "", id: v, disabled: y, placeholder: b, onValueChange: x, onFocus: S, onBlur: C, onKeyDown: w, ...T }, E) {
	let D = (0, import_react.useId)(), O = (0, import_react.useRef)(null), k = `nabs-ui-combobox-list-${D.replace(/:/g, "")}`, A = v ?? `nabs-ui-combobox-${D.replace(/:/g, "")}`, j = p !== void 0, [M, N] = (0, import_react.useState)(m ?? null), P = j ? p : M, F = d$7(e, P), I = F ? l$9(F) : P ?? "", [L, R] = (0, import_react.useState)(!1), [z, B] = (0, import_react.useState)(I), [V, H] = (0, import_react.useState)(0), U = (0, import_react.useMemo)(() => {
		let t = f$6(z);
		return e.filter((e) => {
			let n = f$6(l$9(e));
			return t.length === 0 || n.includes(t);
		});
	}, [e, z]), W = h ? [{
		value: "",
		label: g,
		disabled: !1,
		__null: !0
	}, ...U] : U;
	(0, import_react.useEffect)(() => {
		L || B(I);
	}, [L, I]), (0, import_react.useEffect)(() => {
		V >= W.length && H(W.length === 0 ? 0 : W.length - 1);
	}, [V, W.length]), (0, import_react.useEffect)(() => {
		let e = (e) => {
			O.current && e.target instanceof Node && !O.current.contains(e.target) && R(!1);
		};
		return document.addEventListener("pointerdown", e), () => {
			document.removeEventListener("pointerdown", e);
		};
	}, []);
	let G = (e, t) => {
		j || N(e), x?.(e, t), R(!1), B(t ? l$9(t) : "");
	}, K = (e) => {
		let t = W[e];
		if (t) {
			if ("__null" in t) {
				G(null, null);
				return;
			}
			t.disabled || G(t.value, t);
		}
	}, q = (e) => {
		R(!0), B(I), H(0), S?.(e);
	}, J = (e) => {
		R(!1), B(I), C?.(e);
	}, Y = (e) => {
		R(!0), B(e.target.value), H(0);
	}, X = (e) => {
		if (e.key === "ArrowDown") {
			e.preventDefault(), R(!0), H((e) => Math.min(e + 1, Math.max(W.length - 1, 0)));
			return;
		}
		if (e.key === "ArrowUp") {
			e.preventDefault(), R(!0), H((e) => Math.max(e - 1, 0));
			return;
		}
		if (e.key === "Enter") {
			L && (e.preventDefault(), K(V));
			return;
		}
		if (e.key === "Escape") {
			e.preventDefault(), R(!1), B(I);
			return;
		}
		w?.(e);
	}, Z = L ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref: E,
		id: A,
		role: "combobox",
		"aria-haspopup": "listbox",
		"aria-autocomplete": "list",
		"aria-expanded": "true",
		"aria-controls": k,
		"aria-activedescendant": W[V] ? `${k}-option-${V}` : void 0,
		className: "nabs-ui-combobox__input",
		disabled: y,
		placeholder: b,
		value: z,
		onFocus: q,
		onBlur: J,
		onChange: Y,
		onKeyDown: X,
		...T
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref: E,
		id: A,
		role: "combobox",
		"aria-haspopup": "listbox",
		"aria-autocomplete": "list",
		"aria-expanded": "false",
		"aria-controls": k,
		className: "nabs-ui-combobox__input",
		disabled: y,
		placeholder: b,
		value: z,
		onFocus: q,
		onBlur: J,
		onChange: Y,
		onKeyDown: X,
		...T
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: O,
		className: [
			"nabs-ui-combobox",
			L ? "nabs-ui-combobox--open" : "",
			y ? "nabs-ui-combobox--disabled" : "",
			_
		].filter(Boolean).join(" "),
		children: [Z, L ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: k,
			className: "nabs-ui-combobox__popup",
			role: "listbox",
			"aria-label": "Combobox options",
			children: W.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-combobox__empty",
				role: "option",
				"aria-disabled": "true",
				"aria-selected": "false",
				children: "No options found"
			}) : W.map((e, t) => {
				let n = "__null" in e, r = !n && P === e.value, i = [
					"nabs-ui-combobox__option",
					t === V ? "nabs-ui-combobox__option--active" : "",
					r ? "nabs-ui-combobox__option--selected" : "",
					n ? "nabs-ui-combobox__option--null" : "",
					e.disabled ? "nabs-ui-combobox__option--disabled" : ""
				].filter(Boolean).join(" ");
				return n ? P === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "true",
					"aria-disabled": "false",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: g
					})
				}, "null") : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "false",
					"aria-disabled": "false",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: g
					})
				}, "null") : e.disabled ? r ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "true",
					"aria-disabled": "true",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: c$10(e)
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionDescription",
						children: e.description
					}) : null]
				}, u$8(e, t)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "false",
					"aria-disabled": "true",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: c$10(e)
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionDescription",
						children: e.description
					}) : null]
				}, u$8(e, t)) : r ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "true",
					"aria-disabled": "false",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: c$10(e)
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionDescription",
						children: e.description
					}) : null]
				}, u$8(e, t)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "false",
					"aria-disabled": "false",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: c$10(e)
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionDescription",
						children: e.description
					}) : null]
				}, u$8(e, t));
			})
		}) : null]
	});
});
p.displayName = "Combobox";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-datepicker/dist/nabs-ui-datepicker.js
var i$19 = {
	none: "nabs-ui-datepicker--label-none",
	top: "nabs-ui-datepicker--label-top",
	left: "nabs-ui-datepicker--label-left"
};
var a$3 = (0, import_react.forwardRef)(({ label: e, labelPosition: a = "top", className: o = "", inputClassName: s = "", labelClassName: c = "", allowNull: l = !1, id: u, value: d, onChange: f, onClick: p, onValueChange: m, ...h }, g) => {
	let _ = (0, import_react.useId)(), v = u ?? `nabs-ui-datepicker-${_.replace(/:/g, "")}`, y = [
		"nabs-ui-datepicker",
		e ? i$19[a] ?? i$19.top : "",
		o
	].filter(Boolean).join(" "), b = ["nabs-ui-datepicker__input", s].filter(Boolean).join(" "), x = ["nabs-ui-datepicker__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: y,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: x,
			htmlFor: v,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: g,
			id: v,
			className: b,
			type: "date",
			value: d === void 0 ? void 0 : d ?? "",
			onClick: (e) => {
				if (p?.(e), e.defaultPrevented) return;
				let t = e.currentTarget;
				t.disabled || t.readOnly || t.showPicker?.();
			},
			onChange: (e) => {
				f?.(e), m?.(l && e.target.value === "" ? null : e.target.value, e);
			},
			...h
		})]
	});
});
a$3.displayName = "DatePicker";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-dialog/dist/nabs-ui-dialog.js
var o$10 = "a[href], area[href], button:not([disabled]), input:not([disabled]):not([type=\"hidden\"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex=\"-1\"])";
function s$10(e) {
	return Array.from(e.querySelectorAll(o$10)).filter((e) => !e.hasAttribute("disabled") && e.getAttribute("aria-hidden") !== "true");
}
var c = (0, import_react.forwardRef)(function({ title: e, description: o, header: c, footer: l, showHeader: u = !0, showFooter: d = !0, onRequestClose: f, closeOnBackdropClick: p = !0, closeOnEscape: m = !0, initialFocusSelector: h, dialogRole: g = "dialog", className: _ = "", backdropClassName: v = "", headerClassName: y = "", descriptionClassName: b = "", contentClassName: x = "", footerClassName: S = "", onKeyDown: C, tabIndex: w, children: T, ...E }, D) {
	let O = (0, import_react.useRef)(null), k = (0, import_react.useRef)(null), A = `nabs-ui-dialog-title-${(0, import_react.useId)().replace(/:/g, "")}`, j = `nabs-ui-dialog-description-${(0, import_react.useId)().replace(/:/g, "")}`, M = E["aria-labelledby"], N = E["aria-describedby"], P = !c && !!e, F = !!o, I = u && (!!c || P), L = d && l != null, R = M ?? (P ? A : void 0), z = N ?? (F ? j : void 0), B = ["nabs-ui-dialog__backdrop", v].filter(Boolean).join(" "), V = ["nabs-ui-dialog", _].filter(Boolean).join(" "), H = ["nabs-ui-dialog__header", y].filter(Boolean).join(" "), U = ["nabs-ui-dialog__description", b].filter(Boolean).join(" "), W = ["nabs-ui-dialog__content", x].filter(Boolean).join(" "), G = ["nabs-ui-dialog__footer", S].filter(Boolean).join(" ");
	return (0, import_react.useEffect)(() => {
		let e = O.current;
		if (!e) return;
		if (k.current = document.activeElement instanceof HTMLElement ? document.activeElement : null, h) try {
			let t = e.querySelector(h);
			if (t) return t.focus(), () => {
				k.current?.focus(), k.current = null;
			};
		} catch {}
		let t = s$10(e);
		return t.length > 0 ? t[0].focus() : e.focus(), () => {
			k.current?.focus(), k.current = null;
		};
	}, [h]), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: B,
		role: "presentation",
		onClick: (e) => {
			!p || e.target !== e.currentTarget || f?.();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			ref: (e) => {
				if (O.current = e, typeof D == "function") {
					D(e);
					return;
				}
				D && (D.current = e);
			},
			className: V,
			role: g,
			"aria-modal": "true",
			"aria-labelledby": R,
			"aria-describedby": z,
			tabIndex: w ?? -1,
			onKeyDown: (e) => {
				if (C?.(e), e.defaultPrevented) return;
				if (e.key === "Escape" && m) {
					e.preventDefault(), f?.();
					return;
				}
				if (e.key !== "Tab" || !O.current) return;
				let t = s$10(O.current);
				if (t.length === 0) {
					e.preventDefault(), O.current.focus();
					return;
				}
				let n = document.activeElement, r = t[0], i = t[t.length - 1];
				if (e.shiftKey) {
					(!n || n === r || !O.current.contains(n)) && (e.preventDefault(), i.focus());
					return;
				}
				(!n || n === i || !O.current.contains(n)) && (e.preventDefault(), r.focus());
			},
			...E,
			children: [
				I ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: H,
					children: c ?? (P ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "nabs-ui-dialog__title",
						id: A,
						children: e
					}) : null)
				}) : null,
				F ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: j,
					className: U,
					children: o
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: W,
					children: T
				}),
				L ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: G,
					children: l
				}) : null
			]
		})
	});
});
c.displayName = "Dialog";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-dropdownlist/dist/nabs-ui-dropdownlist.js
function i$17(e) {
	return e.label ?? e.children ?? e.value;
}
function a$15(e, t) {
	return e.value || `item-${t}`;
}
function o$9(e, t, n) {
	return e || t === null || n === null;
}
var s = (0, import_react.forwardRef)(function({ items: e = [], value: s, defaultValue: c, allowNull: l = !1, nullLabel: u = "None", className: d = "", onChange: f, onValueChange: p, id: m, disabled: h, ...g }, _) {
	let v = (0, import_react.useId)(), y = m ?? `nabs-ui-dropdownlist-${v.replace(/:/g, "")}`, b = [
		"nabs-ui-dropdownlist",
		h ? "nabs-ui-dropdownlist--disabled" : "",
		d
	].filter(Boolean).join(" "), x = o$9(l, s, c);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		ref: _,
		id: y,
		className: b,
		disabled: h,
		value: s ?? void 0,
		defaultValue: c ?? void 0,
		onChange: (e) => {
			let t = e.target.value === "" ? null : e.target.value;
			p?.(t, e), f?.(e);
		},
		...g,
		children: [x ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			disabled: !l,
			children: u
		}) : null, e.map((e, t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: e.value,
			disabled: e.disabled,
			children: i$17(e)
		}, a$15(e, t)))]
	});
});
s.displayName = "DropdownList";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-dropdownmenu/dist/nabs-ui-dropdownmenu.js
function l$8(e) {
	return !!(e && "type" in e && e.type === "divider");
}
function u$7(e) {
	return e.label ?? e.children ?? "Menu item";
}
function d$6(e, t) {
	return e.value ?? e.label ?? `item-${t}`;
}
function f({ label: f = "Menu", triggerContent: p, triggerAriaLabel: m, menuAlign: h = "start", items: g = [], className: _ = "", triggerClassName: v = "", menuClassName: y = "", itemClassName: b = "", dividerClassName: x = "", id: S, onItemSelect: C, ...w }) {
	let [T, E] = (0, import_react.useState)(!1), D = (0, import_react.useRef)(null), O = (0, import_react.useRef)(null), k = (0, import_react.useRef)(null), A = (0, import_react.useId)(), j = S ?? `nabs-ui-dropdownmenu-${A.replace(/:/g, "")}`, M = ["nabs-ui-dropdownmenu", _].filter(Boolean).join(" "), N = ["nabs-ui-dropdownmenu__trigger", v].filter(Boolean).join(" "), P = ["nabs-ui-dropdownmenu__menu", y].filter(Boolean).join(" "), F = ["nabs-ui-dropdownmenu__item", b].filter(Boolean).join(" "), I = ["nabs-ui-dropdownmenu__divider", x].filter(Boolean).join(" ");
	(0, import_react.useEffect)(() => {
		let e = (e) => {
			e.target instanceof Node && D.current && !D.current.contains(e.target) && k.current && !k.current.contains(e.target) && E(!1);
		}, t = (e) => {
			e.key === "Escape" && E(!1);
		};
		return document.addEventListener("pointerdown", e), document.addEventListener("keydown", t), () => {
			document.removeEventListener("pointerdown", e), document.removeEventListener("keydown", t);
		};
	}, []), (0, import_react.useLayoutEffect)(() => {
		if (!T || !O.current) return;
		let e = () => {
			let e = O.current?.getBoundingClientRect(), t = k.current;
			if (!e || !t) return;
			let n = e.width, r = window.innerWidth - n - 8, i = h === "end" ? e.right - n : e.left, a = Math.max(8, Math.min(i, r)), o = Math.max(8, e.bottom + 10);
			t.style.position = "fixed", t.style.top = `${o}px`, t.style.left = `${a}px`, t.style.right = "auto", t.style.minWidth = `${n}px`, t.style.visibility = "visible";
		};
		return k.current && (k.current.style.visibility = "hidden"), e(), window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0);
		};
	}, [h, T]);
	let L = (e, t) => {
		if (E(!1), e.disabled) {
			t.preventDefault();
			return;
		}
		C?.(e, t), e.onSelect?.(e, t);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: D,
		className: M,
		...w,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			ref: O,
			type: "button",
			className: N,
			"aria-haspopup": "menu",
			"aria-controls": j,
			"aria-label": m ?? f,
			onClick: () => E((e) => !e),
			children: p ?? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-dropdownmenu__triggerLabel",
				children: f
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-dropdownmenu__triggerChevron",
				"aria-hidden": "true",
				children: "▾"
			})] })
		}), T && typeof document < "u" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: k,
			id: j,
			className: P,
			"aria-label": f,
			children: g.map((e, t) => {
				if (l$8(e)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: I,
					role: "separator",
					"aria-hidden": "true"
				}, `divider-${t}`);
				let n = u$7(e), r = [
					F,
					e.disabled ? "nabs-ui-dropdownmenu__item--disabled" : "",
					e.danger ? "nabs-ui-dropdownmenu__item--danger" : ""
				].filter(Boolean).join(" "), i = {
					className: r,
					"aria-disabled": e.disabled || void 0
				};
				return e.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					...i,
					href: e.disabled ? void 0 : e.href,
					onClick: (t) => L(e, t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemLabel",
						children: n
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemDescription",
						children: e.description
					}) : null]
				}, d$6(e, t)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: r,
					disabled: e.disabled,
					onClick: (t) => L(e, t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemLabel",
						children: n
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemDescription",
						children: e.description
					}) : null]
				}, d$6(e, t));
			})
		}), document.body) : null]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-dynamicform/dist/nabs-ui-dynamicform.js
var o$7 = {
	right: "nabs-ui-checkbox--label-right",
	left: "nabs-ui-checkbox--label-left",
	top: "nabs-ui-checkbox--label-top",
	bottom: "nabs-ui-checkbox--label-bottom"
};
var s$8 = (0, import_react.forwardRef)(function({ label: e = "Checkbox", labelPosition: t = "right", className: r = "", inputClassName: s = "", labelClassName: c = "", id: l, disabled: u, ...d }, f) {
	let p = (0, import_react.useId)(), m = l ?? `nabs-ui-checkbox-${p.replace(/:/g, "")}`, h = [
		"nabs-ui-checkbox",
		u ? "nabs-ui-checkbox--disabled" : "",
		o$7[t] ?? o$7.right,
		r
	].filter(Boolean).join(" "), g = ["nabs-ui-checkbox__input", s].filter(Boolean).join(" "), _ = ["nabs-ui-checkbox__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: h,
		htmlFor: m,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: f,
			id: m,
			className: g,
			type: "checkbox",
			disabled: u,
			...d
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: _,
			children: e
		})]
	});
});
s$8.displayName = "Checkbox";
var c$8 = {
	right: "nabs-ui-radiobutton--label-right",
	left: "nabs-ui-radiobutton--label-left",
	top: "nabs-ui-radiobutton--label-top",
	bottom: "nabs-ui-radiobutton--label-bottom"
};
function l$7({ label: e = "Radio button", labelPosition: t = "right", className: r = "", inputClassName: o = "", labelClassName: s = "", id: l, ...u }) {
	let d = u.disabled === !0, f = (0, import_react.useId)(), p = l ?? `nabs-ui-radiobutton-${f.replace(/:/g, "")}`, m = [
		"nabs-ui-radiobutton",
		d ? "nabs-ui-radiobutton--disabled" : "",
		c$8[t] ?? c$8.right,
		r
	].filter(Boolean).join(" "), h = ["nabs-ui-radiobutton__input", o].filter(Boolean).join(" "), g = ["nabs-ui-radiobutton__label", s].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: m,
		htmlFor: p,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: p,
			className: h,
			type: "radio",
			...u
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: g,
			children: e
		})]
	});
}
var u$6 = (0, import_react.forwardRef)(({ label: e, className: t = "", inputClassName: r = "", labelClassName: o = "", id: s, rows: c = 4, resize: l = "vertical", ...u }, d) => {
	let f = (0, import_react.useId)(), p = s ?? `nabs-ui-textarea-${f.replace(/:/g, "")}`, m = ["nabs-ui-textarea", t].filter(Boolean).join(" "), h = ["nabs-ui-textarea__input", r].filter(Boolean).join(" "), g = ["nabs-ui-textarea__label", o].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: m,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: g,
			htmlFor: p,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			ref: d,
			id: p,
			className: h,
			rows: c,
			"data-resize": l,
			...u
		})]
	});
});
u$6.displayName = "Textarea";
var d$5 = {
	none: "",
	top: "nabs-ui-textbox--label-top",
	left: "nabs-ui-textbox--label-left"
};
var f$5 = (0, import_react.forwardRef)(({ label: e, labelPosition: t = "top", className: r = "", inputClassName: o = "", labelClassName: s = "", id: c, type: l = "text", ...u }, f) => {
	let p = (0, import_react.useId)(), m = c ?? `nabs-ui-textbox-${p.replace(/:/g, "")}`, h = [
		"nabs-ui-textbox",
		e ? d$5[t] ?? d$5.top : "",
		r
	].filter(Boolean).join(" "), g = ["nabs-ui-textbox__input", o].filter(Boolean).join(" "), _ = ["nabs-ui-textbox__label", s].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: h,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: _,
			htmlFor: m,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: f,
			id: m,
			className: g,
			type: l,
			...u
		})]
	});
});
f$5.displayName = "Textbox";
function p$5(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function m$4(e) {
	return !e || e.type !== "object" || !p$5(e.properties) ? {} : Object.fromEntries(Object.entries(e.properties).map(([e, t]) => [e, h$5(t)]));
}
function h$5(e) {
	if (!e || !p$5(e)) return "";
	if (e.default !== void 0) return e.default;
	if (Array.isArray(e.enum) && e.enum.length > 0) return e.enum[0];
	switch (e.type) {
		case "boolean": return !1;
		case "integer":
		case "number": return "";
		case "object": return m$4(e);
		default: return "";
	}
}
function g$4(e, t) {
	if (!e || !p$5(e)) return t;
	if (e.type === "object" && p$5(e.properties)) {
		let n = p$5(t) ? t : {};
		return Object.fromEntries(Object.entries(e.properties).map(([e, t]) => [e, g$4(t, n[e] === void 0 ? h$5(t) : n[e])]));
	}
	if (e.type === "boolean") return t === !0;
	if (e.type === "integer") {
		if (t === "" || t == null) return "";
		let e = Number.parseInt(String(t), 10);
		return Number.isNaN(e) ? "" : e;
	}
	if (e.type === "number") {
		if (t === "" || t == null) return "";
		let e = Number.parseFloat(String(t));
		return Number.isNaN(e) ? "" : e;
	}
	return t ?? "";
}
function _$4(e) {
	return !e || !p$5(e) ? "textbox" : Array.isArray(e.enum) && e.enum.length > 0 ? "radio" : e.type === "string" ? e.maxLength !== void 0 && e.maxLength > 50 ? "textarea" : "textbox" : e.type === "integer" ? "int" : e.type === "number" ? String(e.format ?? "").toLowerCase() === "decimal" ? "decimal" : "double" : e.type === "boolean" ? "bool" : "textbox";
}
var v$4 = {
	type: "object",
	properties: {}
};
function y$4({ schema: e, name: t, value: n, onChange: r }) {
	let o = e.title ?? t, c = e.description, d = _$4(e), p = n ?? h$5(e);
	if (d === "radio") {
		let n = Array.isArray(e.enum) ? e.enum : [];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
			className: "nabs-ui-dynamicform__fieldset",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "nabs-ui-dynamicform__legend",
					children: o
				}),
				c ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "nabs-ui-dynamicform__description",
					children: c
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nabs-ui-dynamicform__radioGroup",
					children: n.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(l$7, {
						label: String(e),
						name: t,
						checked: p === e,
						onChange: () => r(e)
					}, String(e)))
				})
			]
		});
	}
	return d === "textarea" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$6, {
		label: o,
		rows: 5,
		value: String(p ?? ""),
		placeholder: String(e.default ?? ""),
		onChange: (e) => r(e.target.value)
	}) : d === "bool" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s$8, {
		label: o,
		checked: p === !0,
		onChange: (e) => r(e.target.checked)
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f$5, {
		label: o,
		type: d === "int" || d === "decimal" || d === "double" ? "number" : "text",
		step: d === "int" ? 1 : d === "decimal" || d === "double" ? "any" : void 0,
		value: String(p ?? ""),
		placeholder: String(e.default ?? ""),
		onChange: (e) => {
			let t = e.target.value;
			if (d === "int") {
				r(t === "" ? "" : Number.parseInt(t, 10));
				return;
			}
			if (d === "decimal" || d === "double") {
				r(t === "" ? "" : Number.parseFloat(t));
				return;
			}
			r(t);
		}
	});
}
var b = (0, import_react.forwardRef)(function({ schema: e, value: o, onChange: s, className: c = "", id: l, disabled: u = !1, ...d }, f) {
	let h = (0, import_react.useId)(), _ = l ?? `nabs-ui-dynamicform-${h.replace(/:/g, "")}`, b = e && e.type === "object" ? e : v$4, [x, S] = (0, import_react.useState)(() => g$4(b, o ?? m$4(b)));
	(0, import_react.useEffect)(() => {
		S(g$4(b, o ?? m$4(b)));
	}, [b, o]);
	let C = p$5(x) ? x : {}, w = b.title ?? "Dynamic form", T = b.description, E = [
		"nabs-ui-dynamicform",
		u ? "nabs-ui-dynamicform--disabled" : "",
		c
	].filter(Boolean).join(" "), D = (e) => {
		S(e), s?.(e);
	};
	return u ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: f,
		id: _,
		className: E,
		"aria-disabled": "true",
		...d,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-dynamicform__header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__title",
				children: w
			}), T ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__description",
				children: T
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-dynamicform__fields",
			children: Object.entries(b.properties ?? {}).map(([e, t]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__field",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(y$4, {
					schema: t,
					name: e,
					value: C[e],
					onChange: (n) => D({
						...C,
						[e]: g$4(t, n)
					})
				})
			}, e))
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: f,
		id: _,
		className: E,
		...d,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-dynamicform__header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__title",
				children: w
			}), T ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__description",
				children: T
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-dynamicform__fields",
			children: Object.entries(b.properties ?? {}).map(([e, t]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__field",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(y$4, {
					schema: t,
					name: e,
					value: C[e],
					onChange: (n) => D({
						...C,
						[e]: g$4(t, n)
					})
				})
			}, e))
		})]
	});
});
b.displayName = "DynamicForm";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-fileupload/dist/nabs-ui-fileupload.js
function a$12(e) {
	return e ? (Array.isArray(e) ? e : String(e).split(",")).map((e) => e.trim().toLowerCase()).filter(Boolean).map((e) => e.startsWith(".") ? e : `.${e}`) : [];
}
function o$6(e, t) {
	let n = String(e).split(",").map((e) => e.trim().toLowerCase()).filter(Boolean), r = a$12(t);
	return [.../* @__PURE__ */ new Set([...n, ...r])];
}
function s$7(e, t) {
	let n = e.name.toLowerCase(), r = (e.type ?? "").toLowerCase();
	return t === "*/*" ? !0 : t.endsWith("/*") ? r.startsWith(t.slice(0, -1)) : t.startsWith(".") ? n.endsWith(t) : r === t;
}
function c$7(e, t) {
	if (t.length === 0) return {
		acceptedFiles: e,
		rejectedFiles: []
	};
	let n = [], r = [];
	for (let i of e) (t.some((e) => s$7(i, e)) ? n : r).push(i);
	return {
		acceptedFiles: n,
		rejectedFiles: r
	};
}
function l({ label: a = "Drop files here or click Browse files", description: s = "Drag and drop files into the drop zone or choose them manually.", accept: l = "", extensions: u = [], multiple: d = !0, disabled: f = !1, className: p = "", surfaceClassName: m = "", labelClassName: h = "", descriptionClassName: g = "", buttonClassName: _ = "", inputClassName: v = "", id: y, onFilesSelected: b, ...x }) {
	let S = (0, import_react.useId)(), C = y ?? `nabs-ui-fileupload-${S.replace(/:/g, "")}`, w = (0, import_react.useRef)(null), [T, E] = (0, import_react.useState)(!1), D = o$6(l, u), O = D.length > 0 ? D.join(",") : void 0, k = [
		"nabs-ui-fileupload",
		f ? "nabs-ui-fileupload--disabled" : "",
		T ? "nabs-ui-fileupload--drag-over" : "",
		p
	].filter(Boolean).join(" "), A = ["nabs-ui-fileupload__surface", m].filter(Boolean).join(" "), j = ["nabs-ui-fileupload__label", h].filter(Boolean).join(" "), M = ["nabs-ui-fileupload__description", g].filter(Boolean).join(" "), N = ["nabs-ui-fileupload__button", _].filter(Boolean).join(" "), P = ["nabs-ui-fileupload__input", v].filter(Boolean).join(" "), F = (e, t) => {
		let { acceptedFiles: n, rejectedFiles: r } = c$7(Array.from(e ?? []), D);
		b?.({
			acceptedFiles: n,
			rejectedFiles: r,
			source: t
		});
	}, I = () => {
		f || w.current?.click();
	}, L = (e) => {
		F(e.target.files, "input"), e.target.value = "";
	}, R = (e) => {
		e.preventDefault(), f || E(!0);
	}, z = (e) => {
		e.preventDefault(), e.currentTarget === e.target && E(!1);
	}, B = (e) => {
		e.preventDefault(), E(!1), !f && F(e.dataTransfer.files, "drop");
	}, V = (e) => {
		(e.key === "Enter" || e.key === " ") && (e.preventDefault(), I());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: k,
		...x,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: A,
			role: "button",
			tabIndex: f ? -1 : 0,
			"aria-label": a,
			"data-disabled": f ? "true" : void 0,
			onClick: I,
			onKeyDown: V,
			onDragOver: R,
			onDragLeave: z,
			onDrop: B,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: w,
					id: C,
					className: P,
					type: "file",
					accept: O,
					multiple: d,
					disabled: f,
					"aria-label": a,
					title: a,
					onChange: L
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nabs-ui-fileupload__content",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: j,
							children: a
						}),
						s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: M,
							children: s
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "nabs-ui-fileupload__meta",
							children: [D.length > 0 ? `Accepted: ${D.join(", ")}` : "Accepted: all files", d ? " • multiple files" : " • single file"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: N,
					disabled: f,
					onClick: (e) => {
						e.stopPropagation(), I();
					},
					children: "Browse files"
				})
			]
		})
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-graph/dist/nabs-ui-graph.js
function c$1({ toolboxLabel: e, toolsets: t, isCollapsed: n, isEdgeToolEnabled: r, edgeHint: i, activeToolIdsBySet: a, onToggleCollapse: c, onToolClick: l, onToolDoubleClick: u }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "nabs-ui-graph__toolbox",
		role: "toolbar",
		"aria-label": e,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "nabs-ui-graph__toolboxToggle",
			onClick: c,
			"aria-label": n ? "Expand toolbox" : "Collapse toolbox",
			title: n ? "Expand toolbox" : "Collapse toolbox",
			children: n ? ">" : "<"
		}), !n && t.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-graph__toolset",
			"data-toolset": e.id,
			children: [e.label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-graph__toolsetTitle",
				children: e.label
			}), e.tools.map((t) => {
				let n = a[e.id] === t.id, c = t.kind === "edge", d = c && !r, f = t.iconClassName ?? `nabs-ui-graph__toolIcon--${t.id}`;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: [
						"nabs-ui-graph__tool",
						n ? "nabs-ui-graph__tool--active" : "",
						d ? "nabs-ui-graph__tool--disabled" : ""
					].filter(Boolean).join(" "),
					disabled: d,
					onClick: () => l(t, e.id),
					onDoubleClick: () => u(t, e.id),
					"data-active": n ? "true" : "false",
					"data-tool": t.id,
					title: c ? i : t.label,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: ["nabs-ui-graph__toolIcon", f].join(" "),
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-graph__toolLabel",
						children: t.label
					})]
				}, t.id);
			})]
		}, e.id))]
	});
}
var l$2 = {
	id: "simple-graph-toolset",
	label: "Simple Graph Toolset",
	tools: [
		{
			id: "square",
			label: "Square",
			kind: "node",
			nodeType: "square"
		},
		{
			id: "circle",
			label: "Circle",
			kind: "node",
			nodeType: "circle"
		},
		{
			id: "rectangle",
			label: "Rectangle",
			kind: "node",
			nodeType: "rectangle"
		},
		{
			id: "hexagon",
			label: "Hexagon",
			kind: "node",
			nodeType: "hexagon"
		},
		{
			id: "edge",
			label: "Edge",
			kind: "edge"
		}
	]
};
var u$1 = [l$2];
var d$1 = {
	id: "agentic-workflow-toolset",
	label: "Agentic Workflow",
	tools: [
		{
			id: "initiative",
			label: "Initiative",
			kind: "node",
			nodeType: "initiative"
		},
		{
			id: "scenario",
			label: "Scenario",
			kind: "node",
			nodeType: "scenario"
		},
		{
			id: "lifecycle",
			label: "Lifecycle",
			kind: "node",
			nodeType: "lifecycle"
		},
		{
			id: "context",
			label: "Context",
			kind: "node",
			nodeType: "context"
		},
		{
			id: "connector",
			label: "Connector",
			kind: "edge",
			iconClassName: "nabs-ui-graph__toolIcon--edge"
		}
	]
};
var f$1 = [d$1];
var p$4 = {
	square: "Square",
	circle: "Circle",
	rectangle: "Rectangle",
	hexagon: "Hexagon",
	initiative: "Initiative",
	scenario: "Scenario",
	lifecycle: "Lifecycle",
	context: "Context",
	edge: "Edge"
};
var m$3 = {
	square: {
		width: 100,
		height: 100
	},
	circle: {
		width: 100,
		height: 100
	},
	rectangle: {
		width: 140,
		height: 90
	},
	hexagon: {
		width: 120,
		height: 104
	},
	initiative: {
		width: 180,
		height: 110
	},
	scenario: {
		width: 190,
		height: 100
	},
	lifecycle: {
		width: 126,
		height: 126
	},
	context: {
		width: 190,
		height: 124
	}
};
var h$4 = {
	simple: "square",
	"agentic-workflow": "initiative"
};
var g$3 = .5;
var _$3 = 2.5;
var v$3 = {
	"initiative->initiative": "Extend",
	"initiative->scenario": "ResultIn",
	"scenario->lifecycle": "Use",
	"context->lifecycle": "UsedBy"
};
var y$3 = () => typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(16).slice(2)}`;
var ee$1 = (e, t, n) => Math.min(n, Math.max(t, e));
var b$4 = (e, t) => v$3[`${e}->${t}`] ?? null;
var x$2 = (e, t, n, r) => {
	let i = e.find((e) => e.id === n), a = e.find((e) => e.id === r);
	if (!i || !a) return {
		allowed: !1,
		label: null
	};
	let o = b$4(i.type, a.type);
	if (!o || i.type === "scenario" && a.type === "lifecycle" && t.some((t) => t.fromId === n ? e.find((e) => e.id === t.toId)?.type === "lifecycle" : !1)) return {
		allowed: !1,
		label: null
	};
	if (i.type === "initiative" && a.type === "initiative") {
		if (t.some((t) => t.toId === r ? e.find((e) => e.id === t.fromId)?.type === "initiative" : !1)) return {
			allowed: !1,
			label: null
		};
		let i = /* @__PURE__ */ new Map();
		for (let n of t) {
			let t = e.find((e) => e.id === n.fromId), r = e.find((e) => e.id === n.toId);
			if (t?.type !== "initiative" || r?.type !== "initiative") continue;
			let a = i.get(n.fromId) ?? [];
			a.push(n.toId), i.set(n.fromId, a);
		}
		if (((e, t) => {
			let n = [e], r = /* @__PURE__ */ new Set();
			for (; n.length > 0;) {
				let e = n.pop();
				if (!e || r.has(e)) continue;
				if (e === t) return !0;
				r.add(e);
				let a = i.get(e) ?? [];
				for (let e of a) n.push(e);
			}
			return !1;
		})(r, n)) return {
			allowed: !1,
			label: null
		};
	}
	return {
		allowed: !0,
		label: o
	};
};
var te$1 = (e, t, n = 4) => {
	let r = e.trim().replace(/\s+/g, " ");
	if (!r) return [""];
	let i = Math.max(9, Math.floor((t - 16) / 6.4)), a = r.split(" "), o = [], s = "";
	for (let e of a) {
		let t = e;
		for (; t.length > i;) {
			let e = t.slice(0, i - 1) + "-";
			if (t = t.slice(i - 1), s.length > 0 && (o.push(s), s = ""), o.push(e), o.length >= n) {
				let e = o.slice(0, n);
				return e[n - 1] = `${e[n - 1].slice(0, Math.max(1, i - 1))}…`, e;
			}
		}
		let r = s.length > 0 ? `${s} ${t}` : t;
		if (r.length <= i) {
			s = r;
			continue;
		}
		if (s.length > 0 && o.push(s), s = t, o.length >= n) break;
	}
	if (s.length > 0 && o.length < n && o.push(s), o.length <= n) return o;
	let c = o.slice(0, n);
	return c[n - 1] = `${c[n - 1].slice(0, Math.max(1, i - 1))}…`, c;
};
var S = (0, import_react.forwardRef)(function({ className: e, toolboxLabel: l = "Tools", toolset: d = "simple", toolsets: v, ToolboxComponent: b = c$1, onShapeAdd: S, onShapeMove: C, ...ne }, w) {
	let T = d, E = !!(v && v.length > 0), D = h$4[T], O = !E && T === "agentic-workflow", k = (0, import_react.useMemo)(() => v && v.length > 0 ? v : T === "agentic-workflow" ? f$1 : u$1, [T, v]), A = (0, import_react.useRef)(null), [j, M] = (0, import_react.useState)([]), [N, P] = (0, import_react.useState)([]), [F, I] = (0, import_react.useState)(D), [re, L] = (0, import_react.useState)({}), [R, ie] = (0, import_react.useState)(!1), [z, B] = (0, import_react.useState)(null), [V, H] = (0, import_react.useState)(null), [U, W] = (0, import_react.useState)(null), [G, K] = (0, import_react.useState)(null), [q, J] = (0, import_react.useState)({
		scale: 1,
		offsetX: 0,
		offsetY: 0
	}), Y = (0, import_react.useRef)(q);
	(0, import_react.useEffect)(() => {
		Y.current = q;
	}, [q]), (0, import_react.useEffect)(() => {
		L((e) => {
			let t = {};
			for (let n of k) t[n.id] = e[n.id] ?? null;
			return t;
		});
	}, [k]), (0, import_react.useEffect)(() => {
		let e = /* @__PURE__ */ new Set(["edge"]);
		for (let t of k) for (let n of t.tools) n.kind === "node" && n.nodeType && e.add(n.nodeType);
		I((t) => e.has(t) ? t : D);
	}, [D, k]);
	let ae = (0, import_react.useMemo)(() => `translate(${q.offsetX}, ${q.offsetY}) scale(${q.scale})`, [q]), X = (0, import_react.useCallback)((e, t, n) => {
		let { scale: r, offsetX: i, offsetY: a } = Y.current;
		return {
			x: (e - n.left - i) / r,
			y: (t - n.top - a) / r
		};
	}, []), Z = (0, import_react.useCallback)((e, t) => {
		let n = A.current?.getBoundingClientRect();
		if (!n) return;
		let r = m$3[e], i = X(n.left + n.width / 2, n.top + n.height / 2, n);
		M((n) => {
			let a = {
				id: y$3(),
				type: e,
				label: `${t ?? p$4[e]} ${n.length + 1}`,
				width: r.width,
				height: r.height,
				x: i.x - r.width / 2,
				y: i.y - r.height / 2,
				createdAt: Date.now()
			}, o = [...n, a];
			return S?.(a), B(a.id), o;
		});
	}, [S, X]), Q = (0, import_react.useCallback)((e, t) => {
		e !== t && P((n) => {
			if (O ? n.some((n) => n.fromId === e && n.toId === t) : n.some((n) => n.fromId === e && n.toId === t || n.fromId === t && n.toId === e)) return n;
			let r = `Edge ${n.length + 1}`;
			if (O) {
				let i = x$2(j, n, e, t);
				if (!i.allowed || !i.label) return n;
				r = i.label;
			}
			return [...n, {
				id: y$3(),
				fromId: e,
				toId: t,
				label: r,
				createdAt: Date.now()
			}];
		});
	}, [O, j]), oe = (0, import_react.useCallback)((e, t) => {
		if (L((n) => ({
			...n,
			[t]: e.id
		})), e.kind === "edge") {
			if (!z) return;
			I("edge"), H(z);
			return;
		}
		e.nodeType && (I(e.nodeType), H(null));
	}, [z]), se = (0, import_react.useCallback)((e, t) => {
		e.kind !== "edge" && e.nodeType && (L((n) => ({
			...n,
			[t]: e.id
		})), I(e.nodeType), H(null), Z(e.nodeType, e.label));
	}, [Z]), ce = (0, import_react.useCallback)(() => {
		ie((e) => !e);
	}, []), $ = (0, import_react.useCallback)((e, t) => {
		if (e.preventDefault(), e.stopPropagation(), B(t), F === "edge") {
			V && V !== t && (Q(V, t), H(null), I(D));
			return;
		}
		let n = A.current?.getBoundingClientRect(), r = j.find((e) => e.id === t);
		if (!n || !r) return;
		let { x: i, y: a } = X(e.clientX, e.clientY, n);
		W({
			id: t,
			offsetX: i - r.x,
			offsetY: a - r.y,
			pointerId: e.pointerId
		});
	}, [
		F,
		Q,
		D,
		V,
		j,
		X
	]), le = (0, import_react.useCallback)((e) => {
		if (e.button !== 0) return;
		B(null), F === "edge" && (H(null), I(D));
		let t = e.pointerId;
		e.currentTarget.setPointerCapture(t), K({
			pointerId: t,
			startX: e.clientX,
			startY: e.clientY,
			startOffsetX: q.offsetX,
			startOffsetY: q.offsetY
		});
	}, [
		F,
		D,
		q
	]), ue = (0, import_react.useCallback)((e) => {
		e.preventDefault();
		let t = A.current?.getBoundingClientRect();
		if (!t) return;
		let n = e.clientX - t.left, r = e.clientY - t.top, i = -e.deltaY * .0015;
		J((e) => {
			let t = ee$1(e.scale + i, g$3, _$3);
			if (t === e.scale) return e;
			let a = (n - e.offsetX) / e.scale, o = (r - e.offsetY) / e.scale;
			return {
				scale: t,
				offsetX: n - a * t,
				offsetY: r - o * t
			};
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!U) return;
		let e = (e) => {
			if (e.pointerId !== U.pointerId) return;
			let t = A.current?.getBoundingClientRect();
			t && M((n) => n.map((n) => {
				if (n.id !== U.id) return n;
				let { x: r, y: i } = X(e.clientX, e.clientY, t), a = {
					...n,
					x: r - U.offsetX,
					y: i - U.offsetY
				};
				return C?.(a), a;
			}));
		}, t = (e) => {
			e.pointerId === U.pointerId && W(null);
		};
		return document.addEventListener("pointermove", e), document.addEventListener("pointerup", t), () => {
			document.removeEventListener("pointermove", e), document.removeEventListener("pointerup", t);
		};
	}, [
		U,
		C,
		X
	]), (0, import_react.useEffect)(() => {
		if (!G) return;
		let e = (e) => {
			if (e.pointerId !== G.pointerId) return;
			let t = e.clientX - G.startX, n = e.clientY - G.startY;
			J((e) => ({
				...e,
				offsetX: G.startOffsetX + t,
				offsetY: G.startOffsetY + n
			}));
		}, t = (e) => {
			e.pointerId === G.pointerId && (A.current?.releasePointerCapture(G.pointerId), K(null));
		};
		return document.addEventListener("pointermove", e), document.addEventListener("pointerup", t), () => {
			document.removeEventListener("pointermove", e), document.removeEventListener("pointerup", t);
		};
	}, [G]);
	let de = [
		"nabs-ui-graph",
		R ? "nabs-ui-graph--toolbox-collapsed" : "",
		e
	].filter(Boolean).join(" "), fe = z !== null, pe = F === "edge" && V ? "Select another node" : "Select node first";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: w,
		className: de,
		...ne,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-graph__canvas",
			ref: A,
			onPointerDown: le,
			onWheel: ue,
			role: "presentation",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				className: "nabs-ui-graph__canvasSvg",
				role: "presentation",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					className: "nabs-ui-graph__viewport",
					transform: ae,
					children: [N.map((e) => {
						let t = j.find((t) => t.id === e.fromId), n = j.find((t) => t.id === e.toId);
						if (!t || !n) return null;
						let r = (t.x + t.width / 2 + (n.x + n.width / 2)) / 2, i = (t.y + t.height / 2 + (n.y + n.height / 2)) / 2;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							className: "nabs-ui-graph__edge",
							x1: t.x + t.width / 2,
							y1: t.y + t.height / 2,
							x2: n.x + n.width / 2,
							y2: n.y + n.height / 2
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							className: "nabs-ui-graph__edgeLabel",
							x: r,
							y: i - 6,
							children: e.label
						})] }, e.id);
					}), j.map((e) => {
						let t = te$1(e.label, e.width), n = e.x + e.width / 2, r = e.y + e.height / 2 - (t.length - 1) * 12 / 2, i = {
							className: [
								"nabs-ui-graph__shape",
								e.type === "circle" && "nabs-ui-graph__shape--circle",
								e.type === "rectangle" && "nabs-ui-graph__shape--rectangle",
								e.type === "hexagon" && "nabs-ui-graph__shape--hexagon",
								e.type === "initiative" && "nabs-ui-graph__shape--initiative",
								e.type === "scenario" && "nabs-ui-graph__shape--scenario",
								e.type === "lifecycle" && "nabs-ui-graph__shape--lifecycle",
								e.type === "context" && "nabs-ui-graph__shape--context",
								z === e.id && "nabs-ui-graph__shape--selected"
							].filter(Boolean).join(" "),
							onPointerDown: (t) => $(t, e.id),
							role: "presentation",
							"aria-hidden": !0
						};
						if (e.type === "circle") {
							let a = e.width / 2, c = e.x + a, l = e.y + a;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								...i,
								cx: c,
								cy: l,
								r: a
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								className: "nabs-ui-graph__nodeLabel",
								x: n,
								y: r,
								children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
									x: n,
									dy: r === 0 ? 0 : 12,
									children: t
								}, `${e.id}-line-${r}`))
							})] }, e.id);
						}
						if (e.type === "scenario") {
							let a = Math.min(26, Math.round(e.width * .16)), c = [
								`${e.x + a},${e.y}`,
								`${e.x + e.width},${e.y}`,
								`${e.x + e.width - a},${e.y + e.height}`,
								`${e.x},${e.y + e.height}`
							].join(" ");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								...i,
								points: c
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								className: "nabs-ui-graph__nodeLabel",
								x: n,
								y: r,
								children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
									x: n,
									dy: r === 0 ? 0 : 12,
									children: t
								}, `${e.id}-line-${r}`))
							})] }, e.id);
						}
						if (e.type === "context") {
							let a = Math.min(24, Math.round(e.width * .14)), c = e.y + e.height - 9, l = [
								`M ${e.x} ${e.y}`,
								`H ${e.x + e.width - a}`,
								`L ${e.x + e.width} ${e.y + a}`,
								`V ${c}`,
								`Q ${e.x + e.width * .76} ${e.y + e.height + 9} ${e.x + e.width * .5} ${c}`,
								`Q ${e.x + e.width * .24} ${e.y + e.height - 18} ${e.x} ${c}`,
								"Z"
							].join(" ");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								...i,
								d: l
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								className: "nabs-ui-graph__nodeLabel",
								x: n,
								y: r,
								children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
									x: n,
									dy: r === 0 ? 0 : 12,
									children: t
								}, `${e.id}-line-${r}`))
							})] }, e.id);
						}
						if (e.type === "hexagon") {
							let a = [
								`${e.x + e.width * .25},${e.y}`,
								`${e.x + e.width * .75},${e.y}`,
								`${e.x + e.width},${e.y + e.height * .5}`,
								`${e.x + e.width * .75},${e.y + e.height}`,
								`${e.x + e.width * .25},${e.y + e.height}`,
								`${e.x},${e.y + e.height * .5}`
							].join(" ");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								...i,
								points: a
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								className: "nabs-ui-graph__nodeLabel",
								x: n,
								y: r,
								children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
									x: n,
									dy: r === 0 ? 0 : 12,
									children: t
								}, `${e.id}-line-${r}`))
							})] }, e.id);
						}
						let a = e.type === "rectangle" || e.type === "initiative" ? 14 : 4;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							...i,
							x: e.x,
							y: e.y,
							width: e.width,
							height: e.height,
							rx: a
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							className: "nabs-ui-graph__nodeLabel",
							x: n,
							y: r,
							children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
								x: n,
								dy: r === 0 ? 0 : 12,
								children: t
							}, `${e.id}-line-${r}`))
						})] }, e.id);
					})]
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(b, {
			toolboxLabel: l,
			toolsets: k,
			isCollapsed: R,
			isEdgeToolEnabled: fe,
			edgeHint: pe,
			activeToolIdsBySet: re,
			onToggleCollapse: ce,
			onToolClick: oe,
			onToolDoubleClick: se
		})]
	});
});
//#endregion
//#region node_modules/@net-advantage/nabs-ui-grid/dist/nabs-ui-grid.js
var l$6 = {
	primary: "nabs-ui-button--primary",
	secondary: "nabs-ui-button--secondary",
	ghost: "nabs-ui-button--ghost"
};
var u$5 = (0, import_react.forwardRef)(function({ children: e, className: t = "", variant: n = "primary", type: r = "button", ...i }, a) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref: a,
		className: [
			"nabs-ui-button",
			l$6[n] ?? l$6.primary,
			t
		].filter(Boolean).join(" "),
		type: r,
		...i,
		children: e
	});
});
u$5.displayName = "Button";
var d$4 = "a[href], area[href], button:not([disabled]), input:not([disabled]):not([type=\"hidden\"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex=\"-1\"])";
function f$4(e) {
	return Array.from(e.querySelectorAll(d$4)).filter((e) => !e.hasAttribute("disabled") && e.getAttribute("aria-hidden") !== "true");
}
var p$3 = (0, import_react.forwardRef)(function({ title: e, description: r, header: a, footer: o, showHeader: l = !0, showFooter: u = !0, onRequestClose: d, closeOnBackdropClick: p = !0, closeOnEscape: ee = !0, initialFocusSelector: m, dialogRole: h = "dialog", className: g = "", backdropClassName: _ = "", headerClassName: v = "", descriptionClassName: te = "", contentClassName: y = "", footerClassName: b = "", onKeyDown: x, tabIndex: ne, children: re, ...ie }, ae) {
	let S = (0, import_react.useRef)(null), C = (0, import_react.useRef)(null), oe = `nabs-ui-dialog-title-${(0, import_react.useId)().replace(/:/g, "")}`, se = `nabs-ui-dialog-description-${(0, import_react.useId)().replace(/:/g, "")}`, w = ie["aria-labelledby"], ce = ie["aria-describedby"], T = !a && !!e, E = !!r, le = l && (!!a || T), ue = u && o != null, de = w ?? (T ? oe : void 0), D = ce ?? (E ? se : void 0), fe = ["nabs-ui-dialog__backdrop", _].filter(Boolean).join(" "), pe = ["nabs-ui-dialog", g].filter(Boolean).join(" "), me = ["nabs-ui-dialog__header", v].filter(Boolean).join(" "), he = ["nabs-ui-dialog__description", te].filter(Boolean).join(" "), ge = ["nabs-ui-dialog__content", y].filter(Boolean).join(" "), _e = ["nabs-ui-dialog__footer", b].filter(Boolean).join(" ");
	return (0, import_react.useEffect)(() => {
		let e = S.current;
		if (!e) return;
		if (C.current = document.activeElement instanceof HTMLElement ? document.activeElement : null, m) try {
			let t = e.querySelector(m);
			if (t) return t.focus(), () => {
				C.current?.focus(), C.current = null;
			};
		} catch {}
		let t = f$4(e);
		return t.length > 0 ? t[0].focus() : e.focus(), () => {
			C.current?.focus(), C.current = null;
		};
	}, [m]), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: fe,
		role: "presentation",
		onClick: (e) => {
			!p || e.target !== e.currentTarget || d?.();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			ref: (e) => {
				if (S.current = e, typeof ae == "function") {
					ae(e);
					return;
				}
				ae && (ae.current = e);
			},
			className: pe,
			role: h,
			"aria-modal": "true",
			"aria-labelledby": de,
			"aria-describedby": D,
			tabIndex: ne ?? -1,
			onKeyDown: (e) => {
				if (x?.(e), e.defaultPrevented) return;
				if (e.key === "Escape" && ee) {
					e.preventDefault(), d?.();
					return;
				}
				if (e.key !== "Tab" || !S.current) return;
				let t = f$4(S.current);
				if (t.length === 0) {
					e.preventDefault(), S.current.focus();
					return;
				}
				let n = document.activeElement, r = t[0], i = t[t.length - 1];
				if (e.shiftKey) {
					(!n || n === r || !S.current.contains(n)) && (e.preventDefault(), i.focus());
					return;
				}
				(!n || n === i || !S.current.contains(n)) && (e.preventDefault(), r.focus());
			},
			...ie,
			children: [
				le ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: me,
					children: a ?? (T ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "nabs-ui-dialog__title",
						id: oe,
						children: e
					}) : null)
				}) : null,
				E ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: se,
					className: he,
					children: r
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: ge,
					children: re
				}),
				ue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: _e,
					children: o
				}) : null
			]
		})
	});
});
p$3.displayName = "Dialog";
var ee = async (e) => {
	let t = await fetch(e);
	if (!t.ok) throw Error(`Failed request for ${e}: ${t.status}`);
	return t.json();
};
function m$2(e) {
	if (!e || !Array.isArray(e.columns)) return {
		idField: "id",
		pageSize: 10,
		pageSizeOptions: [
			10,
			20,
			50
		],
		selectionMode: "multiple",
		columns: []
	};
	let t = e.columns.map((e) => ({
		type: "string",
		sortable: !0,
		filterable: !0,
		groupable: !1,
		editable: !1,
		aggregate: "none",
		format: "plain",
		...e
	}));
	return {
		idField: e.idField ?? "id",
		pageSize: e.pageSize ?? 10,
		pageSizeOptions: e.pageSizeOptions?.length ? e.pageSizeOptions : [
			10,
			20,
			50
		],
		selectionMode: e.selectionMode ?? "multiple",
		defaultGroupBy: e.defaultGroupBy,
		defaultSort: e.defaultSort,
		footer: {
			showColumnAggregates: e.footer?.showColumnAggregates ?? !0,
			rowAggregates: e.footer?.rowAggregates?.length ? e.footer.rowAggregates : [
				"filteredRows",
				"pagedRows",
				"selectedRows",
				"groupCount"
			]
		},
		columns: t
	};
}
function h$3(e, t) {
	return t === "date" ? "date" : t === "date-time" ? "datetime" : e === "number" || e === "integer" ? "number" : e === "boolean" ? "boolean" : "string";
}
function g$2(e) {
	return e === "date" ? "date" : e === "date-time" ? "datetime" : e === "currency" ? "currency" : e === "percent" ? "percent" : "plain";
}
function _$2(e) {
	if (e?.length) return e.map((e) => ({
		label: e === null ? "(empty)" : String(e),
		value: e
	}));
}
function v$2(e) {
	if (!e?.properties) return m$2(void 0);
	let t = new Set(e.required ?? []), n = e["x-grid"], r = Object.entries(e.properties).map(([e, n]) => {
		let r = n["x-grid"], i = h$3(n.type, n.format), a = g$2(n.format), o = r?.editor ?? (i === "boolean" ? "checkbox" : i === "number" ? "number" : i === "date" ? "date" : void 0);
		return {
			key: r?.key ?? e,
			label: n.title ?? e,
			type: i,
			sortable: r?.sortable ?? !0,
			filterable: r?.filterable ?? !0,
			groupable: r?.groupable ?? !1,
			editable: r?.editable ?? t.has(e),
			editor: o,
			aggregate: r?.aggregate ?? "none",
			width: r?.width,
			minWidth: r?.minWidth,
			options: r?.options ?? _$2(n.enum),
			format: r?.format ?? a
		};
	});
	return m$2({
		idField: n?.idField,
		pageSize: n?.pageSize,
		pageSizeOptions: n?.pageSizeOptions,
		selectionMode: n?.selectionMode,
		defaultGroupBy: n?.defaultGroupBy,
		defaultSort: n?.defaultSort,
		footer: n?.footer,
		columns: r
	});
}
function te(e) {
	if (e) {
		if (typeof e == "string") {
			let t = JSON.parse(e);
			if (!t || typeof t != "object") throw Error("Invalid jsonIsland: expected a JSON object.");
			return t;
		}
		return e;
	}
}
async function y$2(e, t) {
	if (e !== void 0) return typeof e == "function" ? e() : typeof e == "string" ? await (t ?? ee)(e) : e;
}
function b$3(...e) {
	return e.filter(Boolean).join(" ");
}
function x$1(e, t, n) {
	let r = e[t];
	return r == null ? `row-${n}` : String(r);
}
function ne(e, t, n, r) {
	let i = n.trim().toLowerCase();
	return e.filter((e) => i.length === 0 || t.some((t) => w$1(e[t.key]).toLowerCase().includes(i)) ? t.every((t) => {
		let n = (r[t.key] ?? "").trim().toLowerCase();
		if (!n) return !0;
		let i = e[t.key];
		if (t.type === "boolean") {
			if (n === "true") return i === !0;
			if (n === "false") return i === !1;
		}
		return w$1(i).toLowerCase().includes(n);
	}) : !1);
}
function re(e, t, n) {
	if (!t) return e;
	let r = n.find((e) => e.key === t.columnKey);
	if (!r || !r.sortable) return e;
	let i = t.direction === "asc" ? 1 : -1;
	return [...e].sort((e, n) => {
		let a = e[t.columnKey], o = n[t.columnKey];
		return se(a, o, r.type) * i;
	});
}
function ie(e, t, n, r) {
	if (!n) return e.map((e, t) => ({
		kind: "data",
		key: `data-${t}`,
		row: e,
		rowIndex: t
	}));
	let i = t.find((e) => e.key === n);
	if (!i || !i.groupable) return e.map((e, t) => ({
		kind: "data",
		key: `data-${t}`,
		row: e,
		rowIndex: t
	}));
	let a = /* @__PURE__ */ new Map();
	e.forEach((e) => {
		let t = w$1(e[n]) || "(empty)", r = a.get(t);
		if (r) {
			r.push(e);
			return;
		}
		a.set(t, [e]);
	});
	let o = [];
	return Array.from(a.entries()).forEach(([e, t]) => {
		let n = `group-${e}`;
		o.push({
			kind: "group",
			key: n,
			groupValue: e,
			groupSize: t.length,
			groupRows: t
		}), r.has(e) && t.forEach((t, r) => {
			o.push({
				kind: "data",
				key: `${n}-row-${r}`,
				row: t,
				rowIndex: r,
				groupValue: e
			});
		});
	}), o;
}
function ae(e, t, n) {
	if (t <= 0) return e;
	let r = Math.max(0, n) * t;
	return e.slice(r, r + t);
}
function S$2(e, t) {
	if (e == null) return "";
	if (t.format === "currency" && typeof e == "number") return new Intl.NumberFormat(void 0, {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 2
	}).format(e);
	if (t.format === "percent" && typeof e == "number") return new Intl.NumberFormat(void 0, {
		style: "percent",
		maximumFractionDigits: 2
	}).format(e);
	if ((t.format === "date" || t.type === "date") && (typeof e == "string" || e instanceof Date)) {
		let t = new Date(e);
		if (!Number.isNaN(t.getTime())) return new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }).format(t);
	}
	if ((t.format === "datetime" || t.type === "datetime") && (typeof e == "string" || e instanceof Date)) {
		let t = new Date(e);
		if (!Number.isNaN(t.getTime())) return new Intl.DateTimeFormat(void 0, {
			dateStyle: "medium",
			timeStyle: "short"
		}).format(t);
	}
	return w$1(e);
}
function C$1(e, t) {
	let n = t.aggregate ?? "none";
	if (n === "none") return {
		type: "none",
		value: null
	};
	let r = e.map((e) => e[t.key]).filter((e) => typeof e == "number" && Number.isFinite(e));
	return n === "count" ? {
		type: "count",
		value: e.length
	} : r.length === 0 ? {
		type: n,
		value: null
	} : n === "sum" ? {
		type: "sum",
		value: r.reduce((e, t) => e + t, 0)
	} : n === "avg" ? {
		type: "avg",
		value: r.reduce((e, t) => e + t, 0) / r.length
	} : n === "min" ? {
		type: "min",
		value: Math.min(...r)
	} : n === "max" ? {
		type: "max",
		value: Math.max(...r)
	} : {
		type: n,
		value: null
	};
}
function oe(e) {
	return e.type === "none" ? "" : e.value === null || e.value === void 0 ? "-" : e.type === "count" ? `${Math.round(e.value)}` : new Intl.NumberFormat(void 0, {
		minimumFractionDigits: 0,
		maximumFractionDigits: 2
	}).format(e.value);
}
function se(e, t, n) {
	if (e === t) return 0;
	if (e == null) return -1;
	if (t == null) return 1;
	if (n === "number") {
		let n = Number(e), r = Number(t);
		if (Number.isFinite(n) && Number.isFinite(r)) return n - r;
	}
	if (n === "date" || n === "datetime") {
		let n = new Date(String(e)).getTime(), r = new Date(String(t)).getTime();
		if (!Number.isNaN(n) && !Number.isNaN(r)) return n - r;
	}
	return n === "boolean" ? !!e - +!!t : w$1(e).localeCompare(w$1(t));
}
function w$1(e) {
	if (e == null) return "";
	if (typeof e == "string") return e;
	if (typeof e == "number" || typeof e == "boolean") return String(e);
	if (e instanceof Date) return e.toISOString();
	if (Array.isArray(e)) return e.map((e) => w$1(e)).join(", ");
	if (typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return "[object]";
	}
	return String(e);
}
function ce(e, t) {
	return t.sortable ? !e || e.columnKey !== t.key ? {
		columnKey: t.key,
		direction: "asc"
	} : e.direction === "asc" ? {
		columnKey: t.key,
		direction: "desc"
	} : null : e;
}
function T$1(e, t) {
	if (e == null) return "";
	if (t === "date" || t === "datetime") {
		let n = new Date(String(e));
		return Number.isNaN(n.getTime()) ? "" : t === "date" ? n.toISOString().slice(0, 10) : n.toISOString().slice(0, 16);
	}
	return w$1(e);
}
function E$1(e, t) {
	if (t.editor === "checkbox" || t.type === "boolean") return e === "true";
	if (t.editor === "number" || t.type === "number") {
		let t = Number(e);
		return Number.isFinite(t) ? t : null;
	}
	return t.type === "date" || t.type === "datetime" ? e || null : e;
}
function le(e) {
	let t = e.trim().toLowerCase();
	return t === "true" || t === "false" ? t : "";
}
function ue(e) {
	return e === "none" ? "" : e.toUpperCase();
}
function de({ columns: e, draft: n, rowId: r, onCancel: i, onSave: l }) {
	let [d, f] = (0, import_react.useState)(n);
	return (0, import_react.useEffect)(() => {
		f(n);
	}, [n]), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(p$3, {
		title: `Edit row ${r}`,
		"aria-label": `Edit row ${r}`,
		onRequestClose: i,
		className: "nabs-ui-grid__editDialog",
		contentClassName: "nabs-ui-grid__editDialogContent",
		footerClassName: "nabs-ui-grid__editDialogFooter",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$5, {
			variant: "secondary",
			onClick: i,
			children: "Cancel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$5, {
			onClick: () => l(d),
			children: "Save"
		})] }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-grid__dialogBody",
			children: e.filter((e) => e.editable).map((e) => {
				let t = T$1(d[e.key], e.type);
				return e.editor === "checkbox" || e.type === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nabs-ui-grid__field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "nabs-ui-grid__input",
						value: t === "true" ? "true" : "false",
						onChange: (t) => {
							let n = t.target.value === "true";
							f((t) => ({
								...t,
								[e.key]: n
							}));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "true",
							children: "True"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "false",
							children: "False"
						})]
					})]
				}, e.key) : e.editor === "select" && e.options?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nabs-ui-grid__field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "nabs-ui-grid__input",
						value: t,
						onChange: (t) => {
							let n = E$1(t.target.value, e);
							f((t) => ({
								...t,
								[e.key]: n
							}));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "(empty)"
						}), e.options.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: String(e.value),
							children: e.label
						}, String(e.value)))]
					})]
				}, e.key) : e.editor === "textarea" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nabs-ui-grid__field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "nabs-ui-grid__input nabs-ui-grid__input--textarea",
						value: t,
						onChange: (t) => {
							let n = E$1(t.target.value, e);
							f((t) => ({
								...t,
								[e.key]: n
							}));
						}
					})]
				}, e.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nabs-ui-grid__field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "nabs-ui-grid__input",
						type: e.editor === "number" || e.type === "number" ? "number" : e.type === "date" ? "date" : "text",
						value: t,
						onChange: (t) => {
							let n = E$1(t.target.value, e);
							f((t) => ({
								...t,
								[e.key]: n
							}));
						}
					})]
				}, e.key);
			})
		})
	});
}
var D = (0, import_react.forwardRef)(function({ mode: e, schema: n, jsonSchema: l, jsonIsland: u, data: d, schemaSource: f, jsonSchemaSource: p, jsonIslandSource: ee, dataSource: h, serverDataSource: g, fetcher: _, height: se = 440, rowHeight: w = 40, overscan: D = 6, editMode: fe = "both", searchable: pe = !0, filterable: me = !0, groupable: he = !0, pageable: ge = !0, selectable: _e = !0, className: ve = "", onDataChange: ye, onSelectionChange: be, onSchemaLoaded: xe, onDataLoaded: Se, onError: Ce, valueFormatters: we, ...Te }, Ee) {
	let [O, k] = (0, import_react.useState)(() => n ? m$2(n) : l ? v$2(l) : m$2(void 0)), [De, Oe] = (0, import_react.useState)(e ?? "client"), [A, j] = (0, import_react.useState)(d ?? []), [ke, Ae] = (0, import_react.useState)(void 0), [je, Me] = (0, import_react.useState)(void 0), [Ne, Pe] = (0, import_react.useState)(void 0), [Fe, Ie] = (0, import_react.useState)(!1), [Le, Re] = (0, import_react.useState)(""), [M, ze] = (0, import_react.useState)(""), [N, Be] = (0, import_react.useState)({}), [P, F] = (0, import_react.useState)(null), [I, L] = (0, import_react.useState)(null), [R, Ve] = (0, import_react.useState)(/* @__PURE__ */ new Set()), [z, B] = (0, import_react.useState)(0), [V, H] = (0, import_react.useState)(O.pageSize ?? 10), [He, Ue] = (0, import_react.useState)(/* @__PURE__ */ new Set()), [We, Ge] = (0, import_react.useState)(null), [Ke, U] = (0, import_react.useState)(null), [qe, Je] = (0, import_react.useState)(null), [Ye, Xe] = (0, import_react.useState)(0), [Ze, Qe] = (0, import_react.useState)(0), $e = (0, import_react.useRef)(be), et = (0, import_react.useRef)(g), W = ke ?? je;
	(0, import_react.useEffect)(() => {
		try {
			let t = te(u);
			Ae(t), !d && t?.data && j(t.data), Oe(e ?? t?.mode ?? "client");
		} catch (t) {
			let n = t instanceof Error ? t : /* @__PURE__ */ Error("Invalid jsonIsland value.");
			Re(n.message), Ce?.(n), Ae(void 0), Oe(e ?? "client");
		}
	}, [
		d,
		u,
		e
	]), (0, import_react.useEffect)(() => {
		if (n) {
			k(m$2(n));
			return;
		}
		if (l) {
			k(v$2(l));
			return;
		}
		if (W?.schema) {
			k(m$2(W.schema));
			return;
		}
		if (W?.jsonSchema) {
			k(v$2(W.jsonSchema));
			return;
		}
		k(m$2(void 0));
	}, [
		W,
		l,
		n
	]), (0, import_react.useEffect)(() => {
		d && (j(d), Pe(void 0));
	}, [d]), (0, import_react.useEffect)(() => {
		let e = n ? m$2(n) : l ? v$2(l) : W?.schema ? m$2(W.schema) : v$2(W?.jsonSchema);
		H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && (L(e.defaultGroupBy), Ve((t) => {
			let n = new Set(t);
			return n.add(e.defaultGroupBy), n;
		}));
	}, [
		W,
		l,
		n
	]), (0, import_react.useEffect)(() => {
		let t = !1;
		return (async () => {
			if (!(!f && !p && !ee && !h)) try {
				Ie(!0), Re("");
				let [n, r, i, a] = await Promise.all([
					y$2(f, _),
					y$2(p, _),
					y$2(ee, _),
					y$2(h, _)
				]), o = te(i);
				if (Me(o), t) return;
				if (n) {
					let e = m$2(n);
					k(e), H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && L(e.defaultGroupBy), xe?.(e);
				} else if (r) {
					let e = v$2(r);
					k(e), H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && L(e.defaultGroupBy), xe?.(e);
				} else if (o?.schema) {
					let e = m$2(o.schema);
					k(e), H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && L(e.defaultGroupBy), xe?.(e);
				} else if (o?.jsonSchema) {
					let e = v$2(o.jsonSchema);
					k(e), H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && L(e.defaultGroupBy), xe?.(e);
				}
				Array.isArray(a) ? (j(a), Pe(void 0), Se?.(a)) : o?.data && !d && (j(o.data), Pe(void 0), Se?.(o.data)), !e && o?.mode && Oe(o.mode);
			} catch (e) {
				if (t) return;
				let n = e instanceof Error ? e : /* @__PURE__ */ Error("Failed to load grid sources.");
				Re(n.message), Ce?.(n);
			} finally {
				t || Ie(!1);
			}
		})(), () => {
			t = !0;
		};
	}, [
		d,
		h,
		_,
		ee,
		p,
		e,
		f
	]), (0, import_react.useEffect)(() => {
		$e.current = be;
	}, [be]), (0, import_react.useEffect)(() => {
		et.current = g;
	}, [g]), (0, import_react.useEffect)(() => {
		if (De !== "server" || !g) return;
		let e = !1, t = {
			pageIndex: z,
			pageSize: V,
			searchTerm: M,
			sort: P,
			groupBy: I,
			filters: N
		};
		return (async () => {
			try {
				let n = et.current;
				if (!n) return;
				Ie(!0), Re("");
				let r = await n(t, O);
				if (e) return;
				if (Array.isArray(r)) {
					j(r), Pe(r.length), Se?.(r);
					return;
				}
				j(r.rows), Pe(r.totalCount ?? r.rows.length), Se?.(r.rows);
			} catch (t) {
				if (e) return;
				let n = t instanceof Error ? t : /* @__PURE__ */ Error("Failed to load server data.");
				Re(n.message), Ce?.(n);
			} finally {
				e || Ie(!1);
			}
		})(), () => {
			e = !0;
		};
	}, [
		N,
		I,
		z,
		V,
		De,
		O,
		M,
		P
	]);
	let G = O.columns, K = O.idField ?? "id", q = _e ? O.selectionMode ?? "multiple" : "none", tt = pe, nt = me, rt = he, it = ge, at = fe === "inline" || fe === "both", ot = fe === "dialog" || fe === "both", J = De === "server", Y = (0, import_react.useMemo)(() => J ? A : ne(A, G, tt ? M : "", nt ? N : {}), [
		nt,
		tt,
		N,
		G,
		J,
		A,
		M
	]), X = (0, import_react.useMemo)(() => J ? Y : re(Y, P, G), [
		G,
		Y,
		J,
		P
	]), st = J ? Ne ?? X.length : X.length, Z = Math.max(1, Math.ceil(st / Math.max(1, V))), Q = Math.min(z, Z - 1);
	(0, import_react.useEffect)(() => {
		Q !== z && B(Q);
	}, [Q, z]);
	let ct = (0, import_react.useMemo)(() => J ? X : it ? ae(X, V, Q) : X, [
		it,
		Q,
		J,
		V,
		X
	]), lt = (0, import_react.useMemo)(() => {
		let e = /* @__PURE__ */ new Set();
		return I && ct.forEach((t) => {
			let n = t[I];
			e.add(n == null || n === "" ? "(empty)" : String(n));
		}), e;
	}, [I, ct]);
	(0, import_react.useEffect)(() => {
		I && R.size === 0 && lt.size > 0 && Ve(lt);
	}, [
		lt,
		R.size,
		I
	]);
	let $ = (0, import_react.useMemo)(() => ie(ct, G, rt ? I : null, R), [
		rt,
		G,
		R,
		I,
		ct
	]), ut = $.filter((e) => e.kind === "data").length, dt = Math.max(1, ut + $.filter((e) => e.kind === "group").length) * w, ft = Math.ceil(se / w) + D * 2, pt = Math.max(0, Math.floor(Ye / w) - D), mt = Math.min($.length, pt + ft), ht = $.slice(pt, mt), gt = pt * w, _t = Math.max(0, dt - gt - ht.length * w), vt = (0, import_react.useMemo)(() => {
		let e = /* @__PURE__ */ new Map();
		return A.forEach((t, n) => {
			e.set(x$1(t, K, n), t);
		}), Array.from(He.values()).map((t) => e.get(t)).filter((e) => !!e);
	}, [
		K,
		A,
		He
	]);
	(0, import_react.useEffect)(() => {
		$e.current?.(vt);
	}, [vt]);
	let yt = (0, import_react.useMemo)(() => {
		let e = /* @__PURE__ */ new Map();
		return G.forEach((t) => {
			let n = C$1(Y, t);
			n.type !== "none" && e.set(t.key, `${ue(n.type)} ${oe(n)}`);
		}), e;
	}, [G, Y]), bt = (0, import_react.useMemo)(() => $.filter((e) => e.kind === "data" && !!e.row).map((e) => x$1(e.row, K, e.rowIndex ?? 0)), [$, K]), xt = q !== "none" && bt.length > 0 && bt.every((e) => He.has(e));
	function St(e) {
		j(e), ye?.(e);
	}
	function Ct(e, t) {
		Be((n) => ({
			...n,
			[e]: t
		})), B(0);
	}
	function wt(e) {
		F((t) => ce(t, e)), B(0);
	}
	function Tt(e, t, n) {
		let r = we?.[n.key], i = e[n.key];
		return r ? r({
			row: e,
			rowIndex: t,
			column: n,
			value: i
		}) : S$2(i, n);
	}
	function Et(e, t) {
		let n = x$1(e, K, t);
		Ge(n), U({ ...e });
	}
	function Dt(e) {
		Ke && (St(A.map((t, n) => x$1(t, K, n) === e ? { ...Ke } : t)), Ge(null), U(null));
	}
	function Ot() {
		Ge(null), U(null);
	}
	function kt(e, t) {
		let n = x$1(e, K, t);
		Je({
			rowId: n,
			draft: { ...e }
		});
	}
	function At(e, t) {
		St(A.map((n, r) => x$1(n, K, r) === e ? { ...t } : n)), Je(null);
	}
	function jt(e) {
		Ve((t) => {
			let n = new Set(t);
			return n.has(e) ? n.delete(e) : n.add(e), n;
		});
	}
	function Mt(e, t, n) {
		if (q === "none") return;
		let r = x$1(e, K, t);
		Ue((e) => {
			if (q === "single") return n ? /* @__PURE__ */ new Set([r]) : /* @__PURE__ */ new Set();
			let t = new Set(e);
			return n ? t.add(r) : t.delete(r), t;
		});
	}
	function Nt(e) {
		if (q !== "none") {
			if (q === "single") {
				let t = $.find((e) => e.kind === "data" && e.row);
				if (!t || !t.row) {
					Ue(/* @__PURE__ */ new Set());
					return;
				}
				Ue(e ? /* @__PURE__ */ new Set([x$1(t.row, K, t.rowIndex ?? 0)]) : /* @__PURE__ */ new Set());
				return;
			}
			Ue((t) => {
				let n = new Set(t);
				return bt.forEach((t) => {
					e ? n.add(t) : n.delete(t);
				}), n;
			});
		}
	}
	let Pt = b$3("nabs-ui-grid", ve), Ft = G.length + (q === "none" ? 0 : 1) + 1, It = G.filter((e) => e.groupable), Lt = O.footer?.showColumnAggregates !== !1, Rt = J ? st : Y.length, zt = (O.footer?.rowAggregates ?? []).map((e) => e === "filteredRows" ? `Filtered rows ${Rt}` : e === "pagedRows" ? `Page rows ${ct.length}` : e === "selectedRows" ? `Selected rows ${vt.length}` : e === "groupCount" ? `Groups ${I ? $.filter((e) => e.kind === "group").length : 0}` : "").filter(Boolean), Bt = Ze === 0 ? void 0 : { transform: `translateX(${-Ze}px)` };
	function Vt() {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("colgroup", { children: [
			q === "none" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "nabs-ui-grid__col nabs-ui-grid__col--selection" }),
			G.map((e) => {
				let t = e.width, n = e.minWidth;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", {
					className: "nabs-ui-grid__col",
					style: {
						width: t === void 0 ? void 0 : typeof t == "number" ? `${t}px` : t,
						minWidth: n === void 0 ? void 0 : `${n}px`
					}
				}, e.key);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "nabs-ui-grid__col nabs-ui-grid__col--actions" })
		] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: Ee,
		className: Pt,
		...Te,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-grid__toolbar",
				children: [
					tt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "nabs-ui-grid__input nabs-ui-grid__search",
						type: "search",
						value: M,
						placeholder: "Find rows...",
						onChange: (e) => {
							ze(e.target.value), B(0);
						}
					}) : null,
					rt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "nabs-ui-grid__groupControl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Group by" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "nabs-ui-grid__input",
							value: I ?? "",
							onChange: (e) => {
								let t = e.target.value || null;
								L(t), Ve(/* @__PURE__ */ new Set());
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "None"
							}), It.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: e.key,
								children: e.label
							}, e.key))]
						})]
					}) : null,
					it ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "nabs-ui-grid__groupControl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Page size" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "nabs-ui-grid__input",
							value: String(V),
							onChange: (e) => {
								let t = Number(e.target.value);
								H(Number.isFinite(t) && t > 0 ? t : 10), B(0);
							},
							children: (O.pageSizeOptions ?? [
								10,
								20,
								50
							]).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: String(e),
								children: e
							}, e))
						})]
					}) : null
				]
			}),
			Le ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-grid__status",
				children: Le
			}) : null,
			Fe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-grid__status",
				children: "Loading data..."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-grid__surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "nabs-ui-grid__headerViewport",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "nabs-ui-grid__table",
							style: Bt,
							children: [Vt(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "nabs-ui-grid__head",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									q === "none" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--head nabs-ui-grid__cell--selection",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: xt,
											onChange: (e) => Nt(e.target.checked),
											"aria-label": "Select visible rows"
										})
									}),
									G.map((e) => {
										let t = P?.columnKey === e.key ? ` (${P.direction})` : "", n = !!N[e.key];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "nabs-ui-grid__cell nabs-ui-grid__cell--head",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "nabs-ui-grid__headCell",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													className: "nabs-ui-grid__sortButton",
													type: "button",
													onClick: () => wt(e),
													disabled: !e.sortable,
													"aria-label": `${e.label}${t}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), e.sortable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: P?.columnKey === e.key ? P.direction : "-" }) : null]
												}), nt && e.filterable ? e.type === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													className: b$3("nabs-ui-grid__input", n ? "nabs-ui-grid__input--active" : ""),
													value: le(N[e.key] ?? ""),
													onChange: (t) => Ct(e.key, t.target.value),
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "",
															children: "All"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "true",
															children: "True"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "false",
															children: "False"
														})
													]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													className: b$3("nabs-ui-grid__input", n ? "nabs-ui-grid__input--active" : ""),
													type: "text",
													value: N[e.key] ?? "",
													placeholder: "Filter",
													onChange: (t) => Ct(e.key, t.target.value)
												}) : null]
											})
										}, e.key);
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--head nabs-ui-grid__cell--actions",
										children: "Actions"
									})
								] })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "nabs-ui-grid__viewport",
						style: { height: `${se}px` },
						onScroll: (e) => {
							let t = e.target;
							Xe(t.scrollTop), Qe(t.scrollLeft);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "nabs-ui-grid__table",
							children: [Vt(), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
								gt > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "nabs-ui-grid__spacer",
									style: { height: `${gt}px` },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { colSpan: Ft })
								}) : null,
								ht.map((e, t) => {
									if (e.kind === "group") {
										let t = e.groupValue ?? "(empty)", n = R.has(t);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
											className: "nabs-ui-grid__groupRow",
											style: { height: `${w}px` },
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: Ft,
												className: "nabs-ui-grid__groupCell",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													className: "nabs-ui-grid__groupToggle",
													type: "button",
													onClick: () => jt(t),
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: n ? "Hide" : "Show" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [e.groupSize ?? 0, " rows"] })
													]
												})
											})
										}, e.key);
									}
									if (!e.row) return null;
									let n = e.row, r = e.rowIndex ?? t, i = x$1(n, K, r), a = He.has(i), l = We === i;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: b$3("nabs-ui-grid__dataRow", a ? "nabs-ui-grid__dataRow--selected" : ""),
										style: { height: `${w}px` },
										children: [
											q === "none" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "nabs-ui-grid__cell nabs-ui-grid__cell--selection",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "checkbox",
													checked: a,
													onChange: (e) => Mt(n, r, e.target.checked),
													"aria-label": `Select row ${i}`
												})
											}),
											G.map((e) => {
												let t = T$1((l ? Ke : n)?.[e.key], e.type);
												return l && e.editable ? e.editor === "checkbox" || e.type === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
														className: "nabs-ui-grid__input",
														value: t === "true" ? "true" : "false",
														onChange: (t) => {
															let n = t.target.value === "true";
															U((t) => ({
																...t ?? {},
																[e.key]: n
															}));
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "true",
															children: "True"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "false",
															children: "False"
														})]
													})
												}, e.key) : e.editor === "select" && e.options?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
														className: "nabs-ui-grid__input",
														value: t,
														onChange: (t) => {
															let n = E$1(t.target.value, e);
															U((t) => ({
																...t ?? {},
																[e.key]: n
															}));
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "",
															children: "(empty)"
														}), e.options.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: String(e.value),
															children: e.label
														}, String(e.value)))]
													})
												}, e.key) : e.editor === "textarea" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
														className: "nabs-ui-grid__input nabs-ui-grid__input--textarea",
														value: t,
														onChange: (t) => {
															let n = E$1(t.target.value, e);
															U((t) => ({
																...t ?? {},
																[e.key]: n
															}));
														}
													})
												}, e.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														className: "nabs-ui-grid__input",
														type: e.editor === "number" || e.type === "number" ? "number" : e.type === "date" ? "date" : "text",
														value: t,
														onChange: (t) => {
															let n = E$1(t.target.value, e);
															U((t) => ({
																...t ?? {},
																[e.key]: n
															}));
														}
													})
												}, e.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													title: S$2(n[e.key], e),
													children: Tt(n, r, e)
												}, e.key);
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "nabs-ui-grid__cell nabs-ui-grid__cell--actions",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "nabs-ui-grid__actionStack",
													children: [at ? l ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "nabs-ui-grid__button nabs-ui-grid__button--primary",
														type: "button",
														onClick: () => Dt(i),
														children: "Save"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "nabs-ui-grid__button",
														type: "button",
														onClick: Ot,
														children: "Cancel"
													})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "nabs-ui-grid__button",
														type: "button",
														onClick: () => Et(n, r),
														children: "Inline"
													}) : null, ot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "nabs-ui-grid__button",
														type: "button",
														onClick: () => kt(n, r),
														children: "Dialog"
													}) : null]
												})
											})
										]
									}, e.key);
								}),
								_t > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "nabs-ui-grid__spacer",
									style: { height: `${_t}px` },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { colSpan: Ft })
								}) : null
							] })]
						})
					}),
					Lt || zt.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "nabs-ui-grid__footer",
						children: [Lt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "nabs-ui-grid__footerSection nabs-ui-grid__footerSection--columns",
							"aria-label": "Column aggregates",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "nabs-ui-grid__footerSectionHeader",
								children: "Column aggregates"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "nabs-ui-grid__table",
								style: Bt,
								children: [Vt(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									q === "none" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--foot",
										children: vt.length
									}),
									G.map((e, t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--foot",
										children: [
											t === 0 ? `Rows ${Rt}` : "",
											t === 0 && yt.has(e.key) ? " | " : "",
											yt.get(e.key) ?? ""
										]
									}, e.key)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--foot",
										children: ["Selected ", vt.length]
									})
								] }) })]
							})]
						}) : null, zt.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "nabs-ui-grid__footerSection nabs-ui-grid__footerSection--rows",
							"aria-label": "Row aggregates",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "nabs-ui-grid__footerSectionHeader",
								children: "Row aggregates"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "nabs-ui-grid__cell nabs-ui-grid__cell--foot",
								children: zt.join(" | ")
							})]
						}) : null]
					}) : null
				]
			}),
			it ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-grid__pager",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nabs-ui-grid__button",
						type: "button",
						onClick: () => B(0),
						disabled: Q === 0,
						children: "First"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nabs-ui-grid__button",
						type: "button",
						onClick: () => B((e) => Math.max(0, e - 1)),
						disabled: Q === 0,
						children: "Prev"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Page ",
						Q + 1,
						" / ",
						Z
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nabs-ui-grid__button",
						type: "button",
						onClick: () => B((e) => Math.min(Z - 1, e + 1)),
						disabled: Q >= Z - 1,
						children: "Next"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nabs-ui-grid__button",
						type: "button",
						onClick: () => B(Z - 1),
						disabled: Q >= Z - 1,
						children: "Last"
					})
				]
			}) : null,
			qe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(de, {
				columns: G,
				draft: qe.draft,
				rowId: qe.rowId,
				onCancel: () => Je(null),
				onSave: (e) => At(qe.rowId, e)
			}) : null
		]
	});
});
D.displayName = "Grid";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-markdown/dist/nabs-ui-markdown.js
var c$5 = {
	left: "nabs-ui-toolbar__content--label-left",
	right: "nabs-ui-toolbar__content--label-right",
	top: "nabs-ui-toolbar__content--label-top",
	bottom: "nabs-ui-toolbar__content--label-bottom"
};
function l$5(e) {
	return e || "right";
}
var u$4 = (0, import_react.forwardRef)(function({ items: e, activeItemId: t, className: n = "", buttonClassName: r = "", iconClassName: i = "", labelClassName: a = "", onItemSelect: u, ...d }, f) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: f,
		className: ["nabs-ui-toolbar", n].filter(Boolean).join(" "),
		role: "toolbar",
		...d,
		children: e.map((e) => {
			let n = e.icon, d = !!e.label, f = e.id === t || e.pressed === !0, p = ["nabs-ui-toolbar__content", c$5[l$5(e.labelPosition)]].filter(Boolean).join(" "), m = [
				"nabs-ui-toolbar__button",
				f ? "nabs-ui-toolbar__button--active" : "",
				d ? "" : "nabs-ui-toolbar__button--icon-only",
				r
			].filter(Boolean).join(" "), h = ["nabs-ui-toolbar__icon", i].filter(Boolean).join(" "), g = ["nabs-ui-toolbar__label", a].filter(Boolean).join(" "), _ = typeof e.label == "string" ? e.label : e.title;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: m,
				disabled: e.disabled,
				title: e.title,
				"aria-label": _,
				"aria-pressed": typeof e.pressed == "boolean" ? e.pressed : void 0,
				onClick: (t) => {
					u?.({
						itemId: e.id,
						item: e,
						event: t
					});
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: p,
					children: [n ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(n, {
						className: h,
						"aria-hidden": "true",
						focusable: "false"
					}) : null, e.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: g,
						children: e.label
					}) : null]
				})
			}, e.id);
		})
	});
});
u$4.displayName = "Toolbar";
function d$3({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M8.625 9.75a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375m-13.5 3.01c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.184-4.183a1.14 1.14 0 0 1 .778-.332 48.294 48.294 0 0 0 5.83-.498c1.585-.233 2.708-1.626 2.708-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z"
	}));
}
var f$3 = /*#__PURE__*/ import_react.forwardRef(d$3);
function p$2({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M17.25 6.75 22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3-4.5 16.5"
	}));
}
var m$1 = /*#__PURE__*/ import_react.forwardRef(p$2);
function h$2({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z"
	}));
}
var g$1 = /*#__PURE__*/ import_react.forwardRef(h$2);
function _$1({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"
	}), /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
	}));
}
var v$1 = /*#__PURE__*/ import_react.forwardRef(_$1);
function y$1({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M5.25 8.25h15m-16.5 7.5h15m-1.8-13.5-3.9 19.5m-2.1-19.5-3.9 19.5"
	}));
}
var b$2 = /*#__PURE__*/ import_react.forwardRef(y$1);
function x({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244"
	}));
}
var S$1 = /*#__PURE__*/ import_react.forwardRef(x);
function C({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0ZM3.75 12h.007v.008H3.75V12Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm-.375 5.25h.007v.008H3.75v-.008Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z"
	}));
}
var w = /*#__PURE__*/ import_react.forwardRef(C);
function T({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10"
	}));
}
var E = /*#__PURE__*/ import_react.forwardRef(T);
function D$1({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M3.75 12h16.5m-16.5 3.75h16.5M3.75 19.5h16.5M5.625 4.5h12.75a1.875 1.875 0 0 1 0 3.75H5.625a1.875 1.875 0 0 1 0-3.75Z"
	}));
}
var O = /*#__PURE__*/ import_react.forwardRef(D$1);
function k(e) {
	return e.split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;").split("\"").join("&quot;").split("'").join("&#39;");
}
function A(e) {
	let t = e.trim();
	return /^(https?:|mailto:|\/|#)/i.test(t) ? k(t) : "#";
}
function j(e) {
	let t = k(e);
	return t = t.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (e, t, n) => `<a href="${A(n)}" target="_blank" rel="noreferrer noopener">${t}</a>`), t = t.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>"), t = t.replace(/__([^_]+)__/g, "<strong>$1</strong>"), t = t.replace(/\*([^*]+)\*/g, "<em>$1</em>"), t = t.replace(/_([^_]+)_/g, "<em>$1</em>"), t = t.replace(/~~([^~]+)~~/g, "<del>$1</del>"), t = t.replace(/`([^`]+)`/g, "<code>$1</code>"), t;
}
function M(e) {
	let t = e.split("\r\n").join("\n").split("\n"), n = [], r = 0;
	for (; r < t.length;) {
		let e = t[r];
		if (!e.trim()) {
			r += 1;
			continue;
		}
		if (e.startsWith("```")) {
			let e = [];
			for (r += 1; r < t.length && !t[r].startsWith("```");) e.push(t[r]), r += 1;
			r < t.length && (r += 1), n.push(`<pre><code>${k(e.join("\n"))}</code></pre>`);
			continue;
		}
		let i = e.match(/^(#{1,6})\s+(.*)$/);
		if (i) {
			let e = i[1].length;
			n.push(`<h${e}>${j(i[2])}</h${e}>`), r += 1;
			continue;
		}
		if (e.startsWith(">")) {
			let e = [];
			for (; r < t.length && t[r].startsWith(">");) e.push(t[r].replace(/^> ?/, "")), r += 1;
			n.push(`<blockquote>${e.map(j).join("<br />")}</blockquote>`);
			continue;
		}
		if (e.match(/^[-*+]\s+(.*)$/)) {
			let e = [];
			for (; r < t.length;) {
				let n = t[r].match(/^[-*+]\s+(.*)$/);
				if (!n) break;
				e.push(`<li>${j(n[1])}</li>`), r += 1;
			}
			n.push(`<ul>${e.join("")}</ul>`);
			continue;
		}
		if (e.match(/^\d+\.\s+(.*)$/)) {
			let e = [];
			for (; r < t.length;) {
				let n = t[r].match(/^\d+\.\s+(.*)$/);
				if (!n) break;
				e.push(`<li>${j(n[1])}</li>`), r += 1;
			}
			n.push(`<ol>${e.join("")}</ol>`);
			continue;
		}
		let a = [];
		for (; r < t.length && t[r].trim();) {
			let e = t[r], n = e.startsWith("```") || /^(#{1,6})\s+/.test(e) || e.startsWith(">") || /^[-*+]\s+/.test(e) || /^\d+\.\s+/.test(e);
			if (a.length > 0 && n) break;
			a.push(e), r += 1;
		}
		n.push(`<p>${j(a.join(" "))}</p>`);
	}
	return n.join("");
}
function N(e, t, n) {
	let r = e.lastIndexOf("\n", Math.max(0, t - 1)) + 1, i = e.indexOf("\n", n), a = i === -1 ? e.length : i;
	return {
		before: e.slice(0, r),
		selected: e.slice(r, a),
		after: e.slice(a),
		lineStart: r,
		lineEnd: a
	};
}
function P(e, t, n) {
	let r = e.value, i = e.selectionStart ?? 0, a = e.selectionEnd ?? i, o = i !== a, { before: s, selected: c, after: l, lineStart: u } = N(r, i, a);
	if (!o) {
		let e = `${t}${n}`;
		return {
			nextValue: `${r.slice(0, i)}${e}${r.slice(a)}`,
			nextStart: i + t.length,
			nextEnd: i + e.length
		};
	}
	let d = c.split("\n").map((e) => e.trim() ? `${t}${e}` : t.trimEnd()).join("\n");
	return {
		nextValue: `${s}${d}${l}`,
		nextStart: u,
		nextEnd: u + d.length
	};
}
function F(e, t, n, r) {
	let i = e.value, a = e.selectionStart ?? 0, o = e.selectionEnd ?? a, s = a === o ? r : i.slice(a, o), c = `${t}${s}${n}`;
	return {
		nextValue: `${i.slice(0, a)}${c}${i.slice(o)}`,
		nextStart: a + t.length,
		nextEnd: a + t.length + s.length
	};
}
function I(e) {
	let t = e.value, n = e.selectionStart ?? 0, r = e.selectionEnd ?? n, i = n === r ? "link text" : t.slice(n, r), a = `[${i}](https://example.com)`;
	return {
		nextValue: `${t.slice(0, n)}${a}${t.slice(r)}`,
		nextStart: n + i.length + 3,
		nextEnd: n + i.length + 3 + 19
	};
}
function L({ label: e = "Markdown", helperText: t = "Use the toolbar to format markdown and toggle between edit and preview modes.", placeholder: c = "Write markdown here...", value: l = "", disabled: d = !1, className: p = "", editorClassName: h = "", toolbarClassName: _ = "", previewClassName: y = "", htmlClassName: x = "", id: C, rows: T = 12, onChange: D, onToolbarAction: k, ...A }) {
	let j = (0, import_react.useId)(), N = C ?? `nabs-ui-markdown-${j.replace(/:/g, "")}`, L = (0, import_react.useRef)(null), [R, z] = (0, import_react.useState)(l), [B, V] = (0, import_react.useState)("edit");
	(0, import_react.useEffect)(() => {
		z(l);
	}, [l]);
	let H = M(R), U = [
		"nabs-ui-markdown",
		"nabs-ui-markdown--single-panel",
		d ? "nabs-ui-markdown--disabled" : "",
		p
	].filter(Boolean).join(" "), W = ["nabs-ui-markdown__toolbar", _].filter(Boolean).join(" "), G = ["nabs-ui-markdown__editor", h].filter(Boolean).join(" "), K = ["nabs-ui-markdown__preview", y].filter(Boolean).join(" "), q = ["nabs-ui-markdown__html", x].filter(Boolean).join(" "), J = [
		{
			id: "mode-toggle",
			icon: v$1,
			title: B === "edit" ? "Preview" : "Edit"
		},
		{
			id: "heading",
			icon: b$2,
			title: "Heading"
		},
		{
			id: "bold",
			icon: g$1,
			title: "Bold"
		},
		{
			id: "italic",
			icon: E,
			title: "Italic"
		},
		{
			id: "quote",
			icon: f$3,
			title: "Quote"
		},
		{
			id: "bullet-list",
			icon: w,
			title: "Bullet list"
		},
		{
			id: "numbered-list",
			icon: O,
			title: "Numbered list"
		},
		{
			id: "code",
			icon: m$1,
			title: "Code"
		},
		{
			id: "link",
			icon: S$1,
			title: "Link"
		}
	], Y = (e, t) => {
		if (d) return;
		let n = L.current;
		if (!n) return;
		let r = t(n);
		r && (n.value = r.nextValue, n.setSelectionRange(r.nextStart, r.nextEnd), z(r.nextValue), D?.(r.nextValue), k?.(e));
	}, X = (e) => {
		let t = e.currentTarget.value;
		z(t), D?.(t);
	}, Z = (e) => {
		if (e === "mode-toggle") {
			let e = B === "edit" ? "preview" : "edit";
			V(e), k?.(`mode-${e}`);
			return;
		}
		switch (e) {
			case "heading":
				Y("heading", (e) => P(e, "# ", "Heading"));
				break;
			case "bold":
				Y("bold", (e) => F(e, "**", "**", "bold text"));
				break;
			case "italic":
				Y("italic", (e) => F(e, "*", "*", "italic text"));
				break;
			case "quote":
				Y("quote", (e) => P(e, "> ", "Quote"));
				break;
			case "bullet-list":
				Y("bullet-list", (e) => P(e, "- ", "List item"));
				break;
			case "numbered-list":
				Y("numbered-list", (e) => P(e, "1. ", "List item"));
				break;
			case "code":
				Y("code", (e) => F(e, "`", "`", "code"));
				break;
			case "link": Y("link", I);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: U,
		...A,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-markdown__editorPanel",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "nabs-ui-markdown__label",
					htmlFor: N,
					children: e
				}),
				t ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nabs-ui-markdown__helper",
					children: t
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$4, {
					className: W,
					"aria-label": "Markdown formatting toolbar",
					items: J.map((e) => {
						let t = e.id === "mode-toggle";
						return {
							...e,
							label: t ? B === "edit" ? "Preview" : "Edit" : void 0,
							disabled: d || !t && B === "preview",
							pressed: t ? B === "preview" : void 0
						};
					}),
					onMouseDown: (e) => {
						e.target?.closest("button") && e.preventDefault();
					},
					onItemSelect: ({ itemId: e }) => Z(e)
				}),
				B === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					id: N,
					ref: L,
					className: G,
					rows: T,
					placeholder: c,
					value: R,
					disabled: d,
					onChange: X
				}) : null
			]
		}), B === "preview" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-markdown__previewPanel",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-markdown__previewLabel",
				children: "Rendered preview"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: K,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: q,
					dangerouslySetInnerHTML: { __html: H || "<p>Preview appears here.</p>" }
				})
			})]
		}) : null]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-navigation/dist/nabs-ui-navigation.js
var i$10 = {
	vertical: "nabs-ui-navigation--vertical",
	horizontal: "nabs-ui-navigation--horizontal"
};
function a$8(e) {
	return [
		"nabs-ui-navigation__itemContent",
		e === "center" ? "nabs-ui-navigation__itemContent--center" : "",
		e === "right" ? "nabs-ui-navigation__itemContent--right" : ""
	].filter(Boolean).join(" ");
}
function o$2(e) {
	let t = e.trim();
	if (!t) return "/";
	let [n] = t.split(/[?#]/, 1);
	if (!n || n === "/") return "/";
	let r = n.startsWith("/") ? n : `/${n}`;
	return r.length > 1 && r.endsWith("/") ? r.slice(0, -1) : r;
}
function s$3(e) {
	if ("path" in e) return e.path;
}
function c$4(e) {
	if ("path" in e) return e.path;
	if ("href" in e) return e.href;
}
function l$4(e) {
	return e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey;
}
function u$3({ item: e, activeItemId: t, textAlignment: n, itemClassName: i, onItemSelect: u, onPathNavigate: d }) {
	let f = [
		"nabs-ui-navigation__item",
		e.id === t ? "nabs-ui-navigation__item--active" : "",
		e.disabled ? "nabs-ui-navigation__item--disabled" : "",
		i
	].filter(Boolean).join(" "), p = (t) => {
		if (e.disabled) {
			t.preventDefault();
			return;
		}
		if (u?.(e.id, e, t), t.defaultPrevented) return;
		let n = s$3(e);
		!n || typeof window > "u" || l$4(t) && (t.preventDefault(), window.history.pushState({}, "", n), d?.(o$2(n)));
	}, m = c$4(e);
	return m ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: f,
		href: m,
		"aria-current": e.id === t ? "page" : void 0,
		onClick: p,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: a$8(n),
			children: e.label
		})
	}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: f,
		disabled: e.disabled,
		"aria-current": e.id === t ? "page" : void 0,
		onClick: p,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: a$8(n),
			children: e.label
		})
	}) });
}
function d({ items: a = [], direction: c = "vertical", textAlignment: l = "left", activeItemId: d, syncActivePath: f = !0, className: p = "", itemClassName: m = "", onItemSelect: h, ...g }) {
	let _ = [
		"nabs-ui-navigation",
		i$10[c] ?? i$10.vertical,
		p
	].filter(Boolean).join(" "), [v, y] = (0, import_react.useState)(() => typeof window > "u" ? "/" : o$2(window.location.pathname));
	(0, import_react.useEffect)(() => {
		if (!f || typeof window > "u") return;
		let e = () => {
			y(o$2(window.location.pathname));
		};
		return window.addEventListener("popstate", e), () => window.removeEventListener("popstate", e);
	}, [f]);
	let b = (0, import_react.useMemo)(() => {
		if (f) return a.find((e) => {
			let t = s$3(e);
			return t ? o$2(t) === v : !1;
		})?.id;
	}, [
		a,
		v,
		f
	]), x = d ?? b;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: _,
		...g,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "nabs-ui-navigation__list",
			children: a.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$3, {
				item: e,
				activeItemId: x,
				textAlignment: l,
				itemClassName: m,
				onItemSelect: h,
				onPathNavigate: y
			}, e.id))
		})
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-panel/dist/nabs-ui-panel.js
var r$1 = (0, import_react.forwardRef)(({ header: e = "Panel", footer: r, showHeader: i = !0, showFooter: a = !1, children: o, className: s = "", headerClassName: c = "", contentClassName: l = "", footerClassName: u = "", ...d }, f) => {
	let p = ["nabs-ui-panel", s].filter(Boolean).join(" "), m = ["nabs-ui-panel__header", c].filter(Boolean).join(" "), h = ["nabs-ui-panel__content", l].filter(Boolean).join(" "), g = ["nabs-ui-panel__footer", u].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref: f,
		className: p,
		...d,
		children: [
			i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: m,
				children: e
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: h,
				children: o
			}),
			a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: g,
				children: r
			}) : null
		]
	});
});
r$1.displayName = "Panel";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-radiobutton/dist/nabs-ui-radiobutton.js
var r$10 = {
	right: "nabs-ui-radiobutton--label-right",
	left: "nabs-ui-radiobutton--label-left",
	top: "nabs-ui-radiobutton--label-top",
	bottom: "nabs-ui-radiobutton--label-bottom"
};
function i$2({ label: i = "Radio button", labelPosition: a = "right", className: o = "", inputClassName: s = "", labelClassName: c = "", id: l, ...u }) {
	let d = u.disabled === !0, f = (0, import_react.useId)(), p = l ?? `nabs-ui-radiobutton-${f.replace(/:/g, "")}`, m = [
		"nabs-ui-radiobutton",
		d ? "nabs-ui-radiobutton--disabled" : "",
		r$10[a] ?? r$10.right,
		o
	].filter(Boolean).join(" "), h = ["nabs-ui-radiobutton__input", s].filter(Boolean).join(" "), g = ["nabs-ui-radiobutton__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: m,
		htmlFor: p,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: p,
			className: h,
			type: "radio",
			...u
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: g,
			children: i
		})]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-signature/dist/nabs-ui-signature.js
function o$1(e, t) {
	let n = t.getBoundingClientRect();
	return {
		x: e.clientX - n.left,
		y: e.clientY - n.top
	};
}
function s$2(e, t) {
	if (t.length !== 0) {
		e.beginPath(), e.moveTo(t[0].x, t[0].y);
		for (let n = 1; n < t.length; n += 1) e.lineTo(t[n].x, t[n].y);
		e.stroke();
	}
}
function c$3(e, t, n) {
	e.fillStyle = n, e.fillRect(0, 0, t.width, t.height);
}
function l$1({ label: l = "Signature", helperText: u = "Use your mouse to draw your signature.", value: d = "", disabled: f = !1, className: p = "", labelClassName: m = "", helperTextClassName: h = "", padClassName: g = "", canvasClassName: _ = "", id: v, width: y = 720, height: b = 240, backgroundColor: x = "#ffffff", penColor: S = "#0f172a", penWidth: C = 2.5, onChange: w, onBeginStroke: T, onEndStroke: E, onClear: D }) {
	let O = (0, import_react.useId)(), k = v ?? `nabs-ui-signature-${O.replace(/:/g, "")}`, A = (0, import_react.useRef)(null), j = (0, import_react.useRef)(null), M = (0, import_react.useRef)(!1), N = (0, import_react.useRef)([]), [P, F] = (0, import_react.useState)(!d), I = [
		"nabs-ui-signature",
		f ? "nabs-ui-signature--disabled" : "",
		p
	].filter(Boolean).join(" "), L = ["nabs-ui-signature__label", m].filter(Boolean).join(" "), R = ["nabs-ui-signature__helper", h].filter(Boolean).join(" "), z = ["nabs-ui-signature__pad", g].filter(Boolean).join(" "), B = ["nabs-ui-signature__canvas", _].filter(Boolean).join(" ");
	(0, import_react.useEffect)(() => {
		let e = A.current;
		if (!e) return;
		let t = e.getContext("2d");
		if (!t) return;
		let n = window.devicePixelRatio || 1, r = Math.round(y), i = Math.round(b);
		if (e.width = Math.round(r * n), e.height = Math.round(i * n), e.style.width = `${r}px`, e.style.height = `${i}px`, j.current = t, t.lineCap = "round", t.lineJoin = "round", t.lineWidth = C * n, t.strokeStyle = S, t.scale(n, n), c$3(t, e, x), d) {
			let e = new Image();
			e.onload = () => {
				t.clearRect(0, 0, r, i), t.fillStyle = x, t.fillRect(0, 0, r, i), t.drawImage(e, 0, 0, r, i), F(!1);
			}, e.src = d;
		}
		return () => {
			j.current = null;
		};
	}, [
		x,
		S,
		C,
		d,
		y,
		b
	]);
	let V = (e) => {
		w?.(e.toDataURL("image/png"));
	}, H = (e) => {
		if (f || M.current) return;
		let t = A.current, n = j.current;
		!t || !n || ("pointerId" in e && typeof e.pointerId == "number" && t.setPointerCapture && t.setPointerCapture(e.pointerId), M.current = !0, N.current = [o$1(e, t)], n.beginPath(), n.moveTo(N.current[0].x, N.current[0].y), T?.());
	}, U = (e) => {
		if (f || !M.current) return;
		let t = A.current, n = j.current;
		if (!t || !n) return;
		let r = o$1(e, t);
		N.current.push(r), n.lineTo(r.x, r.y), n.stroke(), F(!1);
	}, W = (e) => {
		let t = A.current, n = j.current;
		if (!(!t || !n || !M.current)) {
			if (e && "pointerId" in e && typeof e.pointerId == "number" && t.releasePointerCapture) try {
				t.releasePointerCapture(e.pointerId);
			} catch {}
			M.current = !1, s$2(n, N.current), N.current = [], V(t), E?.();
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: I,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: L,
				id: `${k}-label`,
				children: l
			}),
			u ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: R,
				children: u
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: z,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					id: k,
					ref: A,
					className: B,
					role: "img",
					"aria-labelledby": `${k}-label`,
					"aria-label": l,
					onPointerDown: H,
					onPointerMove: U,
					onPointerUp: W,
					onPointerCancel: W,
					onPointerLeave: W,
					onMouseDown: H,
					onMouseMove: U,
					onMouseUp: W,
					onMouseLeave: W
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nabs-ui-signature__placeholder",
					"aria-hidden": "true",
					children: P ? "Draw here" : null
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-signature__actions",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "nabs-ui-signature__clearButton",
					onClick: () => {
						let e = A.current, t = j.current;
						!e || !t || (t.clearRect(0, 0, e.width, e.height), c$3(t, e, x), F(!0), w?.(""), D?.());
					},
					disabled: f || P,
					children: "Clear"
				})
			})
		]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-slider/dist/nabs-ui-slider.js
var i$4 = (0, import_react.forwardRef)(({ label: e = "Slider", value: i = 0, min: a = 0, max: o = 100, step: s = 1, disabled: c = !1, className: l = "", inputClassName: u = "", labelClassName: d = "", valueClassName: f = "", id: p, onChange: m, ...h }, g) => {
	let _ = (0, import_react.useId)(), v = p ?? `nabs-ui-slider-${_.replace(/:/g, "")}`, y = [
		"nabs-ui-slider",
		c ? "nabs-ui-slider--disabled" : "",
		l
	].filter(Boolean).join(" "), b = ["nabs-ui-slider__input", u].filter(Boolean).join(" "), x = ["nabs-ui-slider__label", d].filter(Boolean).join(" "), S = ["nabs-ui-slider__value", f].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: y,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-slider__header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: x,
					htmlFor: v,
					children: e
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("output", {
					className: S,
					htmlFor: v,
					children: i
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: g,
				id: v,
				className: b,
				type: "range",
				value: i,
				min: a,
				max: o,
				step: s,
				disabled: c,
				onChange: m,
				...h
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-slider__scale",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: o })]
			})
		]
	});
});
i$4.displayName = "Slider";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-stepper/dist/nabs-ui-stepper.js
function c$2(e) {
	return e === "top" || e === "bottom" ? "horizontal" : "vertical";
}
function l$3(e, t) {
	return [
		"nabs-ui-stepper",
		`nabs-ui-stepper--${e}`,
		t
	].filter(Boolean).join(" ");
}
function u$2(e) {
	return ["nabs-ui-stepper__steps", `nabs-ui-stepper__steps--${e}`].filter(Boolean).join(" ");
}
function d$2(e) {
	return ["nabs-ui-stepper__content", `nabs-ui-stepper__content--${e}`].filter(Boolean).join(" ");
}
function f$2(t) {
	return import_react.Children.toArray(t).flatMap((e) => {
		if (!(0, import_react.isValidElement)(e)) return [];
		let t = Number(e.props.index);
		return Number.isFinite(t) ? [{
			index: t,
			label: e.props.label ?? e.props.children ?? `Step ${t}`,
			icon: e.props.icon,
			disabled: !!e.props.disabled
		}] : [];
	}).sort((e, t) => e.index - t.index);
}
function p$1(t) {
	return import_react.Children.toArray(t).flatMap((e) => {
		if (!(0, import_react.isValidElement)(e)) return [];
		let t = Number(e.props.index);
		return Number.isFinite(t) ? [{
			index: t,
			content: e.props.children
		}] : [];
	}).sort((e, t) => e.index - t.index);
}
function m({ children: e }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: e });
}
function h$1(e) {
	return null;
}
function g({ children: e }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: e });
}
function _(e) {
	return null;
}
var v = m;
var y = g;
var b$1 = (0, import_react.forwardRef)(({ children: t, className: a = "", stepsPosition: m = "top", stepsAlignment: h = "left", stepLabelAlignment: g = "right", showCenterLine: _ = !0, activeIndex: b, defaultActiveIndex: x, onStepChange: S, ...C }, w) => {
	let [T, E] = (0, import_react.useState)(x), { parsedSteps: D, parsedContentSteps: O } = (0, import_react.useMemo)(() => {
		let r = import_react.Children.toArray(t), i = r.find((e) => (0, import_react.isValidElement)(e) && e.type === v), a = r.find((e) => (0, import_react.isValidElement)(e) && e.type === y);
		return {
			parsedSteps: f$2(i?.props.children),
			parsedContentSteps: p$1(a?.props.children)
		};
	}, [t]), k = D[0]?.index ?? O[0]?.index ?? 0, A = b ?? T ?? k, j = O.find((e) => e.index === A), M = c$2(m), N = [
		l$3(m, a),
		`nabs-ui-stepper--label-${g}`,
		`nabs-ui-stepper--align-${h}`,
		_ ? "nabs-ui-stepper--with-center-line" : "nabs-ui-stepper--without-center-line"
	].filter(Boolean).join(" "), P = u$2(m), F = d$2(m);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref: w,
		className: N,
		...C,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: P,
			role: "tablist",
			"aria-orientation": M,
			children: D.map((e) => {
				let t = e.index === A;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "tab",
					"aria-selected": t,
					"aria-disabled": e.disabled,
					tabIndex: e.disabled ? -1 : 0,
					className: [
						"nabs-ui-stepper__step",
						t ? "nabs-ui-stepper__step--active" : "",
						e.disabled ? "nabs-ui-stepper__step--disabled" : ""
					].filter(Boolean).join(" "),
					onClick: (t) => {
						e.disabled || (b === void 0 && E(e.index), S?.(e.index, t));
					},
					children: [e.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-stepper__stepIndicators",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nabs-ui-stepper__stepIcon",
							children: e.icon
						})
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-stepper__stepLabel",
						children: e.label
					})]
				}, e.index);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: F,
			role: "tabpanel",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-stepper__contentInner",
				children: j?.content ?? null
			})
		})]
	});
});
b$1.displayName = "Stepper", m.displayName = "Stepper.Steps", h$1.displayName = "Stepper.Step", g.displayName = "Stepper.ContentSteps", _.displayName = "Stepper.ContentStep", b$1.Steps = m, b$1.Step = h$1, b$1.ContentSteps = g, b$1.ContentStep = _;
//#endregion
//#region node_modules/@net-advantage/nabs-ui-tab/dist/nabs-ui-tab.js
var r$2 = (0, import_react.forwardRef)(({ label: e = "Tab", children: r, showHeader: i = !0, className: a = "", headerClassName: o = "", contentClassName: s = "", labelClassName: c = "", id: l, ...u }, d) => {
	let f = ["nabs-ui-tab", a].filter(Boolean).join(" "), p = ["nabs-ui-tab__header", o].filter(Boolean).join(" "), m = ["nabs-ui-tab__content", s].filter(Boolean).join(" "), h = ["nabs-ui-tab__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref: d,
		id: l,
		className: f,
		...u,
		children: [i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: p,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: h,
				children: e
			})
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: m,
			children: r
		})]
	});
});
r$2.displayName = "Tab";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-textarea/dist/nabs-ui-textarea.js
var i$5 = (0, import_react.forwardRef)(({ label: e, className: i = "", inputClassName: a = "", labelClassName: o = "", id: s, rows: c = 4, resize: l = "vertical", ...u }, d) => {
	let f = (0, import_react.useId)(), p = s ?? `nabs-ui-textarea-${f.replace(/:/g, "")}`, m = ["nabs-ui-textarea", i].filter(Boolean).join(" "), h = ["nabs-ui-textarea__input", a].filter(Boolean).join(" "), g = ["nabs-ui-textarea__label", o].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: m,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: g,
			htmlFor: p,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			ref: d,
			id: p,
			className: h,
			rows: c,
			"data-resize": l,
			...u
		})]
	});
});
i$5.displayName = "Textarea";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-textbox/dist/nabs-ui-textbox.js
var i$7 = {
	none: "",
	top: "nabs-ui-textbox--label-top",
	left: "nabs-ui-textbox--label-left"
};
var a$4 = (0, import_react.forwardRef)(({ label: e, labelPosition: a = "top", className: o = "", inputClassName: s = "", labelClassName: c = "", id: l, type: u = "text", ...d }, f) => {
	let p = (0, import_react.useId)(), m = l ?? `nabs-ui-textbox-${p.replace(/:/g, "")}`, h = [
		"nabs-ui-textbox",
		e ? i$7[a] ?? i$7.top : "",
		o
	].filter(Boolean).join(" "), g = ["nabs-ui-textbox__input", s].filter(Boolean).join(" "), _ = ["nabs-ui-textbox__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: h,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: _,
			htmlFor: m,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: f,
			id: m,
			className: g,
			type: u,
			...d
		})]
	});
});
a$4.displayName = "Textbox";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-toolbar/dist/nabs-ui-toolbar.js
var r$4 = {
	left: "nabs-ui-toolbar__content--label-left",
	right: "nabs-ui-toolbar__content--label-right",
	top: "nabs-ui-toolbar__content--label-top",
	bottom: "nabs-ui-toolbar__content--label-bottom"
};
function i$6(e) {
	return e || "right";
}
var a$5 = (0, import_react.forwardRef)(function({ items: e, activeItemId: a, className: o = "", buttonClassName: s = "", iconClassName: c = "", labelClassName: l = "", onItemSelect: u, ...d }, f) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: f,
		className: ["nabs-ui-toolbar", o].filter(Boolean).join(" "),
		role: "toolbar",
		...d,
		children: e.map((e) => {
			let o = e.icon, d = !!e.label, f = e.id === a || e.pressed === !0, p = ["nabs-ui-toolbar__content", r$4[i$6(e.labelPosition)]].filter(Boolean).join(" "), m = [
				"nabs-ui-toolbar__button",
				f ? "nabs-ui-toolbar__button--active" : "",
				d ? "" : "nabs-ui-toolbar__button--icon-only",
				s
			].filter(Boolean).join(" "), h = ["nabs-ui-toolbar__icon", c].filter(Boolean).join(" "), g = ["nabs-ui-toolbar__label", l].filter(Boolean).join(" "), _ = typeof e.label == "string" ? e.label : e.title;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: m,
				disabled: e.disabled,
				title: e.title,
				"aria-label": _,
				"aria-pressed": typeof e.pressed == "boolean" ? e.pressed : void 0,
				onClick: (t) => {
					u?.({
						itemId: e.id,
						item: e,
						event: t
					});
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: p,
					children: [o ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(o, {
						className: h,
						"aria-hidden": "true",
						focusable: "false"
					}) : null, e.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: g,
						children: e.label
					}) : null]
				})
			}, e.id);
		})
	});
});
a$5.displayName = "Toolbar";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-shell/dist/nabs-ui-shell.js
var i$3 = (0, import_react.forwardRef)(({ header: e, navigation: r, footer: i, children: a, className: o = "", headerClassName: s = "", navigationClassName: c = "", contentClassName: l = "", footerClassName: u = "", ...d }, f) => {
	let p = ["nabs-ui-shell", o].filter(Boolean).join(" "), m = ["nabs-ui-shell__header", s].filter(Boolean).join(" "), h = ["nabs-ui-shell__navigation", c].filter(Boolean).join(" "), g = ["nabs-ui-shell__content", l].filter(Boolean).join(" "), _ = ["nabs-ui-shell__footer", u].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: f,
		className: p,
		...d,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(i$1, {
			className: "nabs-ui-shell__layout",
			header: e,
			footer: i,
			leftSidePanel: r,
			headerClassName: m,
			footerClassName: _,
			leftSidePanelClassName: h,
			contentClassName: g,
			children: a
		})
	});
});
i$3.displayName = "Shell";
var a = (0, import_react.forwardRef)(function({ logo: e, title: t, byline: i, className: a = "", ...o }, s) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: s,
		className: ["nabs-ui-branding", a].filter(Boolean).join(" "),
		...o,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-branding__logo",
			"aria-hidden": "true",
			children: e
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-branding__text",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
				className: "nabs-ui-branding__title",
				children: t
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-branding__byline",
				children: i
			})]
		})]
	});
});
a.displayName = "Branding";
//#endregion
export { u as Accordion, h as Avatar, a as Branding, r as Button, a$1 as Cards, a$2 as Checkbox, i as Code, p as Combobox, a$3 as DatePicker, c as Dialog, s as DropdownList, f as DropdownMenu, b as DynamicForm, l as FileUpload, S as Graph, D as Grid, i$1 as Layout, L as Markdown, d as Navigation, r$1 as Panel, i$2 as RadioButton, i$3 as Shell, l$1 as Signature, c$1 as SimpleGraphToolset, i$4 as Slider, b$1 as Stepper, r$2 as Tab, i$5 as Textarea, a$4 as Textbox, a$5 as Toolbar, d$1 as agenticWorkflowToolset, f$1 as agenticWorkflowToolsets, l$2 as simpleGraphToolset, u$1 as simpleGraphToolsets };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQG5ldC1hZHZhbnRhZ2VfbmFicy11aS1zaGVsbC5qcyIsIm5hbWVzIjpbIm4iLCJyIiwiaSIsInMiLCJjIiwibCIsImUiLCJuIiwiaSIsInIiLCJ1IiwiZCIsImYiLCJwIiwiYSIsImkiLCJuIiwiciIsInMiLCJvIiwibSIsImUiLCJuIiwiZSIsInIiLCJpIiwiYSIsImUiLCJpIiwiYSIsImUiLCJ0IiwiciIsImUiLCJjIiwibCIsInUiLCJkIiwiZiIsImUiLCJuIiwiaSIsImEiLCJyIiwidCIsImkiLCJhIiwiZSIsInQiLCJvIiwicyIsImUiLCJyIiwibiIsInQiLCJpIiwiYSIsIm8iLCJlIiwidCIsImwiLCJ1IiwiZCIsImkiLCJyIiwidCIsIm4iLCJvIiwiYSIsIm8iLCJzIiwiZSIsIm4iLCJjIiwibCIsInUiLCJkIiwiZiIsInAiLCJtIiwiaCIsImciLCJfIiwidiIsInkiLCJyIiwiYSIsIm8iLCJzIiwiYyIsImUiLCJ0IiwibiIsImMiLCJsIiwidSIsImQiLCJmIiwicCIsIm0iLCJoIiwiZyIsIl8iLCJ2IiwieSIsImVlIiwiYiIsIngiLCJ0ZSIsImUiLCJyIiwiaSIsImEiLCJuIiwidCIsImwiLCJ1IiwiZSIsImQiLCJmIiwicCIsImkiLCJuIiwidCIsIm0iLCJoIiwiZyIsIl8iLCJ2IiwieSIsImIiLCJ4IiwidyIsIlMiLCJDIiwiVCIsIkUiLCJhIiwibyIsInIiLCJjIiwibCIsInUiLCJ0IiwiZCIsImYiLCJwIiwibSIsImgiLCJnIiwiXyIsInYiLCJ5IiwiYiIsIlMiLCJEIiwiciIsImkiLCJhIiwiaSIsImEiLCJvIiwicyIsImMiLCJsIiwidSIsIm4iLCJ0IiwiciIsImUiLCJyIiwiaSIsImUiLCJvIiwicyIsImMiLCJsIiwidCIsIm4iLCJyIiwiaSIsImUiLCJ0IiwiYyIsImwiLCJ1IiwiZCIsImYiLCJlIiwibiIsInAiLCJhIiwiaCIsImIiLCJ0IiwiaSIsInIiLCJyIiwiZSIsImkiLCJlIiwidCIsImkiLCJhIiwiZSIsInQiLCJyIiwiaSIsImEiLCJlIiwiaSIsImUiLCJ0Il0sInNvdXJjZXMiOlsiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1sYXlvdXQvZGlzdC9uYWJzLXVpLWxheW91dC5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktYWNjb3JkaW9uL2Rpc3QvbmFicy11aS1hY2NvcmRpb24uanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWF2YXRhci9kaXN0L25hYnMtdWktYXZhdGFyLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1idXR0b25zL2Rpc3QvbmFicy11aS1idXR0b25zLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1jYXJkcy9kaXN0L25hYnMtdWktY2FyZHMuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWNoZWNrYm94L2Rpc3QvbmFicy11aS1jaGVja2JveC5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktY29kZS9kaXN0L25hYnMtdWktY29kZS5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktY29tYm9ib3gvZGlzdC9uYWJzLXVpLWNvbWJvYm94LmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1kYXRlcGlja2VyL2Rpc3QvbmFicy11aS1kYXRlcGlja2VyLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1kaWFsb2cvZGlzdC9uYWJzLXVpLWRpYWxvZy5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktZHJvcGRvd25saXN0L2Rpc3QvbmFicy11aS1kcm9wZG93bmxpc3QuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWRyb3Bkb3dubWVudS9kaXN0L25hYnMtdWktZHJvcGRvd25tZW51LmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1keW5hbWljZm9ybS9kaXN0L25hYnMtdWktZHluYW1pY2Zvcm0uanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWZpbGV1cGxvYWQvZGlzdC9uYWJzLXVpLWZpbGV1cGxvYWQuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWdyYXBoL2Rpc3QvbmFicy11aS1ncmFwaC5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktZ3JpZC9kaXN0L25hYnMtdWktZ3JpZC5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktbWFya2Rvd24vZGlzdC9uYWJzLXVpLW1hcmtkb3duLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1uYXZpZ2F0aW9uL2Rpc3QvbmFicy11aS1uYXZpZ2F0aW9uLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1wYW5lbC9kaXN0L25hYnMtdWktcGFuZWwuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLXJhZGlvYnV0dG9uL2Rpc3QvbmFicy11aS1yYWRpb2J1dHRvbi5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktc2lnbmF0dXJlL2Rpc3QvbmFicy11aS1zaWduYXR1cmUuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLXNsaWRlci9kaXN0L25hYnMtdWktc2xpZGVyLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1zdGVwcGVyL2Rpc3QvbmFicy11aS1zdGVwcGVyLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS10YWIvZGlzdC9uYWJzLXVpLXRhYi5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktdGV4dGFyZWEvZGlzdC9uYWJzLXVpLXRleHRhcmVhLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS10ZXh0Ym94L2Rpc3QvbmFicy11aS10ZXh0Ym94LmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS10b29sYmFyL2Rpc3QvbmFicy11aS10b29sYmFyLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1zaGVsbC9kaXN0L25hYnMtdWktc2hlbGwuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsganN4IGFzIGUsIGpzeHMgYXMgdCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9MYXlvdXQudHN4XG5mdW5jdGlvbiBuKGUpIHtcblx0aWYgKGUgPT0gbnVsbCkgcmV0dXJuO1xuXHRpZiAodHlwZW9mIGUgPT0gXCJudW1iZXJcIikgcmV0dXJuIGAke2V9cHhgO1xuXHRsZXQgdCA9IGUudHJpbSgpO1xuXHRyZXR1cm4gdC5sZW5ndGggPiAwID8gdCA6IHZvaWQgMDtcbn1cbmZ1bmN0aW9uIHIoeyBhczogdCA9IFwiZGl2XCIsIGNsYXNzTmFtZTogbiA9IFwiXCIsIGNoaWxkcmVuOiByLCAuLi5pIH0pIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBlKHQsIHtcblx0XHRjbGFzc05hbWU6IG4sXG5cdFx0Li4uaSxcblx0XHRjaGlsZHJlbjogclxuXHR9KTtcbn1cbmZ1bmN0aW9uIGkoeyBoZWFkZXI6IGksIGZvb3RlcjogYSwgbGVmdFNpZGVQYW5lbDogbywgcmlnaHRTaWRlUGFuZWw6IHMsIGxlZnRTaWRlUGFuZWxXaWR0aDogYywgcmlnaHRTaWRlUGFuZWxXaWR0aDogbCwgY2hpbGRyZW46IHUsIGNsYXNzTmFtZTogZCA9IFwiXCIsIGhlYWRlckNsYXNzTmFtZTogZiA9IFwiXCIsIGZvb3RlckNsYXNzTmFtZTogcCA9IFwiXCIsIGxlZnRTaWRlUGFuZWxDbGFzc05hbWU6IG0gPSBcIlwiLCByaWdodFNpZGVQYW5lbENsYXNzTmFtZTogaCA9IFwiXCIsIGNvbnRlbnRDbGFzc05hbWU6IGcgPSBcIlwiLCBzdHlsZTogXywgLi4udiB9KSB7XG5cdGxldCB5ID0gaSAhPSBudWxsICYmIGkgIT09ICExLCBiID0gYSAhPSBudWxsICYmIGEgIT09ICExLCB4ID0gbyAhPSBudWxsICYmIG8gIT09ICExLCBTID0gcyAhPSBudWxsICYmIHMgIT09ICExLCBDID0gW1xuXHRcdFwibmFicy11aS1sYXlvdXRfX2JvZHlcIixcblx0XHR4ICYmIFMgPyBcIm5hYnMtdWktbGF5b3V0X19ib2R5LS13aXRoLWJvdGgtcGFuZWxzXCIgOiBcIlwiLFxuXHRcdHggJiYgIVMgPyBcIm5hYnMtdWktbGF5b3V0X19ib2R5LS13aXRoLWxlZnQtcGFuZWxcIiA6IFwiXCIsXG5cdFx0IXggJiYgUyA/IFwibmFicy11aS1sYXlvdXRfX2JvZHktLXdpdGgtcmlnaHQtcGFuZWxcIiA6IFwiXCJcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIHcgPSBbXCJuYWJzLXVpLWxheW91dFwiLCBkXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFQgPSBuKGMpLCBFID0gbihsKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyB0KFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IHcsXG5cdFx0c3R5bGU6IHtcblx0XHRcdC4uLl8gPz8ge30sXG5cdFx0XHQuLi5UID8geyBcIi0tbmFicy11aS1sYXlvdXQtbGVmdC1wYW5lbC13aWR0aFwiOiBUIH0gOiB7fSxcblx0XHRcdC4uLkUgPyB7IFwiLS1uYWJzLXVpLWxheW91dC1yaWdodC1wYW5lbC13aWR0aFwiOiBFIH0gOiB7fVxuXHRcdH0sXG5cdFx0Li4udixcblx0XHRjaGlsZHJlbjogW1xuXHRcdFx0eSA/IC8qIEBfX1BVUkVfXyAqLyBlKHIsIHtcblx0XHRcdFx0YXM6IFwiaGVhZGVyXCIsXG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWxheW91dF9faGVhZGVyV3JhcHBlclwiLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGUoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogW1wibmFicy11aS1sYXlvdXRfX2hlYWRlclwiLCBmXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGlcblx0XHRcdFx0fSlcblx0XHRcdH0pIDogbnVsbCxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyB0KFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBDLFxuXHRcdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHRcdHggPyAvKiBAX19QVVJFX18gKi8gZShyLCB7XG5cdFx0XHRcdFx0XHRhczogXCJhc2lkZVwiLFxuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBbXG5cdFx0XHRcdFx0XHRcdFwibmFicy11aS1sYXlvdXRfX3BhbmVsXCIsXG5cdFx0XHRcdFx0XHRcdFwibmFicy11aS1sYXlvdXRfX3BhbmVsLS1sZWZ0XCIsXG5cdFx0XHRcdFx0XHRcdG1cblx0XHRcdFx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IG9cblx0XHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIGUociwge1xuXHRcdFx0XHRcdFx0YXM6IFwic2VjdGlvblwiLFxuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBbXCJuYWJzLXVpLWxheW91dF9fY29udGVudFwiLCBnXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogdVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdFMgPyAvKiBAX19QVVJFX18gKi8gZShyLCB7XG5cdFx0XHRcdFx0XHRhczogXCJhc2lkZVwiLFxuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBbXG5cdFx0XHRcdFx0XHRcdFwibmFicy11aS1sYXlvdXRfX3BhbmVsXCIsXG5cdFx0XHRcdFx0XHRcdFwibmFicy11aS1sYXlvdXRfX3BhbmVsLS1yaWdodFwiLFxuXHRcdFx0XHRcdFx0XHRoXG5cdFx0XHRcdFx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBzXG5cdFx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRcdF1cblx0XHRcdH0pLFxuXHRcdFx0YiA/IC8qIEBfX1BVUkVfXyAqLyBlKHIsIHtcblx0XHRcdFx0YXM6IFwiZm9vdGVyXCIsXG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWxheW91dF9fZm9vdGVyV3JhcHBlclwiLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGUoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogW1wibmFicy11aS1sYXlvdXRfX2Zvb3RlclwiLCBwXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGFcblx0XHRcdFx0fSlcblx0XHRcdH0pIDogbnVsbFxuXHRcdF1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGkgYXMgTGF5b3V0IH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUVmZmVjdCBhcyB0LCB1c2VJZCBhcyBuLCB1c2VNZW1vIGFzIHIsIHVzZVN0YXRlIGFzIGkgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBhLCBqc3hzIGFzIG8gfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvYWNjb3JkaW9uLnV0aWxzLnRzXG5mdW5jdGlvbiBzKGUsIHQsIG4pIHtcblx0bGV0IHIgPSBlID8/IFtdLCBpID0gbmV3IFNldCh0Lm1hcCgoZSkgPT4gZS5pZCkpLCBhID0gci5maWx0ZXIoKGUsIHQsIG4pID0+IGkuaGFzKGUpICYmIG4uaW5kZXhPZihlKSA9PT0gdCk7XG5cdHJldHVybiBuID09PSBcInNpbmdsZVwiID8gYS5zbGljZSgwLCAxKSA6IGE7XG59XG5mdW5jdGlvbiBjKGUsIHQsIG4pIHtcblx0bGV0IHIgPSBlLmluY2x1ZGVzKHQpO1xuXHRyZXR1cm4gbiA9PT0gXCJzaW5nbGVcIiA/IHIgPyBbXSA6IFt0XSA6IHIgPyBlLmZpbHRlcigoZSkgPT4gZSAhPT0gdCkgOiBbLi4uZSwgdF07XG59XG5mdW5jdGlvbiBsKGUpIHtcblx0cmV0dXJuIFtcIm5hYnMtdWktYWNjb3JkaW9uXCIsIGVdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9BY2NvcmRpb24udHN4XG52YXIgdSA9IGUoZnVuY3Rpb24oeyBpdGVtczogZSwgbW9kZTogdSA9IFwibXVsdGlwbGVcIiwgZXhwYW5kZWRJdGVtSWRzOiBkLCBkZWZhdWx0RXhwYW5kZWRJdGVtSWRzOiBmLCBvbkV4cGFuZGVkSXRlbUlkc0NoYW5nZTogcCwgY2xhc3NOYW1lOiBtID0gXCJcIiwgaXRlbUNsYXNzTmFtZTogaCA9IFwiXCIsIHRyaWdnZXJDbGFzc05hbWU6IGcgPSBcIlwiLCBwYW5lbENsYXNzTmFtZTogXyA9IFwiXCIsIGlkOiB2LCAuLi55IH0sIGIpIHtcblx0bGV0IHggPSBuKCksIFMgPSB2ID8/IGBuYWJzLXVpLWFjY29yZGlvbi0ke3gucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBbQywgd10gPSBpKHIoKCkgPT4gcyhmLCBlLCB1KSwgW1xuXHRcdGYsXG5cdFx0ZSxcblx0XHR1XG5cdF0pKTtcblx0dCgoKSA9PiB7XG5cdFx0dygodCkgPT4gcyh0LCBlLCB1KSk7XG5cdH0sIFtlLCB1XSk7XG5cdGxldCBUID0gcigoKSA9PiBzKGQgPT09IHZvaWQgMCA/IEMgOiBkLCBlLCB1KSwgW1xuXHRcdGQsXG5cdFx0Qyxcblx0XHRlLFxuXHRcdHVcblx0XSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gYShcInNlY3Rpb25cIiwge1xuXHRcdHJlZjogYixcblx0XHRpZDogUyxcblx0XHRjbGFzc05hbWU6IGwobSksXG5cdFx0Li4ueSxcblx0XHRjaGlsZHJlbjogZS5tYXAoKGUpID0+IHtcblx0XHRcdGxldCB0ID0gVC5pbmNsdWRlcyhlLmlkKSwgbiA9IGAke1N9LXBhbmVsLSR7ZS5pZH1gLCByID0gYCR7U30tdHJpZ2dlci0ke2UuaWR9YCwgaSA9IFtcblx0XHRcdFx0XCJuYWJzLXVpLWFjY29yZGlvbl9faXRlbVwiLFxuXHRcdFx0XHR0ID8gXCJuYWJzLXVpLWFjY29yZGlvbl9faXRlbS0tZXhwYW5kZWRcIiA6IFwiXCIsXG5cdFx0XHRcdGhcblx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBzID0gW1wibmFicy11aS1hY2NvcmRpb25fX3RyaWdnZXJcIiwgZ10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBsID0gW1wibmFicy11aS1hY2NvcmRpb25fX3BhbmVsXCIsIF9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZiA9ICh0KSA9PiB7XG5cdFx0XHRcdGxldCBuID0gYyhULCBlLmlkLCB1KTtcblx0XHRcdFx0ZCA9PT0gdm9pZCAwICYmIHcobiksIHA/Lih7XG5cdFx0XHRcdFx0aXRlbUlkOiBlLmlkLFxuXHRcdFx0XHRcdGV4cGFuZGVkSXRlbUlkczogbixcblx0XHRcdFx0XHRldmVudDogdFxuXHRcdFx0XHR9KTtcblx0XHRcdH07XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG8oXCJhcnRpY2xlXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBpLFxuXHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBhKFwiaDNcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJtLTBcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogdCA/IC8qIEBfX1BVUkVfXyAqLyBvKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdGlkOiByLFxuXHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogcyxcblx0XHRcdFx0XHRcdFwiYXJpYS1leHBhbmRlZFwiOiBcInRydWVcIixcblx0XHRcdFx0XHRcdFwiYXJpYS1jb250cm9sc1wiOiBuLFxuXHRcdFx0XHRcdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XHRcdFx0XHRvbkNsaWNrOiBmLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gYShcInNwYW5cIiwgeyBjaGlsZHJlbjogZS5oZWFkZXIgfSksIC8qIEBfX1BVUkVfXyAqLyBhKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWFjY29yZGlvbl9fdHJpZ2dlckljb25cIixcblx0XHRcdFx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiK1wiXG5cdFx0XHRcdFx0XHR9KV1cblx0XHRcdFx0XHR9KSA6IC8qIEBfX1BVUkVfXyAqLyBvKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdGlkOiByLFxuXHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogcyxcblx0XHRcdFx0XHRcdFwiYXJpYS1leHBhbmRlZFwiOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XHRcImFyaWEtY29udHJvbHNcIjogbixcblx0XHRcdFx0XHRcdGRpc2FibGVkOiBlLmRpc2FibGVkLFxuXHRcdFx0XHRcdFx0b25DbGljazogZixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGEoXCJzcGFuXCIsIHsgY2hpbGRyZW46IGUuaGVhZGVyIH0pLCAvKiBAX19QVVJFX18gKi8gYShcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1hY2NvcmRpb25fX3RyaWdnZXJJY29uXCIsXG5cdFx0XHRcdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIitcIlxuXHRcdFx0XHRcdFx0fSldXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBhKFwic2VjdGlvblwiLCB7XG5cdFx0XHRcdFx0aWQ6IG4sXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBsLFxuXHRcdFx0XHRcdHJvbGU6IFwicmVnaW9uXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogcixcblx0XHRcdFx0XHRoaWRkZW46ICF0LFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBlLmNvbnRlbnRcblx0XHRcdFx0fSldXG5cdFx0XHR9LCBlLmlkKTtcblx0XHR9KVxuXHR9KTtcbn0pO1xudS5kaXNwbGF5TmFtZSA9IFwiQWNjb3JkaW9uXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHUgYXMgQWNjb3JkaW9uIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUVmZmVjdCBhcyB0LCB1c2VJZCBhcyBuLCB1c2VMYXlvdXRFZmZlY3QgYXMgciwgdXNlUmVmIGFzIGksIHVzZVN0YXRlIGFzIGEgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCBhcyBvIH0gZnJvbSBcInJlYWN0LWRvbVwiO1xuaW1wb3J0IHsgRnJhZ21lbnQgYXMgcywganN4IGFzIGMsIGpzeHMgYXMgbCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIC4uL25hYnMtdWktZHJvcGRvd25tZW51L3NyYy9kcm9wZG93bm1lbnUudXRpbHMudHNcbmZ1bmN0aW9uIHUoZSkge1xuXHRyZXR1cm4gISEoZSAmJiBcInR5cGVcIiBpbiBlICYmIGUudHlwZSA9PT0gXCJkaXZpZGVyXCIpO1xufVxuZnVuY3Rpb24gZChlKSB7XG5cdHJldHVybiBlLmxhYmVsID8/IGUuY2hpbGRyZW4gPz8gXCJNZW51IGl0ZW1cIjtcbn1cbmZ1bmN0aW9uIGYoZSwgdCkge1xuXHRyZXR1cm4gZS52YWx1ZSA/PyBlLmxhYmVsID8/IGBpdGVtLSR7dH1gO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vbmFicy11aS1kcm9wZG93bm1lbnUvc3JjL0Ryb3Bkb3duTWVudS50c3hcbmZ1bmN0aW9uIHAoeyBsYWJlbDogZSA9IFwiTWVudVwiLCB0cmlnZ2VyQ29udGVudDogcCwgdHJpZ2dlckFyaWFMYWJlbDogbSwgbWVudUFsaWduOiBoID0gXCJzdGFydFwiLCBpdGVtczogZyA9IFtdLCBjbGFzc05hbWU6IF8gPSBcIlwiLCB0cmlnZ2VyQ2xhc3NOYW1lOiB2ID0gXCJcIiwgbWVudUNsYXNzTmFtZTogeSA9IFwiXCIsIGl0ZW1DbGFzc05hbWU6IGIgPSBcIlwiLCBkaXZpZGVyQ2xhc3NOYW1lOiB4ID0gXCJcIiwgaWQ6IFMsIG9uSXRlbVNlbGVjdDogQywgLi4udyB9KSB7XG5cdGxldCBbVCwgRV0gPSBhKCExKSwgRCA9IGkobnVsbCksIE8gPSBpKG51bGwpLCBrID0gaShudWxsKSwgQSA9IG4oKSwgaiA9IFMgPz8gYG5hYnMtdWktZHJvcGRvd25tZW51LSR7QS5yZXBsYWNlKC86L2csIFwiXCIpfWAsIE0gPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudVwiLCBfXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIE4gPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9fdHJpZ2dlclwiLCB2XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFAgPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9fbWVudVwiLCB5XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEYgPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbVwiLCBiXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEkgPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9fZGl2aWRlclwiLCB4XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHQoKCkgPT4ge1xuXHRcdGxldCBlID0gKGUpID0+IHtcblx0XHRcdGUudGFyZ2V0IGluc3RhbmNlb2YgTm9kZSAmJiBELmN1cnJlbnQgJiYgIUQuY3VycmVudC5jb250YWlucyhlLnRhcmdldCkgJiYgay5jdXJyZW50ICYmICFrLmN1cnJlbnQuY29udGFpbnMoZS50YXJnZXQpICYmIEUoITEpO1xuXHRcdH0sIHQgPSAoZSkgPT4ge1xuXHRcdFx0ZS5rZXkgPT09IFwiRXNjYXBlXCIgJiYgRSghMSk7XG5cdFx0fTtcblx0XHRyZXR1cm4gZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIGUpLCBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCB0KSwgKCkgPT4ge1xuXHRcdFx0ZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIGUpLCBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCB0KTtcblx0XHR9O1xuXHR9LCBbXSksIHIoKCkgPT4ge1xuXHRcdGlmICghVCB8fCAhTy5jdXJyZW50KSByZXR1cm47XG5cdFx0bGV0IGUgPSAoKSA9PiB7XG5cdFx0XHRsZXQgZSA9IE8uY3VycmVudD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksIHQgPSBrLmN1cnJlbnQ7XG5cdFx0XHRpZiAoIWUgfHwgIXQpIHJldHVybjtcblx0XHRcdGxldCBuID0gZS53aWR0aCwgciA9IHdpbmRvdy5pbm5lcldpZHRoIC0gbiAtIDgsIGkgPSBoID09PSBcImVuZFwiID8gZS5yaWdodCAtIG4gOiBlLmxlZnQsIGEgPSBNYXRoLm1heCg4LCBNYXRoLm1pbihpLCByKSksIG8gPSBNYXRoLm1heCg4LCBlLmJvdHRvbSArIDEwKTtcblx0XHRcdHQuc3R5bGUucG9zaXRpb24gPSBcImZpeGVkXCIsIHQuc3R5bGUudG9wID0gYCR7b31weGAsIHQuc3R5bGUubGVmdCA9IGAke2F9cHhgLCB0LnN0eWxlLnJpZ2h0ID0gXCJhdXRvXCIsIHQuc3R5bGUubWluV2lkdGggPSBgJHtufXB4YCwgdC5zdHlsZS52aXNpYmlsaXR5ID0gXCJ2aXNpYmxlXCI7XG5cdFx0fTtcblx0XHRyZXR1cm4gay5jdXJyZW50ICYmIChrLmN1cnJlbnQuc3R5bGUudmlzaWJpbGl0eSA9IFwiaGlkZGVuXCIpLCBlKCksIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIGUpLCB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBlLCAhMCksICgpID0+IHtcblx0XHRcdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIGUpLCB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBlLCAhMCk7XG5cdFx0fTtcblx0fSwgW2gsIFRdKTtcblx0bGV0IEwgPSAoZSwgdCkgPT4ge1xuXHRcdGlmIChFKCExKSwgZS5kaXNhYmxlZCkge1xuXHRcdFx0dC5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRDPy4oZSwgdCksIGUub25TZWxlY3Q/LihlLCB0KTtcblx0fTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBsKFwiZGl2XCIsIHtcblx0XHRyZWY6IEQsXG5cdFx0Y2xhc3NOYW1lOiBNLFxuXHRcdC4uLncsXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gYyhcImJ1dHRvblwiLCB7XG5cdFx0XHRyZWY6IE8sXG5cdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0Y2xhc3NOYW1lOiBOLFxuXHRcdFx0XCJhcmlhLWhhc3BvcHVwXCI6IFwibWVudVwiLFxuXHRcdFx0XCJhcmlhLWNvbnRyb2xzXCI6IGosXG5cdFx0XHRcImFyaWEtbGFiZWxcIjogbSA/PyBlLFxuXHRcdFx0b25DbGljazogKCkgPT4gRSgoZSkgPT4gIWUpLFxuXHRcdFx0Y2hpbGRyZW46IHAgPz8gLyogQF9fUFVSRV9fICovIGwocywgeyBjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9fdHJpZ2dlckxhYmVsXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X190cmlnZ2VyQ2hldnJvblwiLFxuXHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogXCLilr5cIlxuXHRcdFx0fSldIH0pXG5cdFx0fSksIFQgJiYgdHlwZW9mIGRvY3VtZW50IDwgXCJ1XCIgPyBvKC8qIEBfX1BVUkVfXyAqLyBjKFwiZGl2XCIsIHtcblx0XHRcdHJlZjogayxcblx0XHRcdGlkOiBqLFxuXHRcdFx0Y2xhc3NOYW1lOiBQLFxuXHRcdFx0XCJhcmlhLWxhYmVsXCI6IGUsXG5cdFx0XHRjaGlsZHJlbjogZy5tYXAoKGUsIHQpID0+IHtcblx0XHRcdFx0aWYgKHUoZSkpIHJldHVybiAvKiBAX19QVVJFX18gKi8gYyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBJLFxuXHRcdFx0XHRcdHJvbGU6IFwic2VwYXJhdG9yXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIlxuXHRcdFx0XHR9LCBgZGl2aWRlci0ke3R9YCk7XG5cdFx0XHRcdGxldCBuID0gZChlKSwgciA9IFtcblx0XHRcdFx0XHRGLFxuXHRcdFx0XHRcdGUuZGlzYWJsZWQgPyBcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtLS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRcdFx0XHRlLmRhbmdlciA/IFwibmFicy11aS1kcm9wZG93bm1lbnVfX2l0ZW0tLWRhbmdlclwiIDogXCJcIlxuXHRcdFx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaSA9IHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IHIsXG5cdFx0XHRcdFx0XCJhcmlhLWRpc2FibGVkXCI6IGUuZGlzYWJsZWQgfHwgdm9pZCAwXG5cdFx0XHRcdH07XG5cdFx0XHRcdHJldHVybiBlLmhyZWYgPyAvKiBAX19QVVJFX18gKi8gbChcImFcIiwge1xuXHRcdFx0XHRcdC4uLmksXG5cdFx0XHRcdFx0aHJlZjogZS5kaXNhYmxlZCA/IHZvaWQgMCA6IGUuaHJlZixcblx0XHRcdFx0XHRvbkNsaWNrOiAodCkgPT4gTChlLCB0KSxcblx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kcm9wZG93bm1lbnVfX2l0ZW1MYWJlbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IG5cblx0XHRcdFx0XHR9KSwgZS5kZXNjcmlwdGlvbiA/IC8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kcm9wZG93bm1lbnVfX2l0ZW1EZXNjcmlwdGlvblwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUuZGVzY3JpcHRpb25cblx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdH0sIGYoZSwgdCkpIDogLyogQF9fUFVSRV9fICovIGwoXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiByLFxuXHRcdFx0XHRcdGRpc2FibGVkOiBlLmRpc2FibGVkLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICh0KSA9PiBMKGUsIHQpLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbUxhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogblxuXHRcdFx0XHRcdH0pLCBlLmRlc2NyaXB0aW9uID8gLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbURlc2NyaXB0aW9uXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5kZXNjcmlwdGlvblxuXHRcdFx0XHRcdH0pIDogbnVsbF1cblx0XHRcdFx0fSwgZihlLCB0KSk7XG5cdFx0XHR9KVxuXHRcdH0pLCBkb2N1bWVudC5ib2R5KSA6IG51bGxdXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2F2YXRhci51dGlscy50c1xuZnVuY3Rpb24gbShlKSB7XG5cdGxldCB0ID0gZS50cmltKCkuc3BsaXQoL1xccysvKS5maWx0ZXIoQm9vbGVhbik7XG5cdHJldHVybiB0Lmxlbmd0aCA9PT0gMCA/IFwiP1wiIDogdC5zbGljZSgwLCAyKS5tYXAoKGUpID0+IGVbMF0/LnRvVXBwZXJDYXNlKCkgPz8gXCJcIikuam9pbihcIlwiKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9BdmF0YXIudHN4XG52YXIgaCA9IGUoZnVuY3Rpb24oeyBhdXRoZW50aWNhdGVkOiBlID0gITEsIG5hbWU6IHQgPSBcIkd1ZXN0IHVzZXJcIiwgYXZhdGFyVXJsOiBuID0gXCJcIiwgbG9naW5IcmVmOiByLCBwcm9maWxlSHJlZjogaSA9IFwiI1wiLCBsb2dvdXRIcmVmOiBhID0gXCIjXCIsIG9uTG9naW5DbGljazogbywgb25Qcm9maWxlQ2xpY2s6IHUsIG9uTG9nb3V0Q2xpY2s6IGQsIGNsYXNzTmFtZTogZiA9IFwiXCIsIG1lbnVMYWJlbDogaCwgLi4uZyB9LCBfKSB7XG5cdGxldCB2ID0gdC50cmltKCkgfHwgXCJHdWVzdCB1c2VyXCIsIHkgPSBtKHYpLCBiID0gW1xuXHRcdFwibmFicy11aS1hdmF0YXJcIixcblx0XHRlID8gXCJuYWJzLXVpLWF2YXRhci0tYXV0aGVudGljYXRlZFwiIDogXCJuYWJzLXVpLWF2YXRhci0tdW5hdXRoZW50aWNhdGVkXCIsXG5cdFx0ZlxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgeCA9IChlKSA9PiB7XG5cdFx0byAmJiAoZS5wcmV2ZW50RGVmYXVsdCgpLCBvKGUpKTtcblx0fSwgUyA9IChlKSA9PiB7XG5cdFx0dSAmJiAoZS5wcmV2ZW50RGVmYXVsdCgpLCB1KGUpKTtcblx0fSwgQyA9IChlKSA9PiB7XG5cdFx0ZCAmJiAoZS5wcmV2ZW50RGVmYXVsdCgpLCBkKGUpKTtcblx0fTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBjKFwiZGl2XCIsIHtcblx0XHRyZWY6IF8sXG5cdFx0Y2xhc3NOYW1lOiBiLFxuXHRcdC4uLmcsXG5cdFx0Y2hpbGRyZW46IGUgPyAvKiBAX19QVVJFX18gKi8gYyhwLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1hdmF0YXJfX21lbnVSb290XCIsXG5cdFx0XHRsYWJlbDogYCR7dn0gYWNjb3VudCBtZW51YCxcblx0XHRcdHRyaWdnZXJBcmlhTGFiZWw6IGggPz8gYCR7dn0gYWNjb3VudCBtZW51YCxcblx0XHRcdG1lbnVBbGlnbjogXCJlbmRcIixcblx0XHRcdHRyaWdnZXJDb250ZW50OiAvKiBAX19QVVJFX18gKi8gbChzLCB7IGNoaWxkcmVuOiBbXG5cdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19hdmF0YXJcIixcblx0XHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBuID8gLyogQF9fUFVSRV9fICovIGMoXCJpbWdcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19pbWFnZVwiLFxuXHRcdFx0XHRcdFx0c3JjOiBuLFxuXHRcdFx0XHRcdFx0YWx0OiBcIlwiXG5cdFx0XHRcdFx0fSkgOiB5XG5cdFx0XHRcdH0pLFxuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gYyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWF2YXRhcl9fbmFtZVwiLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiB2XG5cdFx0XHRcdH0pLFxuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gYyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWF2YXRhcl9fY2hldnJvblwiLFxuXHRcdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFwi4pa+XCJcblx0XHRcdFx0fSlcblx0XHRcdF0gfSksXG5cdFx0XHR0cmlnZ2VyQ2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX190cmlnZ2VyXCIsXG5cdFx0XHRtZW51Q2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19tZW51XCIsXG5cdFx0XHRpdGVtQ2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19tZW51SXRlbVwiLFxuXHRcdFx0aXRlbXM6IFt7XG5cdFx0XHRcdGxhYmVsOiBcIlByb2ZpbGVcIixcblx0XHRcdFx0aHJlZjogaSxcblx0XHRcdFx0b25TZWxlY3Q6IChlLCB0KSA9PiBTKHQpXG5cdFx0XHR9LCB7XG5cdFx0XHRcdGxhYmVsOiBcIkxvZ291dFwiLFxuXHRcdFx0XHRocmVmOiBhLFxuXHRcdFx0XHRkYW5nZXI6ICEwLFxuXHRcdFx0XHRvblNlbGVjdDogKGUsIHQpID0+IEModClcblx0XHRcdH1dXG5cdFx0fSkgOiByID8gLyogQF9fUFVSRV9fICovIGwoXCJhXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWF2YXRhcl9fbG9naW5cIixcblx0XHRcdGhyZWY6IHIsXG5cdFx0XHRvbkNsaWNrOiB4LFxuXHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gYyhcInNwYW5cIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1hdmF0YXJfX2F2YXRhciBuYWJzLXVpLWF2YXRhcl9fYXZhdGFyLS1wbGFjZWhvbGRlclwiLFxuXHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogeVxuXHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWF2YXRhcl9fbG9naW5UZXh0XCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBcIkxvZ2luXCJcblx0XHRcdH0pXVxuXHRcdH0pIDogLyogQF9fUFVSRV9fICovIGwoXCJidXR0b25cIiwge1xuXHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWF2YXRhcl9fbG9naW5cIixcblx0XHRcdG9uQ2xpY2s6IHgsXG5cdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWF2YXRhcl9fYXZhdGFyIG5hYnMtdWktYXZhdGFyX19hdmF0YXItLXBsYWNlaG9sZGVyXCIsXG5cdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiB5XG5cdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19sb2dpblRleHRcIixcblx0XHRcdFx0Y2hpbGRyZW46IFwiTG9naW5cIlxuXHRcdFx0fSldXG5cdFx0fSlcblx0fSk7XG59KTtcbmguZGlzcGxheU5hbWUgPSBcIkF2YXRhclwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBoIGFzIEF2YXRhciB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgdCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9idXR0b24udXRpbHMudHNcbnZhciBuID0ge1xuXHRwcmltYXJ5OiBcIm5hYnMtdWktYnV0dG9uLS1wcmltYXJ5XCIsXG5cdHNlY29uZGFyeTogXCJuYWJzLXVpLWJ1dHRvbi0tc2Vjb25kYXJ5XCIsXG5cdGdob3N0OiBcIm5hYnMtdWktYnV0dG9uLS1naG9zdFwiXG59LCByID0gZShmdW5jdGlvbih7IGNoaWxkcmVuOiBlLCBjbGFzc05hbWU6IHIgPSBcIlwiLCB2YXJpYW50OiBpID0gXCJwcmltYXJ5XCIsIHR5cGU6IGEgPSBcImJ1dHRvblwiLCAuLi5vIH0sIHMpIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyB0KFwiYnV0dG9uXCIsIHtcblx0XHRyZWY6IHMsXG5cdFx0Y2xhc3NOYW1lOiBbXG5cdFx0XHRcIm5hYnMtdWktYnV0dG9uXCIsXG5cdFx0XHRuW2ldID8/IG4ucHJpbWFyeSxcblx0XHRcdHJcblx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHR0eXBlOiBhLFxuXHRcdC4uLm8sXG5cdFx0Y2hpbGRyZW46IGVcblx0fSk7XG59KTtcbnIuZGlzcGxheU5hbWUgPSBcIkJ1dHRvblwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyByIGFzIEJ1dHRvbiB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgdCwganN4cyBhcyBuIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2NhcmRzLnV0aWxzLnRzXG5mdW5jdGlvbiByKGUpIHtcblx0cmV0dXJuIGUgPT09IHZvaWQgMCA/IDEgOiBOdW1iZXIuaXNGaW5pdGUoZSkgPyBNYXRoLm1pbigxMiwgTWF0aC5tYXgoMSwgTWF0aC5mbG9vcihlKSkpIDogMTtcbn1cbmZ1bmN0aW9uIGkoZSwgdCwgbikge1xuXHRyZXR1cm4gdCA9PT0gXCJaXCIgPyBbLi4uZV0uc29ydCgodCwgcikgPT4ge1xuXHRcdGxldCBpID0gZS5maW5kSW5kZXgoKGUpID0+IGUuaWQgPT09IHQuaWQpLCBhID0gZS5maW5kSW5kZXgoKGUpID0+IGUuaWQgPT09IHIuaWQpLCBvID0gTWF0aC5mbG9vcihpIC8gbiksIHMgPSBNYXRoLmZsb29yKGEgLyBuKTtcblx0XHRpZiAobyAhPT0gcykgcmV0dXJuIG8gLSBzO1xuXHRcdGxldCBjID0gaSAlIG4sIGwgPSBhICUgbjtcblx0XHRyZXR1cm4gKG8gJSAyID09IDAgPyBjIDogbiAtIDEgLSBjKSAtIChzICUgMiA9PSAwID8gbCA6IG4gLSAxIC0gbCk7XG5cdH0pIDogZTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9DYXJkcy50c3hcbnZhciBhID0gZSgoeyBpdGVtczogZSwgbGF5b3V0OiBhID0gXCJOXCIsIGNvbHVtbnM6IG8sIGNsYXNzTmFtZTogcyA9IFwiXCIsIGl0ZW1DbGFzc05hbWU6IGMgPSBcIlwiLCBoZWFkZXJDbGFzc05hbWU6IGwgPSBcIlwiLCBjb250ZW50Q2xhc3NOYW1lOiB1ID0gXCJcIiwgYWN0aW9uc0NsYXNzTmFtZTogZCA9IFwiXCIsIC4uLmYgfSwgcCkgPT4ge1xuXHRsZXQgbSA9IHIobyksIGggPSBbXCJuYWJzLXVpLWNhcmRzXCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktY2FyZHNfX2dyaWRcIiwgYG5hYnMtdWktY2FyZHNfX2dyaWQtLWNvbHVtbnMtJHttfWBdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgXyA9IGkoZSwgYSwgbSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gdChcInNlY3Rpb25cIiwge1xuXHRcdHJlZjogcCxcblx0XHRjbGFzc05hbWU6IGgsXG5cdFx0Li4uZixcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIHQoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0Y2hpbGRyZW46IF8ubWFwKChlKSA9PiB7XG5cdFx0XHRcdGxldCByID0gW1wibmFicy11aS1jYXJkc19fY2FyZFwiLCBjXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGkgPSBlLmhlYWRlciAhPSBudWxsICYmIGUuaGVhZGVyICE9PSAhMSwgYSA9IGUuY29udGVudCAhPSBudWxsICYmIGUuY29udGVudCAhPT0gITEsIG8gPSBlLmFjdGlvbnMgIT0gbnVsbCAmJiBlLmFjdGlvbnMgIT09ICExO1xuXHRcdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG4oXCJhcnRpY2xlXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IHIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFtcblx0XHRcdFx0XHRcdGkgPyAvKiBAX19QVVJFX18gKi8gdChcImhlYWRlclwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogW1wibmFicy11aS1jYXJkc19faGVhZGVyXCIsIGxdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUuaGVhZGVyXG5cdFx0XHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdFx0XHRhID8gLyogQF9fUFVSRV9fICovIHQoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFtcIm5hYnMtdWktY2FyZHNfX2NvbnRlbnRcIiwgdV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5jb250ZW50XG5cdFx0XHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdFx0XHRvID8gLyogQF9fUFVSRV9fICovIHQoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFtcIm5hYnMtdWktY2FyZHNfX2FjdGlvbnNcIiwgZF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5hY3Rpb25zXG5cdFx0XHRcdFx0XHR9KSA6IG51bGxcblx0XHRcdFx0XHRdXG5cdFx0XHRcdH0sIGUuaWQpO1xuXHRcdFx0fSlcblx0XHR9KVxuXHR9KTtcbn0pO1xuYS5kaXNwbGF5TmFtZSA9IFwiQ2FyZHNcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYSBhcyBDYXJkcyB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlLCB1c2VJZCBhcyB0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgbiwganN4cyBhcyByIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2NoZWNrYm94LnV0aWxzLnRzXG52YXIgaSA9IHtcblx0cmlnaHQ6IFwibmFicy11aS1jaGVja2JveC0tbGFiZWwtcmlnaHRcIixcblx0bGVmdDogXCJuYWJzLXVpLWNoZWNrYm94LS1sYWJlbC1sZWZ0XCIsXG5cdHRvcDogXCJuYWJzLXVpLWNoZWNrYm94LS1sYWJlbC10b3BcIixcblx0Ym90dG9tOiBcIm5hYnMtdWktY2hlY2tib3gtLWxhYmVsLWJvdHRvbVwiXG59LCBhID0gZShmdW5jdGlvbih7IGxhYmVsOiBlID0gXCJDaGVja2JveFwiLCBsYWJlbFBvc2l0aW9uOiBhID0gXCJyaWdodFwiLCBjbGFzc05hbWU6IG8gPSBcIlwiLCBpbnB1dENsYXNzTmFtZTogcyA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBjID0gXCJcIiwgaWQ6IGwsIGRpc2FibGVkOiB1LCAuLi5kIH0sIGYpIHtcblx0bGV0IHAgPSB0KCksIG0gPSBsID8/IGBuYWJzLXVpLWNoZWNrYm94LSR7cC5yZXBsYWNlKC86L2csIFwiXCIpfWAsIGggPSBbXG5cdFx0XCJuYWJzLXVpLWNoZWNrYm94XCIsXG5cdFx0dSA/IFwibmFicy11aS1jaGVja2JveC0tZGlzYWJsZWRcIiA6IFwiXCIsXG5cdFx0aVthXSA/PyBpLnJpZ2h0LFxuXHRcdG9cblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGcgPSBbXCJuYWJzLXVpLWNoZWNrYm94X19pbnB1dFwiLCBzXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIF8gPSBbXCJuYWJzLXVpLWNoZWNrYm94X19sYWJlbFwiLCBjXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcihcImxhYmVsXCIsIHtcblx0XHRjbGFzc05hbWU6IGgsXG5cdFx0aHRtbEZvcjogbSxcblx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBuKFwiaW5wdXRcIiwge1xuXHRcdFx0cmVmOiBmLFxuXHRcdFx0aWQ6IG0sXG5cdFx0XHRjbGFzc05hbWU6IGcsXG5cdFx0XHR0eXBlOiBcImNoZWNrYm94XCIsXG5cdFx0XHRkaXNhYmxlZDogdSxcblx0XHRcdC4uLmRcblx0XHR9KSwgLyogQF9fUFVSRV9fICovIG4oXCJzcGFuXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXyxcblx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0fSldXG5cdH0pO1xufSk7XG5hLmRpc3BsYXlOYW1lID0gXCJDaGVja2JveFwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhIGFzIENoZWNrYm94IH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyB0LCBqc3hzIGFzIG4gfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvY29kZS51dGlscy50c1xudmFyIHIgPSB7XG5cdGh0bWw6IFwiSFRNTFwiLFxuXHRjc3M6IFwiQ1NTXCIsXG5cdGpzb246IFwiSlNPTlwiLFxuXHRjc2hhcnA6IFwiQyNcIlxufSwgaSA9IGUoKHsgY29kZTogZSwgbGFuZ3VhZ2U6IGkgPSBcImh0bWxcIiwgc2hvd0xpbmVOdW1iZXJzOiBhID0gITEsIHdyYXA6IG8gPSAhMSwgdGl0bGU6IHMsIGNsYXNzTmFtZTogYyA9IFwiXCIsIHByZUNsYXNzTmFtZTogbCA9IFwiXCIsIGNvZGVDbGFzc05hbWU6IHUgPSBcIlwiLCAuLi5kIH0sIGYpID0+IHtcblx0bGV0IHAgPSBbXCJuYWJzLXVpLWNvZGVcIiwgY10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBtID0gW1xuXHRcdFwibmFicy11aS1jb2RlX19wcmVcIixcblx0XHRvID8gXCJuYWJzLXVpLWNvZGVfX3ByZS0td3JhcFwiIDogXCJcIixcblx0XHRhID8gXCJuYWJzLXVpLWNvZGVfX3ByZS0tbGluZU51bWJlcnNcIiA6IFwiXCIsXG5cdFx0bFxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaCA9IFtcblx0XHRcIm5hYnMtdWktY29kZV9fc25pcHBldFwiLFxuXHRcdGBuYWJzLXVpLWNvZGVfX3NuaXBwZXQtLSR7aX1gLFxuXHRcdHVcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGcgPSBlLnJlcGxhY2UoL1xcclxcbi9nLCBcIlxcblwiKSwgXyA9IGcuc3BsaXQoXCJcXG5cIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gbihcInNlY3Rpb25cIiwge1xuXHRcdHJlZjogZixcblx0XHRjbGFzc05hbWU6IHAsXG5cdFx0Li4uZCxcblx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBuKFwiaGVhZGVyXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvZGVfX2hlYWRlclwiLFxuXHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gdChcInNwYW5cIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb2RlX19sYW5ndWFnZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogcltpXVxuXHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyB0KFwic3BhblwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvZGVfX3RpdGxlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBzID8/IFwiU25pcHBldFwiXG5cdFx0XHR9KV1cblx0XHR9KSwgLyogQF9fUFVSRV9fICovIHQoXCJwcmVcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBtLFxuXHRcdFx0Y2hpbGRyZW46IGEgPyAvKiBAX19QVVJFX18gKi8gdChcImNvZGVcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IGgsXG5cdFx0XHRcdGNoaWxkcmVuOiBfLm1hcCgoZSwgcikgPT4gLyogQF9fUFVSRV9fICovIG4oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb2RlX19saW5lXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gdChcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29kZV9fbGluZU51bWJlclwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IHIgKyAxXG5cdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyB0KFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb2RlX19saW5lVGV4dFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUgfHwgXCIgXCJcblx0XHRcdFx0XHR9KV1cblx0XHRcdFx0fSwgcikpXG5cdFx0XHR9KSA6IC8qIEBfX1BVUkVfXyAqLyB0KFwiY29kZVwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogaCxcblx0XHRcdFx0Y2hpbGRyZW46IGdcblx0XHRcdH0pXG5cdFx0fSldXG5cdH0pO1xufSk7XG5pLmRpc3BsYXlOYW1lID0gXCJDb2RlXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGkgYXMgQ29kZSB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlLCB1c2VFZmZlY3QgYXMgdCwgdXNlSWQgYXMgbiwgdXNlTWVtbyBhcyByLCB1c2VSZWYgYXMgaSwgdXNlU3RhdGUgYXMgYSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIG8sIGpzeHMgYXMgcyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9jb21ib2JveC51dGlscy50c1xuZnVuY3Rpb24gYyhlKSB7XG5cdHJldHVybiBlLmxhYmVsID8/IGUuY2hpbGRyZW4gPz8gZS52YWx1ZTtcbn1cbmZ1bmN0aW9uIGwoZSkge1xuXHRsZXQgdCA9IGMoZSk7XG5cdHJldHVybiB0eXBlb2YgdCA9PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB0ID09IFwibnVtYmVyXCIgPyBgJHt0fWAgOiBlLnZhbHVlO1xufVxuZnVuY3Rpb24gdShlLCB0KSB7XG5cdHJldHVybiBlLnZhbHVlIHx8IGBpdGVtLSR7dH1gO1xufVxuZnVuY3Rpb24gZChlLCB0KSB7XG5cdHJldHVybiB0ID09IG51bGwgPyBudWxsIDogZS5maW5kKChlKSA9PiBlLnZhbHVlID09PSB0KSA/PyBudWxsO1xufVxuZnVuY3Rpb24gZihlKSB7XG5cdHJldHVybiBlLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL0NvbWJvYm94LnRzeFxudmFyIHAgPSBlKGZ1bmN0aW9uKHsgaXRlbXM6IGUgPSBbXSwgdmFsdWU6IHAsIGRlZmF1bHRWYWx1ZTogbSwgYWxsb3dOdWxsOiBoID0gITEsIG51bGxMYWJlbDogZyA9IFwiTm9uZVwiLCBjbGFzc05hbWU6IF8gPSBcIlwiLCBpZDogdiwgZGlzYWJsZWQ6IHksIHBsYWNlaG9sZGVyOiBiLCBvblZhbHVlQ2hhbmdlOiB4LCBvbkZvY3VzOiBTLCBvbkJsdXI6IEMsIG9uS2V5RG93bjogdywgLi4uVCB9LCBFKSB7XG5cdGxldCBEID0gbigpLCBPID0gaShudWxsKSwgayA9IGBuYWJzLXVpLWNvbWJvYm94LWxpc3QtJHtELnJlcGxhY2UoLzovZywgXCJcIil9YCwgQSA9IHYgPz8gYG5hYnMtdWktY29tYm9ib3gtJHtELnJlcGxhY2UoLzovZywgXCJcIil9YCwgaiA9IHAgIT09IHZvaWQgMCwgW00sIE5dID0gYShtID8/IG51bGwpLCBQID0gaiA/IHAgOiBNLCBGID0gZChlLCBQKSwgSSA9IEYgPyBsKEYpIDogUCA/PyBcIlwiLCBbTCwgUl0gPSBhKCExKSwgW3osIEJdID0gYShJKSwgW1YsIEhdID0gYSgwKSwgVSA9IHIoKCkgPT4ge1xuXHRcdGxldCB0ID0gZih6KTtcblx0XHRyZXR1cm4gZS5maWx0ZXIoKGUpID0+IHtcblx0XHRcdGxldCBuID0gZihsKGUpKTtcblx0XHRcdHJldHVybiB0Lmxlbmd0aCA9PT0gMCB8fCBuLmluY2x1ZGVzKHQpO1xuXHRcdH0pO1xuXHR9LCBbZSwgel0pLCBXID0gaCA/IFt7XG5cdFx0dmFsdWU6IFwiXCIsXG5cdFx0bGFiZWw6IGcsXG5cdFx0ZGlzYWJsZWQ6ICExLFxuXHRcdF9fbnVsbDogITBcblx0fSwgLi4uVV0gOiBVO1xuXHR0KCgpID0+IHtcblx0XHRMIHx8IEIoSSk7XG5cdH0sIFtMLCBJXSksIHQoKCkgPT4ge1xuXHRcdFYgPj0gVy5sZW5ndGggJiYgSChXLmxlbmd0aCA9PT0gMCA/IDAgOiBXLmxlbmd0aCAtIDEpO1xuXHR9LCBbViwgVy5sZW5ndGhdKSwgdCgoKSA9PiB7XG5cdFx0bGV0IGUgPSAoZSkgPT4ge1xuXHRcdFx0Ty5jdXJyZW50ICYmIGUudGFyZ2V0IGluc3RhbmNlb2YgTm9kZSAmJiAhTy5jdXJyZW50LmNvbnRhaW5zKGUudGFyZ2V0KSAmJiBSKCExKTtcblx0XHR9O1xuXHRcdHJldHVybiBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcmRvd25cIiwgZSksICgpID0+IHtcblx0XHRcdGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVyZG93blwiLCBlKTtcblx0XHR9O1xuXHR9LCBbXSk7XG5cdGxldCBHID0gKGUsIHQpID0+IHtcblx0XHRqIHx8IE4oZSksIHg/LihlLCB0KSwgUighMSksIEIodCA/IGwodCkgOiBcIlwiKTtcblx0fSwgSyA9IChlKSA9PiB7XG5cdFx0bGV0IHQgPSBXW2VdO1xuXHRcdGlmICh0KSB7XG5cdFx0XHRpZiAoXCJfX251bGxcIiBpbiB0KSB7XG5cdFx0XHRcdEcobnVsbCwgbnVsbCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdHQuZGlzYWJsZWQgfHwgRyh0LnZhbHVlLCB0KTtcblx0XHR9XG5cdH0sIHEgPSAoZSkgPT4ge1xuXHRcdFIoITApLCBCKEkpLCBIKDApLCBTPy4oZSk7XG5cdH0sIEogPSAoZSkgPT4ge1xuXHRcdFIoITEpLCBCKEkpLCBDPy4oZSk7XG5cdH0sIFkgPSAoZSkgPT4ge1xuXHRcdFIoITApLCBCKGUudGFyZ2V0LnZhbHVlKSwgSCgwKTtcblx0fSwgWCA9IChlKSA9PiB7XG5cdFx0aWYgKGUua2V5ID09PSBcIkFycm93RG93blwiKSB7XG5cdFx0XHRlLnByZXZlbnREZWZhdWx0KCksIFIoITApLCBIKChlKSA9PiBNYXRoLm1pbihlICsgMSwgTWF0aC5tYXgoVy5sZW5ndGggLSAxLCAwKSkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoZS5rZXkgPT09IFwiQXJyb3dVcFwiKSB7XG5cdFx0XHRlLnByZXZlbnREZWZhdWx0KCksIFIoITApLCBIKChlKSA9PiBNYXRoLm1heChlIC0gMSwgMCkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoZS5rZXkgPT09IFwiRW50ZXJcIikge1xuXHRcdFx0TCAmJiAoZS5wcmV2ZW50RGVmYXVsdCgpLCBLKFYpKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0aWYgKGUua2V5ID09PSBcIkVzY2FwZVwiKSB7XG5cdFx0XHRlLnByZXZlbnREZWZhdWx0KCksIFIoITEpLCBCKEkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHR3Py4oZSk7XG5cdH0sIFogPSBMID8gLyogQF9fUFVSRV9fICovIG8oXCJpbnB1dFwiLCB7XG5cdFx0cmVmOiBFLFxuXHRcdGlkOiBBLFxuXHRcdHJvbGU6IFwiY29tYm9ib3hcIixcblx0XHRcImFyaWEtaGFzcG9wdXBcIjogXCJsaXN0Ym94XCIsXG5cdFx0XCJhcmlhLWF1dG9jb21wbGV0ZVwiOiBcImxpc3RcIixcblx0XHRcImFyaWEtZXhwYW5kZWRcIjogXCJ0cnVlXCIsXG5cdFx0XCJhcmlhLWNvbnRyb2xzXCI6IGssXG5cdFx0XCJhcmlhLWFjdGl2ZWRlc2NlbmRhbnRcIjogV1tWXSA/IGAke2t9LW9wdGlvbi0ke1Z9YCA6IHZvaWQgMCxcblx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb21ib2JveF9faW5wdXRcIixcblx0XHRkaXNhYmxlZDogeSxcblx0XHRwbGFjZWhvbGRlcjogYixcblx0XHR2YWx1ZTogeixcblx0XHRvbkZvY3VzOiBxLFxuXHRcdG9uQmx1cjogSixcblx0XHRvbkNoYW5nZTogWSxcblx0XHRvbktleURvd246IFgsXG5cdFx0Li4uVFxuXHR9KSA6IC8qIEBfX1BVUkVfXyAqLyBvKFwiaW5wdXRcIiwge1xuXHRcdHJlZjogRSxcblx0XHRpZDogQSxcblx0XHRyb2xlOiBcImNvbWJvYm94XCIsXG5cdFx0XCJhcmlhLWhhc3BvcHVwXCI6IFwibGlzdGJveFwiLFxuXHRcdFwiYXJpYS1hdXRvY29tcGxldGVcIjogXCJsaXN0XCIsXG5cdFx0XCJhcmlhLWV4cGFuZGVkXCI6IFwiZmFsc2VcIixcblx0XHRcImFyaWEtY29udHJvbHNcIjogayxcblx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb21ib2JveF9faW5wdXRcIixcblx0XHRkaXNhYmxlZDogeSxcblx0XHRwbGFjZWhvbGRlcjogYixcblx0XHR2YWx1ZTogeixcblx0XHRvbkZvY3VzOiBxLFxuXHRcdG9uQmx1cjogSixcblx0XHRvbkNoYW5nZTogWSxcblx0XHRvbktleURvd246IFgsXG5cdFx0Li4uVFxuXHR9KTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRyZWY6IE8sXG5cdFx0Y2xhc3NOYW1lOiBbXG5cdFx0XHRcIm5hYnMtdWktY29tYm9ib3hcIixcblx0XHRcdEwgPyBcIm5hYnMtdWktY29tYm9ib3gtLW9wZW5cIiA6IFwiXCIsXG5cdFx0XHR5ID8gXCJuYWJzLXVpLWNvbWJvYm94LS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRcdF9cblx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHRjaGlsZHJlbjogW1osIEwgPyAvKiBAX19QVVJFX18gKi8gbyhcImRpdlwiLCB7XG5cdFx0XHRpZDogayxcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19wb3B1cFwiLFxuXHRcdFx0cm9sZTogXCJsaXN0Ym94XCIsXG5cdFx0XHRcImFyaWEtbGFiZWxcIjogXCJDb21ib2JveCBvcHRpb25zXCIsXG5cdFx0XHRjaGlsZHJlbjogVy5sZW5ndGggPT09IDAgPyAvKiBAX19QVVJFX18gKi8gbyhcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19lbXB0eVwiLFxuXHRcdFx0XHRyb2xlOiBcIm9wdGlvblwiLFxuXHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFwiYXJpYS1zZWxlY3RlZFwiOiBcImZhbHNlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBcIk5vIG9wdGlvbnMgZm91bmRcIlxuXHRcdFx0fSkgOiBXLm1hcCgoZSwgdCkgPT4ge1xuXHRcdFx0XHRsZXQgbiA9IFwiX19udWxsXCIgaW4gZSwgciA9ICFuICYmIFAgPT09IGUudmFsdWUsIGkgPSBbXG5cdFx0XHRcdFx0XCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25cIixcblx0XHRcdFx0XHR0ID09PSBWID8gXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb24tLWFjdGl2ZVwiIDogXCJcIixcblx0XHRcdFx0XHRyID8gXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb24tLXNlbGVjdGVkXCIgOiBcIlwiLFxuXHRcdFx0XHRcdG4gPyBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbi0tbnVsbFwiIDogXCJcIixcblx0XHRcdFx0XHRlLmRpc2FibGVkID8gXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb24tLWRpc2FibGVkXCIgOiBcIlwiXG5cdFx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRcdFx0XHRyZXR1cm4gbiA/IFAgPT09IG51bGwgPyAvKiBAX19QVVJFX18gKi8gbyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0aWQ6IGAke2t9LW9wdGlvbi0ke3R9YCxcblx0XHRcdFx0XHRjbGFzc05hbWU6IGksXG5cdFx0XHRcdFx0cm9sZTogXCJvcHRpb25cIixcblx0XHRcdFx0XHRcImFyaWEtc2VsZWN0ZWRcIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWRpc2FibGVkXCI6IFwiZmFsc2VcIixcblx0XHRcdFx0XHR0YWJJbmRleDogLTEsXG5cdFx0XHRcdFx0b25Nb3VzZURvd246IChlKSA9PiBlLnByZXZlbnREZWZhdWx0KCksXG5cdFx0XHRcdFx0b25DbGljazogKCkgPT4gSyh0KSxcblx0XHRcdFx0XHRvbk1vdXNlRW50ZXI6ICgpID0+IEgodCksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb21ib2JveF9fb3B0aW9uTGFiZWxcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBnXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSwgXCJudWxsXCIpIDogLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdFx0XHRcdGlkOiBgJHtrfS1vcHRpb24tJHt0fWAsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBpLFxuXHRcdFx0XHRcdHJvbGU6IFwib3B0aW9uXCIsXG5cdFx0XHRcdFx0XCJhcmlhLXNlbGVjdGVkXCI6IFwiZmFsc2VcIixcblx0XHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogXCJmYWxzZVwiLFxuXHRcdFx0XHRcdHRhYkluZGV4OiAtMSxcblx0XHRcdFx0XHRvbk1vdXNlRG93bjogKGUpID0+IGUucHJldmVudERlZmF1bHQoKSxcblx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBLKHQpLFxuXHRcdFx0XHRcdG9uTW91c2VFbnRlcjogKCkgPT4gSCh0KSxcblx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25MYWJlbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGdcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9LCBcIm51bGxcIikgOiBlLmRpc2FibGVkID8gciA/IC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRpZDogYCR7a30tb3B0aW9uLSR7dH1gLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogaSxcblx0XHRcdFx0XHRyb2xlOiBcIm9wdGlvblwiLFxuXHRcdFx0XHRcdFwiYXJpYS1zZWxlY3RlZFwiOiBcInRydWVcIixcblx0XHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0dGFiSW5kZXg6IC0xLFxuXHRcdFx0XHRcdG9uTW91c2VEb3duOiAoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IEsodCksXG5cdFx0XHRcdFx0b25Nb3VzZUVudGVyOiAoKSA9PiBIKHQpLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25MYWJlbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGMoZSlcblx0XHRcdFx0XHR9KSwgZS5kZXNjcmlwdGlvbiA/IC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb21ib2JveF9fb3B0aW9uRGVzY3JpcHRpb25cIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmRlc2NyaXB0aW9uXG5cdFx0XHRcdFx0fSkgOiBudWxsXVxuXHRcdFx0XHR9LCB1KGUsIHQpKSA6IC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRpZDogYCR7a30tb3B0aW9uLSR7dH1gLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogaSxcblx0XHRcdFx0XHRyb2xlOiBcIm9wdGlvblwiLFxuXHRcdFx0XHRcdFwiYXJpYS1zZWxlY3RlZFwiOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWRpc2FibGVkXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdHRhYkluZGV4OiAtMSxcblx0XHRcdFx0XHRvbk1vdXNlRG93bjogKGUpID0+IGUucHJldmVudERlZmF1bHQoKSxcblx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBLKHQpLFxuXHRcdFx0XHRcdG9uTW91c2VFbnRlcjogKCkgPT4gSCh0KSxcblx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb21ib2JveF9fb3B0aW9uTGFiZWxcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBjKGUpXG5cdFx0XHRcdFx0fSksIGUuZGVzY3JpcHRpb24gPyAvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbkRlc2NyaXB0aW9uXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5kZXNjcmlwdGlvblxuXHRcdFx0XHRcdH0pIDogbnVsbF1cblx0XHRcdFx0fSwgdShlLCB0KSkgOiByID8gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGlkOiBgJHtrfS1vcHRpb24tJHt0fWAsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBpLFxuXHRcdFx0XHRcdHJvbGU6IFwib3B0aW9uXCIsXG5cdFx0XHRcdFx0XCJhcmlhLXNlbGVjdGVkXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdFwiYXJpYS1kaXNhYmxlZFwiOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0dGFiSW5kZXg6IC0xLFxuXHRcdFx0XHRcdG9uTW91c2VEb3duOiAoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IEsodCksXG5cdFx0XHRcdFx0b25Nb3VzZUVudGVyOiAoKSA9PiBIKHQpLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25MYWJlbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGMoZSlcblx0XHRcdFx0XHR9KSwgZS5kZXNjcmlwdGlvbiA/IC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb21ib2JveF9fb3B0aW9uRGVzY3JpcHRpb25cIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmRlc2NyaXB0aW9uXG5cdFx0XHRcdFx0fSkgOiBudWxsXVxuXHRcdFx0XHR9LCB1KGUsIHQpKSA6IC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRpZDogYCR7a30tb3B0aW9uLSR7dH1gLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogaSxcblx0XHRcdFx0XHRyb2xlOiBcIm9wdGlvblwiLFxuXHRcdFx0XHRcdFwiYXJpYS1zZWxlY3RlZFwiOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWRpc2FibGVkXCI6IFwiZmFsc2VcIixcblx0XHRcdFx0XHR0YWJJbmRleDogLTEsXG5cdFx0XHRcdFx0b25Nb3VzZURvd246IChlKSA9PiBlLnByZXZlbnREZWZhdWx0KCksXG5cdFx0XHRcdFx0b25DbGljazogKCkgPT4gSyh0KSxcblx0XHRcdFx0XHRvbk1vdXNlRW50ZXI6ICgpID0+IEgodCksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbkxhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogYyhlKVxuXHRcdFx0XHRcdH0pLCBlLmRlc2NyaXB0aW9uID8gLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25EZXNjcmlwdGlvblwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUuZGVzY3JpcHRpb25cblx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdH0sIHUoZSwgdCkpO1xuXHRcdFx0fSlcblx0XHR9KSA6IG51bGxdXG5cdH0pO1xufSk7XG5wLmRpc3BsYXlOYW1lID0gXCJDb21ib2JveFwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBwIGFzIENvbWJvYm94IH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUlkIGFzIHQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBuLCBqc3hzIGFzIHIgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvZGF0ZXBpY2tlci51dGlscy50c1xudmFyIGkgPSB7XG5cdG5vbmU6IFwibmFicy11aS1kYXRlcGlja2VyLS1sYWJlbC1ub25lXCIsXG5cdHRvcDogXCJuYWJzLXVpLWRhdGVwaWNrZXItLWxhYmVsLXRvcFwiLFxuXHRsZWZ0OiBcIm5hYnMtdWktZGF0ZXBpY2tlci0tbGFiZWwtbGVmdFwiXG59LCBhID0gZSgoeyBsYWJlbDogZSwgbGFiZWxQb3NpdGlvbjogYSA9IFwidG9wXCIsIGNsYXNzTmFtZTogbyA9IFwiXCIsIGlucHV0Q2xhc3NOYW1lOiBzID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IGMgPSBcIlwiLCBhbGxvd051bGw6IGwgPSAhMSwgaWQ6IHUsIHZhbHVlOiBkLCBvbkNoYW5nZTogZiwgb25DbGljazogcCwgb25WYWx1ZUNoYW5nZTogbSwgLi4uaCB9LCBnKSA9PiB7XG5cdGxldCBfID0gdCgpLCB2ID0gdSA/PyBgbmFicy11aS1kYXRlcGlja2VyLSR7Xy5yZXBsYWNlKC86L2csIFwiXCIpfWAsIHkgPSBbXG5cdFx0XCJuYWJzLXVpLWRhdGVwaWNrZXJcIixcblx0XHRlID8gaVthXSA/PyBpLnRvcCA6IFwiXCIsXG5cdFx0b1xuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgYiA9IFtcIm5hYnMtdWktZGF0ZXBpY2tlcl9faW5wdXRcIiwgc10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCB4ID0gW1wibmFicy11aS1kYXRlcGlja2VyX19sYWJlbFwiLCBjXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcihcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiB5LFxuXHRcdGNoaWxkcmVuOiBbZSA/IC8qIEBfX1BVUkVfXyAqLyBuKFwibGFiZWxcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiB4LFxuXHRcdFx0aHRtbEZvcjogdixcblx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0fSkgOiBudWxsLCAvKiBAX19QVVJFX18gKi8gbihcImlucHV0XCIsIHtcblx0XHRcdHJlZjogZyxcblx0XHRcdGlkOiB2LFxuXHRcdFx0Y2xhc3NOYW1lOiBiLFxuXHRcdFx0dHlwZTogXCJkYXRlXCIsXG5cdFx0XHR2YWx1ZTogZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogZCA/PyBcIlwiLFxuXHRcdFx0b25DbGljazogKGUpID0+IHtcblx0XHRcdFx0aWYgKHA/LihlKSwgZS5kZWZhdWx0UHJldmVudGVkKSByZXR1cm47XG5cdFx0XHRcdGxldCB0ID0gZS5jdXJyZW50VGFyZ2V0O1xuXHRcdFx0XHR0LmRpc2FibGVkIHx8IHQucmVhZE9ubHkgfHwgdC5zaG93UGlja2VyPy4oKTtcblx0XHRcdH0sXG5cdFx0XHRvbkNoYW5nZTogKGUpID0+IHtcblx0XHRcdFx0Zj8uKGUpLCBtPy4obCAmJiBlLnRhcmdldC52YWx1ZSA9PT0gXCJcIiA/IG51bGwgOiBlLnRhcmdldC52YWx1ZSwgZSk7XG5cdFx0XHR9LFxuXHRcdFx0Li4uaFxuXHRcdH0pXVxuXHR9KTtcbn0pO1xuYS5kaXNwbGF5TmFtZSA9IFwiRGF0ZVBpY2tlclwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhIGFzIERhdGVQaWNrZXIgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSwgdXNlRWZmZWN0IGFzIHQsIHVzZUlkIGFzIG4sIHVzZVJlZiBhcyByIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgaSwganN4cyBhcyBhIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL0RpYWxvZy50c3hcbnZhciBvID0gXCJhW2hyZWZdLCBhcmVhW2hyZWZdLCBidXR0b246bm90KFtkaXNhYmxlZF0pLCBpbnB1dDpub3QoW2Rpc2FibGVkXSk6bm90KFt0eXBlPVxcXCJoaWRkZW5cXFwiXSksIHNlbGVjdDpub3QoW2Rpc2FibGVkXSksIHRleHRhcmVhOm5vdChbZGlzYWJsZWRdKSwgW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVxcXCItMVxcXCJdKVwiO1xuZnVuY3Rpb24gcyhlKSB7XG5cdHJldHVybiBBcnJheS5mcm9tKGUucXVlcnlTZWxlY3RvckFsbChvKSkuZmlsdGVyKChlKSA9PiAhZS5oYXNBdHRyaWJ1dGUoXCJkaXNhYmxlZFwiKSAmJiBlLmdldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIpICE9PSBcInRydWVcIik7XG59XG52YXIgYyA9IGUoZnVuY3Rpb24oeyB0aXRsZTogZSwgZGVzY3JpcHRpb246IG8sIGhlYWRlcjogYywgZm9vdGVyOiBsLCBzaG93SGVhZGVyOiB1ID0gITAsIHNob3dGb290ZXI6IGQgPSAhMCwgb25SZXF1ZXN0Q2xvc2U6IGYsIGNsb3NlT25CYWNrZHJvcENsaWNrOiBwID0gITAsIGNsb3NlT25Fc2NhcGU6IG0gPSAhMCwgaW5pdGlhbEZvY3VzU2VsZWN0b3I6IGgsIGRpYWxvZ1JvbGU6IGcgPSBcImRpYWxvZ1wiLCBjbGFzc05hbWU6IF8gPSBcIlwiLCBiYWNrZHJvcENsYXNzTmFtZTogdiA9IFwiXCIsIGhlYWRlckNsYXNzTmFtZTogeSA9IFwiXCIsIGRlc2NyaXB0aW9uQ2xhc3NOYW1lOiBiID0gXCJcIiwgY29udGVudENsYXNzTmFtZTogeCA9IFwiXCIsIGZvb3RlckNsYXNzTmFtZTogUyA9IFwiXCIsIG9uS2V5RG93bjogQywgdGFiSW5kZXg6IHcsIGNoaWxkcmVuOiBULCAuLi5FIH0sIEQpIHtcblx0bGV0IE8gPSByKG51bGwpLCBrID0gcihudWxsKSwgQSA9IGBuYWJzLXVpLWRpYWxvZy10aXRsZS0ke24oKS5yZXBsYWNlKC86L2csIFwiXCIpfWAsIGogPSBgbmFicy11aS1kaWFsb2ctZGVzY3JpcHRpb24tJHtuKCkucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBNID0gRVtcImFyaWEtbGFiZWxsZWRieVwiXSwgTiA9IEVbXCJhcmlhLWRlc2NyaWJlZGJ5XCJdLCBQID0gIWMgJiYgISFlLCBGID0gISFvLCBJID0gdSAmJiAoISFjIHx8IFApLCBMID0gZCAmJiBsICE9IG51bGwsIFIgPSBNID8/IChQID8gQSA6IHZvaWQgMCksIHogPSBOID8/IChGID8gaiA6IHZvaWQgMCksIEIgPSBbXCJuYWJzLXVpLWRpYWxvZ19fYmFja2Ryb3BcIiwgdl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBWID0gW1wibmFicy11aS1kaWFsb2dcIiwgX10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBIID0gW1wibmFicy11aS1kaWFsb2dfX2hlYWRlclwiLCB5XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFUgPSBbXCJuYWJzLXVpLWRpYWxvZ19fZGVzY3JpcHRpb25cIiwgYl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBXID0gW1wibmFicy11aS1kaWFsb2dfX2NvbnRlbnRcIiwgeF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBHID0gW1wibmFicy11aS1kaWFsb2dfX2Zvb3RlclwiLCBTXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiB0KCgpID0+IHtcblx0XHRsZXQgZSA9IE8uY3VycmVudDtcblx0XHRpZiAoIWUpIHJldHVybjtcblx0XHRpZiAoay5jdXJyZW50ID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50ID8gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA6IG51bGwsIGgpIHRyeSB7XG5cdFx0XHRsZXQgdCA9IGUucXVlcnlTZWxlY3RvcihoKTtcblx0XHRcdGlmICh0KSByZXR1cm4gdC5mb2N1cygpLCAoKSA9PiB7XG5cdFx0XHRcdGsuY3VycmVudD8uZm9jdXMoKSwgay5jdXJyZW50ID0gbnVsbDtcblx0XHRcdH07XG5cdFx0fSBjYXRjaCB7fVxuXHRcdGxldCB0ID0gcyhlKTtcblx0XHRyZXR1cm4gdC5sZW5ndGggPiAwID8gdFswXS5mb2N1cygpIDogZS5mb2N1cygpLCAoKSA9PiB7XG5cdFx0XHRrLmN1cnJlbnQ/LmZvY3VzKCksIGsuY3VycmVudCA9IG51bGw7XG5cdFx0fTtcblx0fSwgW2hdKSwgLyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdGNsYXNzTmFtZTogQixcblx0XHRyb2xlOiBcInByZXNlbnRhdGlvblwiLFxuXHRcdG9uQ2xpY2s6IChlKSA9PiB7XG5cdFx0XHQhcCB8fCBlLnRhcmdldCAhPT0gZS5jdXJyZW50VGFyZ2V0IHx8IGY/LigpO1xuXHRcdH0sXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBhKFwic2VjdGlvblwiLCB7XG5cdFx0XHRyZWY6IChlKSA9PiB7XG5cdFx0XHRcdGlmIChPLmN1cnJlbnQgPSBlLCB0eXBlb2YgRCA9PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdFx0XHREKGUpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHREICYmIChELmN1cnJlbnQgPSBlKTtcblx0XHRcdH0sXG5cdFx0XHRjbGFzc05hbWU6IFYsXG5cdFx0XHRyb2xlOiBnLFxuXHRcdFx0XCJhcmlhLW1vZGFsXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogUixcblx0XHRcdFwiYXJpYS1kZXNjcmliZWRieVwiOiB6LFxuXHRcdFx0dGFiSW5kZXg6IHcgPz8gLTEsXG5cdFx0XHRvbktleURvd246IChlKSA9PiB7XG5cdFx0XHRcdGlmIChDPy4oZSksIGUuZGVmYXVsdFByZXZlbnRlZCkgcmV0dXJuO1xuXHRcdFx0XHRpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIgJiYgbSkge1xuXHRcdFx0XHRcdGUucHJldmVudERlZmF1bHQoKSwgZj8uKCk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChlLmtleSAhPT0gXCJUYWJcIiB8fCAhTy5jdXJyZW50KSByZXR1cm47XG5cdFx0XHRcdGxldCB0ID0gcyhPLmN1cnJlbnQpO1xuXHRcdFx0XHRpZiAodC5sZW5ndGggPT09IDApIHtcblx0XHRcdFx0XHRlLnByZXZlbnREZWZhdWx0KCksIE8uY3VycmVudC5mb2N1cygpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHRsZXQgbiA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQsIHIgPSB0WzBdLCBpID0gdFt0Lmxlbmd0aCAtIDFdO1xuXHRcdFx0XHRpZiAoZS5zaGlmdEtleSkge1xuXHRcdFx0XHRcdCghbiB8fCBuID09PSByIHx8ICFPLmN1cnJlbnQuY29udGFpbnMobikpICYmIChlLnByZXZlbnREZWZhdWx0KCksIGkuZm9jdXMoKSk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdCghbiB8fCBuID09PSBpIHx8ICFPLmN1cnJlbnQuY29udGFpbnMobikpICYmIChlLnByZXZlbnREZWZhdWx0KCksIHIuZm9jdXMoKSk7XG5cdFx0XHR9LFxuXHRcdFx0Li4uRSxcblx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdEkgPyAvKiBAX19QVVJFX18gKi8gaShcImhlYWRlclwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBILFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBjID8/IChQID8gLyogQF9fUFVSRV9fICovIGkoXCJoM1wiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kaWFsb2dfX3RpdGxlXCIsXG5cdFx0XHRcdFx0XHRpZDogQSxcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0XHRcdFx0fSkgOiBudWxsKVxuXHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdEYgPyAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdFx0aWQ6IGosXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBVLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBvXG5cdFx0XHRcdH0pIDogbnVsbCxcblx0XHRcdFx0LyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogVyxcblx0XHRcdFx0XHRjaGlsZHJlbjogVFxuXHRcdFx0XHR9KSxcblx0XHRcdFx0TCA/IC8qIEBfX1BVUkVfXyAqLyBpKFwiZm9vdGVyXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IEcsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGxcblx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRdXG5cdFx0fSlcblx0fSk7XG59KTtcbmMuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1wiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjIGFzIERpYWxvZyB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlLCB1c2VJZCBhcyB0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgbiwganN4cyBhcyByIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2Ryb3Bkb3dubGlzdC51dGlscy50c1xuZnVuY3Rpb24gaShlKSB7XG5cdHJldHVybiBlLmxhYmVsID8/IGUuY2hpbGRyZW4gPz8gZS52YWx1ZTtcbn1cbmZ1bmN0aW9uIGEoZSwgdCkge1xuXHRyZXR1cm4gZS52YWx1ZSB8fCBgaXRlbS0ke3R9YDtcbn1cbmZ1bmN0aW9uIG8oZSwgdCwgbikge1xuXHRyZXR1cm4gZSB8fCB0ID09PSBudWxsIHx8IG4gPT09IG51bGw7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvRHJvcGRvd25MaXN0LnRzeFxudmFyIHMgPSBlKGZ1bmN0aW9uKHsgaXRlbXM6IGUgPSBbXSwgdmFsdWU6IHMsIGRlZmF1bHRWYWx1ZTogYywgYWxsb3dOdWxsOiBsID0gITEsIG51bGxMYWJlbDogdSA9IFwiTm9uZVwiLCBjbGFzc05hbWU6IGQgPSBcIlwiLCBvbkNoYW5nZTogZiwgb25WYWx1ZUNoYW5nZTogcCwgaWQ6IG0sIGRpc2FibGVkOiBoLCAuLi5nIH0sIF8pIHtcblx0bGV0IHYgPSB0KCksIHkgPSBtID8/IGBuYWJzLXVpLWRyb3Bkb3dubGlzdC0ke3YucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBiID0gW1xuXHRcdFwibmFicy11aS1kcm9wZG93bmxpc3RcIixcblx0XHRoID8gXCJuYWJzLXVpLWRyb3Bkb3dubGlzdC0tZGlzYWJsZWRcIiA6IFwiXCIsXG5cdFx0ZFxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgeCA9IG8obCwgcywgYyk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcihcInNlbGVjdFwiLCB7XG5cdFx0cmVmOiBfLFxuXHRcdGlkOiB5LFxuXHRcdGNsYXNzTmFtZTogYixcblx0XHRkaXNhYmxlZDogaCxcblx0XHR2YWx1ZTogcyA/PyB2b2lkIDAsXG5cdFx0ZGVmYXVsdFZhbHVlOiBjID8/IHZvaWQgMCxcblx0XHRvbkNoYW5nZTogKGUpID0+IHtcblx0XHRcdGxldCB0ID0gZS50YXJnZXQudmFsdWUgPT09IFwiXCIgPyBudWxsIDogZS50YXJnZXQudmFsdWU7XG5cdFx0XHRwPy4odCwgZSksIGY/LihlKTtcblx0XHR9LFxuXHRcdC4uLmcsXG5cdFx0Y2hpbGRyZW46IFt4ID8gLyogQF9fUFVSRV9fICovIG4oXCJvcHRpb25cIiwge1xuXHRcdFx0dmFsdWU6IFwiXCIsXG5cdFx0XHRkaXNhYmxlZDogIWwsXG5cdFx0XHRjaGlsZHJlbjogdVxuXHRcdH0pIDogbnVsbCwgZS5tYXAoKGUsIHQpID0+IC8qIEBfX1BVUkVfXyAqLyBuKFwib3B0aW9uXCIsIHtcblx0XHRcdHZhbHVlOiBlLnZhbHVlLFxuXHRcdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XHRjaGlsZHJlbjogaShlKVxuXHRcdH0sIGEoZSwgdCkpKV1cblx0fSk7XG59KTtcbnMuZGlzcGxheU5hbWUgPSBcIkRyb3Bkb3duTGlzdFwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBzIGFzIERyb3Bkb3duTGlzdCB9O1xuIiwiaW1wb3J0IHsgdXNlRWZmZWN0IGFzIGUsIHVzZUlkIGFzIHQsIHVzZUxheW91dEVmZmVjdCBhcyBuLCB1c2VSZWYgYXMgciwgdXNlU3RhdGUgYXMgaSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY3JlYXRlUG9ydGFsIGFzIGEgfSBmcm9tIFwicmVhY3QtZG9tXCI7XG5pbXBvcnQgeyBGcmFnbWVudCBhcyBvLCBqc3ggYXMgcywganN4cyBhcyBjIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2Ryb3Bkb3dubWVudS51dGlscy50c1xuZnVuY3Rpb24gbChlKSB7XG5cdHJldHVybiAhIShlICYmIFwidHlwZVwiIGluIGUgJiYgZS50eXBlID09PSBcImRpdmlkZXJcIik7XG59XG5mdW5jdGlvbiB1KGUpIHtcblx0cmV0dXJuIGUubGFiZWwgPz8gZS5jaGlsZHJlbiA/PyBcIk1lbnUgaXRlbVwiO1xufVxuZnVuY3Rpb24gZChlLCB0KSB7XG5cdHJldHVybiBlLnZhbHVlID8/IGUubGFiZWwgPz8gYGl0ZW0tJHt0fWA7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvRHJvcGRvd25NZW51LnRzeFxuZnVuY3Rpb24gZih7IGxhYmVsOiBmID0gXCJNZW51XCIsIHRyaWdnZXJDb250ZW50OiBwLCB0cmlnZ2VyQXJpYUxhYmVsOiBtLCBtZW51QWxpZ246IGggPSBcInN0YXJ0XCIsIGl0ZW1zOiBnID0gW10sIGNsYXNzTmFtZTogXyA9IFwiXCIsIHRyaWdnZXJDbGFzc05hbWU6IHYgPSBcIlwiLCBtZW51Q2xhc3NOYW1lOiB5ID0gXCJcIiwgaXRlbUNsYXNzTmFtZTogYiA9IFwiXCIsIGRpdmlkZXJDbGFzc05hbWU6IHggPSBcIlwiLCBpZDogUywgb25JdGVtU2VsZWN0OiBDLCAuLi53IH0pIHtcblx0bGV0IFtULCBFXSA9IGkoITEpLCBEID0gcihudWxsKSwgTyA9IHIobnVsbCksIGsgPSByKG51bGwpLCBBID0gdCgpLCBqID0gUyA/PyBgbmFicy11aS1kcm9wZG93bm1lbnUtJHtBLnJlcGxhY2UoLzovZywgXCJcIil9YCwgTSA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51XCIsIF9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgTiA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51X190cmlnZ2VyXCIsIHZdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgUCA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51X19tZW51XCIsIHldLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgRiA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtXCIsIGJdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgSSA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51X19kaXZpZGVyXCIsIHhdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0ZSgoKSA9PiB7XG5cdFx0bGV0IGUgPSAoZSkgPT4ge1xuXHRcdFx0ZS50YXJnZXQgaW5zdGFuY2VvZiBOb2RlICYmIEQuY3VycmVudCAmJiAhRC5jdXJyZW50LmNvbnRhaW5zKGUudGFyZ2V0KSAmJiBrLmN1cnJlbnQgJiYgIWsuY3VycmVudC5jb250YWlucyhlLnRhcmdldCkgJiYgRSghMSk7XG5cdFx0fSwgdCA9IChlKSA9PiB7XG5cdFx0XHRlLmtleSA9PT0gXCJFc2NhcGVcIiAmJiBFKCExKTtcblx0XHR9O1xuXHRcdHJldHVybiBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcmRvd25cIiwgZSksIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHQpLCAoKSA9PiB7XG5cdFx0XHRkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcmRvd25cIiwgZSksIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHQpO1xuXHRcdH07XG5cdH0sIFtdKSwgbigoKSA9PiB7XG5cdFx0aWYgKCFUIHx8ICFPLmN1cnJlbnQpIHJldHVybjtcblx0XHRsZXQgZSA9ICgpID0+IHtcblx0XHRcdGxldCBlID0gTy5jdXJyZW50Py5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSwgdCA9IGsuY3VycmVudDtcblx0XHRcdGlmICghZSB8fCAhdCkgcmV0dXJuO1xuXHRcdFx0bGV0IG4gPSBlLndpZHRoLCByID0gd2luZG93LmlubmVyV2lkdGggLSBuIC0gOCwgaSA9IGggPT09IFwiZW5kXCIgPyBlLnJpZ2h0IC0gbiA6IGUubGVmdCwgYSA9IE1hdGgubWF4KDgsIE1hdGgubWluKGksIHIpKSwgbyA9IE1hdGgubWF4KDgsIGUuYm90dG9tICsgMTApO1xuXHRcdFx0dC5zdHlsZS5wb3NpdGlvbiA9IFwiZml4ZWRcIiwgdC5zdHlsZS50b3AgPSBgJHtvfXB4YCwgdC5zdHlsZS5sZWZ0ID0gYCR7YX1weGAsIHQuc3R5bGUucmlnaHQgPSBcImF1dG9cIiwgdC5zdHlsZS5taW5XaWR0aCA9IGAke259cHhgLCB0LnN0eWxlLnZpc2liaWxpdHkgPSBcInZpc2libGVcIjtcblx0XHR9O1xuXHRcdHJldHVybiBrLmN1cnJlbnQgJiYgKGsuY3VycmVudC5zdHlsZS52aXNpYmlsaXR5ID0gXCJoaWRkZW5cIiksIGUoKSwgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgZSksIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIGUsICEwKSwgKCkgPT4ge1xuXHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgZSksIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIGUsICEwKTtcblx0XHR9O1xuXHR9LCBbaCwgVF0pO1xuXHRsZXQgTCA9IChlLCB0KSA9PiB7XG5cdFx0aWYgKEUoITEpLCBlLmRpc2FibGVkKSB7XG5cdFx0XHR0LnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdEM/LihlLCB0KSwgZS5vblNlbGVjdD8uKGUsIHQpO1xuXHR9O1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdHJlZjogRCxcblx0XHRjbGFzc05hbWU6IE0sXG5cdFx0Li4udyxcblx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwiYnV0dG9uXCIsIHtcblx0XHRcdHJlZjogTyxcblx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRjbGFzc05hbWU6IE4sXG5cdFx0XHRcImFyaWEtaGFzcG9wdXBcIjogXCJtZW51XCIsXG5cdFx0XHRcImFyaWEtY29udHJvbHNcIjogaixcblx0XHRcdFwiYXJpYS1sYWJlbFwiOiBtID8/IGYsXG5cdFx0XHRvbkNsaWNrOiAoKSA9PiBFKChlKSA9PiAhZSksXG5cdFx0XHRjaGlsZHJlbjogcCA/PyAvKiBAX19QVVJFX18gKi8gYyhvLCB7IGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X190cmlnZ2VyTGFiZWxcIixcblx0XHRcdFx0Y2hpbGRyZW46IGZcblx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kcm9wZG93bm1lbnVfX3RyaWdnZXJDaGV2cm9uXCIsXG5cdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBcIuKWvlwiXG5cdFx0XHR9KV0gfSlcblx0XHR9KSwgVCAmJiB0eXBlb2YgZG9jdW1lbnQgPCBcInVcIiA/IGEoLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0cmVmOiBrLFxuXHRcdFx0aWQ6IGosXG5cdFx0XHRjbGFzc05hbWU6IFAsXG5cdFx0XHRcImFyaWEtbGFiZWxcIjogZixcblx0XHRcdGNoaWxkcmVuOiBnLm1hcCgoZSwgdCkgPT4ge1xuXHRcdFx0XHRpZiAobChlKSkgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IEksXG5cdFx0XHRcdFx0cm9sZTogXCJzZXBhcmF0b3JcIixcblx0XHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiXG5cdFx0XHRcdH0sIGBkaXZpZGVyLSR7dH1gKTtcblx0XHRcdFx0bGV0IG4gPSB1KGUpLCByID0gW1xuXHRcdFx0XHRcdEYsXG5cdFx0XHRcdFx0ZS5kaXNhYmxlZCA/IFwibmFicy11aS1kcm9wZG93bm1lbnVfX2l0ZW0tLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdFx0XHRcdGUuZGFuZ2VyID8gXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbS0tZGFuZ2VyXCIgOiBcIlwiXG5cdFx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBpID0ge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogcixcblx0XHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogZS5kaXNhYmxlZCB8fCB2b2lkIDBcblx0XHRcdFx0fTtcblx0XHRcdFx0cmV0dXJuIGUuaHJlZiA/IC8qIEBfX1BVUkVfXyAqLyBjKFwiYVwiLCB7XG5cdFx0XHRcdFx0Li4uaSxcblx0XHRcdFx0XHRocmVmOiBlLmRpc2FibGVkID8gdm9pZCAwIDogZS5ocmVmLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICh0KSA9PiBMKGUsIHQpLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbUxhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogblxuXHRcdFx0XHRcdH0pLCBlLmRlc2NyaXB0aW9uID8gLyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbURlc2NyaXB0aW9uXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5kZXNjcmlwdGlvblxuXHRcdFx0XHRcdH0pIDogbnVsbF1cblx0XHRcdFx0fSwgZChlLCB0KSkgOiAvKiBAX19QVVJFX18gKi8gYyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRjbGFzc05hbWU6IHIsXG5cdFx0XHRcdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XHRcdFx0b25DbGljazogKHQpID0+IEwoZSwgdCksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtTGFiZWxcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBuXG5cdFx0XHRcdFx0fSksIGUuZGVzY3JpcHRpb24gPyAvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtRGVzY3JpcHRpb25cIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmRlc2NyaXB0aW9uXG5cdFx0XHRcdFx0fSkgOiBudWxsXVxuXHRcdFx0XHR9LCBkKGUsIHQpKTtcblx0XHRcdH0pXG5cdFx0fSksIGRvY3VtZW50LmJvZHkpIDogbnVsbF1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGYgYXMgRHJvcGRvd25NZW51IH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUVmZmVjdCBhcyB0LCB1c2VJZCBhcyBuLCB1c2VTdGF0ZSBhcyByIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgaSwganN4cyBhcyBhIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gLi4vbmFicy11aS1jaGVja2JveC9zcmMvY2hlY2tib3gudXRpbHMudHNcbnZhciBvID0ge1xuXHRyaWdodDogXCJuYWJzLXVpLWNoZWNrYm94LS1sYWJlbC1yaWdodFwiLFxuXHRsZWZ0OiBcIm5hYnMtdWktY2hlY2tib3gtLWxhYmVsLWxlZnRcIixcblx0dG9wOiBcIm5hYnMtdWktY2hlY2tib3gtLWxhYmVsLXRvcFwiLFxuXHRib3R0b206IFwibmFicy11aS1jaGVja2JveC0tbGFiZWwtYm90dG9tXCJcbn0sIHMgPSBlKGZ1bmN0aW9uKHsgbGFiZWw6IGUgPSBcIkNoZWNrYm94XCIsIGxhYmVsUG9zaXRpb246IHQgPSBcInJpZ2h0XCIsIGNsYXNzTmFtZTogciA9IFwiXCIsIGlucHV0Q2xhc3NOYW1lOiBzID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IGMgPSBcIlwiLCBpZDogbCwgZGlzYWJsZWQ6IHUsIC4uLmQgfSwgZikge1xuXHRsZXQgcCA9IG4oKSwgbSA9IGwgPz8gYG5hYnMtdWktY2hlY2tib3gtJHtwLnJlcGxhY2UoLzovZywgXCJcIil9YCwgaCA9IFtcblx0XHRcIm5hYnMtdWktY2hlY2tib3hcIixcblx0XHR1ID8gXCJuYWJzLXVpLWNoZWNrYm94LS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRvW3RdID8/IG8ucmlnaHQsXG5cdFx0clxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktY2hlY2tib3hfX2lucHV0XCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgXyA9IFtcIm5hYnMtdWktY2hlY2tib3hfX2xhYmVsXCIsIGNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBhKFwibGFiZWxcIiwge1xuXHRcdGNsYXNzTmFtZTogaCxcblx0XHRodG1sRm9yOiBtLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGkoXCJpbnB1dFwiLCB7XG5cdFx0XHRyZWY6IGYsXG5cdFx0XHRpZDogbSxcblx0XHRcdGNsYXNzTmFtZTogZyxcblx0XHRcdHR5cGU6IFwiY2hlY2tib3hcIixcblx0XHRcdGRpc2FibGVkOiB1LFxuXHRcdFx0Li4uZFxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gaShcInNwYW5cIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBfLFxuXHRcdFx0Y2hpbGRyZW46IGVcblx0XHR9KV1cblx0fSk7XG59KTtcbnMuZGlzcGxheU5hbWUgPSBcIkNoZWNrYm94XCI7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi9uYWJzLXVpLXJhZGlvYnV0dG9uL3NyYy9yYWRpb2J1dHRvbi51dGlscy50c1xudmFyIGMgPSB7XG5cdHJpZ2h0OiBcIm5hYnMtdWktcmFkaW9idXR0b24tLWxhYmVsLXJpZ2h0XCIsXG5cdGxlZnQ6IFwibmFicy11aS1yYWRpb2J1dHRvbi0tbGFiZWwtbGVmdFwiLFxuXHR0b3A6IFwibmFicy11aS1yYWRpb2J1dHRvbi0tbGFiZWwtdG9wXCIsXG5cdGJvdHRvbTogXCJuYWJzLXVpLXJhZGlvYnV0dG9uLS1sYWJlbC1ib3R0b21cIlxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uL25hYnMtdWktcmFkaW9idXR0b24vc3JjL1JhZGlvQnV0dG9uLnRzeFxuZnVuY3Rpb24gbCh7IGxhYmVsOiBlID0gXCJSYWRpbyBidXR0b25cIiwgbGFiZWxQb3NpdGlvbjogdCA9IFwicmlnaHRcIiwgY2xhc3NOYW1lOiByID0gXCJcIiwgaW5wdXRDbGFzc05hbWU6IG8gPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogcyA9IFwiXCIsIGlkOiBsLCAuLi51IH0pIHtcblx0bGV0IGQgPSB1LmRpc2FibGVkID09PSAhMCwgZiA9IG4oKSwgcCA9IGwgPz8gYG5hYnMtdWktcmFkaW9idXR0b24tJHtmLnJlcGxhY2UoLzovZywgXCJcIil9YCwgbSA9IFtcblx0XHRcIm5hYnMtdWktcmFkaW9idXR0b25cIixcblx0XHRkID8gXCJuYWJzLXVpLXJhZGlvYnV0dG9uLS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRjW3RdID8/IGMucmlnaHQsXG5cdFx0clxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaCA9IFtcIm5hYnMtdWktcmFkaW9idXR0b25fX2lucHV0XCIsIG9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktcmFkaW9idXR0b25fX2xhYmVsXCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBhKFwibGFiZWxcIiwge1xuXHRcdGNsYXNzTmFtZTogbSxcblx0XHRodG1sRm9yOiBwLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGkoXCJpbnB1dFwiLCB7XG5cdFx0XHRpZDogcCxcblx0XHRcdGNsYXNzTmFtZTogaCxcblx0XHRcdHR5cGU6IFwicmFkaW9cIixcblx0XHRcdC4uLnVcblx0XHR9KSwgLyogQF9fUFVSRV9fICovIGkoXCJzcGFuXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogZyxcblx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0fSldXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vbmFicy11aS10ZXh0YXJlYS9zcmMvVGV4dGFyZWEudHN4XG52YXIgdSA9IGUoKHsgbGFiZWw6IGUsIGNsYXNzTmFtZTogdCA9IFwiXCIsIGlucHV0Q2xhc3NOYW1lOiByID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IG8gPSBcIlwiLCBpZDogcywgcm93czogYyA9IDQsIHJlc2l6ZTogbCA9IFwidmVydGljYWxcIiwgLi4udSB9LCBkKSA9PiB7XG5cdGxldCBmID0gbigpLCBwID0gcyA/PyBgbmFicy11aS10ZXh0YXJlYS0ke2YucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBtID0gW1wibmFicy11aS10ZXh0YXJlYVwiLCB0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGggPSBbXCJuYWJzLXVpLXRleHRhcmVhX19pbnB1dFwiLCByXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGcgPSBbXCJuYWJzLXVpLXRleHRhcmVhX19sYWJlbFwiLCBvXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gYShcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBtLFxuXHRcdGNoaWxkcmVuOiBbZSA/IC8qIEBfX1BVUkVfXyAqLyBpKFwibGFiZWxcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0aHRtbEZvcjogcCxcblx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0fSkgOiBudWxsLCAvKiBAX19QVVJFX18gKi8gaShcInRleHRhcmVhXCIsIHtcblx0XHRcdHJlZjogZCxcblx0XHRcdGlkOiBwLFxuXHRcdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdFx0cm93czogYyxcblx0XHRcdFwiZGF0YS1yZXNpemVcIjogbCxcblx0XHRcdC4uLnVcblx0XHR9KV1cblx0fSk7XG59KTtcbnUuZGlzcGxheU5hbWUgPSBcIlRleHRhcmVhXCI7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi9uYWJzLXVpLXRleHRib3gvc3JjL3RleHRib3gudXRpbHMudHNcbnZhciBkID0ge1xuXHRub25lOiBcIlwiLFxuXHR0b3A6IFwibmFicy11aS10ZXh0Ym94LS1sYWJlbC10b3BcIixcblx0bGVmdDogXCJuYWJzLXVpLXRleHRib3gtLWxhYmVsLWxlZnRcIlxufSwgZiA9IGUoKHsgbGFiZWw6IGUsIGxhYmVsUG9zaXRpb246IHQgPSBcInRvcFwiLCBjbGFzc05hbWU6IHIgPSBcIlwiLCBpbnB1dENsYXNzTmFtZTogbyA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBzID0gXCJcIiwgaWQ6IGMsIHR5cGU6IGwgPSBcInRleHRcIiwgLi4udSB9LCBmKSA9PiB7XG5cdGxldCBwID0gbigpLCBtID0gYyA/PyBgbmFicy11aS10ZXh0Ym94LSR7cC5yZXBsYWNlKC86L2csIFwiXCIpfWAsIGggPSBbXG5cdFx0XCJuYWJzLXVpLXRleHRib3hcIixcblx0XHRlID8gZFt0XSA/PyBkLnRvcCA6IFwiXCIsXG5cdFx0clxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktdGV4dGJveF9faW5wdXRcIiwgb10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBfID0gW1wibmFicy11aS10ZXh0Ym94X19sYWJlbFwiLCBzXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gYShcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdGNoaWxkcmVuOiBbZSA/IC8qIEBfX1BVUkVfXyAqLyBpKFwibGFiZWxcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBfLFxuXHRcdFx0aHRtbEZvcjogbSxcblx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0fSkgOiBudWxsLCAvKiBAX19QVVJFX18gKi8gaShcImlucHV0XCIsIHtcblx0XHRcdHJlZjogZixcblx0XHRcdGlkOiBtLFxuXHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0dHlwZTogbCxcblx0XHRcdC4uLnVcblx0XHR9KV1cblx0fSk7XG59KTtcbmYuZGlzcGxheU5hbWUgPSBcIlRleHRib3hcIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9keW5hbWljZm9ybS51dGlscy50c1xuZnVuY3Rpb24gcChlKSB7XG5cdHJldHVybiB0eXBlb2YgZSA9PSBcIm9iamVjdFwiICYmICEhZSAmJiAhQXJyYXkuaXNBcnJheShlKTtcbn1cbmZ1bmN0aW9uIG0oZSkge1xuXHRyZXR1cm4gIWUgfHwgZS50eXBlICE9PSBcIm9iamVjdFwiIHx8ICFwKGUucHJvcGVydGllcykgPyB7fSA6IE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhlLnByb3BlcnRpZXMpLm1hcCgoW2UsIHRdKSA9PiBbZSwgaCh0KV0pKTtcbn1cbmZ1bmN0aW9uIGgoZSkge1xuXHRpZiAoIWUgfHwgIXAoZSkpIHJldHVybiBcIlwiO1xuXHRpZiAoZS5kZWZhdWx0ICE9PSB2b2lkIDApIHJldHVybiBlLmRlZmF1bHQ7XG5cdGlmIChBcnJheS5pc0FycmF5KGUuZW51bSkgJiYgZS5lbnVtLmxlbmd0aCA+IDApIHJldHVybiBlLmVudW1bMF07XG5cdHN3aXRjaCAoZS50eXBlKSB7XG5cdFx0Y2FzZSBcImJvb2xlYW5cIjogcmV0dXJuICExO1xuXHRcdGNhc2UgXCJpbnRlZ2VyXCI6XG5cdFx0Y2FzZSBcIm51bWJlclwiOiByZXR1cm4gXCJcIjtcblx0XHRjYXNlIFwib2JqZWN0XCI6IHJldHVybiBtKGUpO1xuXHRcdGRlZmF1bHQ6IHJldHVybiBcIlwiO1xuXHR9XG59XG5mdW5jdGlvbiBnKGUsIHQpIHtcblx0aWYgKCFlIHx8ICFwKGUpKSByZXR1cm4gdDtcblx0aWYgKGUudHlwZSA9PT0gXCJvYmplY3RcIiAmJiBwKGUucHJvcGVydGllcykpIHtcblx0XHRsZXQgbiA9IHAodCkgPyB0IDoge307XG5cdFx0cmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhlLnByb3BlcnRpZXMpLm1hcCgoW2UsIHRdKSA9PiBbZSwgZyh0LCBuW2VdID09PSB2b2lkIDAgPyBoKHQpIDogbltlXSldKSk7XG5cdH1cblx0aWYgKGUudHlwZSA9PT0gXCJib29sZWFuXCIpIHJldHVybiB0ID09PSAhMDtcblx0aWYgKGUudHlwZSA9PT0gXCJpbnRlZ2VyXCIpIHtcblx0XHRpZiAodCA9PT0gXCJcIiB8fCB0ID09IG51bGwpIHJldHVybiBcIlwiO1xuXHRcdGxldCBlID0gTnVtYmVyLnBhcnNlSW50KFN0cmluZyh0KSwgMTApO1xuXHRcdHJldHVybiBOdW1iZXIuaXNOYU4oZSkgPyBcIlwiIDogZTtcblx0fVxuXHRpZiAoZS50eXBlID09PSBcIm51bWJlclwiKSB7XG5cdFx0aWYgKHQgPT09IFwiXCIgfHwgdCA9PSBudWxsKSByZXR1cm4gXCJcIjtcblx0XHRsZXQgZSA9IE51bWJlci5wYXJzZUZsb2F0KFN0cmluZyh0KSk7XG5cdFx0cmV0dXJuIE51bWJlci5pc05hTihlKSA/IFwiXCIgOiBlO1xuXHR9XG5cdHJldHVybiB0ID8/IFwiXCI7XG59XG5mdW5jdGlvbiBfKGUpIHtcblx0cmV0dXJuICFlIHx8ICFwKGUpID8gXCJ0ZXh0Ym94XCIgOiBBcnJheS5pc0FycmF5KGUuZW51bSkgJiYgZS5lbnVtLmxlbmd0aCA+IDAgPyBcInJhZGlvXCIgOiBlLnR5cGUgPT09IFwic3RyaW5nXCIgPyBlLm1heExlbmd0aCAhPT0gdm9pZCAwICYmIGUubWF4TGVuZ3RoID4gNTAgPyBcInRleHRhcmVhXCIgOiBcInRleHRib3hcIiA6IGUudHlwZSA9PT0gXCJpbnRlZ2VyXCIgPyBcImludFwiIDogZS50eXBlID09PSBcIm51bWJlclwiID8gU3RyaW5nKGUuZm9ybWF0ID8/IFwiXCIpLnRvTG93ZXJDYXNlKCkgPT09IFwiZGVjaW1hbFwiID8gXCJkZWNpbWFsXCIgOiBcImRvdWJsZVwiIDogZS50eXBlID09PSBcImJvb2xlYW5cIiA/IFwiYm9vbFwiIDogXCJ0ZXh0Ym94XCI7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvRHluYW1pY0Zvcm0udHN4XG52YXIgdiA9IHtcblx0dHlwZTogXCJvYmplY3RcIixcblx0cHJvcGVydGllczoge31cbn07XG5mdW5jdGlvbiB5KHsgc2NoZW1hOiBlLCBuYW1lOiB0LCB2YWx1ZTogbiwgb25DaGFuZ2U6IHIgfSkge1xuXHRsZXQgbyA9IGUudGl0bGUgPz8gdCwgYyA9IGUuZGVzY3JpcHRpb24sIGQgPSBfKGUpLCBwID0gbiA/PyBoKGUpO1xuXHRpZiAoZCA9PT0gXCJyYWRpb1wiKSB7XG5cdFx0bGV0IG4gPSBBcnJheS5pc0FycmF5KGUuZW51bSkgPyBlLmVudW0gOiBbXTtcblx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGEoXCJmaWVsZHNldFwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1keW5hbWljZm9ybV9fZmllbGRzZXRcIixcblx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBpKFwibGVnZW5kXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1keW5hbWljZm9ybV9fbGVnZW5kXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IG9cblx0XHRcdFx0fSksXG5cdFx0XHRcdGMgPyAvKiBAX19QVVJFX18gKi8gaShcInBcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19kZXNjcmlwdGlvblwiLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBjXG5cdFx0XHRcdH0pIDogbnVsbCxcblx0XHRcdFx0LyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19yYWRpb0dyb3VwXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IG4ubWFwKChlKSA9PiAvKiBAX19QVVJFX18gKi8gaShsLCB7XG5cdFx0XHRcdFx0XHRsYWJlbDogU3RyaW5nKGUpLFxuXHRcdFx0XHRcdFx0bmFtZTogdCxcblx0XHRcdFx0XHRcdGNoZWNrZWQ6IHAgPT09IGUsXG5cdFx0XHRcdFx0XHRvbkNoYW5nZTogKCkgPT4gcihlKVxuXHRcdFx0XHRcdH0sIFN0cmluZyhlKSkpXG5cdFx0XHRcdH0pXG5cdFx0XHRdXG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIGQgPT09IFwidGV4dGFyZWFcIiA/IC8qIEBfX1BVUkVfXyAqLyBpKHUsIHtcblx0XHRsYWJlbDogbyxcblx0XHRyb3dzOiA1LFxuXHRcdHZhbHVlOiBTdHJpbmcocCA/PyBcIlwiKSxcblx0XHRwbGFjZWhvbGRlcjogU3RyaW5nKGUuZGVmYXVsdCA/PyBcIlwiKSxcblx0XHRvbkNoYW5nZTogKGUpID0+IHIoZS50YXJnZXQudmFsdWUpXG5cdH0pIDogZCA9PT0gXCJib29sXCIgPyAvKiBAX19QVVJFX18gKi8gaShzLCB7XG5cdFx0bGFiZWw6IG8sXG5cdFx0Y2hlY2tlZDogcCA9PT0gITAsXG5cdFx0b25DaGFuZ2U6IChlKSA9PiByKGUudGFyZ2V0LmNoZWNrZWQpXG5cdH0pIDogLyogQF9fUFVSRV9fICovIGkoZiwge1xuXHRcdGxhYmVsOiBvLFxuXHRcdHR5cGU6IGQgPT09IFwiaW50XCIgfHwgZCA9PT0gXCJkZWNpbWFsXCIgfHwgZCA9PT0gXCJkb3VibGVcIiA/IFwibnVtYmVyXCIgOiBcInRleHRcIixcblx0XHRzdGVwOiBkID09PSBcImludFwiID8gMSA6IGQgPT09IFwiZGVjaW1hbFwiIHx8IGQgPT09IFwiZG91YmxlXCIgPyBcImFueVwiIDogdm9pZCAwLFxuXHRcdHZhbHVlOiBTdHJpbmcocCA/PyBcIlwiKSxcblx0XHRwbGFjZWhvbGRlcjogU3RyaW5nKGUuZGVmYXVsdCA/PyBcIlwiKSxcblx0XHRvbkNoYW5nZTogKGUpID0+IHtcblx0XHRcdGxldCB0ID0gZS50YXJnZXQudmFsdWU7XG5cdFx0XHRpZiAoZCA9PT0gXCJpbnRcIikge1xuXHRcdFx0XHRyKHQgPT09IFwiXCIgPyBcIlwiIDogTnVtYmVyLnBhcnNlSW50KHQsIDEwKSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGlmIChkID09PSBcImRlY2ltYWxcIiB8fCBkID09PSBcImRvdWJsZVwiKSB7XG5cdFx0XHRcdHIodCA9PT0gXCJcIiA/IFwiXCIgOiBOdW1iZXIucGFyc2VGbG9hdCh0KSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdHIodCk7XG5cdFx0fVxuXHR9KTtcbn1cbnZhciBiID0gZShmdW5jdGlvbih7IHNjaGVtYTogZSwgdmFsdWU6IG8sIG9uQ2hhbmdlOiBzLCBjbGFzc05hbWU6IGMgPSBcIlwiLCBpZDogbCwgZGlzYWJsZWQ6IHUgPSAhMSwgLi4uZCB9LCBmKSB7XG5cdGxldCBoID0gbigpLCBfID0gbCA/PyBgbmFicy11aS1keW5hbWljZm9ybS0ke2gucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBiID0gZSAmJiBlLnR5cGUgPT09IFwib2JqZWN0XCIgPyBlIDogdiwgW3gsIFNdID0gcigoKSA9PiBnKGIsIG8gPz8gbShiKSkpO1xuXHR0KCgpID0+IHtcblx0XHRTKGcoYiwgbyA/PyBtKGIpKSk7XG5cdH0sIFtiLCBvXSk7XG5cdGxldCBDID0gcCh4KSA/IHggOiB7fSwgdyA9IGIudGl0bGUgPz8gXCJEeW5hbWljIGZvcm1cIiwgVCA9IGIuZGVzY3JpcHRpb24sIEUgPSBbXG5cdFx0XCJuYWJzLXVpLWR5bmFtaWNmb3JtXCIsXG5cdFx0dSA/IFwibmFicy11aS1keW5hbWljZm9ybS0tZGlzYWJsZWRcIiA6IFwiXCIsXG5cdFx0Y1xuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgRCA9IChlKSA9PiB7XG5cdFx0UyhlKSwgcz8uKGUpO1xuXHR9O1xuXHRyZXR1cm4gdSA/IC8qIEBfX1BVUkVfXyAqLyBhKFwiZGl2XCIsIHtcblx0XHRyZWY6IGYsXG5cdFx0aWQ6IF8sXG5cdFx0Y2xhc3NOYW1lOiBFLFxuXHRcdFwiYXJpYS1kaXNhYmxlZFwiOiBcInRydWVcIixcblx0XHQuLi5kLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGEoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHluYW1pY2Zvcm1fX2hlYWRlclwiLFxuXHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX190aXRsZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogd1xuXHRcdFx0fSksIFQgPyAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19kZXNjcmlwdGlvblwiLFxuXHRcdFx0XHRjaGlsZHJlbjogVFxuXHRcdFx0fSkgOiBudWxsXVxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1keW5hbWljZm9ybV9fZmllbGRzXCIsXG5cdFx0XHRjaGlsZHJlbjogT2JqZWN0LmVudHJpZXMoYi5wcm9wZXJ0aWVzID8/IHt9KS5tYXAoKFtlLCB0XSkgPT4gLyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1keW5hbWljZm9ybV9fZmllbGRcIixcblx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBpKHksIHtcblx0XHRcdFx0XHRzY2hlbWE6IHQsXG5cdFx0XHRcdFx0bmFtZTogZSxcblx0XHRcdFx0XHR2YWx1ZTogQ1tlXSxcblx0XHRcdFx0XHRvbkNoYW5nZTogKG4pID0+IEQoe1xuXHRcdFx0XHRcdFx0Li4uQyxcblx0XHRcdFx0XHRcdFtlXTogZyh0LCBuKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdH0pXG5cdFx0XHR9LCBlKSlcblx0XHR9KV1cblx0fSkgOiAvKiBAX19QVVJFX18gKi8gYShcImRpdlwiLCB7XG5cdFx0cmVmOiBmLFxuXHRcdGlkOiBfLFxuXHRcdGNsYXNzTmFtZTogRSxcblx0XHQuLi5kLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGEoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHluYW1pY2Zvcm1fX2hlYWRlclwiLFxuXHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX190aXRsZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogd1xuXHRcdFx0fSksIFQgPyAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19kZXNjcmlwdGlvblwiLFxuXHRcdFx0XHRjaGlsZHJlbjogVFxuXHRcdFx0fSkgOiBudWxsXVxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1keW5hbWljZm9ybV9fZmllbGRzXCIsXG5cdFx0XHRjaGlsZHJlbjogT2JqZWN0LmVudHJpZXMoYi5wcm9wZXJ0aWVzID8/IHt9KS5tYXAoKFtlLCB0XSkgPT4gLyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1keW5hbWljZm9ybV9fZmllbGRcIixcblx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBpKHksIHtcblx0XHRcdFx0XHRzY2hlbWE6IHQsXG5cdFx0XHRcdFx0bmFtZTogZSxcblx0XHRcdFx0XHR2YWx1ZTogQ1tlXSxcblx0XHRcdFx0XHRvbkNoYW5nZTogKG4pID0+IEQoe1xuXHRcdFx0XHRcdFx0Li4uQyxcblx0XHRcdFx0XHRcdFtlXTogZyh0LCBuKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdH0pXG5cdFx0XHR9LCBlKSlcblx0XHR9KV1cblx0fSk7XG59KTtcbmIuZGlzcGxheU5hbWUgPSBcIkR5bmFtaWNGb3JtXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGIgYXMgRHluYW1pY0Zvcm0gfTtcbiIsImltcG9ydCB7IHVzZUlkIGFzIGUsIHVzZVJlZiBhcyB0LCB1c2VTdGF0ZSBhcyBuIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgciwganN4cyBhcyBpIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2ZpbGV1cGxvYWQudXRpbHMudHNcbmZ1bmN0aW9uIGEoZSkge1xuXHRyZXR1cm4gZSA/IChBcnJheS5pc0FycmF5KGUpID8gZSA6IFN0cmluZyhlKS5zcGxpdChcIixcIikpLm1hcCgoZSkgPT4gZS50cmltKCkudG9Mb3dlckNhc2UoKSkuZmlsdGVyKEJvb2xlYW4pLm1hcCgoZSkgPT4gZS5zdGFydHNXaXRoKFwiLlwiKSA/IGUgOiBgLiR7ZX1gKSA6IFtdO1xufVxuZnVuY3Rpb24gbyhlLCB0KSB7XG5cdGxldCBuID0gU3RyaW5nKGUpLnNwbGl0KFwiLFwiKS5tYXAoKGUpID0+IGUudHJpbSgpLnRvTG93ZXJDYXNlKCkpLmZpbHRlcihCb29sZWFuKSwgciA9IGEodCk7XG5cdHJldHVybiBbLi4ubmV3IFNldChbLi4ubiwgLi4ucl0pXTtcbn1cbmZ1bmN0aW9uIHMoZSwgdCkge1xuXHRsZXQgbiA9IGUubmFtZS50b0xvd2VyQ2FzZSgpLCByID0gKGUudHlwZSA/PyBcIlwiKS50b0xvd2VyQ2FzZSgpO1xuXHRyZXR1cm4gdCA9PT0gXCIqLypcIiA/ICEwIDogdC5lbmRzV2l0aChcIi8qXCIpID8gci5zdGFydHNXaXRoKHQuc2xpY2UoMCwgLTEpKSA6IHQuc3RhcnRzV2l0aChcIi5cIikgPyBuLmVuZHNXaXRoKHQpIDogciA9PT0gdDtcbn1cbmZ1bmN0aW9uIGMoZSwgdCkge1xuXHRpZiAodC5sZW5ndGggPT09IDApIHJldHVybiB7XG5cdFx0YWNjZXB0ZWRGaWxlczogZSxcblx0XHRyZWplY3RlZEZpbGVzOiBbXVxuXHR9O1xuXHRsZXQgbiA9IFtdLCByID0gW107XG5cdGZvciAobGV0IGkgb2YgZSkgKHQuc29tZSgoZSkgPT4gcyhpLCBlKSkgPyBuIDogcikucHVzaChpKTtcblx0cmV0dXJuIHtcblx0XHRhY2NlcHRlZEZpbGVzOiBuLFxuXHRcdHJlamVjdGVkRmlsZXM6IHJcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9GaWxlVXBsb2FkLnRzeFxuZnVuY3Rpb24gbCh7IGxhYmVsOiBhID0gXCJEcm9wIGZpbGVzIGhlcmUgb3IgY2xpY2sgQnJvd3NlIGZpbGVzXCIsIGRlc2NyaXB0aW9uOiBzID0gXCJEcmFnIGFuZCBkcm9wIGZpbGVzIGludG8gdGhlIGRyb3Agem9uZSBvciBjaG9vc2UgdGhlbSBtYW51YWxseS5cIiwgYWNjZXB0OiBsID0gXCJcIiwgZXh0ZW5zaW9uczogdSA9IFtdLCBtdWx0aXBsZTogZCA9ICEwLCBkaXNhYmxlZDogZiA9ICExLCBjbGFzc05hbWU6IHAgPSBcIlwiLCBzdXJmYWNlQ2xhc3NOYW1lOiBtID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IGggPSBcIlwiLCBkZXNjcmlwdGlvbkNsYXNzTmFtZTogZyA9IFwiXCIsIGJ1dHRvbkNsYXNzTmFtZTogXyA9IFwiXCIsIGlucHV0Q2xhc3NOYW1lOiB2ID0gXCJcIiwgaWQ6IHksIG9uRmlsZXNTZWxlY3RlZDogYiwgLi4ueCB9KSB7XG5cdGxldCBTID0gZSgpLCBDID0geSA/PyBgbmFicy11aS1maWxldXBsb2FkLSR7Uy5yZXBsYWNlKC86L2csIFwiXCIpfWAsIHcgPSB0KG51bGwpLCBbVCwgRV0gPSBuKCExKSwgRCA9IG8obCwgdSksIE8gPSBELmxlbmd0aCA+IDAgPyBELmpvaW4oXCIsXCIpIDogdm9pZCAwLCBrID0gW1xuXHRcdFwibmFicy11aS1maWxldXBsb2FkXCIsXG5cdFx0ZiA/IFwibmFicy11aS1maWxldXBsb2FkLS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRUID8gXCJuYWJzLXVpLWZpbGV1cGxvYWQtLWRyYWctb3ZlclwiIDogXCJcIixcblx0XHRwXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBBID0gW1wibmFicy11aS1maWxldXBsb2FkX19zdXJmYWNlXCIsIG1dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaiA9IFtcIm5hYnMtdWktZmlsZXVwbG9hZF9fbGFiZWxcIiwgaF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBNID0gW1wibmFicy11aS1maWxldXBsb2FkX19kZXNjcmlwdGlvblwiLCBnXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIE4gPSBbXCJuYWJzLXVpLWZpbGV1cGxvYWRfX2J1dHRvblwiLCBfXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFAgPSBbXCJuYWJzLXVpLWZpbGV1cGxvYWRfX2lucHV0XCIsIHZdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgRiA9IChlLCB0KSA9PiB7XG5cdFx0bGV0IHsgYWNjZXB0ZWRGaWxlczogbiwgcmVqZWN0ZWRGaWxlczogciB9ID0gYyhBcnJheS5mcm9tKGUgPz8gW10pLCBEKTtcblx0XHRiPy4oe1xuXHRcdFx0YWNjZXB0ZWRGaWxlczogbixcblx0XHRcdHJlamVjdGVkRmlsZXM6IHIsXG5cdFx0XHRzb3VyY2U6IHRcblx0XHR9KTtcblx0fSwgSSA9ICgpID0+IHtcblx0XHRmIHx8IHcuY3VycmVudD8uY2xpY2soKTtcblx0fSwgTCA9IChlKSA9PiB7XG5cdFx0RihlLnRhcmdldC5maWxlcywgXCJpbnB1dFwiKSwgZS50YXJnZXQudmFsdWUgPSBcIlwiO1xuXHR9LCBSID0gKGUpID0+IHtcblx0XHRlLnByZXZlbnREZWZhdWx0KCksIGYgfHwgRSghMCk7XG5cdH0sIHogPSAoZSkgPT4ge1xuXHRcdGUucHJldmVudERlZmF1bHQoKSwgZS5jdXJyZW50VGFyZ2V0ID09PSBlLnRhcmdldCAmJiBFKCExKTtcblx0fSwgQiA9IChlKSA9PiB7XG5cdFx0ZS5wcmV2ZW50RGVmYXVsdCgpLCBFKCExKSwgIWYgJiYgRihlLmRhdGFUcmFuc2Zlci5maWxlcywgXCJkcm9wXCIpO1xuXHR9LCBWID0gKGUpID0+IHtcblx0XHQoZS5rZXkgPT09IFwiRW50ZXJcIiB8fCBlLmtleSA9PT0gXCIgXCIpICYmIChlLnByZXZlbnREZWZhdWx0KCksIEkoKSk7XG5cdH07XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcihcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBrLFxuXHRcdC4uLngsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogQSxcblx0XHRcdHJvbGU6IFwiYnV0dG9uXCIsXG5cdFx0XHR0YWJJbmRleDogZiA/IC0xIDogMCxcblx0XHRcdFwiYXJpYS1sYWJlbFwiOiBhLFxuXHRcdFx0XCJkYXRhLWRpc2FibGVkXCI6IGYgPyBcInRydWVcIiA6IHZvaWQgMCxcblx0XHRcdG9uQ2xpY2s6IEksXG5cdFx0XHRvbktleURvd246IFYsXG5cdFx0XHRvbkRyYWdPdmVyOiBSLFxuXHRcdFx0b25EcmFnTGVhdmU6IHosXG5cdFx0XHRvbkRyb3A6IEIsXG5cdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcihcImlucHV0XCIsIHtcblx0XHRcdFx0XHRyZWY6IHcsXG5cdFx0XHRcdFx0aWQ6IEMsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBQLFxuXHRcdFx0XHRcdHR5cGU6IFwiZmlsZVwiLFxuXHRcdFx0XHRcdGFjY2VwdDogTyxcblx0XHRcdFx0XHRtdWx0aXBsZTogZCxcblx0XHRcdFx0XHRkaXNhYmxlZDogZixcblx0XHRcdFx0XHRcImFyaWEtbGFiZWxcIjogYSxcblx0XHRcdFx0XHR0aXRsZTogYSxcblx0XHRcdFx0XHRvbkNoYW5nZTogTFxuXHRcdFx0XHR9KSxcblx0XHRcdFx0LyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWZpbGV1cGxvYWRfX2NvbnRlbnRcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIHIoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBqLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogYVxuXHRcdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0XHRzID8gLyogQF9fUFVSRV9fICovIHIoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBNLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogc1xuXHRcdFx0XHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIGkoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZmlsZXVwbG9hZF9fbWV0YVwiLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW0QubGVuZ3RoID4gMCA/IGBBY2NlcHRlZDogJHtELmpvaW4oXCIsIFwiKX1gIDogXCJBY2NlcHRlZDogYWxsIGZpbGVzXCIsIGQgPyBcIiDigKIgbXVsdGlwbGUgZmlsZXNcIiA6IFwiIOKAoiBzaW5nbGUgZmlsZVwiXVxuXHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRdXG5cdFx0XHRcdH0pLFxuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcihcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRjbGFzc05hbWU6IE4sXG5cdFx0XHRcdFx0ZGlzYWJsZWQ6IGYsXG5cdFx0XHRcdFx0b25DbGljazogKGUpID0+IHtcblx0XHRcdFx0XHRcdGUuc3RvcFByb3BhZ2F0aW9uKCksIEkoKTtcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBcIkJyb3dzZSBmaWxlc1wiXG5cdFx0XHRcdH0pXG5cdFx0XHRdXG5cdFx0fSlcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGwgYXMgRmlsZVVwbG9hZCB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlLCB1c2VDYWxsYmFjayBhcyB0LCB1c2VFZmZlY3QgYXMgbiwgdXNlTWVtbyBhcyByLCB1c2VSZWYgYXMgaSwgdXNlU3RhdGUgYXMgYSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIG8sIGpzeHMgYXMgcyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy90b29sc2V0cy9TaW1wbGVHcmFwaFRvb2xzZXQvU2ltcGxlR3JhcGhUb29sc2V0LnRzeFxuZnVuY3Rpb24gYyh7IHRvb2xib3hMYWJlbDogZSwgdG9vbHNldHM6IHQsIGlzQ29sbGFwc2VkOiBuLCBpc0VkZ2VUb29sRW5hYmxlZDogciwgZWRnZUhpbnQ6IGksIGFjdGl2ZVRvb2xJZHNCeVNldDogYSwgb25Ub2dnbGVDb2xsYXBzZTogYywgb25Ub29sQ2xpY2s6IGwsIG9uVG9vbERvdWJsZUNsaWNrOiB1IH0pIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fdG9vbGJveFwiLFxuXHRcdHJvbGU6IFwidG9vbGJhclwiLFxuXHRcdFwiYXJpYS1sYWJlbFwiOiBlLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJidXR0b25cIiwge1xuXHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyYXBoX190b29sYm94VG9nZ2xlXCIsXG5cdFx0XHRvbkNsaWNrOiBjLFxuXHRcdFx0XCJhcmlhLWxhYmVsXCI6IG4gPyBcIkV4cGFuZCB0b29sYm94XCIgOiBcIkNvbGxhcHNlIHRvb2xib3hcIixcblx0XHRcdHRpdGxlOiBuID8gXCJFeHBhbmQgdG9vbGJveFwiIDogXCJDb2xsYXBzZSB0b29sYm94XCIsXG5cdFx0XHRjaGlsZHJlbjogbiA/IFwiPlwiIDogXCI8XCJcblx0XHR9KSwgIW4gJiYgdC5tYXAoKGUpID0+IC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyYXBoX190b29sc2V0XCIsXG5cdFx0XHRcImRhdGEtdG9vbHNldFwiOiBlLmlkLFxuXHRcdFx0Y2hpbGRyZW46IFtlLmxhYmVsICYmIC8qIEBfX1BVUkVfXyAqLyBvKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX3Rvb2xzZXRUaXRsZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogZS5sYWJlbFxuXHRcdFx0fSksIGUudG9vbHMubWFwKCh0KSA9PiB7XG5cdFx0XHRcdGxldCBuID0gYVtlLmlkXSA9PT0gdC5pZCwgYyA9IHQua2luZCA9PT0gXCJlZGdlXCIsIGQgPSBjICYmICFyLCBmID0gdC5pY29uQ2xhc3NOYW1lID8/IGBuYWJzLXVpLWdyYXBoX190b29sSWNvbi0tJHt0LmlkfWA7XG5cdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRjbGFzc05hbWU6IFtcblx0XHRcdFx0XHRcdFwibmFicy11aS1ncmFwaF9fdG9vbFwiLFxuXHRcdFx0XHRcdFx0biA/IFwibmFicy11aS1ncmFwaF9fdG9vbC0tYWN0aXZlXCIgOiBcIlwiLFxuXHRcdFx0XHRcdFx0ZCA/IFwibmFicy11aS1ncmFwaF9fdG9vbC0tZGlzYWJsZWRcIiA6IFwiXCJcblx0XHRcdFx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHRcdFx0XHRkaXNhYmxlZDogZCxcblx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBsKHQsIGUuaWQpLFxuXHRcdFx0XHRcdG9uRG91YmxlQ2xpY2s6ICgpID0+IHUodCwgZS5pZCksXG5cdFx0XHRcdFx0XCJkYXRhLWFjdGl2ZVwiOiBuID8gXCJ0cnVlXCIgOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XCJkYXRhLXRvb2xcIjogdC5pZCxcblx0XHRcdFx0XHR0aXRsZTogYyA/IGkgOiB0LmxhYmVsLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogW1wibmFicy11aS1ncmFwaF9fdG9vbEljb25cIiwgZl0uam9pbihcIiBcIiksXG5cdFx0XHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiXG5cdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fdG9vbExhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogdC5sYWJlbFxuXHRcdFx0XHRcdH0pXVxuXHRcdFx0XHR9LCB0LmlkKTtcblx0XHRcdH0pXVxuXHRcdH0sIGUuaWQpKV1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdG9vbHNldHMvU2ltcGxlR3JhcGhUb29sc2V0L3NpbXBsZUdyYXBoVG9vbHNldC50c1xudmFyIGwgPSB7XG5cdGlkOiBcInNpbXBsZS1ncmFwaC10b29sc2V0XCIsXG5cdGxhYmVsOiBcIlNpbXBsZSBHcmFwaCBUb29sc2V0XCIsXG5cdHRvb2xzOiBbXG5cdFx0e1xuXHRcdFx0aWQ6IFwic3F1YXJlXCIsXG5cdFx0XHRsYWJlbDogXCJTcXVhcmVcIixcblx0XHRcdGtpbmQ6IFwibm9kZVwiLFxuXHRcdFx0bm9kZVR5cGU6IFwic3F1YXJlXCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcImNpcmNsZVwiLFxuXHRcdFx0bGFiZWw6IFwiQ2lyY2xlXCIsXG5cdFx0XHRraW5kOiBcIm5vZGVcIixcblx0XHRcdG5vZGVUeXBlOiBcImNpcmNsZVwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJyZWN0YW5nbGVcIixcblx0XHRcdGxhYmVsOiBcIlJlY3RhbmdsZVwiLFxuXHRcdFx0a2luZDogXCJub2RlXCIsXG5cdFx0XHRub2RlVHlwZTogXCJyZWN0YW5nbGVcIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwiaGV4YWdvblwiLFxuXHRcdFx0bGFiZWw6IFwiSGV4YWdvblwiLFxuXHRcdFx0a2luZDogXCJub2RlXCIsXG5cdFx0XHRub2RlVHlwZTogXCJoZXhhZ29uXCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcImVkZ2VcIixcblx0XHRcdGxhYmVsOiBcIkVkZ2VcIixcblx0XHRcdGtpbmQ6IFwiZWRnZVwiXG5cdFx0fVxuXHRdXG59LCB1ID0gW2xdLCBkID0ge1xuXHRpZDogXCJhZ2VudGljLXdvcmtmbG93LXRvb2xzZXRcIixcblx0bGFiZWw6IFwiQWdlbnRpYyBXb3JrZmxvd1wiLFxuXHR0b29sczogW1xuXHRcdHtcblx0XHRcdGlkOiBcImluaXRpYXRpdmVcIixcblx0XHRcdGxhYmVsOiBcIkluaXRpYXRpdmVcIixcblx0XHRcdGtpbmQ6IFwibm9kZVwiLFxuXHRcdFx0bm9kZVR5cGU6IFwiaW5pdGlhdGl2ZVwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJzY2VuYXJpb1wiLFxuXHRcdFx0bGFiZWw6IFwiU2NlbmFyaW9cIixcblx0XHRcdGtpbmQ6IFwibm9kZVwiLFxuXHRcdFx0bm9kZVR5cGU6IFwic2NlbmFyaW9cIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwibGlmZWN5Y2xlXCIsXG5cdFx0XHRsYWJlbDogXCJMaWZlY3ljbGVcIixcblx0XHRcdGtpbmQ6IFwibm9kZVwiLFxuXHRcdFx0bm9kZVR5cGU6IFwibGlmZWN5Y2xlXCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcImNvbnRleHRcIixcblx0XHRcdGxhYmVsOiBcIkNvbnRleHRcIixcblx0XHRcdGtpbmQ6IFwibm9kZVwiLFxuXHRcdFx0bm9kZVR5cGU6IFwiY29udGV4dFwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJjb25uZWN0b3JcIixcblx0XHRcdGxhYmVsOiBcIkNvbm5lY3RvclwiLFxuXHRcdFx0a2luZDogXCJlZGdlXCIsXG5cdFx0XHRpY29uQ2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX3Rvb2xJY29uLS1lZGdlXCJcblx0XHR9XG5cdF1cbn0sIGYgPSBbZF0sIHAgPSB7XG5cdHNxdWFyZTogXCJTcXVhcmVcIixcblx0Y2lyY2xlOiBcIkNpcmNsZVwiLFxuXHRyZWN0YW5nbGU6IFwiUmVjdGFuZ2xlXCIsXG5cdGhleGFnb246IFwiSGV4YWdvblwiLFxuXHRpbml0aWF0aXZlOiBcIkluaXRpYXRpdmVcIixcblx0c2NlbmFyaW86IFwiU2NlbmFyaW9cIixcblx0bGlmZWN5Y2xlOiBcIkxpZmVjeWNsZVwiLFxuXHRjb250ZXh0OiBcIkNvbnRleHRcIixcblx0ZWRnZTogXCJFZGdlXCJcbn0sIG0gPSB7XG5cdHNxdWFyZToge1xuXHRcdHdpZHRoOiAxMDAsXG5cdFx0aGVpZ2h0OiAxMDBcblx0fSxcblx0Y2lyY2xlOiB7XG5cdFx0d2lkdGg6IDEwMCxcblx0XHRoZWlnaHQ6IDEwMFxuXHR9LFxuXHRyZWN0YW5nbGU6IHtcblx0XHR3aWR0aDogMTQwLFxuXHRcdGhlaWdodDogOTBcblx0fSxcblx0aGV4YWdvbjoge1xuXHRcdHdpZHRoOiAxMjAsXG5cdFx0aGVpZ2h0OiAxMDRcblx0fSxcblx0aW5pdGlhdGl2ZToge1xuXHRcdHdpZHRoOiAxODAsXG5cdFx0aGVpZ2h0OiAxMTBcblx0fSxcblx0c2NlbmFyaW86IHtcblx0XHR3aWR0aDogMTkwLFxuXHRcdGhlaWdodDogMTAwXG5cdH0sXG5cdGxpZmVjeWNsZToge1xuXHRcdHdpZHRoOiAxMjYsXG5cdFx0aGVpZ2h0OiAxMjZcblx0fSxcblx0Y29udGV4dDoge1xuXHRcdHdpZHRoOiAxOTAsXG5cdFx0aGVpZ2h0OiAxMjRcblx0fVxufSwgaCA9IHtcblx0c2ltcGxlOiBcInNxdWFyZVwiLFxuXHRcImFnZW50aWMtd29ya2Zsb3dcIjogXCJpbml0aWF0aXZlXCJcbn0sIGcgPSAuNSwgXyA9IDIuNSwgdiA9IHtcblx0XCJpbml0aWF0aXZlLT5pbml0aWF0aXZlXCI6IFwiRXh0ZW5kXCIsXG5cdFwiaW5pdGlhdGl2ZS0+c2NlbmFyaW9cIjogXCJSZXN1bHRJblwiLFxuXHRcInNjZW5hcmlvLT5saWZlY3ljbGVcIjogXCJVc2VcIixcblx0XCJjb250ZXh0LT5saWZlY3ljbGVcIjogXCJVc2VkQnlcIlxufSwgeSA9ICgpID0+IHR5cGVvZiBjcnlwdG8gPCBcInVcIiAmJiBcInJhbmRvbVVVSURcIiBpbiBjcnlwdG8gPyBjcnlwdG8ucmFuZG9tVVVJRCgpIDogYCR7RGF0ZS5ub3coKS50b1N0cmluZygzNil9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygxNikuc2xpY2UoMil9YCwgZWUgPSAoZSwgdCwgbikgPT4gTWF0aC5taW4obiwgTWF0aC5tYXgodCwgZSkpLCBiID0gKGUsIHQpID0+IHZbYCR7ZX0tPiR7dH1gXSA/PyBudWxsLCB4ID0gKGUsIHQsIG4sIHIpID0+IHtcblx0bGV0IGkgPSBlLmZpbmQoKGUpID0+IGUuaWQgPT09IG4pLCBhID0gZS5maW5kKChlKSA9PiBlLmlkID09PSByKTtcblx0aWYgKCFpIHx8ICFhKSByZXR1cm4ge1xuXHRcdGFsbG93ZWQ6ICExLFxuXHRcdGxhYmVsOiBudWxsXG5cdH07XG5cdGxldCBvID0gYihpLnR5cGUsIGEudHlwZSk7XG5cdGlmICghbyB8fCBpLnR5cGUgPT09IFwic2NlbmFyaW9cIiAmJiBhLnR5cGUgPT09IFwibGlmZWN5Y2xlXCIgJiYgdC5zb21lKCh0KSA9PiB0LmZyb21JZCA9PT0gbiA/IGUuZmluZCgoZSkgPT4gZS5pZCA9PT0gdC50b0lkKT8udHlwZSA9PT0gXCJsaWZlY3ljbGVcIiA6ICExKSkgcmV0dXJuIHtcblx0XHRhbGxvd2VkOiAhMSxcblx0XHRsYWJlbDogbnVsbFxuXHR9O1xuXHRpZiAoaS50eXBlID09PSBcImluaXRpYXRpdmVcIiAmJiBhLnR5cGUgPT09IFwiaW5pdGlhdGl2ZVwiKSB7XG5cdFx0aWYgKHQuc29tZSgodCkgPT4gdC50b0lkID09PSByID8gZS5maW5kKChlKSA9PiBlLmlkID09PSB0LmZyb21JZCk/LnR5cGUgPT09IFwiaW5pdGlhdGl2ZVwiIDogITEpKSByZXR1cm4ge1xuXHRcdFx0YWxsb3dlZDogITEsXG5cdFx0XHRsYWJlbDogbnVsbFxuXHRcdH07XG5cdFx0bGV0IGkgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdGZvciAobGV0IG4gb2YgdCkge1xuXHRcdFx0bGV0IHQgPSBlLmZpbmQoKGUpID0+IGUuaWQgPT09IG4uZnJvbUlkKSwgciA9IGUuZmluZCgoZSkgPT4gZS5pZCA9PT0gbi50b0lkKTtcblx0XHRcdGlmICh0Py50eXBlICE9PSBcImluaXRpYXRpdmVcIiB8fCByPy50eXBlICE9PSBcImluaXRpYXRpdmVcIikgY29udGludWU7XG5cdFx0XHRsZXQgYSA9IGkuZ2V0KG4uZnJvbUlkKSA/PyBbXTtcblx0XHRcdGEucHVzaChuLnRvSWQpLCBpLnNldChuLmZyb21JZCwgYSk7XG5cdFx0fVxuXHRcdGlmICgoKGUsIHQpID0+IHtcblx0XHRcdGxldCBuID0gW2VdLCByID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRcdGZvciAoOyBuLmxlbmd0aCA+IDA7KSB7XG5cdFx0XHRcdGxldCBlID0gbi5wb3AoKTtcblx0XHRcdFx0aWYgKCFlIHx8IHIuaGFzKGUpKSBjb250aW51ZTtcblx0XHRcdFx0aWYgKGUgPT09IHQpIHJldHVybiAhMDtcblx0XHRcdFx0ci5hZGQoZSk7XG5cdFx0XHRcdGxldCBhID0gaS5nZXQoZSkgPz8gW107XG5cdFx0XHRcdGZvciAobGV0IGUgb2YgYSkgbi5wdXNoKGUpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuICExO1xuXHRcdH0pKHIsIG4pKSByZXR1cm4ge1xuXHRcdFx0YWxsb3dlZDogITEsXG5cdFx0XHRsYWJlbDogbnVsbFxuXHRcdH07XG5cdH1cblx0cmV0dXJuIHtcblx0XHRhbGxvd2VkOiAhMCxcblx0XHRsYWJlbDogb1xuXHR9O1xufSwgdGUgPSAoZSwgdCwgbiA9IDQpID0+IHtcblx0bGV0IHIgPSBlLnRyaW0oKS5yZXBsYWNlKC9cXHMrL2csIFwiIFwiKTtcblx0aWYgKCFyKSByZXR1cm4gW1wiXCJdO1xuXHRsZXQgaSA9IE1hdGgubWF4KDksIE1hdGguZmxvb3IoKHQgLSAxNikgLyA2LjQpKSwgYSA9IHIuc3BsaXQoXCIgXCIpLCBvID0gW10sIHMgPSBcIlwiO1xuXHRmb3IgKGxldCBlIG9mIGEpIHtcblx0XHRsZXQgdCA9IGU7XG5cdFx0Zm9yICg7IHQubGVuZ3RoID4gaTspIHtcblx0XHRcdGxldCBlID0gdC5zbGljZSgwLCBpIC0gMSkgKyBcIi1cIjtcblx0XHRcdGlmICh0ID0gdC5zbGljZShpIC0gMSksIHMubGVuZ3RoID4gMCAmJiAoby5wdXNoKHMpLCBzID0gXCJcIiksIG8ucHVzaChlKSwgby5sZW5ndGggPj0gbikge1xuXHRcdFx0XHRsZXQgZSA9IG8uc2xpY2UoMCwgbik7XG5cdFx0XHRcdHJldHVybiBlW24gLSAxXSA9IGAke2VbbiAtIDFdLnNsaWNlKDAsIE1hdGgubWF4KDEsIGkgLSAxKSl94oCmYCwgZTtcblx0XHRcdH1cblx0XHR9XG5cdFx0bGV0IHIgPSBzLmxlbmd0aCA+IDAgPyBgJHtzfSAke3R9YCA6IHQ7XG5cdFx0aWYgKHIubGVuZ3RoIDw9IGkpIHtcblx0XHRcdHMgPSByO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChzLmxlbmd0aCA+IDAgJiYgby5wdXNoKHMpLCBzID0gdCwgby5sZW5ndGggPj0gbikgYnJlYWs7XG5cdH1cblx0aWYgKHMubGVuZ3RoID4gMCAmJiBvLmxlbmd0aCA8IG4gJiYgby5wdXNoKHMpLCBvLmxlbmd0aCA8PSBuKSByZXR1cm4gbztcblx0bGV0IGMgPSBvLnNsaWNlKDAsIG4pO1xuXHRyZXR1cm4gY1tuIC0gMV0gPSBgJHtjW24gLSAxXS5zbGljZSgwLCBNYXRoLm1heCgxLCBpIC0gMSkpfeKApmAsIGM7XG59LCBTID0gZShmdW5jdGlvbih7IGNsYXNzTmFtZTogZSwgdG9vbGJveExhYmVsOiBsID0gXCJUb29sc1wiLCB0b29sc2V0OiBkID0gXCJzaW1wbGVcIiwgdG9vbHNldHM6IHYsIFRvb2xib3hDb21wb25lbnQ6IGIgPSBjLCBvblNoYXBlQWRkOiBTLCBvblNoYXBlTW92ZTogQywgLi4ubmUgfSwgdykge1xuXHRsZXQgVCA9IGQsIEUgPSAhISh2ICYmIHYubGVuZ3RoID4gMCksIEQgPSBoW1RdLCBPID0gIUUgJiYgVCA9PT0gXCJhZ2VudGljLXdvcmtmbG93XCIsIGsgPSByKCgpID0+IHYgJiYgdi5sZW5ndGggPiAwID8gdiA6IFQgPT09IFwiYWdlbnRpYy13b3JrZmxvd1wiID8gZiA6IHUsIFtULCB2XSksIEEgPSBpKG51bGwpLCBbaiwgTV0gPSBhKFtdKSwgW04sIFBdID0gYShbXSksIFtGLCBJXSA9IGEoRCksIFtyZSwgTF0gPSBhKHt9KSwgW1IsIGllXSA9IGEoITEpLCBbeiwgQl0gPSBhKG51bGwpLCBbViwgSF0gPSBhKG51bGwpLCBbVSwgV10gPSBhKG51bGwpLCBbRywgS10gPSBhKG51bGwpLCBbcSwgSl0gPSBhKHtcblx0XHRzY2FsZTogMSxcblx0XHRvZmZzZXRYOiAwLFxuXHRcdG9mZnNldFk6IDBcblx0fSksIFkgPSBpKHEpO1xuXHRuKCgpID0+IHtcblx0XHRZLmN1cnJlbnQgPSBxO1xuXHR9LCBbcV0pLCBuKCgpID0+IHtcblx0XHRMKChlKSA9PiB7XG5cdFx0XHRsZXQgdCA9IHt9O1xuXHRcdFx0Zm9yIChsZXQgbiBvZiBrKSB0W24uaWRdID0gZVtuLmlkXSA/PyBudWxsO1xuXHRcdFx0cmV0dXJuIHQ7XG5cdFx0fSk7XG5cdH0sIFtrXSksIG4oKCkgPT4ge1xuXHRcdGxldCBlID0gbmV3IFNldChbXCJlZGdlXCJdKTtcblx0XHRmb3IgKGxldCB0IG9mIGspIGZvciAobGV0IG4gb2YgdC50b29scykgbi5raW5kID09PSBcIm5vZGVcIiAmJiBuLm5vZGVUeXBlICYmIGUuYWRkKG4ubm9kZVR5cGUpO1xuXHRcdEkoKHQpID0+IGUuaGFzKHQpID8gdCA6IEQpO1xuXHR9LCBbRCwga10pO1xuXHRsZXQgYWUgPSByKCgpID0+IGB0cmFuc2xhdGUoJHtxLm9mZnNldFh9LCAke3Eub2Zmc2V0WX0pIHNjYWxlKCR7cS5zY2FsZX0pYCwgW3FdKSwgWCA9IHQoKGUsIHQsIG4pID0+IHtcblx0XHRsZXQgeyBzY2FsZTogciwgb2Zmc2V0WDogaSwgb2Zmc2V0WTogYSB9ID0gWS5jdXJyZW50O1xuXHRcdHJldHVybiB7XG5cdFx0XHR4OiAoZSAtIG4ubGVmdCAtIGkpIC8gcixcblx0XHRcdHk6ICh0IC0gbi50b3AgLSBhKSAvIHJcblx0XHR9O1xuXHR9LCBbXSksIFogPSB0KChlLCB0KSA9PiB7XG5cdFx0bGV0IG4gPSBBLmN1cnJlbnQ/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRcdGlmICghbikgcmV0dXJuO1xuXHRcdGxldCByID0gbVtlXSwgaSA9IFgobi5sZWZ0ICsgbi53aWR0aCAvIDIsIG4udG9wICsgbi5oZWlnaHQgLyAyLCBuKTtcblx0XHRNKChuKSA9PiB7XG5cdFx0XHRsZXQgYSA9IHtcblx0XHRcdFx0aWQ6IHkoKSxcblx0XHRcdFx0dHlwZTogZSxcblx0XHRcdFx0bGFiZWw6IGAke3QgPz8gcFtlXX0gJHtuLmxlbmd0aCArIDF9YCxcblx0XHRcdFx0d2lkdGg6IHIud2lkdGgsXG5cdFx0XHRcdGhlaWdodDogci5oZWlnaHQsXG5cdFx0XHRcdHg6IGkueCAtIHIud2lkdGggLyAyLFxuXHRcdFx0XHR5OiBpLnkgLSByLmhlaWdodCAvIDIsXG5cdFx0XHRcdGNyZWF0ZWRBdDogRGF0ZS5ub3coKVxuXHRcdFx0fSwgbyA9IFsuLi5uLCBhXTtcblx0XHRcdHJldHVybiBTPy4oYSksIEIoYS5pZCksIG87XG5cdFx0fSk7XG5cdH0sIFtTLCBYXSksIFEgPSB0KChlLCB0KSA9PiB7XG5cdFx0ZSAhPT0gdCAmJiBQKChuKSA9PiB7XG5cdFx0XHRpZiAoTyA/IG4uc29tZSgobikgPT4gbi5mcm9tSWQgPT09IGUgJiYgbi50b0lkID09PSB0KSA6IG4uc29tZSgobikgPT4gbi5mcm9tSWQgPT09IGUgJiYgbi50b0lkID09PSB0IHx8IG4uZnJvbUlkID09PSB0ICYmIG4udG9JZCA9PT0gZSkpIHJldHVybiBuO1xuXHRcdFx0bGV0IHIgPSBgRWRnZSAke24ubGVuZ3RoICsgMX1gO1xuXHRcdFx0aWYgKE8pIHtcblx0XHRcdFx0bGV0IGkgPSB4KGosIG4sIGUsIHQpO1xuXHRcdFx0XHRpZiAoIWkuYWxsb3dlZCB8fCAhaS5sYWJlbCkgcmV0dXJuIG47XG5cdFx0XHRcdHIgPSBpLmxhYmVsO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIFsuLi5uLCB7XG5cdFx0XHRcdGlkOiB5KCksXG5cdFx0XHRcdGZyb21JZDogZSxcblx0XHRcdFx0dG9JZDogdCxcblx0XHRcdFx0bGFiZWw6IHIsXG5cdFx0XHRcdGNyZWF0ZWRBdDogRGF0ZS5ub3coKVxuXHRcdFx0fV07XG5cdFx0fSk7XG5cdH0sIFtPLCBqXSksIG9lID0gdCgoZSwgdCkgPT4ge1xuXHRcdGlmIChMKChuKSA9PiAoe1xuXHRcdFx0Li4ubixcblx0XHRcdFt0XTogZS5pZFxuXHRcdH0pKSwgZS5raW5kID09PSBcImVkZ2VcIikge1xuXHRcdFx0aWYgKCF6KSByZXR1cm47XG5cdFx0XHRJKFwiZWRnZVwiKSwgSCh6KTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0ZS5ub2RlVHlwZSAmJiAoSShlLm5vZGVUeXBlKSwgSChudWxsKSk7XG5cdH0sIFt6XSksIHNlID0gdCgoZSwgdCkgPT4ge1xuXHRcdGUua2luZCAhPT0gXCJlZGdlXCIgJiYgZS5ub2RlVHlwZSAmJiAoTCgobikgPT4gKHtcblx0XHRcdC4uLm4sXG5cdFx0XHRbdF06IGUuaWRcblx0XHR9KSksIEkoZS5ub2RlVHlwZSksIEgobnVsbCksIFooZS5ub2RlVHlwZSwgZS5sYWJlbCkpO1xuXHR9LCBbWl0pLCBjZSA9IHQoKCkgPT4ge1xuXHRcdGllKChlKSA9PiAhZSk7XG5cdH0sIFtdKSwgJCA9IHQoKGUsIHQpID0+IHtcblx0XHRpZiAoZS5wcmV2ZW50RGVmYXVsdCgpLCBlLnN0b3BQcm9wYWdhdGlvbigpLCBCKHQpLCBGID09PSBcImVkZ2VcIikge1xuXHRcdFx0ViAmJiBWICE9PSB0ICYmIChRKFYsIHQpLCBIKG51bGwpLCBJKEQpKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0bGV0IG4gPSBBLmN1cnJlbnQ/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLCByID0gai5maW5kKChlKSA9PiBlLmlkID09PSB0KTtcblx0XHRpZiAoIW4gfHwgIXIpIHJldHVybjtcblx0XHRsZXQgeyB4OiBpLCB5OiBhIH0gPSBYKGUuY2xpZW50WCwgZS5jbGllbnRZLCBuKTtcblx0XHRXKHtcblx0XHRcdGlkOiB0LFxuXHRcdFx0b2Zmc2V0WDogaSAtIHIueCxcblx0XHRcdG9mZnNldFk6IGEgLSByLnksXG5cdFx0XHRwb2ludGVySWQ6IGUucG9pbnRlcklkXG5cdFx0fSk7XG5cdH0sIFtcblx0XHRGLFxuXHRcdFEsXG5cdFx0RCxcblx0XHRWLFxuXHRcdGosXG5cdFx0WFxuXHRdKSwgbGUgPSB0KChlKSA9PiB7XG5cdFx0aWYgKGUuYnV0dG9uICE9PSAwKSByZXR1cm47XG5cdFx0QihudWxsKSwgRiA9PT0gXCJlZGdlXCIgJiYgKEgobnVsbCksIEkoRCkpO1xuXHRcdGxldCB0ID0gZS5wb2ludGVySWQ7XG5cdFx0ZS5jdXJyZW50VGFyZ2V0LnNldFBvaW50ZXJDYXB0dXJlKHQpLCBLKHtcblx0XHRcdHBvaW50ZXJJZDogdCxcblx0XHRcdHN0YXJ0WDogZS5jbGllbnRYLFxuXHRcdFx0c3RhcnRZOiBlLmNsaWVudFksXG5cdFx0XHRzdGFydE9mZnNldFg6IHEub2Zmc2V0WCxcblx0XHRcdHN0YXJ0T2Zmc2V0WTogcS5vZmZzZXRZXG5cdFx0fSk7XG5cdH0sIFtcblx0XHRGLFxuXHRcdEQsXG5cdFx0cVxuXHRdKSwgdWUgPSB0KChlKSA9PiB7XG5cdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdGxldCB0ID0gQS5jdXJyZW50Py5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcblx0XHRpZiAoIXQpIHJldHVybjtcblx0XHRsZXQgbiA9IGUuY2xpZW50WCAtIHQubGVmdCwgciA9IGUuY2xpZW50WSAtIHQudG9wLCBpID0gLWUuZGVsdGFZICogLjAwMTU7XG5cdFx0SigoZSkgPT4ge1xuXHRcdFx0bGV0IHQgPSBlZShlLnNjYWxlICsgaSwgZywgXyk7XG5cdFx0XHRpZiAodCA9PT0gZS5zY2FsZSkgcmV0dXJuIGU7XG5cdFx0XHRsZXQgYSA9IChuIC0gZS5vZmZzZXRYKSAvIGUuc2NhbGUsIG8gPSAociAtIGUub2Zmc2V0WSkgLyBlLnNjYWxlO1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0c2NhbGU6IHQsXG5cdFx0XHRcdG9mZnNldFg6IG4gLSBhICogdCxcblx0XHRcdFx0b2Zmc2V0WTogciAtIG8gKiB0XG5cdFx0XHR9O1xuXHRcdH0pO1xuXHR9LCBbXSk7XG5cdG4oKCkgPT4ge1xuXHRcdGlmICghVSkgcmV0dXJuO1xuXHRcdGxldCBlID0gKGUpID0+IHtcblx0XHRcdGlmIChlLnBvaW50ZXJJZCAhPT0gVS5wb2ludGVySWQpIHJldHVybjtcblx0XHRcdGxldCB0ID0gQS5jdXJyZW50Py5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcblx0XHRcdHQgJiYgTSgobikgPT4gbi5tYXAoKG4pID0+IHtcblx0XHRcdFx0aWYgKG4uaWQgIT09IFUuaWQpIHJldHVybiBuO1xuXHRcdFx0XHRsZXQgeyB4OiByLCB5OiBpIH0gPSBYKGUuY2xpZW50WCwgZS5jbGllbnRZLCB0KSwgYSA9IHtcblx0XHRcdFx0XHQuLi5uLFxuXHRcdFx0XHRcdHg6IHIgLSBVLm9mZnNldFgsXG5cdFx0XHRcdFx0eTogaSAtIFUub2Zmc2V0WVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRyZXR1cm4gQz8uKGEpLCBhO1xuXHRcdFx0fSkpO1xuXHRcdH0sIHQgPSAoZSkgPT4ge1xuXHRcdFx0ZS5wb2ludGVySWQgPT09IFUucG9pbnRlcklkICYmIFcobnVsbCk7XG5cdFx0fTtcblx0XHRyZXR1cm4gZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJtb3ZlXCIsIGUpLCBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcnVwXCIsIHQpLCAoKSA9PiB7XG5cdFx0XHRkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcm1vdmVcIiwgZSksIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVydXBcIiwgdCk7XG5cdFx0fTtcblx0fSwgW1xuXHRcdFUsXG5cdFx0Qyxcblx0XHRYXG5cdF0pLCBuKCgpID0+IHtcblx0XHRpZiAoIUcpIHJldHVybjtcblx0XHRsZXQgZSA9IChlKSA9PiB7XG5cdFx0XHRpZiAoZS5wb2ludGVySWQgIT09IEcucG9pbnRlcklkKSByZXR1cm47XG5cdFx0XHRsZXQgdCA9IGUuY2xpZW50WCAtIEcuc3RhcnRYLCBuID0gZS5jbGllbnRZIC0gRy5zdGFydFk7XG5cdFx0XHRKKChlKSA9PiAoe1xuXHRcdFx0XHQuLi5lLFxuXHRcdFx0XHRvZmZzZXRYOiBHLnN0YXJ0T2Zmc2V0WCArIHQsXG5cdFx0XHRcdG9mZnNldFk6IEcuc3RhcnRPZmZzZXRZICsgblxuXHRcdFx0fSkpO1xuXHRcdH0sIHQgPSAoZSkgPT4ge1xuXHRcdFx0ZS5wb2ludGVySWQgPT09IEcucG9pbnRlcklkICYmIChBLmN1cnJlbnQ/LnJlbGVhc2VQb2ludGVyQ2FwdHVyZShHLnBvaW50ZXJJZCksIEsobnVsbCkpO1xuXHRcdH07XG5cdFx0cmV0dXJuIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJwb2ludGVybW92ZVwiLCBlKSwgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJ1cFwiLCB0KSwgKCkgPT4ge1xuXHRcdFx0ZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJtb3ZlXCIsIGUpLCBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcnVwXCIsIHQpO1xuXHRcdH07XG5cdH0sIFtHXSk7XG5cdGxldCBkZSA9IFtcblx0XHRcIm5hYnMtdWktZ3JhcGhcIixcblx0XHRSID8gXCJuYWJzLXVpLWdyYXBoLS10b29sYm94LWNvbGxhcHNlZFwiIDogXCJcIixcblx0XHRlXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBmZSA9IHogIT09IG51bGwsIHBlID0gRiA9PT0gXCJlZGdlXCIgJiYgViA/IFwiU2VsZWN0IGFub3RoZXIgbm9kZVwiIDogXCJTZWxlY3Qgbm9kZSBmaXJzdFwiO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdHJlZjogdyxcblx0XHRjbGFzc05hbWU6IGRlLFxuXHRcdC4uLm5lLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX2NhbnZhc1wiLFxuXHRcdFx0cmVmOiBBLFxuXHRcdFx0b25Qb2ludGVyRG93bjogbGUsXG5cdFx0XHRvbldoZWVsOiB1ZSxcblx0XHRcdHJvbGU6IFwicHJlc2VudGF0aW9uXCIsXG5cdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBvKFwic3ZnXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX2NhbnZhc1N2Z1wiLFxuXHRcdFx0XHRyb2xlOiBcInByZXNlbnRhdGlvblwiLFxuXHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIHMoXCJnXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fdmlld3BvcnRcIixcblx0XHRcdFx0XHR0cmFuc2Zvcm06IGFlLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbTi5tYXAoKGUpID0+IHtcblx0XHRcdFx0XHRcdGxldCB0ID0gai5maW5kKCh0KSA9PiB0LmlkID09PSBlLmZyb21JZCksIG4gPSBqLmZpbmQoKHQpID0+IHQuaWQgPT09IGUudG9JZCk7XG5cdFx0XHRcdFx0XHRpZiAoIXQgfHwgIW4pIHJldHVybiBudWxsO1xuXHRcdFx0XHRcdFx0bGV0IHIgPSAodC54ICsgdC53aWR0aCAvIDIgKyAobi54ICsgbi53aWR0aCAvIDIpKSAvIDIsIGkgPSAodC55ICsgdC5oZWlnaHQgLyAyICsgKG4ueSArIG4uaGVpZ2h0IC8gMikpIC8gMjtcblx0XHRcdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImdcIiwgeyBjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBvKFwibGluZVwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyYXBoX19lZGdlXCIsXG5cdFx0XHRcdFx0XHRcdHgxOiB0LnggKyB0LndpZHRoIC8gMixcblx0XHRcdFx0XHRcdFx0eTE6IHQueSArIHQuaGVpZ2h0IC8gMixcblx0XHRcdFx0XHRcdFx0eDI6IG4ueCArIG4ud2lkdGggLyAyLFxuXHRcdFx0XHRcdFx0XHR5Mjogbi55ICsgbi5oZWlnaHQgLyAyXG5cdFx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIG8oXCJ0ZXh0XCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX2VkZ2VMYWJlbFwiLFxuXHRcdFx0XHRcdFx0XHR4OiByLFxuXHRcdFx0XHRcdFx0XHR5OiBpIC0gNixcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUubGFiZWxcblx0XHRcdFx0XHRcdH0pXSB9LCBlLmlkKTtcblx0XHRcdFx0XHR9KSwgai5tYXAoKGUpID0+IHtcblx0XHRcdFx0XHRcdGxldCB0ID0gdGUoZS5sYWJlbCwgZS53aWR0aCksIG4gPSBlLnggKyBlLndpZHRoIC8gMiwgciA9IGUueSArIGUuaGVpZ2h0IC8gMiAtICh0Lmxlbmd0aCAtIDEpICogMTIgLyAyLCBpID0ge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFtcblx0XHRcdFx0XHRcdFx0XHRcIm5hYnMtdWktZ3JhcGhfX3NoYXBlXCIsXG5cdFx0XHRcdFx0XHRcdFx0ZS50eXBlID09PSBcImNpcmNsZVwiICYmIFwibmFicy11aS1ncmFwaF9fc2hhcGUtLWNpcmNsZVwiLFxuXHRcdFx0XHRcdFx0XHRcdGUudHlwZSA9PT0gXCJyZWN0YW5nbGVcIiAmJiBcIm5hYnMtdWktZ3JhcGhfX3NoYXBlLS1yZWN0YW5nbGVcIixcblx0XHRcdFx0XHRcdFx0XHRlLnR5cGUgPT09IFwiaGV4YWdvblwiICYmIFwibmFicy11aS1ncmFwaF9fc2hhcGUtLWhleGFnb25cIixcblx0XHRcdFx0XHRcdFx0XHRlLnR5cGUgPT09IFwiaW5pdGlhdGl2ZVwiICYmIFwibmFicy11aS1ncmFwaF9fc2hhcGUtLWluaXRpYXRpdmVcIixcblx0XHRcdFx0XHRcdFx0XHRlLnR5cGUgPT09IFwic2NlbmFyaW9cIiAmJiBcIm5hYnMtdWktZ3JhcGhfX3NoYXBlLS1zY2VuYXJpb1wiLFxuXHRcdFx0XHRcdFx0XHRcdGUudHlwZSA9PT0gXCJsaWZlY3ljbGVcIiAmJiBcIm5hYnMtdWktZ3JhcGhfX3NoYXBlLS1saWZlY3ljbGVcIixcblx0XHRcdFx0XHRcdFx0XHRlLnR5cGUgPT09IFwiY29udGV4dFwiICYmIFwibmFicy11aS1ncmFwaF9fc2hhcGUtLWNvbnRleHRcIixcblx0XHRcdFx0XHRcdFx0XHR6ID09PSBlLmlkICYmIFwibmFicy11aS1ncmFwaF9fc2hhcGUtLXNlbGVjdGVkXCJcblx0XHRcdFx0XHRcdFx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0XHRcdG9uUG9pbnRlckRvd246ICh0KSA9PiAkKHQsIGUuaWQpLFxuXHRcdFx0XHRcdFx0XHRyb2xlOiBcInByZXNlbnRhdGlvblwiLFxuXHRcdFx0XHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6ICEwXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0aWYgKGUudHlwZSA9PT0gXCJjaXJjbGVcIikge1xuXHRcdFx0XHRcdFx0XHRsZXQgYSA9IGUud2lkdGggLyAyLCBjID0gZS54ICsgYSwgbCA9IGUueSArIGE7XG5cdFx0XHRcdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImdcIiwgeyBjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBvKFwiY2lyY2xlXCIsIHtcblx0XHRcdFx0XHRcdFx0XHQuLi5pLFxuXHRcdFx0XHRcdFx0XHRcdGN4OiBjLFxuXHRcdFx0XHRcdFx0XHRcdGN5OiBsLFxuXHRcdFx0XHRcdFx0XHRcdHI6IGFcblx0XHRcdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBvKFwidGV4dFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX25vZGVMYWJlbFwiLFxuXHRcdFx0XHRcdFx0XHRcdHg6IG4sXG5cdFx0XHRcdFx0XHRcdFx0eTogcixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdC5tYXAoKHQsIHIpID0+IC8qIEBfX1BVUkVfXyAqLyBvKFwidHNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0eDogbixcblx0XHRcdFx0XHRcdFx0XHRcdGR5OiByID09PSAwID8gMCA6IDEyLFxuXHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IHRcblx0XHRcdFx0XHRcdFx0XHR9LCBgJHtlLmlkfS1saW5lLSR7cn1gKSlcblx0XHRcdFx0XHRcdFx0fSldIH0sIGUuaWQpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKGUudHlwZSA9PT0gXCJzY2VuYXJpb1wiKSB7XG5cdFx0XHRcdFx0XHRcdGxldCBhID0gTWF0aC5taW4oMjYsIE1hdGgucm91bmQoZS53aWR0aCAqIC4xNikpLCBjID0gW1xuXHRcdFx0XHRcdFx0XHRcdGAke2UueCArIGF9LCR7ZS55fWAsXG5cdFx0XHRcdFx0XHRcdFx0YCR7ZS54ICsgZS53aWR0aH0sJHtlLnl9YCxcblx0XHRcdFx0XHRcdFx0XHRgJHtlLnggKyBlLndpZHRoIC0gYX0sJHtlLnkgKyBlLmhlaWdodH1gLFxuXHRcdFx0XHRcdFx0XHRcdGAke2UueH0sJHtlLnkgKyBlLmhlaWdodH1gXG5cdFx0XHRcdFx0XHRcdF0uam9pbihcIiBcIik7XG5cdFx0XHRcdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImdcIiwgeyBjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBvKFwicG9seWdvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0Li4uaSxcblx0XHRcdFx0XHRcdFx0XHRwb2ludHM6IGNcblx0XHRcdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBvKFwidGV4dFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX25vZGVMYWJlbFwiLFxuXHRcdFx0XHRcdFx0XHRcdHg6IG4sXG5cdFx0XHRcdFx0XHRcdFx0eTogcixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdC5tYXAoKHQsIHIpID0+IC8qIEBfX1BVUkVfXyAqLyBvKFwidHNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0eDogbixcblx0XHRcdFx0XHRcdFx0XHRcdGR5OiByID09PSAwID8gMCA6IDEyLFxuXHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IHRcblx0XHRcdFx0XHRcdFx0XHR9LCBgJHtlLmlkfS1saW5lLSR7cn1gKSlcblx0XHRcdFx0XHRcdFx0fSldIH0sIGUuaWQpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKGUudHlwZSA9PT0gXCJjb250ZXh0XCIpIHtcblx0XHRcdFx0XHRcdFx0bGV0IGEgPSBNYXRoLm1pbigyNCwgTWF0aC5yb3VuZChlLndpZHRoICogLjE0KSksIGMgPSBlLnkgKyBlLmhlaWdodCAtIDksIGwgPSBbXG5cdFx0XHRcdFx0XHRcdFx0YE0gJHtlLnh9ICR7ZS55fWAsXG5cdFx0XHRcdFx0XHRcdFx0YEggJHtlLnggKyBlLndpZHRoIC0gYX1gLFxuXHRcdFx0XHRcdFx0XHRcdGBMICR7ZS54ICsgZS53aWR0aH0gJHtlLnkgKyBhfWAsXG5cdFx0XHRcdFx0XHRcdFx0YFYgJHtjfWAsXG5cdFx0XHRcdFx0XHRcdFx0YFEgJHtlLnggKyBlLndpZHRoICogLjc2fSAke2UueSArIGUuaGVpZ2h0ICsgOX0gJHtlLnggKyBlLndpZHRoICogLjV9ICR7Y31gLFxuXHRcdFx0XHRcdFx0XHRcdGBRICR7ZS54ICsgZS53aWR0aCAqIC4yNH0gJHtlLnkgKyBlLmhlaWdodCAtIDE4fSAke2UueH0gJHtjfWAsXG5cdFx0XHRcdFx0XHRcdFx0XCJaXCJcblx0XHRcdFx0XHRcdFx0XS5qb2luKFwiIFwiKTtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZ1wiLCB7IGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJwYXRoXCIsIHtcblx0XHRcdFx0XHRcdFx0XHQuLi5pLFxuXHRcdFx0XHRcdFx0XHRcdGQ6IGxcblx0XHRcdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBvKFwidGV4dFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX25vZGVMYWJlbFwiLFxuXHRcdFx0XHRcdFx0XHRcdHg6IG4sXG5cdFx0XHRcdFx0XHRcdFx0eTogcixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdC5tYXAoKHQsIHIpID0+IC8qIEBfX1BVUkVfXyAqLyBvKFwidHNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0eDogbixcblx0XHRcdFx0XHRcdFx0XHRcdGR5OiByID09PSAwID8gMCA6IDEyLFxuXHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IHRcblx0XHRcdFx0XHRcdFx0XHR9LCBgJHtlLmlkfS1saW5lLSR7cn1gKSlcblx0XHRcdFx0XHRcdFx0fSldIH0sIGUuaWQpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKGUudHlwZSA9PT0gXCJoZXhhZ29uXCIpIHtcblx0XHRcdFx0XHRcdFx0bGV0IGEgPSBbXG5cdFx0XHRcdFx0XHRcdFx0YCR7ZS54ICsgZS53aWR0aCAqIC4yNX0sJHtlLnl9YCxcblx0XHRcdFx0XHRcdFx0XHRgJHtlLnggKyBlLndpZHRoICogLjc1fSwke2UueX1gLFxuXHRcdFx0XHRcdFx0XHRcdGAke2UueCArIGUud2lkdGh9LCR7ZS55ICsgZS5oZWlnaHQgKiAuNX1gLFxuXHRcdFx0XHRcdFx0XHRcdGAke2UueCArIGUud2lkdGggKiAuNzV9LCR7ZS55ICsgZS5oZWlnaHR9YCxcblx0XHRcdFx0XHRcdFx0XHRgJHtlLnggKyBlLndpZHRoICogLjI1fSwke2UueSArIGUuaGVpZ2h0fWAsXG5cdFx0XHRcdFx0XHRcdFx0YCR7ZS54fSwke2UueSArIGUuaGVpZ2h0ICogLjV9YFxuXHRcdFx0XHRcdFx0XHRdLmpvaW4oXCIgXCIpO1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJnXCIsIHsgY2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcInBvbHlnb25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdC4uLmksXG5cdFx0XHRcdFx0XHRcdFx0cG9pbnRzOiBhXG5cdFx0XHRcdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gbyhcInRleHRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyYXBoX19ub2RlTGFiZWxcIixcblx0XHRcdFx0XHRcdFx0XHR4OiBuLFxuXHRcdFx0XHRcdFx0XHRcdHk6IHIsXG5cdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IHQubWFwKCh0LCByKSA9PiAvKiBAX19QVVJFX18gKi8gbyhcInRzcGFuXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdHg6IG4sXG5cdFx0XHRcdFx0XHRcdFx0XHRkeTogciA9PT0gMCA/IDAgOiAxMixcblx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiB0XG5cdFx0XHRcdFx0XHRcdFx0fSwgYCR7ZS5pZH0tbGluZS0ke3J9YCkpXG5cdFx0XHRcdFx0XHRcdH0pXSB9LCBlLmlkKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGxldCBhID0gZS50eXBlID09PSBcInJlY3RhbmdsZVwiIHx8IGUudHlwZSA9PT0gXCJpbml0aWF0aXZlXCIgPyAxNCA6IDQ7XG5cdFx0XHRcdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJnXCIsIHsgY2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcInJlY3RcIiwge1xuXHRcdFx0XHRcdFx0XHQuLi5pLFxuXHRcdFx0XHRcdFx0XHR4OiBlLngsXG5cdFx0XHRcdFx0XHRcdHk6IGUueSxcblx0XHRcdFx0XHRcdFx0d2lkdGg6IGUud2lkdGgsXG5cdFx0XHRcdFx0XHRcdGhlaWdodDogZS5oZWlnaHQsXG5cdFx0XHRcdFx0XHRcdHJ4OiBhXG5cdFx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIG8oXCJ0ZXh0XCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX25vZGVMYWJlbFwiLFxuXHRcdFx0XHRcdFx0XHR4OiBuLFxuXHRcdFx0XHRcdFx0XHR5OiByLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdC5tYXAoKHQsIHIpID0+IC8qIEBfX1BVUkVfXyAqLyBvKFwidHNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRcdHg6IG4sXG5cdFx0XHRcdFx0XHRcdFx0ZHk6IHIgPT09IDAgPyAwIDogMTIsXG5cdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IHRcblx0XHRcdFx0XHRcdFx0fSwgYCR7ZS5pZH0tbGluZS0ke3J9YCkpXG5cdFx0XHRcdFx0XHR9KV0gfSwgZS5pZCk7XG5cdFx0XHRcdFx0fSldXG5cdFx0XHRcdH0pXG5cdFx0XHR9KVxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gbyhiLCB7XG5cdFx0XHR0b29sYm94TGFiZWw6IGwsXG5cdFx0XHR0b29sc2V0czogayxcblx0XHRcdGlzQ29sbGFwc2VkOiBSLFxuXHRcdFx0aXNFZGdlVG9vbEVuYWJsZWQ6IGZlLFxuXHRcdFx0ZWRnZUhpbnQ6IHBlLFxuXHRcdFx0YWN0aXZlVG9vbElkc0J5U2V0OiByZSxcblx0XHRcdG9uVG9nZ2xlQ29sbGFwc2U6IGNlLFxuXHRcdFx0b25Ub29sQ2xpY2s6IG9lLFxuXHRcdFx0b25Ub29sRG91YmxlQ2xpY2s6IHNlXG5cdFx0fSldXG5cdH0pO1xufSk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFMgYXMgR3JhcGgsIGMgYXMgU2ltcGxlR3JhcGhUb29sc2V0LCBkIGFzIGFnZW50aWNXb3JrZmxvd1Rvb2xzZXQsIGYgYXMgYWdlbnRpY1dvcmtmbG93VG9vbHNldHMsIGwgYXMgc2ltcGxlR3JhcGhUb29sc2V0LCB1IGFzIHNpbXBsZUdyYXBoVG9vbHNldHMgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSwgdXNlRWZmZWN0IGFzIHQsIHVzZUlkIGFzIG4sIHVzZU1lbW8gYXMgciwgdXNlUmVmIGFzIGksIHVzZVN0YXRlIGFzIGEgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEZyYWdtZW50IGFzIG8sIGpzeCBhcyBzLCBqc3hzIGFzIGMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiAuLi9uYWJzLXVpLWJ1dHRvbnMvc3JjL2J1dHRvbi51dGlscy50c1xudmFyIGwgPSB7XG5cdHByaW1hcnk6IFwibmFicy11aS1idXR0b24tLXByaW1hcnlcIixcblx0c2Vjb25kYXJ5OiBcIm5hYnMtdWktYnV0dG9uLS1zZWNvbmRhcnlcIixcblx0Z2hvc3Q6IFwibmFicy11aS1idXR0b24tLWdob3N0XCJcbn0sIHUgPSBlKGZ1bmN0aW9uKHsgY2hpbGRyZW46IGUsIGNsYXNzTmFtZTogdCA9IFwiXCIsIHZhcmlhbnQ6IG4gPSBcInByaW1hcnlcIiwgdHlwZTogciA9IFwiYnV0dG9uXCIsIC4uLmkgfSwgYSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJidXR0b25cIiwge1xuXHRcdHJlZjogYSxcblx0XHRjbGFzc05hbWU6IFtcblx0XHRcdFwibmFicy11aS1idXR0b25cIixcblx0XHRcdGxbbl0gPz8gbC5wcmltYXJ5LFxuXHRcdFx0dFxuXHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdHR5cGU6IHIsXG5cdFx0Li4uaSxcblx0XHRjaGlsZHJlbjogZVxuXHR9KTtcbn0pO1xudS5kaXNwbGF5TmFtZSA9IFwiQnV0dG9uXCI7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi9uYWJzLXVpLWRpYWxvZy9zcmMvRGlhbG9nLnRzeFxudmFyIGQgPSBcImFbaHJlZl0sIGFyZWFbaHJlZl0sIGJ1dHRvbjpub3QoW2Rpc2FibGVkXSksIGlucHV0Om5vdChbZGlzYWJsZWRdKTpub3QoW3R5cGU9XFxcImhpZGRlblxcXCJdKSwgc2VsZWN0Om5vdChbZGlzYWJsZWRdKSwgdGV4dGFyZWE6bm90KFtkaXNhYmxlZF0pLCBbdGFiaW5kZXhdOm5vdChbdGFiaW5kZXg9XFxcIi0xXFxcIl0pXCI7XG5mdW5jdGlvbiBmKGUpIHtcblx0cmV0dXJuIEFycmF5LmZyb20oZS5xdWVyeVNlbGVjdG9yQWxsKGQpKS5maWx0ZXIoKGUpID0+ICFlLmhhc0F0dHJpYnV0ZShcImRpc2FibGVkXCIpICYmIGUuZ2V0QXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIikgIT09IFwidHJ1ZVwiKTtcbn1cbnZhciBwID0gZShmdW5jdGlvbih7IHRpdGxlOiBlLCBkZXNjcmlwdGlvbjogciwgaGVhZGVyOiBhLCBmb290ZXI6IG8sIHNob3dIZWFkZXI6IGwgPSAhMCwgc2hvd0Zvb3RlcjogdSA9ICEwLCBvblJlcXVlc3RDbG9zZTogZCwgY2xvc2VPbkJhY2tkcm9wQ2xpY2s6IHAgPSAhMCwgY2xvc2VPbkVzY2FwZTogZWUgPSAhMCwgaW5pdGlhbEZvY3VzU2VsZWN0b3I6IG0sIGRpYWxvZ1JvbGU6IGggPSBcImRpYWxvZ1wiLCBjbGFzc05hbWU6IGcgPSBcIlwiLCBiYWNrZHJvcENsYXNzTmFtZTogXyA9IFwiXCIsIGhlYWRlckNsYXNzTmFtZTogdiA9IFwiXCIsIGRlc2NyaXB0aW9uQ2xhc3NOYW1lOiB0ZSA9IFwiXCIsIGNvbnRlbnRDbGFzc05hbWU6IHkgPSBcIlwiLCBmb290ZXJDbGFzc05hbWU6IGIgPSBcIlwiLCBvbktleURvd246IHgsIHRhYkluZGV4OiBuZSwgY2hpbGRyZW46IHJlLCAuLi5pZSB9LCBhZSkge1xuXHRsZXQgUyA9IGkobnVsbCksIEMgPSBpKG51bGwpLCBvZSA9IGBuYWJzLXVpLWRpYWxvZy10aXRsZS0ke24oKS5yZXBsYWNlKC86L2csIFwiXCIpfWAsIHNlID0gYG5hYnMtdWktZGlhbG9nLWRlc2NyaXB0aW9uLSR7bigpLnJlcGxhY2UoLzovZywgXCJcIil9YCwgdyA9IGllW1wiYXJpYS1sYWJlbGxlZGJ5XCJdLCBjZSA9IGllW1wiYXJpYS1kZXNjcmliZWRieVwiXSwgVCA9ICFhICYmICEhZSwgRSA9ICEhciwgbGUgPSBsICYmICghIWEgfHwgVCksIHVlID0gdSAmJiBvICE9IG51bGwsIGRlID0gdyA/PyAoVCA/IG9lIDogdm9pZCAwKSwgRCA9IGNlID8/IChFID8gc2UgOiB2b2lkIDApLCBmZSA9IFtcIm5hYnMtdWktZGlhbG9nX19iYWNrZHJvcFwiLCBfXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIHBlID0gW1wibmFicy11aS1kaWFsb2dcIiwgZ10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBtZSA9IFtcIm5hYnMtdWktZGlhbG9nX19oZWFkZXJcIiwgdl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBoZSA9IFtcIm5hYnMtdWktZGlhbG9nX19kZXNjcmlwdGlvblwiLCB0ZV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBnZSA9IFtcIm5hYnMtdWktZGlhbG9nX19jb250ZW50XCIsIHldLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgX2UgPSBbXCJuYWJzLXVpLWRpYWxvZ19fZm9vdGVyXCIsIGJdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIHQoKCkgPT4ge1xuXHRcdGxldCBlID0gUy5jdXJyZW50O1xuXHRcdGlmICghZSkgcmV0dXJuO1xuXHRcdGlmIChDLmN1cnJlbnQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgPyBkb2N1bWVudC5hY3RpdmVFbGVtZW50IDogbnVsbCwgbSkgdHJ5IHtcblx0XHRcdGxldCB0ID0gZS5xdWVyeVNlbGVjdG9yKG0pO1xuXHRcdFx0aWYgKHQpIHJldHVybiB0LmZvY3VzKCksICgpID0+IHtcblx0XHRcdFx0Qy5jdXJyZW50Py5mb2N1cygpLCBDLmN1cnJlbnQgPSBudWxsO1xuXHRcdFx0fTtcblx0XHR9IGNhdGNoIHt9XG5cdFx0bGV0IHQgPSBmKGUpO1xuXHRcdHJldHVybiB0Lmxlbmd0aCA+IDAgPyB0WzBdLmZvY3VzKCkgOiBlLmZvY3VzKCksICgpID0+IHtcblx0XHRcdEMuY3VycmVudD8uZm9jdXMoKSwgQy5jdXJyZW50ID0gbnVsbDtcblx0XHR9O1xuXHR9LCBbbV0pLCAvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBmZSxcblx0XHRyb2xlOiBcInByZXNlbnRhdGlvblwiLFxuXHRcdG9uQ2xpY2s6IChlKSA9PiB7XG5cdFx0XHQhcCB8fCBlLnRhcmdldCAhPT0gZS5jdXJyZW50VGFyZ2V0IHx8IGQ/LigpO1xuXHRcdH0sXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBjKFwic2VjdGlvblwiLCB7XG5cdFx0XHRyZWY6IChlKSA9PiB7XG5cdFx0XHRcdGlmIChTLmN1cnJlbnQgPSBlLCB0eXBlb2YgYWUgPT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0XHRcdFx0YWUoZSk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGFlICYmIChhZS5jdXJyZW50ID0gZSk7XG5cdFx0XHR9LFxuXHRcdFx0Y2xhc3NOYW1lOiBwZSxcblx0XHRcdHJvbGU6IGgsXG5cdFx0XHRcImFyaWEtbW9kYWxcIjogXCJ0cnVlXCIsXG5cdFx0XHRcImFyaWEtbGFiZWxsZWRieVwiOiBkZSxcblx0XHRcdFwiYXJpYS1kZXNjcmliZWRieVwiOiBELFxuXHRcdFx0dGFiSW5kZXg6IG5lID8/IC0xLFxuXHRcdFx0b25LZXlEb3duOiAoZSkgPT4ge1xuXHRcdFx0XHRpZiAoeD8uKGUpLCBlLmRlZmF1bHRQcmV2ZW50ZWQpIHJldHVybjtcblx0XHRcdFx0aWYgKGUua2V5ID09PSBcIkVzY2FwZVwiICYmIGVlKSB7XG5cdFx0XHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpLCBkPy4oKTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGUua2V5ICE9PSBcIlRhYlwiIHx8ICFTLmN1cnJlbnQpIHJldHVybjtcblx0XHRcdFx0bGV0IHQgPSBmKFMuY3VycmVudCk7XG5cdFx0XHRcdGlmICh0Lmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0XHRcdGUucHJldmVudERlZmF1bHQoKSwgUy5jdXJyZW50LmZvY3VzKCk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGxldCBuID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCwgciA9IHRbMF0sIGkgPSB0W3QubGVuZ3RoIC0gMV07XG5cdFx0XHRcdGlmIChlLnNoaWZ0S2V5KSB7XG5cdFx0XHRcdFx0KCFuIHx8IG4gPT09IHIgfHwgIVMuY3VycmVudC5jb250YWlucyhuKSkgJiYgKGUucHJldmVudERlZmF1bHQoKSwgaS5mb2N1cygpKTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdFx0KCFuIHx8IG4gPT09IGkgfHwgIVMuY3VycmVudC5jb250YWlucyhuKSkgJiYgKGUucHJldmVudERlZmF1bHQoKSwgci5mb2N1cygpKTtcblx0XHRcdH0sXG5cdFx0XHQuLi5pZSxcblx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdGxlID8gLyogQF9fUFVSRV9fICovIHMoXCJoZWFkZXJcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogbWUsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGEgPz8gKFQgPyAvKiBAX19QVVJFX18gKi8gcyhcImgzXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRpYWxvZ19fdGl0bGVcIixcblx0XHRcdFx0XHRcdGlkOiBvZSxcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0XHRcdFx0fSkgOiBudWxsKVxuXHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdEUgPyAvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0aWQ6IHNlLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogaGUsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IHJcblx0XHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBnZSxcblx0XHRcdFx0XHRjaGlsZHJlbjogcmVcblx0XHRcdFx0fSksXG5cdFx0XHRcdHVlID8gLyogQF9fUFVSRV9fICovIHMoXCJmb290ZXJcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogX2UsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IG9cblx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRdXG5cdFx0fSlcblx0fSk7XG59KTtcbnAuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1wiO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2dyaWQudXRpbHMudHNcbnZhciBlZSA9IGFzeW5jIChlKSA9PiB7XG5cdGxldCB0ID0gYXdhaXQgZmV0Y2goZSk7XG5cdGlmICghdC5vaykgdGhyb3cgRXJyb3IoYEZhaWxlZCByZXF1ZXN0IGZvciAke2V9OiAke3Quc3RhdHVzfWApO1xuXHRyZXR1cm4gdC5qc29uKCk7XG59O1xuZnVuY3Rpb24gbShlKSB7XG5cdGlmICghZSB8fCAhQXJyYXkuaXNBcnJheShlLmNvbHVtbnMpKSByZXR1cm4ge1xuXHRcdGlkRmllbGQ6IFwiaWRcIixcblx0XHRwYWdlU2l6ZTogMTAsXG5cdFx0cGFnZVNpemVPcHRpb25zOiBbXG5cdFx0XHQxMCxcblx0XHRcdDIwLFxuXHRcdFx0NTBcblx0XHRdLFxuXHRcdHNlbGVjdGlvbk1vZGU6IFwibXVsdGlwbGVcIixcblx0XHRjb2x1bW5zOiBbXVxuXHR9O1xuXHRsZXQgdCA9IGUuY29sdW1ucy5tYXAoKGUpID0+ICh7XG5cdFx0dHlwZTogXCJzdHJpbmdcIixcblx0XHRzb3J0YWJsZTogITAsXG5cdFx0ZmlsdGVyYWJsZTogITAsXG5cdFx0Z3JvdXBhYmxlOiAhMSxcblx0XHRlZGl0YWJsZTogITEsXG5cdFx0YWdncmVnYXRlOiBcIm5vbmVcIixcblx0XHRmb3JtYXQ6IFwicGxhaW5cIixcblx0XHQuLi5lXG5cdH0pKTtcblx0cmV0dXJuIHtcblx0XHRpZEZpZWxkOiBlLmlkRmllbGQgPz8gXCJpZFwiLFxuXHRcdHBhZ2VTaXplOiBlLnBhZ2VTaXplID8/IDEwLFxuXHRcdHBhZ2VTaXplT3B0aW9uczogZS5wYWdlU2l6ZU9wdGlvbnM/Lmxlbmd0aCA/IGUucGFnZVNpemVPcHRpb25zIDogW1xuXHRcdFx0MTAsXG5cdFx0XHQyMCxcblx0XHRcdDUwXG5cdFx0XSxcblx0XHRzZWxlY3Rpb25Nb2RlOiBlLnNlbGVjdGlvbk1vZGUgPz8gXCJtdWx0aXBsZVwiLFxuXHRcdGRlZmF1bHRHcm91cEJ5OiBlLmRlZmF1bHRHcm91cEJ5LFxuXHRcdGRlZmF1bHRTb3J0OiBlLmRlZmF1bHRTb3J0LFxuXHRcdGZvb3Rlcjoge1xuXHRcdFx0c2hvd0NvbHVtbkFnZ3JlZ2F0ZXM6IGUuZm9vdGVyPy5zaG93Q29sdW1uQWdncmVnYXRlcyA/PyAhMCxcblx0XHRcdHJvd0FnZ3JlZ2F0ZXM6IGUuZm9vdGVyPy5yb3dBZ2dyZWdhdGVzPy5sZW5ndGggPyBlLmZvb3Rlci5yb3dBZ2dyZWdhdGVzIDogW1xuXHRcdFx0XHRcImZpbHRlcmVkUm93c1wiLFxuXHRcdFx0XHRcInBhZ2VkUm93c1wiLFxuXHRcdFx0XHRcInNlbGVjdGVkUm93c1wiLFxuXHRcdFx0XHRcImdyb3VwQ291bnRcIlxuXHRcdFx0XVxuXHRcdH0sXG5cdFx0Y29sdW1uczogdFxuXHR9O1xufVxuZnVuY3Rpb24gaChlLCB0KSB7XG5cdHJldHVybiB0ID09PSBcImRhdGVcIiA/IFwiZGF0ZVwiIDogdCA9PT0gXCJkYXRlLXRpbWVcIiA/IFwiZGF0ZXRpbWVcIiA6IGUgPT09IFwibnVtYmVyXCIgfHwgZSA9PT0gXCJpbnRlZ2VyXCIgPyBcIm51bWJlclwiIDogZSA9PT0gXCJib29sZWFuXCIgPyBcImJvb2xlYW5cIiA6IFwic3RyaW5nXCI7XG59XG5mdW5jdGlvbiBnKGUpIHtcblx0cmV0dXJuIGUgPT09IFwiZGF0ZVwiID8gXCJkYXRlXCIgOiBlID09PSBcImRhdGUtdGltZVwiID8gXCJkYXRldGltZVwiIDogZSA9PT0gXCJjdXJyZW5jeVwiID8gXCJjdXJyZW5jeVwiIDogZSA9PT0gXCJwZXJjZW50XCIgPyBcInBlcmNlbnRcIiA6IFwicGxhaW5cIjtcbn1cbmZ1bmN0aW9uIF8oZSkge1xuXHRpZiAoZT8ubGVuZ3RoKSByZXR1cm4gZS5tYXAoKGUpID0+ICh7XG5cdFx0bGFiZWw6IGUgPT09IG51bGwgPyBcIihlbXB0eSlcIiA6IFN0cmluZyhlKSxcblx0XHR2YWx1ZTogZVxuXHR9KSk7XG59XG5mdW5jdGlvbiB2KGUpIHtcblx0aWYgKCFlPy5wcm9wZXJ0aWVzKSByZXR1cm4gbSh2b2lkIDApO1xuXHRsZXQgdCA9IG5ldyBTZXQoZS5yZXF1aXJlZCA/PyBbXSksIG4gPSBlW1wieC1ncmlkXCJdLCByID0gT2JqZWN0LmVudHJpZXMoZS5wcm9wZXJ0aWVzKS5tYXAoKFtlLCBuXSkgPT4ge1xuXHRcdGxldCByID0gbltcIngtZ3JpZFwiXSwgaSA9IGgobi50eXBlLCBuLmZvcm1hdCksIGEgPSBnKG4uZm9ybWF0KSwgbyA9IHI/LmVkaXRvciA/PyAoaSA9PT0gXCJib29sZWFuXCIgPyBcImNoZWNrYm94XCIgOiBpID09PSBcIm51bWJlclwiID8gXCJudW1iZXJcIiA6IGkgPT09IFwiZGF0ZVwiID8gXCJkYXRlXCIgOiB2b2lkIDApO1xuXHRcdHJldHVybiB7XG5cdFx0XHRrZXk6IHI/LmtleSA/PyBlLFxuXHRcdFx0bGFiZWw6IG4udGl0bGUgPz8gZSxcblx0XHRcdHR5cGU6IGksXG5cdFx0XHRzb3J0YWJsZTogcj8uc29ydGFibGUgPz8gITAsXG5cdFx0XHRmaWx0ZXJhYmxlOiByPy5maWx0ZXJhYmxlID8/ICEwLFxuXHRcdFx0Z3JvdXBhYmxlOiByPy5ncm91cGFibGUgPz8gITEsXG5cdFx0XHRlZGl0YWJsZTogcj8uZWRpdGFibGUgPz8gdC5oYXMoZSksXG5cdFx0XHRlZGl0b3I6IG8sXG5cdFx0XHRhZ2dyZWdhdGU6IHI/LmFnZ3JlZ2F0ZSA/PyBcIm5vbmVcIixcblx0XHRcdHdpZHRoOiByPy53aWR0aCxcblx0XHRcdG1pbldpZHRoOiByPy5taW5XaWR0aCxcblx0XHRcdG9wdGlvbnM6IHI/Lm9wdGlvbnMgPz8gXyhuLmVudW0pLFxuXHRcdFx0Zm9ybWF0OiByPy5mb3JtYXQgPz8gYVxuXHRcdH07XG5cdH0pO1xuXHRyZXR1cm4gbSh7XG5cdFx0aWRGaWVsZDogbj8uaWRGaWVsZCxcblx0XHRwYWdlU2l6ZTogbj8ucGFnZVNpemUsXG5cdFx0cGFnZVNpemVPcHRpb25zOiBuPy5wYWdlU2l6ZU9wdGlvbnMsXG5cdFx0c2VsZWN0aW9uTW9kZTogbj8uc2VsZWN0aW9uTW9kZSxcblx0XHRkZWZhdWx0R3JvdXBCeTogbj8uZGVmYXVsdEdyb3VwQnksXG5cdFx0ZGVmYXVsdFNvcnQ6IG4/LmRlZmF1bHRTb3J0LFxuXHRcdGZvb3Rlcjogbj8uZm9vdGVyLFxuXHRcdGNvbHVtbnM6IHJcblx0fSk7XG59XG5mdW5jdGlvbiB0ZShlKSB7XG5cdGlmIChlKSB7XG5cdFx0aWYgKHR5cGVvZiBlID09IFwic3RyaW5nXCIpIHtcblx0XHRcdGxldCB0ID0gSlNPTi5wYXJzZShlKTtcblx0XHRcdGlmICghdCB8fCB0eXBlb2YgdCAhPSBcIm9iamVjdFwiKSB0aHJvdyBFcnJvcihcIkludmFsaWQganNvbklzbGFuZDogZXhwZWN0ZWQgYSBKU09OIG9iamVjdC5cIik7XG5cdFx0XHRyZXR1cm4gdDtcblx0XHR9XG5cdFx0cmV0dXJuIGU7XG5cdH1cbn1cbmFzeW5jIGZ1bmN0aW9uIHkoZSwgdCkge1xuXHRpZiAoZSAhPT0gdm9pZCAwKSByZXR1cm4gdHlwZW9mIGUgPT0gXCJmdW5jdGlvblwiID8gZSgpIDogdHlwZW9mIGUgPT0gXCJzdHJpbmdcIiA/IGF3YWl0ICh0ID8/IGVlKShlKSA6IGU7XG59XG5mdW5jdGlvbiBiKC4uLmUpIHtcblx0cmV0dXJuIGUuZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xufVxuZnVuY3Rpb24geChlLCB0LCBuKSB7XG5cdGxldCByID0gZVt0XTtcblx0cmV0dXJuIHIgPT0gbnVsbCA/IGByb3ctJHtufWAgOiBTdHJpbmcocik7XG59XG5mdW5jdGlvbiBuZShlLCB0LCBuLCByKSB7XG5cdGxldCBpID0gbi50cmltKCkudG9Mb3dlckNhc2UoKTtcblx0cmV0dXJuIGUuZmlsdGVyKChlKSA9PiBpLmxlbmd0aCA9PT0gMCB8fCB0LnNvbWUoKHQpID0+IHcoZVt0LmtleV0pLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaSkpID8gdC5ldmVyeSgodCkgPT4ge1xuXHRcdGxldCBuID0gKHJbdC5rZXldID8/IFwiXCIpLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuXHRcdGlmICghbikgcmV0dXJuICEwO1xuXHRcdGxldCBpID0gZVt0LmtleV07XG5cdFx0aWYgKHQudHlwZSA9PT0gXCJib29sZWFuXCIpIHtcblx0XHRcdGlmIChuID09PSBcInRydWVcIikgcmV0dXJuIGkgPT09ICEwO1xuXHRcdFx0aWYgKG4gPT09IFwiZmFsc2VcIikgcmV0dXJuIGkgPT09ICExO1xuXHRcdH1cblx0XHRyZXR1cm4gdyhpKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG4pO1xuXHR9KSA6ICExKTtcbn1cbmZ1bmN0aW9uIHJlKGUsIHQsIG4pIHtcblx0aWYgKCF0KSByZXR1cm4gZTtcblx0bGV0IHIgPSBuLmZpbmQoKGUpID0+IGUua2V5ID09PSB0LmNvbHVtbktleSk7XG5cdGlmICghciB8fCAhci5zb3J0YWJsZSkgcmV0dXJuIGU7XG5cdGxldCBpID0gdC5kaXJlY3Rpb24gPT09IFwiYXNjXCIgPyAxIDogLTE7XG5cdHJldHVybiBbLi4uZV0uc29ydCgoZSwgbikgPT4ge1xuXHRcdGxldCBhID0gZVt0LmNvbHVtbktleV0sIG8gPSBuW3QuY29sdW1uS2V5XTtcblx0XHRyZXR1cm4gc2UoYSwgbywgci50eXBlKSAqIGk7XG5cdH0pO1xufVxuZnVuY3Rpb24gaWUoZSwgdCwgbiwgcikge1xuXHRpZiAoIW4pIHJldHVybiBlLm1hcCgoZSwgdCkgPT4gKHtcblx0XHRraW5kOiBcImRhdGFcIixcblx0XHRrZXk6IGBkYXRhLSR7dH1gLFxuXHRcdHJvdzogZSxcblx0XHRyb3dJbmRleDogdFxuXHR9KSk7XG5cdGxldCBpID0gdC5maW5kKChlKSA9PiBlLmtleSA9PT0gbik7XG5cdGlmICghaSB8fCAhaS5ncm91cGFibGUpIHJldHVybiBlLm1hcCgoZSwgdCkgPT4gKHtcblx0XHRraW5kOiBcImRhdGFcIixcblx0XHRrZXk6IGBkYXRhLSR7dH1gLFxuXHRcdHJvdzogZSxcblx0XHRyb3dJbmRleDogdFxuXHR9KSk7XG5cdGxldCBhID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0ZS5mb3JFYWNoKChlKSA9PiB7XG5cdFx0bGV0IHQgPSB3KGVbbl0pIHx8IFwiKGVtcHR5KVwiLCByID0gYS5nZXQodCk7XG5cdFx0aWYgKHIpIHtcblx0XHRcdHIucHVzaChlKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0YS5zZXQodCwgW2VdKTtcblx0fSk7XG5cdGxldCBvID0gW107XG5cdHJldHVybiBBcnJheS5mcm9tKGEuZW50cmllcygpKS5mb3JFYWNoKChbZSwgdF0pID0+IHtcblx0XHRsZXQgbiA9IGBncm91cC0ke2V9YDtcblx0XHRvLnB1c2goe1xuXHRcdFx0a2luZDogXCJncm91cFwiLFxuXHRcdFx0a2V5OiBuLFxuXHRcdFx0Z3JvdXBWYWx1ZTogZSxcblx0XHRcdGdyb3VwU2l6ZTogdC5sZW5ndGgsXG5cdFx0XHRncm91cFJvd3M6IHRcblx0XHR9KSwgci5oYXMoZSkgJiYgdC5mb3JFYWNoKCh0LCByKSA9PiB7XG5cdFx0XHRvLnB1c2goe1xuXHRcdFx0XHRraW5kOiBcImRhdGFcIixcblx0XHRcdFx0a2V5OiBgJHtufS1yb3ctJHtyfWAsXG5cdFx0XHRcdHJvdzogdCxcblx0XHRcdFx0cm93SW5kZXg6IHIsXG5cdFx0XHRcdGdyb3VwVmFsdWU6IGVcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9KSwgbztcbn1cbmZ1bmN0aW9uIGFlKGUsIHQsIG4pIHtcblx0aWYgKHQgPD0gMCkgcmV0dXJuIGU7XG5cdGxldCByID0gTWF0aC5tYXgoMCwgbikgKiB0O1xuXHRyZXR1cm4gZS5zbGljZShyLCByICsgdCk7XG59XG5mdW5jdGlvbiBTKGUsIHQpIHtcblx0aWYgKGUgPT0gbnVsbCkgcmV0dXJuIFwiXCI7XG5cdGlmICh0LmZvcm1hdCA9PT0gXCJjdXJyZW5jeVwiICYmIHR5cGVvZiBlID09IFwibnVtYmVyXCIpIHJldHVybiBuZXcgSW50bC5OdW1iZXJGb3JtYXQodm9pZCAwLCB7XG5cdFx0c3R5bGU6IFwiY3VycmVuY3lcIixcblx0XHRjdXJyZW5jeTogXCJVU0RcIixcblx0XHRtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDJcblx0fSkuZm9ybWF0KGUpO1xuXHRpZiAodC5mb3JtYXQgPT09IFwicGVyY2VudFwiICYmIHR5cGVvZiBlID09IFwibnVtYmVyXCIpIHJldHVybiBuZXcgSW50bC5OdW1iZXJGb3JtYXQodm9pZCAwLCB7XG5cdFx0c3R5bGU6IFwicGVyY2VudFwiLFxuXHRcdG1heGltdW1GcmFjdGlvbkRpZ2l0czogMlxuXHR9KS5mb3JtYXQoZSk7XG5cdGlmICgodC5mb3JtYXQgPT09IFwiZGF0ZVwiIHx8IHQudHlwZSA9PT0gXCJkYXRlXCIpICYmICh0eXBlb2YgZSA9PSBcInN0cmluZ1wiIHx8IGUgaW5zdGFuY2VvZiBEYXRlKSkge1xuXHRcdGxldCB0ID0gbmV3IERhdGUoZSk7XG5cdFx0aWYgKCFOdW1iZXIuaXNOYU4odC5nZXRUaW1lKCkpKSByZXR1cm4gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQodm9pZCAwLCB7IGRhdGVTdHlsZTogXCJtZWRpdW1cIiB9KS5mb3JtYXQodCk7XG5cdH1cblx0aWYgKCh0LmZvcm1hdCA9PT0gXCJkYXRldGltZVwiIHx8IHQudHlwZSA9PT0gXCJkYXRldGltZVwiKSAmJiAodHlwZW9mIGUgPT0gXCJzdHJpbmdcIiB8fCBlIGluc3RhbmNlb2YgRGF0ZSkpIHtcblx0XHRsZXQgdCA9IG5ldyBEYXRlKGUpO1xuXHRcdGlmICghTnVtYmVyLmlzTmFOKHQuZ2V0VGltZSgpKSkgcmV0dXJuIG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KHZvaWQgMCwge1xuXHRcdFx0ZGF0ZVN0eWxlOiBcIm1lZGl1bVwiLFxuXHRcdFx0dGltZVN0eWxlOiBcInNob3J0XCJcblx0XHR9KS5mb3JtYXQodCk7XG5cdH1cblx0cmV0dXJuIHcoZSk7XG59XG5mdW5jdGlvbiBDKGUsIHQpIHtcblx0bGV0IG4gPSB0LmFnZ3JlZ2F0ZSA/PyBcIm5vbmVcIjtcblx0aWYgKG4gPT09IFwibm9uZVwiKSByZXR1cm4ge1xuXHRcdHR5cGU6IFwibm9uZVwiLFxuXHRcdHZhbHVlOiBudWxsXG5cdH07XG5cdGxldCByID0gZS5tYXAoKGUpID0+IGVbdC5rZXldKS5maWx0ZXIoKGUpID0+IHR5cGVvZiBlID09IFwibnVtYmVyXCIgJiYgTnVtYmVyLmlzRmluaXRlKGUpKTtcblx0cmV0dXJuIG4gPT09IFwiY291bnRcIiA/IHtcblx0XHR0eXBlOiBcImNvdW50XCIsXG5cdFx0dmFsdWU6IGUubGVuZ3RoXG5cdH0gOiByLmxlbmd0aCA9PT0gMCA/IHtcblx0XHR0eXBlOiBuLFxuXHRcdHZhbHVlOiBudWxsXG5cdH0gOiBuID09PSBcInN1bVwiID8ge1xuXHRcdHR5cGU6IFwic3VtXCIsXG5cdFx0dmFsdWU6IHIucmVkdWNlKChlLCB0KSA9PiBlICsgdCwgMClcblx0fSA6IG4gPT09IFwiYXZnXCIgPyB7XG5cdFx0dHlwZTogXCJhdmdcIixcblx0XHR2YWx1ZTogci5yZWR1Y2UoKGUsIHQpID0+IGUgKyB0LCAwKSAvIHIubGVuZ3RoXG5cdH0gOiBuID09PSBcIm1pblwiID8ge1xuXHRcdHR5cGU6IFwibWluXCIsXG5cdFx0dmFsdWU6IE1hdGgubWluKC4uLnIpXG5cdH0gOiBuID09PSBcIm1heFwiID8ge1xuXHRcdHR5cGU6IFwibWF4XCIsXG5cdFx0dmFsdWU6IE1hdGgubWF4KC4uLnIpXG5cdH0gOiB7XG5cdFx0dHlwZTogbixcblx0XHR2YWx1ZTogbnVsbFxuXHR9O1xufVxuZnVuY3Rpb24gb2UoZSkge1xuXHRyZXR1cm4gZS50eXBlID09PSBcIm5vbmVcIiA/IFwiXCIgOiBlLnZhbHVlID09PSBudWxsIHx8IGUudmFsdWUgPT09IHZvaWQgMCA/IFwiLVwiIDogZS50eXBlID09PSBcImNvdW50XCIgPyBgJHtNYXRoLnJvdW5kKGUudmFsdWUpfWAgOiBuZXcgSW50bC5OdW1iZXJGb3JtYXQodm9pZCAwLCB7XG5cdFx0bWluaW11bUZyYWN0aW9uRGlnaXRzOiAwLFxuXHRcdG1heGltdW1GcmFjdGlvbkRpZ2l0czogMlxuXHR9KS5mb3JtYXQoZS52YWx1ZSk7XG59XG5mdW5jdGlvbiBzZShlLCB0LCBuKSB7XG5cdGlmIChlID09PSB0KSByZXR1cm4gMDtcblx0aWYgKGUgPT0gbnVsbCkgcmV0dXJuIC0xO1xuXHRpZiAodCA9PSBudWxsKSByZXR1cm4gMTtcblx0aWYgKG4gPT09IFwibnVtYmVyXCIpIHtcblx0XHRsZXQgbiA9IE51bWJlcihlKSwgciA9IE51bWJlcih0KTtcblx0XHRpZiAoTnVtYmVyLmlzRmluaXRlKG4pICYmIE51bWJlci5pc0Zpbml0ZShyKSkgcmV0dXJuIG4gLSByO1xuXHR9XG5cdGlmIChuID09PSBcImRhdGVcIiB8fCBuID09PSBcImRhdGV0aW1lXCIpIHtcblx0XHRsZXQgbiA9IG5ldyBEYXRlKFN0cmluZyhlKSkuZ2V0VGltZSgpLCByID0gbmV3IERhdGUoU3RyaW5nKHQpKS5nZXRUaW1lKCk7XG5cdFx0aWYgKCFOdW1iZXIuaXNOYU4obikgJiYgIU51bWJlci5pc05hTihyKSkgcmV0dXJuIG4gLSByO1xuXHR9XG5cdHJldHVybiBuID09PSBcImJvb2xlYW5cIiA/ICEhZSAtICshIXQgOiB3KGUpLmxvY2FsZUNvbXBhcmUodyh0KSk7XG59XG5mdW5jdGlvbiB3KGUpIHtcblx0aWYgKGUgPT0gbnVsbCkgcmV0dXJuIFwiXCI7XG5cdGlmICh0eXBlb2YgZSA9PSBcInN0cmluZ1wiKSByZXR1cm4gZTtcblx0aWYgKHR5cGVvZiBlID09IFwibnVtYmVyXCIgfHwgdHlwZW9mIGUgPT0gXCJib29sZWFuXCIpIHJldHVybiBTdHJpbmcoZSk7XG5cdGlmIChlIGluc3RhbmNlb2YgRGF0ZSkgcmV0dXJuIGUudG9JU09TdHJpbmcoKTtcblx0aWYgKEFycmF5LmlzQXJyYXkoZSkpIHJldHVybiBlLm1hcCgoZSkgPT4gdyhlKSkuam9pbihcIiwgXCIpO1xuXHRpZiAodHlwZW9mIGUgPT0gXCJvYmplY3RcIikgdHJ5IHtcblx0XHRyZXR1cm4gSlNPTi5zdHJpbmdpZnkoZSk7XG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybiBcIltvYmplY3RdXCI7XG5cdH1cblx0cmV0dXJuIFN0cmluZyhlKTtcbn1cbmZ1bmN0aW9uIGNlKGUsIHQpIHtcblx0cmV0dXJuIHQuc29ydGFibGUgPyAhZSB8fCBlLmNvbHVtbktleSAhPT0gdC5rZXkgPyB7XG5cdFx0Y29sdW1uS2V5OiB0LmtleSxcblx0XHRkaXJlY3Rpb246IFwiYXNjXCJcblx0fSA6IGUuZGlyZWN0aW9uID09PSBcImFzY1wiID8ge1xuXHRcdGNvbHVtbktleTogdC5rZXksXG5cdFx0ZGlyZWN0aW9uOiBcImRlc2NcIlxuXHR9IDogbnVsbCA6IGU7XG59XG5mdW5jdGlvbiBUKGUsIHQpIHtcblx0aWYgKGUgPT0gbnVsbCkgcmV0dXJuIFwiXCI7XG5cdGlmICh0ID09PSBcImRhdGVcIiB8fCB0ID09PSBcImRhdGV0aW1lXCIpIHtcblx0XHRsZXQgbiA9IG5ldyBEYXRlKFN0cmluZyhlKSk7XG5cdFx0cmV0dXJuIE51bWJlci5pc05hTihuLmdldFRpbWUoKSkgPyBcIlwiIDogdCA9PT0gXCJkYXRlXCIgPyBuLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApIDogbi50b0lTT1N0cmluZygpLnNsaWNlKDAsIDE2KTtcblx0fVxuXHRyZXR1cm4gdyhlKTtcbn1cbmZ1bmN0aW9uIEUoZSwgdCkge1xuXHRpZiAodC5lZGl0b3IgPT09IFwiY2hlY2tib3hcIiB8fCB0LnR5cGUgPT09IFwiYm9vbGVhblwiKSByZXR1cm4gZSA9PT0gXCJ0cnVlXCI7XG5cdGlmICh0LmVkaXRvciA9PT0gXCJudW1iZXJcIiB8fCB0LnR5cGUgPT09IFwibnVtYmVyXCIpIHtcblx0XHRsZXQgdCA9IE51bWJlcihlKTtcblx0XHRyZXR1cm4gTnVtYmVyLmlzRmluaXRlKHQpID8gdCA6IG51bGw7XG5cdH1cblx0cmV0dXJuIHQudHlwZSA9PT0gXCJkYXRlXCIgfHwgdC50eXBlID09PSBcImRhdGV0aW1lXCIgPyBlIHx8IG51bGwgOiBlO1xufVxuZnVuY3Rpb24gbGUoZSkge1xuXHRsZXQgdCA9IGUudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG5cdHJldHVybiB0ID09PSBcInRydWVcIiB8fCB0ID09PSBcImZhbHNlXCIgPyB0IDogXCJcIjtcbn1cbmZ1bmN0aW9uIHVlKGUpIHtcblx0cmV0dXJuIGUgPT09IFwibm9uZVwiID8gXCJcIiA6IGUudG9VcHBlckNhc2UoKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9HcmlkLnRzeFxuZnVuY3Rpb24gZGUoeyBjb2x1bW5zOiBlLCBkcmFmdDogbiwgcm93SWQ6IHIsIG9uQ2FuY2VsOiBpLCBvblNhdmU6IGwgfSkge1xuXHRsZXQgW2QsIGZdID0gYShuKTtcblx0cmV0dXJuIHQoKCkgPT4ge1xuXHRcdGYobik7XG5cdH0sIFtuXSksIC8qIEBfX1BVUkVfXyAqLyBzKHAsIHtcblx0XHR0aXRsZTogYEVkaXQgcm93ICR7cn1gLFxuXHRcdFwiYXJpYS1sYWJlbFwiOiBgRWRpdCByb3cgJHtyfWAsXG5cdFx0b25SZXF1ZXN0Q2xvc2U6IGksXG5cdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZWRpdERpYWxvZ1wiLFxuXHRcdGNvbnRlbnRDbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19lZGl0RGlhbG9nQ29udGVudFwiLFxuXHRcdGZvb3RlckNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2VkaXREaWFsb2dGb290ZXJcIixcblx0XHRmb290ZXI6IC8qIEBfX1BVUkVfXyAqLyBjKG8sIHsgY2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyh1LCB7XG5cdFx0XHR2YXJpYW50OiBcInNlY29uZGFyeVwiLFxuXHRcdFx0b25DbGljazogaSxcblx0XHRcdGNoaWxkcmVuOiBcIkNhbmNlbFwiXG5cdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBzKHUsIHtcblx0XHRcdG9uQ2xpY2s6ICgpID0+IGwoZCksXG5cdFx0XHRjaGlsZHJlbjogXCJTYXZlXCJcblx0XHR9KV0gfSksXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2RpYWxvZ0JvZHlcIixcblx0XHRcdGNoaWxkcmVuOiBlLmZpbHRlcigoZSkgPT4gZS5lZGl0YWJsZSkubWFwKChlKSA9PiB7XG5cdFx0XHRcdGxldCB0ID0gVChkW2Uua2V5XSwgZS50eXBlKTtcblx0XHRcdFx0cmV0dXJuIGUuZWRpdG9yID09PSBcImNoZWNrYm94XCIgfHwgZS50eXBlID09PSBcImJvb2xlYW5cIiA/IC8qIEBfX1BVUkVfXyAqLyBjKFwibGFiZWxcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2ZpZWxkXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwgeyBjaGlsZHJlbjogZS5sYWJlbCB9KSwgLyogQF9fUFVSRV9fICovIGMoXCJzZWxlY3RcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faW5wdXRcIixcblx0XHRcdFx0XHRcdHZhbHVlOiB0ID09PSBcInRydWVcIiA/IFwidHJ1ZVwiIDogXCJmYWxzZVwiLFxuXHRcdFx0XHRcdFx0b25DaGFuZ2U6ICh0KSA9PiB7XG5cdFx0XHRcdFx0XHRcdGxldCBuID0gdC50YXJnZXQudmFsdWUgPT09IFwidHJ1ZVwiO1xuXHRcdFx0XHRcdFx0XHRmKCh0KSA9PiAoe1xuXHRcdFx0XHRcdFx0XHRcdC4uLnQsXG5cdFx0XHRcdFx0XHRcdFx0W2Uua2V5XTogblxuXHRcdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBcInRydWVcIixcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiVHJ1ZVwiXG5cdFx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIHMoXCJvcHRpb25cIiwge1xuXHRcdFx0XHRcdFx0XHR2YWx1ZTogXCJmYWxzZVwiLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJGYWxzZVwiXG5cdFx0XHRcdFx0XHR9KV1cblx0XHRcdFx0XHR9KV1cblx0XHRcdFx0fSwgZS5rZXkpIDogZS5lZGl0b3IgPT09IFwic2VsZWN0XCIgJiYgZS5vcHRpb25zPy5sZW5ndGggPyAvKiBAX19QVVJFX18gKi8gYyhcImxhYmVsXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19maWVsZFwiLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHsgY2hpbGRyZW46IGUubGFiZWwgfSksIC8qIEBfX1BVUkVfXyAqLyBjKFwic2VsZWN0XCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2lucHV0XCIsXG5cdFx0XHRcdFx0XHR2YWx1ZTogdCxcblx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAodCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRsZXQgbiA9IEUodC50YXJnZXQudmFsdWUsIGUpO1xuXHRcdFx0XHRcdFx0XHRmKCh0KSA9PiAoe1xuXHRcdFx0XHRcdFx0XHRcdC4uLnQsXG5cdFx0XHRcdFx0XHRcdFx0W2Uua2V5XTogblxuXHRcdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBcIlwiLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCIoZW1wdHkpXCJcblx0XHRcdFx0XHRcdH0pLCBlLm9wdGlvbnMubWFwKChlKSA9PiAvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBTdHJpbmcoZS52YWx1ZSksXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmxhYmVsXG5cdFx0XHRcdFx0XHR9LCBTdHJpbmcoZS52YWx1ZSkpKV1cblx0XHRcdFx0XHR9KV1cblx0XHRcdFx0fSwgZS5rZXkpIDogZS5lZGl0b3IgPT09IFwidGV4dGFyZWFcIiA/IC8qIEBfX1BVUkVfXyAqLyBjKFwibGFiZWxcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2ZpZWxkXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwgeyBjaGlsZHJlbjogZS5sYWJlbCB9KSwgLyogQF9fUFVSRV9fICovIHMoXCJ0ZXh0YXJlYVwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19pbnB1dCBuYWJzLXVpLWdyaWRfX2lucHV0LS10ZXh0YXJlYVwiLFxuXHRcdFx0XHRcdFx0dmFsdWU6IHQsXG5cdFx0XHRcdFx0XHRvbkNoYW5nZTogKHQpID0+IHtcblx0XHRcdFx0XHRcdFx0bGV0IG4gPSBFKHQudGFyZ2V0LnZhbHVlLCBlKTtcblx0XHRcdFx0XHRcdFx0ZigodCkgPT4gKHtcblx0XHRcdFx0XHRcdFx0XHQuLi50LFxuXHRcdFx0XHRcdFx0XHRcdFtlLmtleV06IG5cblx0XHRcdFx0XHRcdFx0fSkpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0pXVxuXHRcdFx0XHR9LCBlLmtleSkgOiAvKiBAX19QVVJFX18gKi8gYyhcImxhYmVsXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19maWVsZFwiLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHsgY2hpbGRyZW46IGUubGFiZWwgfSksIC8qIEBfX1BVUkVfXyAqLyBzKFwiaW5wdXRcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faW5wdXRcIixcblx0XHRcdFx0XHRcdHR5cGU6IGUuZWRpdG9yID09PSBcIm51bWJlclwiIHx8IGUudHlwZSA9PT0gXCJudW1iZXJcIiA/IFwibnVtYmVyXCIgOiBlLnR5cGUgPT09IFwiZGF0ZVwiID8gXCJkYXRlXCIgOiBcInRleHRcIixcblx0XHRcdFx0XHRcdHZhbHVlOiB0LFxuXHRcdFx0XHRcdFx0b25DaGFuZ2U6ICh0KSA9PiB7XG5cdFx0XHRcdFx0XHRcdGxldCBuID0gRSh0LnRhcmdldC52YWx1ZSwgZSk7XG5cdFx0XHRcdFx0XHRcdGYoKHQpID0+ICh7XG5cdFx0XHRcdFx0XHRcdFx0Li4udCxcblx0XHRcdFx0XHRcdFx0XHRbZS5rZXldOiBuXG5cdFx0XHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9KV1cblx0XHRcdFx0fSwgZS5rZXkpO1xuXHRcdFx0fSlcblx0XHR9KVxuXHR9KTtcbn1cbnZhciBEID0gZShmdW5jdGlvbih7IG1vZGU6IGUsIHNjaGVtYTogbiwganNvblNjaGVtYTogbCwganNvbklzbGFuZDogdSwgZGF0YTogZCwgc2NoZW1hU291cmNlOiBmLCBqc29uU2NoZW1hU291cmNlOiBwLCBqc29uSXNsYW5kU291cmNlOiBlZSwgZGF0YVNvdXJjZTogaCwgc2VydmVyRGF0YVNvdXJjZTogZywgZmV0Y2hlcjogXywgaGVpZ2h0OiBzZSA9IDQ0MCwgcm93SGVpZ2h0OiB3ID0gNDAsIG92ZXJzY2FuOiBEID0gNiwgZWRpdE1vZGU6IGZlID0gXCJib3RoXCIsIHNlYXJjaGFibGU6IHBlID0gITAsIGZpbHRlcmFibGU6IG1lID0gITAsIGdyb3VwYWJsZTogaGUgPSAhMCwgcGFnZWFibGU6IGdlID0gITAsIHNlbGVjdGFibGU6IF9lID0gITAsIGNsYXNzTmFtZTogdmUgPSBcIlwiLCBvbkRhdGFDaGFuZ2U6IHllLCBvblNlbGVjdGlvbkNoYW5nZTogYmUsIG9uU2NoZW1hTG9hZGVkOiB4ZSwgb25EYXRhTG9hZGVkOiBTZSwgb25FcnJvcjogQ2UsIHZhbHVlRm9ybWF0dGVyczogd2UsIC4uLlRlIH0sIEVlKSB7XG5cdGxldCBbTywga10gPSBhKCgpID0+IG4gPyBtKG4pIDogbCA/IHYobCkgOiBtKHZvaWQgMCkpLCBbRGUsIE9lXSA9IGEoZSA/PyBcImNsaWVudFwiKSwgW0EsIGpdID0gYShkID8/IFtdKSwgW2tlLCBBZV0gPSBhKHZvaWQgMCksIFtqZSwgTWVdID0gYSh2b2lkIDApLCBbTmUsIFBlXSA9IGEodm9pZCAwKSwgW0ZlLCBJZV0gPSBhKCExKSwgW0xlLCBSZV0gPSBhKFwiXCIpLCBbTSwgemVdID0gYShcIlwiKSwgW04sIEJlXSA9IGEoe30pLCBbUCwgRl0gPSBhKG51bGwpLCBbSSwgTF0gPSBhKG51bGwpLCBbUiwgVmVdID0gYSgvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpKSwgW3osIEJdID0gYSgwKSwgW1YsIEhdID0gYShPLnBhZ2VTaXplID8/IDEwKSwgW0hlLCBVZV0gPSBhKC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpLCBbV2UsIEdlXSA9IGEobnVsbCksIFtLZSwgVV0gPSBhKG51bGwpLCBbcWUsIEplXSA9IGEobnVsbCksIFtZZSwgWGVdID0gYSgwKSwgW1plLCBRZV0gPSBhKDApLCAkZSA9IGkoYmUpLCBldCA9IGkoZyksIFcgPSBrZSA/PyBqZTtcblx0dCgoKSA9PiB7XG5cdFx0dHJ5IHtcblx0XHRcdGxldCB0ID0gdGUodSk7XG5cdFx0XHRBZSh0KSwgIWQgJiYgdD8uZGF0YSAmJiBqKHQuZGF0YSksIE9lKGUgPz8gdD8ubW9kZSA/PyBcImNsaWVudFwiKTtcblx0XHR9IGNhdGNoICh0KSB7XG5cdFx0XHRsZXQgbiA9IHQgaW5zdGFuY2VvZiBFcnJvciA/IHQgOiAvKiBAX19QVVJFX18gKi8gRXJyb3IoXCJJbnZhbGlkIGpzb25Jc2xhbmQgdmFsdWUuXCIpO1xuXHRcdFx0UmUobi5tZXNzYWdlKSwgQ2U/LihuKSwgQWUodm9pZCAwKSwgT2UoZSA/PyBcImNsaWVudFwiKTtcblx0XHR9XG5cdH0sIFtcblx0XHRkLFxuXHRcdHUsXG5cdFx0ZVxuXHRdKSwgdCgoKSA9PiB7XG5cdFx0aWYgKG4pIHtcblx0XHRcdGsobShuKSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChsKSB7XG5cdFx0XHRrKHYobCkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoVz8uc2NoZW1hKSB7XG5cdFx0XHRrKG0oVy5zY2hlbWEpKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0aWYgKFc/Lmpzb25TY2hlbWEpIHtcblx0XHRcdGsodihXLmpzb25TY2hlbWEpKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0ayhtKHZvaWQgMCkpO1xuXHR9LCBbXG5cdFx0Vyxcblx0XHRsLFxuXHRcdG5cblx0XSksIHQoKCkgPT4ge1xuXHRcdGQgJiYgKGooZCksIFBlKHZvaWQgMCkpO1xuXHR9LCBbZF0pLCB0KCgpID0+IHtcblx0XHRsZXQgZSA9IG4gPyBtKG4pIDogbCA/IHYobCkgOiBXPy5zY2hlbWEgPyBtKFcuc2NoZW1hKSA6IHYoVz8uanNvblNjaGVtYSk7XG5cdFx0SChlLnBhZ2VTaXplID8/IDEwKSwgZS5kZWZhdWx0U29ydCAmJiBGKGUuZGVmYXVsdFNvcnQpLCBlLmRlZmF1bHRHcm91cEJ5ICYmIChMKGUuZGVmYXVsdEdyb3VwQnkpLCBWZSgodCkgPT4ge1xuXHRcdFx0bGV0IG4gPSBuZXcgU2V0KHQpO1xuXHRcdFx0cmV0dXJuIG4uYWRkKGUuZGVmYXVsdEdyb3VwQnkpLCBuO1xuXHRcdH0pKTtcblx0fSwgW1xuXHRcdFcsXG5cdFx0bCxcblx0XHRuXG5cdF0pLCB0KCgpID0+IHtcblx0XHRsZXQgdCA9ICExO1xuXHRcdHJldHVybiAoYXN5bmMgKCkgPT4ge1xuXHRcdFx0aWYgKCEoIWYgJiYgIXAgJiYgIWVlICYmICFoKSkgdHJ5IHtcblx0XHRcdFx0SWUoITApLCBSZShcIlwiKTtcblx0XHRcdFx0bGV0IFtuLCByLCBpLCBhXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcblx0XHRcdFx0XHR5KGYsIF8pLFxuXHRcdFx0XHRcdHkocCwgXyksXG5cdFx0XHRcdFx0eShlZSwgXyksXG5cdFx0XHRcdFx0eShoLCBfKVxuXHRcdFx0XHRdKSwgbyA9IHRlKGkpO1xuXHRcdFx0XHRpZiAoTWUobyksIHQpIHJldHVybjtcblx0XHRcdFx0aWYgKG4pIHtcblx0XHRcdFx0XHRsZXQgZSA9IG0obik7XG5cdFx0XHRcdFx0ayhlKSwgSChlLnBhZ2VTaXplID8/IDEwKSwgZS5kZWZhdWx0U29ydCAmJiBGKGUuZGVmYXVsdFNvcnQpLCBlLmRlZmF1bHRHcm91cEJ5ICYmIEwoZS5kZWZhdWx0R3JvdXBCeSksIHhlPy4oZSk7XG5cdFx0XHRcdH0gZWxzZSBpZiAocikge1xuXHRcdFx0XHRcdGxldCBlID0gdihyKTtcblx0XHRcdFx0XHRrKGUpLCBIKGUucGFnZVNpemUgPz8gMTApLCBlLmRlZmF1bHRTb3J0ICYmIEYoZS5kZWZhdWx0U29ydCksIGUuZGVmYXVsdEdyb3VwQnkgJiYgTChlLmRlZmF1bHRHcm91cEJ5KSwgeGU/LihlKTtcblx0XHRcdFx0fSBlbHNlIGlmIChvPy5zY2hlbWEpIHtcblx0XHRcdFx0XHRsZXQgZSA9IG0oby5zY2hlbWEpO1xuXHRcdFx0XHRcdGsoZSksIEgoZS5wYWdlU2l6ZSA/PyAxMCksIGUuZGVmYXVsdFNvcnQgJiYgRihlLmRlZmF1bHRTb3J0KSwgZS5kZWZhdWx0R3JvdXBCeSAmJiBMKGUuZGVmYXVsdEdyb3VwQnkpLCB4ZT8uKGUpO1xuXHRcdFx0XHR9IGVsc2UgaWYgKG8/Lmpzb25TY2hlbWEpIHtcblx0XHRcdFx0XHRsZXQgZSA9IHYoby5qc29uU2NoZW1hKTtcblx0XHRcdFx0XHRrKGUpLCBIKGUucGFnZVNpemUgPz8gMTApLCBlLmRlZmF1bHRTb3J0ICYmIEYoZS5kZWZhdWx0U29ydCksIGUuZGVmYXVsdEdyb3VwQnkgJiYgTChlLmRlZmF1bHRHcm91cEJ5KSwgeGU/LihlKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRBcnJheS5pc0FycmF5KGEpID8gKGooYSksIFBlKHZvaWQgMCksIFNlPy4oYSkpIDogbz8uZGF0YSAmJiAhZCAmJiAoaihvLmRhdGEpLCBQZSh2b2lkIDApLCBTZT8uKG8uZGF0YSkpLCAhZSAmJiBvPy5tb2RlICYmIE9lKG8ubW9kZSk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGlmICh0KSByZXR1cm47XG5cdFx0XHRcdGxldCBuID0gZSBpbnN0YW5jZW9mIEVycm9yID8gZSA6IC8qIEBfX1BVUkVfXyAqLyBFcnJvcihcIkZhaWxlZCB0byBsb2FkIGdyaWQgc291cmNlcy5cIik7XG5cdFx0XHRcdFJlKG4ubWVzc2FnZSksIENlPy4obik7XG5cdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHR0IHx8IEllKCExKTtcblx0XHRcdH1cblx0XHR9KSgpLCAoKSA9PiB7XG5cdFx0XHR0ID0gITA7XG5cdFx0fTtcblx0fSwgW1xuXHRcdGQsXG5cdFx0aCxcblx0XHRfLFxuXHRcdGVlLFxuXHRcdHAsXG5cdFx0ZSxcblx0XHRmXG5cdF0pLCB0KCgpID0+IHtcblx0XHQkZS5jdXJyZW50ID0gYmU7XG5cdH0sIFtiZV0pLCB0KCgpID0+IHtcblx0XHRldC5jdXJyZW50ID0gZztcblx0fSwgW2ddKSwgdCgoKSA9PiB7XG5cdFx0aWYgKERlICE9PSBcInNlcnZlclwiIHx8ICFnKSByZXR1cm47XG5cdFx0bGV0IGUgPSAhMSwgdCA9IHtcblx0XHRcdHBhZ2VJbmRleDogeixcblx0XHRcdHBhZ2VTaXplOiBWLFxuXHRcdFx0c2VhcmNoVGVybTogTSxcblx0XHRcdHNvcnQ6IFAsXG5cdFx0XHRncm91cEJ5OiBJLFxuXHRcdFx0ZmlsdGVyczogTlxuXHRcdH07XG5cdFx0cmV0dXJuIChhc3luYyAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRsZXQgbiA9IGV0LmN1cnJlbnQ7XG5cdFx0XHRcdGlmICghbikgcmV0dXJuO1xuXHRcdFx0XHRJZSghMCksIFJlKFwiXCIpO1xuXHRcdFx0XHRsZXQgciA9IGF3YWl0IG4odCwgTyk7XG5cdFx0XHRcdGlmIChlKSByZXR1cm47XG5cdFx0XHRcdGlmIChBcnJheS5pc0FycmF5KHIpKSB7XG5cdFx0XHRcdFx0aihyKSwgUGUoci5sZW5ndGgpLCBTZT8uKHIpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHRqKHIucm93cyksIFBlKHIudG90YWxDb3VudCA/PyByLnJvd3MubGVuZ3RoKSwgU2U/LihyLnJvd3MpO1xuXHRcdFx0fSBjYXRjaCAodCkge1xuXHRcdFx0XHRpZiAoZSkgcmV0dXJuO1xuXHRcdFx0XHRsZXQgbiA9IHQgaW5zdGFuY2VvZiBFcnJvciA/IHQgOiAvKiBAX19QVVJFX18gKi8gRXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBzZXJ2ZXIgZGF0YS5cIik7XG5cdFx0XHRcdFJlKG4ubWVzc2FnZSksIENlPy4obik7XG5cdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHRlIHx8IEllKCExKTtcblx0XHRcdH1cblx0XHR9KSgpLCAoKSA9PiB7XG5cdFx0XHRlID0gITA7XG5cdFx0fTtcblx0fSwgW1xuXHRcdE4sXG5cdFx0SSxcblx0XHR6LFxuXHRcdFYsXG5cdFx0RGUsXG5cdFx0Tyxcblx0XHRNLFxuXHRcdFBcblx0XSk7XG5cdGxldCBHID0gTy5jb2x1bW5zLCBLID0gTy5pZEZpZWxkID8/IFwiaWRcIiwgcSA9IF9lID8gTy5zZWxlY3Rpb25Nb2RlID8/IFwibXVsdGlwbGVcIiA6IFwibm9uZVwiLCB0dCA9IHBlLCBudCA9IG1lLCBydCA9IGhlLCBpdCA9IGdlLCBhdCA9IGZlID09PSBcImlubGluZVwiIHx8IGZlID09PSBcImJvdGhcIiwgb3QgPSBmZSA9PT0gXCJkaWFsb2dcIiB8fCBmZSA9PT0gXCJib3RoXCIsIEogPSBEZSA9PT0gXCJzZXJ2ZXJcIiwgWSA9IHIoKCkgPT4gSiA/IEEgOiBuZShBLCBHLCB0dCA/IE0gOiBcIlwiLCBudCA/IE4gOiB7fSksIFtcblx0XHRudCxcblx0XHR0dCxcblx0XHROLFxuXHRcdEcsXG5cdFx0Sixcblx0XHRBLFxuXHRcdE1cblx0XSksIFggPSByKCgpID0+IEogPyBZIDogcmUoWSwgUCwgRyksIFtcblx0XHRHLFxuXHRcdFksXG5cdFx0Sixcblx0XHRQXG5cdF0pLCBzdCA9IEogPyBOZSA/PyBYLmxlbmd0aCA6IFgubGVuZ3RoLCBaID0gTWF0aC5tYXgoMSwgTWF0aC5jZWlsKHN0IC8gTWF0aC5tYXgoMSwgVikpKSwgUSA9IE1hdGgubWluKHosIFogLSAxKTtcblx0dCgoKSA9PiB7XG5cdFx0USAhPT0geiAmJiBCKFEpO1xuXHR9LCBbUSwgel0pO1xuXHRsZXQgY3QgPSByKCgpID0+IEogPyBYIDogaXQgPyBhZShYLCBWLCBRKSA6IFgsIFtcblx0XHRpdCxcblx0XHRRLFxuXHRcdEosXG5cdFx0Vixcblx0XHRYXG5cdF0pLCBsdCA9IHIoKCkgPT4ge1xuXHRcdGxldCBlID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRyZXR1cm4gSSAmJiBjdC5mb3JFYWNoKCh0KSA9PiB7XG5cdFx0XHRsZXQgbiA9IHRbSV07XG5cdFx0XHRlLmFkZChuID09IG51bGwgfHwgbiA9PT0gXCJcIiA/IFwiKGVtcHR5KVwiIDogU3RyaW5nKG4pKTtcblx0XHR9KSwgZTtcblx0fSwgW0ksIGN0XSk7XG5cdHQoKCkgPT4ge1xuXHRcdEkgJiYgUi5zaXplID09PSAwICYmIGx0LnNpemUgPiAwICYmIFZlKGx0KTtcblx0fSwgW1xuXHRcdGx0LFxuXHRcdFIuc2l6ZSxcblx0XHRJXG5cdF0pO1xuXHRsZXQgJCA9IHIoKCkgPT4gaWUoY3QsIEcsIHJ0ID8gSSA6IG51bGwsIFIpLCBbXG5cdFx0cnQsXG5cdFx0Ryxcblx0XHRSLFxuXHRcdEksXG5cdFx0Y3Rcblx0XSksIHV0ID0gJC5maWx0ZXIoKGUpID0+IGUua2luZCA9PT0gXCJkYXRhXCIpLmxlbmd0aCwgZHQgPSBNYXRoLm1heCgxLCB1dCArICQuZmlsdGVyKChlKSA9PiBlLmtpbmQgPT09IFwiZ3JvdXBcIikubGVuZ3RoKSAqIHcsIGZ0ID0gTWF0aC5jZWlsKHNlIC8gdykgKyBEICogMiwgcHQgPSBNYXRoLm1heCgwLCBNYXRoLmZsb29yKFllIC8gdykgLSBEKSwgbXQgPSBNYXRoLm1pbigkLmxlbmd0aCwgcHQgKyBmdCksIGh0ID0gJC5zbGljZShwdCwgbXQpLCBndCA9IHB0ICogdywgX3QgPSBNYXRoLm1heCgwLCBkdCAtIGd0IC0gaHQubGVuZ3RoICogdyksIHZ0ID0gcigoKSA9PiB7XG5cdFx0bGV0IGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHJldHVybiBBLmZvckVhY2goKHQsIG4pID0+IHtcblx0XHRcdGUuc2V0KHgodCwgSywgbiksIHQpO1xuXHRcdH0pLCBBcnJheS5mcm9tKEhlLnZhbHVlcygpKS5tYXAoKHQpID0+IGUuZ2V0KHQpKS5maWx0ZXIoKGUpID0+ICEhZSk7XG5cdH0sIFtcblx0XHRLLFxuXHRcdEEsXG5cdFx0SGVcblx0XSk7XG5cdHQoKCkgPT4ge1xuXHRcdCRlLmN1cnJlbnQ/Lih2dCk7XG5cdH0sIFt2dF0pO1xuXHRsZXQgeXQgPSByKCgpID0+IHtcblx0XHRsZXQgZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0cmV0dXJuIEcuZm9yRWFjaCgodCkgPT4ge1xuXHRcdFx0bGV0IG4gPSBDKFksIHQpO1xuXHRcdFx0bi50eXBlICE9PSBcIm5vbmVcIiAmJiBlLnNldCh0LmtleSwgYCR7dWUobi50eXBlKX0gJHtvZShuKX1gKTtcblx0XHR9KSwgZTtcblx0fSwgW0csIFldKSwgYnQgPSByKCgpID0+ICQuZmlsdGVyKChlKSA9PiBlLmtpbmQgPT09IFwiZGF0YVwiICYmICEhZS5yb3cpLm1hcCgoZSkgPT4geChlLnJvdywgSywgZS5yb3dJbmRleCA/PyAwKSksIFskLCBLXSksIHh0ID0gcSAhPT0gXCJub25lXCIgJiYgYnQubGVuZ3RoID4gMCAmJiBidC5ldmVyeSgoZSkgPT4gSGUuaGFzKGUpKTtcblx0ZnVuY3Rpb24gU3QoZSkge1xuXHRcdGooZSksIHllPy4oZSk7XG5cdH1cblx0ZnVuY3Rpb24gQ3QoZSwgdCkge1xuXHRcdEJlKChuKSA9PiAoe1xuXHRcdFx0Li4ubixcblx0XHRcdFtlXTogdFxuXHRcdH0pKSwgQigwKTtcblx0fVxuXHRmdW5jdGlvbiB3dChlKSB7XG5cdFx0RigodCkgPT4gY2UodCwgZSkpLCBCKDApO1xuXHR9XG5cdGZ1bmN0aW9uIFR0KGUsIHQsIG4pIHtcblx0XHRsZXQgciA9IHdlPy5bbi5rZXldLCBpID0gZVtuLmtleV07XG5cdFx0cmV0dXJuIHIgPyByKHtcblx0XHRcdHJvdzogZSxcblx0XHRcdHJvd0luZGV4OiB0LFxuXHRcdFx0Y29sdW1uOiBuLFxuXHRcdFx0dmFsdWU6IGlcblx0XHR9KSA6IFMoaSwgbik7XG5cdH1cblx0ZnVuY3Rpb24gRXQoZSwgdCkge1xuXHRcdGxldCBuID0geChlLCBLLCB0KTtcblx0XHRHZShuKSwgVSh7IC4uLmUgfSk7XG5cdH1cblx0ZnVuY3Rpb24gRHQoZSkge1xuXHRcdEtlICYmIChTdChBLm1hcCgodCwgbikgPT4geCh0LCBLLCBuKSA9PT0gZSA/IHsgLi4uS2UgfSA6IHQpKSwgR2UobnVsbCksIFUobnVsbCkpO1xuXHR9XG5cdGZ1bmN0aW9uIE90KCkge1xuXHRcdEdlKG51bGwpLCBVKG51bGwpO1xuXHR9XG5cdGZ1bmN0aW9uIGt0KGUsIHQpIHtcblx0XHRsZXQgbiA9IHgoZSwgSywgdCk7XG5cdFx0SmUoe1xuXHRcdFx0cm93SWQ6IG4sXG5cdFx0XHRkcmFmdDogeyAuLi5lIH1cblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBBdChlLCB0KSB7XG5cdFx0U3QoQS5tYXAoKG4sIHIpID0+IHgobiwgSywgcikgPT09IGUgPyB7IC4uLnQgfSA6IG4pKSwgSmUobnVsbCk7XG5cdH1cblx0ZnVuY3Rpb24ganQoZSkge1xuXHRcdFZlKCh0KSA9PiB7XG5cdFx0XHRsZXQgbiA9IG5ldyBTZXQodCk7XG5cdFx0XHRyZXR1cm4gbi5oYXMoZSkgPyBuLmRlbGV0ZShlKSA6IG4uYWRkKGUpLCBuO1xuXHRcdH0pO1xuXHR9XG5cdGZ1bmN0aW9uIE10KGUsIHQsIG4pIHtcblx0XHRpZiAocSA9PT0gXCJub25lXCIpIHJldHVybjtcblx0XHRsZXQgciA9IHgoZSwgSywgdCk7XG5cdFx0VWUoKGUpID0+IHtcblx0XHRcdGlmIChxID09PSBcInNpbmdsZVwiKSByZXR1cm4gbiA/IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtyXSkgOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdFx0bGV0IHQgPSBuZXcgU2V0KGUpO1xuXHRcdFx0cmV0dXJuIG4gPyB0LmFkZChyKSA6IHQuZGVsZXRlKHIpLCB0O1xuXHRcdH0pO1xuXHR9XG5cdGZ1bmN0aW9uIE50KGUpIHtcblx0XHRpZiAocSAhPT0gXCJub25lXCIpIHtcblx0XHRcdGlmIChxID09PSBcInNpbmdsZVwiKSB7XG5cdFx0XHRcdGxldCB0ID0gJC5maW5kKChlKSA9PiBlLmtpbmQgPT09IFwiZGF0YVwiICYmIGUucm93KTtcblx0XHRcdFx0aWYgKCF0IHx8ICF0LnJvdykge1xuXHRcdFx0XHRcdFVlKC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHRVZShlID8gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW3godC5yb3csIEssIHQucm93SW5kZXggPz8gMCldKSA6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRVZSgodCkgPT4ge1xuXHRcdFx0XHRsZXQgbiA9IG5ldyBTZXQodCk7XG5cdFx0XHRcdHJldHVybiBidC5mb3JFYWNoKCh0KSA9PiB7XG5cdFx0XHRcdFx0ZSA/IG4uYWRkKHQpIDogbi5kZWxldGUodCk7XG5cdFx0XHRcdH0pLCBuO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdGxldCBQdCA9IGIoXCJuYWJzLXVpLWdyaWRcIiwgdmUpLCBGdCA9IEcubGVuZ3RoICsgKHEgPT09IFwibm9uZVwiID8gMCA6IDEpICsgMSwgSXQgPSBHLmZpbHRlcigoZSkgPT4gZS5ncm91cGFibGUpLCBMdCA9IE8uZm9vdGVyPy5zaG93Q29sdW1uQWdncmVnYXRlcyAhPT0gITEsIFJ0ID0gSiA/IHN0IDogWS5sZW5ndGgsIHp0ID0gKE8uZm9vdGVyPy5yb3dBZ2dyZWdhdGVzID8/IFtdKS5tYXAoKGUpID0+IGUgPT09IFwiZmlsdGVyZWRSb3dzXCIgPyBgRmlsdGVyZWQgcm93cyAke1J0fWAgOiBlID09PSBcInBhZ2VkUm93c1wiID8gYFBhZ2Ugcm93cyAke2N0Lmxlbmd0aH1gIDogZSA9PT0gXCJzZWxlY3RlZFJvd3NcIiA/IGBTZWxlY3RlZCByb3dzICR7dnQubGVuZ3RofWAgOiBlID09PSBcImdyb3VwQ291bnRcIiA/IGBHcm91cHMgJHtJID8gJC5maWx0ZXIoKGUpID0+IGUua2luZCA9PT0gXCJncm91cFwiKS5sZW5ndGggOiAwfWAgOiBcIlwiKS5maWx0ZXIoQm9vbGVhbiksIEJ0ID0gWmUgPT09IDAgPyB2b2lkIDAgOiB7IHRyYW5zZm9ybTogYHRyYW5zbGF0ZVgoJHstWmV9cHgpYCB9O1xuXHRmdW5jdGlvbiBWdCgpIHtcblx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGMoXCJjb2xncm91cFwiLCB7IGNoaWxkcmVuOiBbXG5cdFx0XHRxID09PSBcIm5vbmVcIiA/IG51bGwgOiAvKiBAX19QVVJFX18gKi8gcyhcImNvbFwiLCB7IGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NvbCBuYWJzLXVpLWdyaWRfX2NvbC0tc2VsZWN0aW9uXCIgfSksXG5cdFx0XHRHLm1hcCgoZSkgPT4ge1xuXHRcdFx0XHRsZXQgdCA9IGUud2lkdGgsIG4gPSBlLm1pbldpZHRoO1xuXHRcdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJjb2xcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NvbFwiLFxuXHRcdFx0XHRcdHN0eWxlOiB7XG5cdFx0XHRcdFx0XHR3aWR0aDogdCA9PT0gdm9pZCAwID8gdm9pZCAwIDogdHlwZW9mIHQgPT0gXCJudW1iZXJcIiA/IGAke3R9cHhgIDogdCxcblx0XHRcdFx0XHRcdG1pbldpZHRoOiBuID09PSB2b2lkIDAgPyB2b2lkIDAgOiBgJHtufXB4YFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSwgZS5rZXkpO1xuXHRcdFx0fSksXG5cdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcImNvbFwiLCB7IGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NvbCBuYWJzLXVpLWdyaWRfX2NvbC0tYWN0aW9uc1wiIH0pXG5cdFx0XSB9KTtcblx0fVxuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdHJlZjogRWUsXG5cdFx0Y2xhc3NOYW1lOiBQdCxcblx0XHQuLi5UZSxcblx0XHRjaGlsZHJlbjogW1xuXHRcdFx0LyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX190b29sYmFyXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0dHQgPyAvKiBAX19QVVJFX18gKi8gcyhcImlucHV0XCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2lucHV0IG5hYnMtdWktZ3JpZF9fc2VhcmNoXCIsXG5cdFx0XHRcdFx0XHR0eXBlOiBcInNlYXJjaFwiLFxuXHRcdFx0XHRcdFx0dmFsdWU6IE0sXG5cdFx0XHRcdFx0XHRwbGFjZWhvbGRlcjogXCJGaW5kIHJvd3MuLi5cIixcblx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHR6ZShlLnRhcmdldC52YWx1ZSksIEIoMCk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0XHRcdHJ0ID8gLyogQF9fUFVSRV9fICovIGMoXCJsYWJlbFwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19ncm91cENvbnRyb2xcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHsgY2hpbGRyZW46IFwiR3JvdXAgYnlcIiB9KSwgLyogQF9fUFVSRV9fICovIGMoXCJzZWxlY3RcIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19pbnB1dFwiLFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogSSA/PyBcIlwiLFxuXHRcdFx0XHRcdFx0XHRvbkNoYW5nZTogKGUpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsZXQgdCA9IGUudGFyZ2V0LnZhbHVlIHx8IG51bGw7XG5cdFx0XHRcdFx0XHRcdFx0TCh0KSwgVmUoLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSk7XG5cdFx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJvcHRpb25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBcIlwiLFxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIk5vbmVcIlxuXHRcdFx0XHRcdFx0XHR9KSwgSXQubWFwKChlKSA9PiAvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0dmFsdWU6IGUua2V5LFxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmxhYmVsXG5cdFx0XHRcdFx0XHRcdH0sIGUua2V5KSldXG5cdFx0XHRcdFx0XHR9KV1cblx0XHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdFx0aXQgPyAvKiBAX19QVVJFX18gKi8gYyhcImxhYmVsXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2dyb3VwQ29udHJvbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwgeyBjaGlsZHJlbjogXCJQYWdlIHNpemVcIiB9KSwgLyogQF9fUFVSRV9fICovIHMoXCJzZWxlY3RcIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19pbnB1dFwiLFxuXHRcdFx0XHRcdFx0XHR2YWx1ZTogU3RyaW5nKFYpLFxuXHRcdFx0XHRcdFx0XHRvbkNoYW5nZTogKGUpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsZXQgdCA9IE51bWJlcihlLnRhcmdldC52YWx1ZSk7XG5cdFx0XHRcdFx0XHRcdFx0SChOdW1iZXIuaXNGaW5pdGUodCkgJiYgdCA+IDAgPyB0IDogMTApLCBCKDApO1xuXHRcdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogKE8ucGFnZVNpemVPcHRpb25zID8/IFtcblx0XHRcdFx0XHRcdFx0XHQxMCxcblx0XHRcdFx0XHRcdFx0XHQyMCxcblx0XHRcdFx0XHRcdFx0XHQ1MFxuXHRcdFx0XHRcdFx0XHRdKS5tYXAoKGUpID0+IC8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogU3RyaW5nKGUpLFxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0XHRcdFx0XHRcdH0sIGUpKVxuXHRcdFx0XHRcdFx0fSldXG5cdFx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRcdF1cblx0XHRcdH0pLFxuXHRcdFx0TGUgPyAvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3N0YXR1c1wiLFxuXHRcdFx0XHRjaGlsZHJlbjogTGVcblx0XHRcdH0pIDogbnVsbCxcblx0XHRcdEZlID8gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19zdGF0dXNcIixcblx0XHRcdFx0Y2hpbGRyZW46IFwiTG9hZGluZyBkYXRhLi4uXCJcblx0XHRcdH0pIDogbnVsbCxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyBjKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fc3VyZmFjZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2hlYWRlclZpZXdwb3J0XCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGMoXCJ0YWJsZVwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3RhYmxlXCIsXG5cdFx0XHRcdFx0XHRcdHN0eWxlOiBCdCxcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFtWdCgpLCAvKiBAX19QVVJFX18gKi8gcyhcInRoZWFkXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19oZWFkXCIsXG5cdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBjKFwidHJcIiwgeyBjaGlsZHJlbjogW1xuXHRcdFx0XHRcdFx0XHRcdFx0cSA9PT0gXCJub25lXCIgPyBudWxsIDogLyogQF9fUFVSRV9fICovIHMoXCJ0aFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NlbGwgbmFicy11aS1ncmlkX19jZWxsLS1oZWFkIG5hYnMtdWktZ3JpZF9fY2VsbC0tc2VsZWN0aW9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gcyhcImlucHV0XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcImNoZWNrYm94XCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hlY2tlZDogeHQsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DaGFuZ2U6IChlKSA9PiBOdChlLnRhcmdldC5jaGVja2VkKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcImFyaWEtbGFiZWxcIjogXCJTZWxlY3QgdmlzaWJsZSByb3dzXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdFx0XHRcdFx0Ry5tYXAoKGUpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0bGV0IHQgPSBQPy5jb2x1bW5LZXkgPT09IGUua2V5ID8gYCAoJHtQLmRpcmVjdGlvbn0pYCA6IFwiXCIsIG4gPSAhIU5bZS5rZXldO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJ0aFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbCBuYWJzLXVpLWdyaWRfX2NlbGwtLWhlYWRcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faGVhZENlbGxcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGMoXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19zb3J0QnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IHd0KGUpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRkaXNhYmxlZDogIWUuc29ydGFibGUsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBgJHtlLmxhYmVsfSR7dH1gLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7IGNoaWxkcmVuOiBlLmxhYmVsIH0pLCBlLnNvcnRhYmxlID8gLyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHsgY2hpbGRyZW46IFA/LmNvbHVtbktleSA9PT0gZS5rZXkgPyBQLmRpcmVjdGlvbiA6IFwiLVwiIH0pIDogbnVsbF1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pLCBudCAmJiBlLmZpbHRlcmFibGUgPyBlLnR5cGUgPT09IFwiYm9vbGVhblwiID8gLyogQF9fUFVSRV9fICovIGMoXCJzZWxlY3RcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IGIoXCJuYWJzLXVpLWdyaWRfX2lucHV0XCIsIG4gPyBcIm5hYnMtdWktZ3JpZF9faW5wdXQtLWFjdGl2ZVwiIDogXCJcIiksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBsZShOW2Uua2V5XSA/PyBcIlwiKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DaGFuZ2U6ICh0KSA9PiBDdChlLmtleSwgdC50YXJnZXQudmFsdWUpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBcIlwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiQWxsXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJUcnVlXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogXCJmYWxzZVwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiRmFsc2VcIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdF1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pIDogLyogQF9fUFVSRV9fICovIHMoXCJpbnB1dFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogYihcIm5hYnMtdWktZ3JpZF9faW5wdXRcIiwgbiA/IFwibmFicy11aS1ncmlkX19pbnB1dC0tYWN0aXZlXCIgOiBcIlwiKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dHlwZTogXCJ0ZXh0XCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBOW2Uua2V5XSA/PyBcIlwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRwbGFjZWhvbGRlcjogXCJGaWx0ZXJcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DaGFuZ2U6ICh0KSA9PiBDdChlLmtleSwgdC50YXJnZXQudmFsdWUpXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0fSwgZS5rZXkpO1xuXHRcdFx0XHRcdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcInRoXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbCBuYWJzLXVpLWdyaWRfX2NlbGwtLWhlYWQgbmFicy11aS1ncmlkX19jZWxsLS1hY3Rpb25zXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIkFjdGlvbnNcIlxuXHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRdIH0pXG5cdFx0XHRcdFx0XHRcdH0pXVxuXHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX192aWV3cG9ydFwiLFxuXHRcdFx0XHRcdFx0c3R5bGU6IHsgaGVpZ2h0OiBgJHtzZX1weGAgfSxcblx0XHRcdFx0XHRcdG9uU2Nyb2xsOiAoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRsZXQgdCA9IGUudGFyZ2V0O1xuXHRcdFx0XHRcdFx0XHRYZSh0LnNjcm9sbFRvcCksIFFlKHQuc2Nyb2xsTGVmdCk7XG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBjKFwidGFibGVcIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX190YWJsZVwiLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW1Z0KCksIC8qIEBfX1BVUkVfXyAqLyBjKFwidGJvZHlcIiwgeyBjaGlsZHJlbjogW1xuXHRcdFx0XHRcdFx0XHRcdGd0ID4gMCA/IC8qIEBfX1BVUkVfXyAqLyBzKFwidHJcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fc3BhY2VyXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRzdHlsZTogeyBoZWlnaHQ6IGAke2d0fXB4YCB9LFxuXHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwgeyBjb2xTcGFuOiBGdCB9KVxuXHRcdFx0XHRcdFx0XHRcdH0pIDogbnVsbCxcblx0XHRcdFx0XHRcdFx0XHRodC5tYXAoKGUsIHQpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdGlmIChlLmtpbmQgPT09IFwiZ3JvdXBcIikge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgdCA9IGUuZ3JvdXBWYWx1ZSA/PyBcIihlbXB0eSlcIiwgbiA9IFIuaGFzKHQpO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJ0clwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZ3JvdXBSb3dcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRzdHlsZTogeyBoZWlnaHQ6IGAke3d9cHhgIH0sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y29sU3BhbjogRnQsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19ncm91cENlbGxcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gYyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2dyb3VwVG9nZ2xlXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IGp0KHQpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7IGNoaWxkcmVuOiBuID8gXCJIaWRlXCIgOiBcIlNob3dcIiB9KSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwgeyBjaGlsZHJlbjogdCB9KSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gYyhcInNwYW5cIiwgeyBjaGlsZHJlbjogW2UuZ3JvdXBTaXplID8/IDAsIFwiIHJvd3NcIl0gfSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9LCBlLmtleSk7XG5cdFx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdFx0XHRpZiAoIWUucm93KSByZXR1cm4gbnVsbDtcblx0XHRcdFx0XHRcdFx0XHRcdGxldCBuID0gZS5yb3csIHIgPSBlLnJvd0luZGV4ID8/IHQsIGkgPSB4KG4sIEssIHIpLCBhID0gSGUuaGFzKGkpLCBsID0gV2UgPT09IGk7XG5cdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGMoXCJ0clwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogYihcIm5hYnMtdWktZ3JpZF9fZGF0YVJvd1wiLCBhID8gXCJuYWJzLXVpLWdyaWRfX2RhdGFSb3ctLXNlbGVjdGVkXCIgOiBcIlwiKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0c3R5bGU6IHsgaGVpZ2h0OiBgJHt3fXB4YCB9LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHEgPT09IFwibm9uZVwiID8gbnVsbCA6IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbCBuYWJzLXVpLWdyaWRfX2NlbGwtLXNlbGVjdGlvblwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBzKFwiaW5wdXRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcImNoZWNrYm94XCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoZWNrZWQ6IGEsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAoZSkgPT4gTXQobiwgciwgZS50YXJnZXQuY2hlY2tlZCksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBgU2VsZWN0IHJvdyAke2l9YFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRHLm1hcCgoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0bGV0IHQgPSBUKChsID8gS2UgOiBuKT8uW2Uua2V5XSwgZS50eXBlKTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiBsICYmIGUuZWRpdGFibGUgPyBlLmVkaXRvciA9PT0gXCJjaGVja2JveFwiIHx8IGUudHlwZSA9PT0gXCJib29sZWFuXCIgPyAvKiBAX19QVVJFX18gKi8gcyhcInRkXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGMoXCJzZWxlY3RcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2lucHV0XCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IHQgPT09IFwidHJ1ZVwiID8gXCJ0cnVlXCIgOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DaGFuZ2U6ICh0KSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgbiA9IHQudGFyZ2V0LnZhbHVlID09PSBcInRydWVcIjtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFUoKHQpID0+ICh7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC4uLnQgPz8ge30sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFtlLmtleV06IG5cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJvcHRpb25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiVHJ1ZVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJGYWxzZVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSldXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9LCBlLmtleSkgOiBlLmVkaXRvciA9PT0gXCJzZWxlY3RcIiAmJiBlLm9wdGlvbnM/Lmxlbmd0aCA/IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gYyhcInNlbGVjdFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faW5wdXRcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogdCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNoYW5nZTogKHQpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGxldCBuID0gRSh0LnRhcmdldC52YWx1ZSwgZSk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRVKCh0KSA9PiAoe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQuLi50ID8/IHt9LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRbZS5rZXldOiBuXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBcIlwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiKGVtcHR5KVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSksIGUub3B0aW9ucy5tYXAoKGUpID0+IC8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBTdHJpbmcoZS52YWx1ZSksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5sYWJlbFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0sIFN0cmluZyhlLnZhbHVlKSkpXVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSwgZS5rZXkpIDogZS5lZGl0b3IgPT09IFwidGV4dGFyZWFcIiA/IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gcyhcInRleHRhcmVhXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19pbnB1dCBuYWJzLXVpLWdyaWRfX2lucHV0LS10ZXh0YXJlYVwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiB0LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAodCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0bGV0IG4gPSBFKHQudGFyZ2V0LnZhbHVlLCBlKTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFUoKHQpID0+ICh7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC4uLnQgPz8ge30sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFtlLmtleV06IG5cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9LCBlLmtleSkgOiAvKiBAX19QVVJFX18gKi8gcyhcInRkXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIHMoXCJpbnB1dFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faW5wdXRcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0eXBlOiBlLmVkaXRvciA9PT0gXCJudW1iZXJcIiB8fCBlLnR5cGUgPT09IFwibnVtYmVyXCIgPyBcIm51bWJlclwiIDogZS50eXBlID09PSBcImRhdGVcIiA/IFwiZGF0ZVwiIDogXCJ0ZXh0XCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IHQsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DaGFuZ2U6ICh0KSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgbiA9IEUodC50YXJnZXQudmFsdWUsIGUpO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0VSgodCkgPT4gKHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Li4udCA/PyB7fSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0W2Uua2V5XTogblxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSkpO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0sIGUua2V5KSA6IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHRpdGxlOiBTKG5bZS5rZXldLCBlKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFR0KG4sIHIsIGUpXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9LCBlLmtleSk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIHMoXCJ0ZFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsIG5hYnMtdWktZ3JpZF9fY2VsbC0tYWN0aW9uc1wiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBjKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fYWN0aW9uU3RhY2tcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFthdCA/IGwgPyAvKiBAX19QVVJFX18gKi8gYyhvLCB7IGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2J1dHRvbiBuYWJzLXVpLWdyaWRfX2J1dHRvbi0tcHJpbWFyeVwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DbGljazogKCkgPT4gRHQoaSksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiU2F2ZVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNsaWNrOiBPdCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJDYW5jZWxcIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KV0gfSkgOiAvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBFdChuLCByKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJJbmxpbmVcIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSA6IG51bGwsIG90ID8gLyogQF9fUFVSRV9fICovIHMoXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2J1dHRvblwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DbGljazogKCkgPT4ga3QobiwgciksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiRGlhbG9nXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSkgOiBudWxsXVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRdXG5cdFx0XHRcdFx0XHRcdFx0XHR9LCBlLmtleSk7XG5cdFx0XHRcdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0XHRcdFx0X3QgPiAwID8gLyogQF9fUFVSRV9fICovIHMoXCJ0clwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19zcGFjZXJcIixcblx0XHRcdFx0XHRcdFx0XHRcdHN0eWxlOiB7IGhlaWdodDogYCR7X3R9cHhgIH0sXG5cdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIHMoXCJ0ZFwiLCB7IGNvbFNwYW46IEZ0IH0pXG5cdFx0XHRcdFx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRcdFx0XHRcdF0gfSldXG5cdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdEx0IHx8IHp0Lmxlbmd0aCA/IC8qIEBfX1BVUkVfXyAqLyBjKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2Zvb3RlclwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFtMdCA/IC8qIEBfX1BVUkVfXyAqLyBjKFwic2VjdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2Zvb3RlclNlY3Rpb24gbmFicy11aS1ncmlkX19mb290ZXJTZWN0aW9uLS1jb2x1bW5zXCIsXG5cdFx0XHRcdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBcIkNvbHVtbiBhZ2dyZWdhdGVzXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2Zvb3RlclNlY3Rpb25IZWFkZXJcIixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJDb2x1bW4gYWdncmVnYXRlc1wiXG5cdFx0XHRcdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gYyhcInRhYmxlXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX190YWJsZVwiLFxuXHRcdFx0XHRcdFx0XHRcdHN0eWxlOiBCdCxcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW1Z0KCksIC8qIEBfX1BVUkVfXyAqLyBzKFwidGJvZHlcIiwgeyBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGMoXCJ0clwiLCB7IGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHRcdFx0XHRxID09PSBcIm5vbmVcIiA/IG51bGwgOiAvKiBAX19QVVJFX18gKi8gcyhcInRkXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbCBuYWJzLXVpLWdyaWRfX2NlbGwtLWZvb3RcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IHZ0Lmxlbmd0aFxuXHRcdFx0XHRcdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0XHRcdFx0XHRHLm1hcCgoZSwgdCkgPT4gLyogQF9fUFVSRV9fICovIGMoXCJ0ZFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NlbGwgbmFicy11aS1ncmlkX19jZWxsLS1mb290XCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dCA9PT0gMCA/IGBSb3dzICR7UnR9YCA6IFwiXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dCA9PT0gMCAmJiB5dC5oYXMoZS5rZXkpID8gXCIgfCBcIiA6IFwiXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0eXQuZ2V0KGUua2V5KSA/PyBcIlwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdF1cblx0XHRcdFx0XHRcdFx0XHRcdH0sIGUua2V5KSksXG5cdFx0XHRcdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gYyhcInRkXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbCBuYWJzLXVpLWdyaWRfX2NlbGwtLWZvb3RcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFtcIlNlbGVjdGVkIFwiLCB2dC5sZW5ndGhdXG5cdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdF0gfSkgfSldXG5cdFx0XHRcdFx0XHRcdH0pXVxuXHRcdFx0XHRcdFx0fSkgOiBudWxsLCB6dC5sZW5ndGggPyAvKiBAX19QVVJFX18gKi8gYyhcInNlY3Rpb25cIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19mb290ZXJTZWN0aW9uIG5hYnMtdWktZ3JpZF9fZm9vdGVyU2VjdGlvbi0tcm93c1wiLFxuXHRcdFx0XHRcdFx0XHRcImFyaWEtbGFiZWxcIjogXCJSb3cgYWdncmVnYXRlc1wiLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19mb290ZXJTZWN0aW9uSGVhZGVyXCIsXG5cdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiUm93IGFnZ3JlZ2F0ZXNcIlxuXHRcdFx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NlbGwgbmFicy11aS1ncmlkX19jZWxsLS1mb290XCIsXG5cdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IHp0LmpvaW4oXCIgfCBcIilcblx0XHRcdFx0XHRcdFx0fSldXG5cdFx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRcdF1cblx0XHRcdH0pLFxuXHRcdFx0aXQgPyAvKiBAX19QVVJFX18gKi8gYyhcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3BhZ2VyXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIHMoXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRcdFx0b25DbGljazogKCkgPT4gQigwKSxcblx0XHRcdFx0XHRcdGRpc2FibGVkOiBRID09PSAwLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiRmlyc3RcIlxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2J1dHRvblwiLFxuXHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IEIoKGUpID0+IE1hdGgubWF4KDAsIGUgLSAxKSksXG5cdFx0XHRcdFx0XHRkaXNhYmxlZDogUSA9PT0gMCxcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIlByZXZcIlxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7IGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHRcIlBhZ2UgXCIsXG5cdFx0XHRcdFx0XHRRICsgMSxcblx0XHRcdFx0XHRcdFwiIC8gXCIsXG5cdFx0XHRcdFx0XHRaXG5cdFx0XHRcdFx0XSB9KSxcblx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19idXR0b25cIixcblx0XHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBCKChlKSA9PiBNYXRoLm1pbihaIC0gMSwgZSArIDEpKSxcblx0XHRcdFx0XHRcdGRpc2FibGVkOiBRID49IFogLSAxLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiTmV4dFwiXG5cdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIHMoXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRcdFx0b25DbGljazogKCkgPT4gQihaIC0gMSksXG5cdFx0XHRcdFx0XHRkaXNhYmxlZDogUSA+PSBaIC0gMSxcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIkxhc3RcIlxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdF1cblx0XHRcdH0pIDogbnVsbCxcblx0XHRcdHFlID8gLyogQF9fUFVSRV9fICovIHMoZGUsIHtcblx0XHRcdFx0Y29sdW1uczogRyxcblx0XHRcdFx0ZHJhZnQ6IHFlLmRyYWZ0LFxuXHRcdFx0XHRyb3dJZDogcWUucm93SWQsXG5cdFx0XHRcdG9uQ2FuY2VsOiAoKSA9PiBKZShudWxsKSxcblx0XHRcdFx0b25TYXZlOiAoZSkgPT4gQXQocWUucm93SWQsIGUpXG5cdFx0XHR9KSA6IG51bGxcblx0XHRdXG5cdH0pO1xufSk7XG5ELmRpc3BsYXlOYW1lID0gXCJHcmlkXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEQgYXMgR3JpZCB9O1xuIiwiaW1wb3J0ICogYXMgZSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGZvcndhcmRSZWYgYXMgdCwgdXNlRWZmZWN0IGFzIG4sIHVzZUlkIGFzIHIsIHVzZVJlZiBhcyBpLCB1c2VTdGF0ZSBhcyBhIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgbywganN4cyBhcyBzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gLi4vbmFicy11aS10b29sYmFyL3NyYy90b29sYmFyLnV0aWxzLnRzXG52YXIgYyA9IHtcblx0bGVmdDogXCJuYWJzLXVpLXRvb2xiYXJfX2NvbnRlbnQtLWxhYmVsLWxlZnRcIixcblx0cmlnaHQ6IFwibmFicy11aS10b29sYmFyX19jb250ZW50LS1sYWJlbC1yaWdodFwiLFxuXHR0b3A6IFwibmFicy11aS10b29sYmFyX19jb250ZW50LS1sYWJlbC10b3BcIixcblx0Ym90dG9tOiBcIm5hYnMtdWktdG9vbGJhcl9fY29udGVudC0tbGFiZWwtYm90dG9tXCJcbn07XG5mdW5jdGlvbiBsKGUpIHtcblx0cmV0dXJuIGUgfHwgXCJyaWdodFwiO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vbmFicy11aS10b29sYmFyL3NyYy9Ub29sYmFyLnRzeFxudmFyIHUgPSB0KGZ1bmN0aW9uKHsgaXRlbXM6IGUsIGFjdGl2ZUl0ZW1JZDogdCwgY2xhc3NOYW1lOiBuID0gXCJcIiwgYnV0dG9uQ2xhc3NOYW1lOiByID0gXCJcIiwgaWNvbkNsYXNzTmFtZTogaSA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBhID0gXCJcIiwgb25JdGVtU2VsZWN0OiB1LCAuLi5kIH0sIGYpIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBvKFwiZGl2XCIsIHtcblx0XHRyZWY6IGYsXG5cdFx0Y2xhc3NOYW1lOiBbXCJuYWJzLXVpLXRvb2xiYXJcIiwgbl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdHJvbGU6IFwidG9vbGJhclwiLFxuXHRcdC4uLmQsXG5cdFx0Y2hpbGRyZW46IGUubWFwKChlKSA9PiB7XG5cdFx0XHRsZXQgbiA9IGUuaWNvbiwgZCA9ICEhZS5sYWJlbCwgZiA9IGUuaWQgPT09IHQgfHwgZS5wcmVzc2VkID09PSAhMCwgcCA9IFtcIm5hYnMtdWktdG9vbGJhcl9fY29udGVudFwiLCBjW2woZS5sYWJlbFBvc2l0aW9uKV1dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgbSA9IFtcblx0XHRcdFx0XCJuYWJzLXVpLXRvb2xiYXJfX2J1dHRvblwiLFxuXHRcdFx0XHRmID8gXCJuYWJzLXVpLXRvb2xiYXJfX2J1dHRvbi0tYWN0aXZlXCIgOiBcIlwiLFxuXHRcdFx0XHRkID8gXCJcIiA6IFwibmFicy11aS10b29sYmFyX19idXR0b24tLWljb24tb25seVwiLFxuXHRcdFx0XHRyXG5cdFx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaCA9IFtcIm5hYnMtdWktdG9vbGJhcl9faWNvblwiLCBpXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGcgPSBbXCJuYWJzLXVpLXRvb2xiYXJfX2xhYmVsXCIsIGFdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgXyA9IHR5cGVvZiBlLmxhYmVsID09IFwic3RyaW5nXCIgPyBlLmxhYmVsIDogZS50aXRsZTtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gbyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdGNsYXNzTmFtZTogbSxcblx0XHRcdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XHRcdHRpdGxlOiBlLnRpdGxlLFxuXHRcdFx0XHRcImFyaWEtbGFiZWxcIjogXyxcblx0XHRcdFx0XCJhcmlhLXByZXNzZWRcIjogdHlwZW9mIGUucHJlc3NlZCA9PSBcImJvb2xlYW5cIiA/IGUucHJlc3NlZCA6IHZvaWQgMCxcblx0XHRcdFx0b25DbGljazogKHQpID0+IHtcblx0XHRcdFx0XHR1Py4oe1xuXHRcdFx0XHRcdFx0aXRlbUlkOiBlLmlkLFxuXHRcdFx0XHRcdFx0aXRlbTogZSxcblx0XHRcdFx0XHRcdGV2ZW50OiB0XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogcCxcblx0XHRcdFx0XHRjaGlsZHJlbjogW24gPyAvKiBAX19QVVJFX18gKi8gbyhuLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IGgsXG5cdFx0XHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdFx0Zm9jdXNhYmxlOiBcImZhbHNlXCJcblx0XHRcdFx0XHR9KSA6IG51bGwsIGUubGFiZWwgPyAvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUubGFiZWxcblx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdH0pXG5cdFx0XHR9LCBlLmlkKTtcblx0XHR9KVxuXHR9KTtcbn0pO1xudS5kaXNwbGF5TmFtZSA9IFwiVG9vbGJhclwiO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BoZXJvaWNvbnMrcmVhY3RAMi4yLjBfcmVhY3RAMTkuMi43L25vZGVfbW9kdWxlcy9AaGVyb2ljb25zL3JlYWN0LzI0L291dGxpbmUvZXNtL0NoYXRCdWJibGVMZWZ0RWxsaXBzaXNJY29uLmpzXG5mdW5jdGlvbiBkKHsgdGl0bGU6IHQsIHRpdGxlSWQ6IG4sIC4uLnIgfSwgaSkge1xuXHRyZXR1cm4gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgT2JqZWN0LmFzc2lnbih7XG5cdFx0eG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcblx0XHRmaWxsOiBcIm5vbmVcIixcblx0XHR2aWV3Qm94OiBcIjAgMCAyNCAyNFwiLFxuXHRcdHN0cm9rZVdpZHRoOiAxLjUsXG5cdFx0c3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuXHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XCJkYXRhLXNsb3RcIjogXCJpY29uXCIsXG5cdFx0cmVmOiBpLFxuXHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IG5cblx0fSwgciksIHQgPyAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIHsgaWQ6IG4gfSwgdCkgOiBudWxsLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwiTTguNjI1IDkuNzVhLjM3NS4zNzUgMCAxIDEtLjc1IDAgLjM3NS4zNzUgMCAwIDEgLjc1IDBabTAgMEg4LjI1bTQuMTI1IDBhLjM3NS4zNzUgMCAxIDEtLjc1IDAgLjM3NS4zNzUgMCAwIDEgLjc1IDBabTAgMEgxMm00LjEyNSAwYS4zNzUuMzc1IDAgMSAxLS43NSAwIC4zNzUuMzc1IDAgMCAxIC43NSAwWm0wIDBoLS4zNzVtLTEzLjUgMy4wMWMwIDEuNiAxLjEyMyAyLjk5NCAyLjcwNyAzLjIyNyAxLjA4Ny4xNiAyLjE4NS4yODMgMy4yOTMuMzY5VjIxbDQuMTg0LTQuMTgzYTEuMTQgMS4xNCAwIDAgMSAuNzc4LS4zMzIgNDguMjk0IDQ4LjI5NCAwIDAgMCA1LjgzLS40OThjMS41ODUtLjIzMyAyLjcwOC0xLjYyNiAyLjcwOC0zLjIyOFY2Ljc0MWMwLTEuNjAyLTEuMTIzLTIuOTk1LTIuNzA3LTMuMjI4QTQ4LjM5NCA0OC4zOTQgMCAwIDAgMTIgM2MtMi4zOTIgMC00Ljc0NC4xNzUtNy4wNDMuNTEzQzMuMzczIDMuNzQ2IDIuMjUgNS4xNCAyLjI1IDYuNzQxdjYuMDE4WlwiXG5cdH0pKTtcbn1cbnZhciBmID0gLyojX19QVVJFX18qLyBlLmZvcndhcmRSZWYoZCk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGhlcm9pY29ucytyZWFjdEAyLjIuMF9yZWFjdEAxOS4yLjcvbm9kZV9tb2R1bGVzL0BoZXJvaWNvbnMvcmVhY3QvMjQvb3V0bGluZS9lc20vQ29kZUJyYWNrZXRJY29uLmpzXG5mdW5jdGlvbiBwKHsgdGl0bGU6IHQsIHRpdGxlSWQ6IG4sIC4uLnIgfSwgaSkge1xuXHRyZXR1cm4gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgT2JqZWN0LmFzc2lnbih7XG5cdFx0eG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcblx0XHRmaWxsOiBcIm5vbmVcIixcblx0XHR2aWV3Qm94OiBcIjAgMCAyNCAyNFwiLFxuXHRcdHN0cm9rZVdpZHRoOiAxLjUsXG5cdFx0c3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuXHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XCJkYXRhLXNsb3RcIjogXCJpY29uXCIsXG5cdFx0cmVmOiBpLFxuXHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IG5cblx0fSwgciksIHQgPyAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIHsgaWQ6IG4gfSwgdCkgOiBudWxsLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwiTTE3LjI1IDYuNzUgMjIuNSAxMmwtNS4yNSA1LjI1bS0xMC41IDBMMS41IDEybDUuMjUtNS4yNW03LjUtMy00LjUgMTYuNVwiXG5cdH0pKTtcbn1cbnZhciBtID0gLyojX19QVVJFX18qLyBlLmZvcndhcmRSZWYocCk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGhlcm9pY29ucytyZWFjdEAyLjIuMF9yZWFjdEAxOS4yLjcvbm9kZV9tb2R1bGVzL0BoZXJvaWNvbnMvcmVhY3QvMjQvb3V0bGluZS9lc20vRG9jdW1lbnRUZXh0SWNvbi5qc1xuZnVuY3Rpb24gaCh7IHRpdGxlOiB0LCB0aXRsZUlkOiBuLCAuLi5yIH0sIGkpIHtcblx0cmV0dXJuIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwic3ZnXCIsIE9iamVjdC5hc3NpZ24oe1xuXHRcdHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG5cdFx0ZmlsbDogXCJub25lXCIsXG5cdFx0dmlld0JveDogXCIwIDAgMjQgMjRcIixcblx0XHRzdHJva2VXaWR0aDogMS41LFxuXHRcdHN0cm9rZTogXCJjdXJyZW50Q29sb3JcIixcblx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFwiZGF0YS1zbG90XCI6IFwiaWNvblwiLFxuXHRcdHJlZjogaSxcblx0XHRcImFyaWEtbGFiZWxsZWRieVwiOiBuXG5cdH0sIHIpLCB0ID8gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJ0aXRsZVwiLCB7IGlkOiBuIH0sIHQpIDogbnVsbCwgLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHtcblx0XHRzdHJva2VMaW5lY2FwOiBcInJvdW5kXCIsXG5cdFx0c3Ryb2tlTGluZWpvaW46IFwicm91bmRcIixcblx0XHRkOiBcIk0xOS41IDE0LjI1di0yLjYyNWEzLjM3NSAzLjM3NSAwIDAgMC0zLjM3NS0zLjM3NWgtMS41QTEuMTI1IDEuMTI1IDAgMCAxIDEzLjUgNy4xMjV2LTEuNWEzLjM3NSAzLjM3NSAwIDAgMC0zLjM3NS0zLjM3NUg4LjI1bTAgMTIuNzVoNy41bS03LjUgM0gxMk0xMC41IDIuMjVINS42MjVjLS42MjEgMC0xLjEyNS41MDQtMS4xMjUgMS4xMjV2MTcuMjVjMCAuNjIxLjUwNCAxLjEyNSAxLjEyNSAxLjEyNWgxMi43NWMuNjIxIDAgMS4xMjUtLjUwNCAxLjEyNS0xLjEyNVYxMS4yNWE5IDkgMCAwIDAtOS05WlwiXG5cdH0pKTtcbn1cbnZhciBnID0gLyojX19QVVJFX18qLyBlLmZvcndhcmRSZWYoaCk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGhlcm9pY29ucytyZWFjdEAyLjIuMF9yZWFjdEAxOS4yLjcvbm9kZV9tb2R1bGVzL0BoZXJvaWNvbnMvcmVhY3QvMjQvb3V0bGluZS9lc20vRXllSWNvbi5qc1xuZnVuY3Rpb24gXyh7IHRpdGxlOiB0LCB0aXRsZUlkOiBuLCAuLi5yIH0sIGkpIHtcblx0cmV0dXJuIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwic3ZnXCIsIE9iamVjdC5hc3NpZ24oe1xuXHRcdHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG5cdFx0ZmlsbDogXCJub25lXCIsXG5cdFx0dmlld0JveDogXCIwIDAgMjQgMjRcIixcblx0XHRzdHJva2VXaWR0aDogMS41LFxuXHRcdHN0cm9rZTogXCJjdXJyZW50Q29sb3JcIixcblx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFwiZGF0YS1zbG90XCI6IFwiaWNvblwiLFxuXHRcdHJlZjogaSxcblx0XHRcImFyaWEtbGFiZWxsZWRieVwiOiBuXG5cdH0sIHIpLCB0ID8gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJ0aXRsZVwiLCB7IGlkOiBuIH0sIHQpIDogbnVsbCwgLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHtcblx0XHRzdHJva2VMaW5lY2FwOiBcInJvdW5kXCIsXG5cdFx0c3Ryb2tlTGluZWpvaW46IFwicm91bmRcIixcblx0XHRkOiBcIk0yLjAzNiAxMi4zMjJhMS4wMTIgMS4wMTIgMCAwIDEgMC0uNjM5QzMuNDIzIDcuNTEgNy4zNiA0LjUgMTIgNC41YzQuNjM4IDAgOC41NzMgMy4wMDcgOS45NjMgNy4xNzguMDcuMjA3LjA3LjQzMSAwIC42MzlDMjAuNTc3IDE2LjQ5IDE2LjY0IDE5LjUgMTIgMTkuNWMtNC42MzggMC04LjU3My0zLjAwNy05Ljk2My03LjE3OFpcIlxuXHR9KSwgLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHtcblx0XHRzdHJva2VMaW5lY2FwOiBcInJvdW5kXCIsXG5cdFx0c3Ryb2tlTGluZWpvaW46IFwicm91bmRcIixcblx0XHRkOiBcIk0xNSAxMmEzIDMgMCAxIDEtNiAwIDMgMyAwIDAgMSA2IDBaXCJcblx0fSkpO1xufVxudmFyIHYgPSAvKiNfX1BVUkVfXyovIGUuZm9yd2FyZFJlZihfKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AaGVyb2ljb25zK3JlYWN0QDIuMi4wX3JlYWN0QDE5LjIuNy9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC8yNC9vdXRsaW5lL2VzbS9IYXNodGFnSWNvbi5qc1xuZnVuY3Rpb24geSh7IHRpdGxlOiB0LCB0aXRsZUlkOiBuLCAuLi5yIH0sIGkpIHtcblx0cmV0dXJuIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwic3ZnXCIsIE9iamVjdC5hc3NpZ24oe1xuXHRcdHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG5cdFx0ZmlsbDogXCJub25lXCIsXG5cdFx0dmlld0JveDogXCIwIDAgMjQgMjRcIixcblx0XHRzdHJva2VXaWR0aDogMS41LFxuXHRcdHN0cm9rZTogXCJjdXJyZW50Q29sb3JcIixcblx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFwiZGF0YS1zbG90XCI6IFwiaWNvblwiLFxuXHRcdHJlZjogaSxcblx0XHRcImFyaWEtbGFiZWxsZWRieVwiOiBuXG5cdH0sIHIpLCB0ID8gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJ0aXRsZVwiLCB7IGlkOiBuIH0sIHQpIDogbnVsbCwgLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHtcblx0XHRzdHJva2VMaW5lY2FwOiBcInJvdW5kXCIsXG5cdFx0c3Ryb2tlTGluZWpvaW46IFwicm91bmRcIixcblx0XHRkOiBcIk01LjI1IDguMjVoMTVtLTE2LjUgNy41aDE1bS0xLjgtMTMuNS0zLjkgMTkuNW0tMi4xLTE5LjUtMy45IDE5LjVcIlxuXHR9KSk7XG59XG52YXIgYiA9IC8qI19fUFVSRV9fKi8gZS5mb3J3YXJkUmVmKHkpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BoZXJvaWNvbnMrcmVhY3RAMi4yLjBfcmVhY3RAMTkuMi43L25vZGVfbW9kdWxlcy9AaGVyb2ljb25zL3JlYWN0LzI0L291dGxpbmUvZXNtL0xpbmtJY29uLmpzXG5mdW5jdGlvbiB4KHsgdGl0bGU6IHQsIHRpdGxlSWQ6IG4sIC4uLnIgfSwgaSkge1xuXHRyZXR1cm4gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgT2JqZWN0LmFzc2lnbih7XG5cdFx0eG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcblx0XHRmaWxsOiBcIm5vbmVcIixcblx0XHR2aWV3Qm94OiBcIjAgMCAyNCAyNFwiLFxuXHRcdHN0cm9rZVdpZHRoOiAxLjUsXG5cdFx0c3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuXHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XCJkYXRhLXNsb3RcIjogXCJpY29uXCIsXG5cdFx0cmVmOiBpLFxuXHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IG5cblx0fSwgciksIHQgPyAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIHsgaWQ6IG4gfSwgdCkgOiBudWxsLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwiTTEzLjE5IDguNjg4YTQuNSA0LjUgMCAwIDEgMS4yNDIgNy4yNDRsLTQuNSA0LjVhNC41IDQuNSAwIDAgMS02LjM2NC02LjM2NGwxLjc1Ny0xLjc1N20xMy4zNS0uNjIyIDEuNzU3LTEuNzU3YTQuNSA0LjUgMCAwIDAtNi4zNjQtNi4zNjRsLTQuNSA0LjVhNC41IDQuNSAwIDAgMCAxLjI0MiA3LjI0NFwiXG5cdH0pKTtcbn1cbnZhciBTID0gLyojX19QVVJFX18qLyBlLmZvcndhcmRSZWYoeCk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGhlcm9pY29ucytyZWFjdEAyLjIuMF9yZWFjdEAxOS4yLjcvbm9kZV9tb2R1bGVzL0BoZXJvaWNvbnMvcmVhY3QvMjQvb3V0bGluZS9lc20vTGlzdEJ1bGxldEljb24uanNcbmZ1bmN0aW9uIEMoeyB0aXRsZTogdCwgdGl0bGVJZDogbiwgLi4uciB9LCBpKSB7XG5cdHJldHVybiAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInN2Z1wiLCBPYmplY3QuYXNzaWduKHtcblx0XHR4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuXHRcdGZpbGw6IFwibm9uZVwiLFxuXHRcdHZpZXdCb3g6IFwiMCAwIDI0IDI0XCIsXG5cdFx0c3Ryb2tlV2lkdGg6IDEuNSxcblx0XHRzdHJva2U6IFwiY3VycmVudENvbG9yXCIsXG5cdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcImRhdGEtc2xvdFwiOiBcImljb25cIixcblx0XHRyZWY6IGksXG5cdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogblxuXHR9LCByKSwgdCA/IC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwidGl0bGVcIiwgeyBpZDogbiB9LCB0KSA6IG51bGwsIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7XG5cdFx0c3Ryb2tlTGluZWNhcDogXCJyb3VuZFwiLFxuXHRcdHN0cm9rZUxpbmVqb2luOiBcInJvdW5kXCIsXG5cdFx0ZDogXCJNOC4yNSA2Ljc1aDEyTTguMjUgMTJoMTJtLTEyIDUuMjVoMTJNMy43NSA2Ljc1aC4wMDd2LjAwOEgzLjc1VjYuNzVabS4zNzUgMGEuMzc1LjM3NSAwIDEgMS0uNzUgMCAuMzc1LjM3NSAwIDAgMSAuNzUgMFpNMy43NSAxMmguMDA3di4wMDhIMy43NVYxMlptLjM3NSAwYS4zNzUuMzc1IDAgMSAxLS43NSAwIC4zNzUuMzc1IDAgMCAxIC43NSAwWm0tLjM3NSA1LjI1aC4wMDd2LjAwOEgzLjc1di0uMDA4Wm0uMzc1IDBhLjM3NS4zNzUgMCAxIDEtLjc1IDAgLjM3NS4zNzUgMCAwIDEgLjc1IDBaXCJcblx0fSkpO1xufVxudmFyIHcgPSAvKiNfX1BVUkVfXyovIGUuZm9yd2FyZFJlZihDKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AaGVyb2ljb25zK3JlYWN0QDIuMi4wX3JlYWN0QDE5LjIuNy9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC8yNC9vdXRsaW5lL2VzbS9QZW5jaWxTcXVhcmVJY29uLmpzXG5mdW5jdGlvbiBUKHsgdGl0bGU6IHQsIHRpdGxlSWQ6IG4sIC4uLnIgfSwgaSkge1xuXHRyZXR1cm4gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgT2JqZWN0LmFzc2lnbih7XG5cdFx0eG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcblx0XHRmaWxsOiBcIm5vbmVcIixcblx0XHR2aWV3Qm94OiBcIjAgMCAyNCAyNFwiLFxuXHRcdHN0cm9rZVdpZHRoOiAxLjUsXG5cdFx0c3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuXHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XCJkYXRhLXNsb3RcIjogXCJpY29uXCIsXG5cdFx0cmVmOiBpLFxuXHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IG5cblx0fSwgciksIHQgPyAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIHsgaWQ6IG4gfSwgdCkgOiBudWxsLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwibTE2Ljg2MiA0LjQ4NyAxLjY4Ny0xLjY4OGExLjg3NSAxLjg3NSAwIDEgMSAyLjY1MiAyLjY1MkwxMC41ODIgMTYuMDdhNC41IDQuNSAwIDAgMS0xLjg5NyAxLjEzTDYgMThsLjgtMi42ODVhNC41IDQuNSAwIDAgMSAxLjEzLTEuODk3bDguOTMyLTguOTMxWm0wIDBMMTkuNSA3LjEyNU0xOCAxNHY0Ljc1QTIuMjUgMi4yNSAwIDAgMSAxNS43NSAyMUg1LjI1QTIuMjUgMi4yNSAwIDAgMSAzIDE4Ljc1VjguMjVBMi4yNSAyLjI1IDAgMCAxIDUuMjUgNkgxMFwiXG5cdH0pKTtcbn1cbnZhciBFID0gLyojX19QVVJFX18qLyBlLmZvcndhcmRSZWYoVCk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGhlcm9pY29ucytyZWFjdEAyLjIuMF9yZWFjdEAxOS4yLjcvbm9kZV9tb2R1bGVzL0BoZXJvaWNvbnMvcmVhY3QvMjQvb3V0bGluZS9lc20vUXVldWVMaXN0SWNvbi5qc1xuZnVuY3Rpb24gRCh7IHRpdGxlOiB0LCB0aXRsZUlkOiBuLCAuLi5yIH0sIGkpIHtcblx0cmV0dXJuIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwic3ZnXCIsIE9iamVjdC5hc3NpZ24oe1xuXHRcdHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG5cdFx0ZmlsbDogXCJub25lXCIsXG5cdFx0dmlld0JveDogXCIwIDAgMjQgMjRcIixcblx0XHRzdHJva2VXaWR0aDogMS41LFxuXHRcdHN0cm9rZTogXCJjdXJyZW50Q29sb3JcIixcblx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFwiZGF0YS1zbG90XCI6IFwiaWNvblwiLFxuXHRcdHJlZjogaSxcblx0XHRcImFyaWEtbGFiZWxsZWRieVwiOiBuXG5cdH0sIHIpLCB0ID8gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJ0aXRsZVwiLCB7IGlkOiBuIH0sIHQpIDogbnVsbCwgLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHtcblx0XHRzdHJva2VMaW5lY2FwOiBcInJvdW5kXCIsXG5cdFx0c3Ryb2tlTGluZWpvaW46IFwicm91bmRcIixcblx0XHRkOiBcIk0zLjc1IDEyaDE2LjVtLTE2LjUgMy43NWgxNi41TTMuNzUgMTkuNWgxNi41TTUuNjI1IDQuNWgxMi43NWExLjg3NSAxLjg3NSAwIDAgMSAwIDMuNzVINS42MjVhMS44NzUgMS44NzUgMCAwIDEgMC0zLjc1WlwiXG5cdH0pKTtcbn1cbnZhciBPID0gLyojX19QVVJFX18qLyBlLmZvcndhcmRSZWYoRCk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWFya2Rvd24udXRpbHMudHNcbmZ1bmN0aW9uIGsoZSkge1xuXHRyZXR1cm4gZS5zcGxpdChcIiZcIikuam9pbihcIiZhbXA7XCIpLnNwbGl0KFwiPFwiKS5qb2luKFwiJmx0O1wiKS5zcGxpdChcIj5cIikuam9pbihcIiZndDtcIikuc3BsaXQoXCJcXFwiXCIpLmpvaW4oXCImcXVvdDtcIikuc3BsaXQoXCInXCIpLmpvaW4oXCImIzM5O1wiKTtcbn1cbmZ1bmN0aW9uIEEoZSkge1xuXHRsZXQgdCA9IGUudHJpbSgpO1xuXHRyZXR1cm4gL14oaHR0cHM/OnxtYWlsdG86fFxcL3wjKS9pLnRlc3QodCkgPyBrKHQpIDogXCIjXCI7XG59XG5mdW5jdGlvbiBqKGUpIHtcblx0bGV0IHQgPSBrKGUpO1xuXHRyZXR1cm4gdCA9IHQucmVwbGFjZSgvXFxbKFteXFxdXSspXFxdXFwoKFteKV0rKVxcKS9nLCAoZSwgdCwgbikgPT4gYDxhIGhyZWY9XCIke0Eobil9XCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlciBub29wZW5lclwiPiR7dH08L2E+YCksIHQgPSB0LnJlcGxhY2UoL1xcKlxcKihbXipdKylcXCpcXCovZywgXCI8c3Ryb25nPiQxPC9zdHJvbmc+XCIpLCB0ID0gdC5yZXBsYWNlKC9fXyhbXl9dKylfXy9nLCBcIjxzdHJvbmc+JDE8L3N0cm9uZz5cIiksIHQgPSB0LnJlcGxhY2UoL1xcKihbXipdKylcXCovZywgXCI8ZW0+JDE8L2VtPlwiKSwgdCA9IHQucmVwbGFjZSgvXyhbXl9dKylfL2csIFwiPGVtPiQxPC9lbT5cIiksIHQgPSB0LnJlcGxhY2UoL35+KFtefl0rKX5+L2csIFwiPGRlbD4kMTwvZGVsPlwiKSwgdCA9IHQucmVwbGFjZSgvYChbXmBdKylgL2csIFwiPGNvZGU+JDE8L2NvZGU+XCIpLCB0O1xufVxuZnVuY3Rpb24gTShlKSB7XG5cdGxldCB0ID0gZS5zcGxpdChcIlxcclxcblwiKS5qb2luKFwiXFxuXCIpLnNwbGl0KFwiXFxuXCIpLCBuID0gW10sIHIgPSAwO1xuXHRmb3IgKDsgciA8IHQubGVuZ3RoOykge1xuXHRcdGxldCBlID0gdFtyXTtcblx0XHRpZiAoIWUudHJpbSgpKSB7XG5cdFx0XHRyICs9IDE7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0aWYgKGUuc3RhcnRzV2l0aChcImBgYFwiKSkge1xuXHRcdFx0bGV0IGUgPSBbXTtcblx0XHRcdGZvciAociArPSAxOyByIDwgdC5sZW5ndGggJiYgIXRbcl0uc3RhcnRzV2l0aChcImBgYFwiKTspIGUucHVzaCh0W3JdKSwgciArPSAxO1xuXHRcdFx0ciA8IHQubGVuZ3RoICYmIChyICs9IDEpLCBuLnB1c2goYDxwcmU+PGNvZGU+JHtrKGUuam9pbihcIlxcblwiKSl9PC9jb2RlPjwvcHJlPmApO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGxldCBpID0gZS5tYXRjaCgvXigjezEsNn0pXFxzKyguKikkLyk7XG5cdFx0aWYgKGkpIHtcblx0XHRcdGxldCBlID0gaVsxXS5sZW5ndGg7XG5cdFx0XHRuLnB1c2goYDxoJHtlfT4ke2ooaVsyXSl9PC9oJHtlfT5gKSwgciArPSAxO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChlLnN0YXJ0c1dpdGgoXCI+XCIpKSB7XG5cdFx0XHRsZXQgZSA9IFtdO1xuXHRcdFx0Zm9yICg7IHIgPCB0Lmxlbmd0aCAmJiB0W3JdLnN0YXJ0c1dpdGgoXCI+XCIpOykgZS5wdXNoKHRbcl0ucmVwbGFjZSgvXj4gPy8sIFwiXCIpKSwgciArPSAxO1xuXHRcdFx0bi5wdXNoKGA8YmxvY2txdW90ZT4ke2UubWFwKGopLmpvaW4oXCI8YnIgLz5cIil9PC9ibG9ja3F1b3RlPmApO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChlLm1hdGNoKC9eWy0qK11cXHMrKC4qKSQvKSkge1xuXHRcdFx0bGV0IGUgPSBbXTtcblx0XHRcdGZvciAoOyByIDwgdC5sZW5ndGg7KSB7XG5cdFx0XHRcdGxldCBuID0gdFtyXS5tYXRjaCgvXlstKitdXFxzKyguKikkLyk7XG5cdFx0XHRcdGlmICghbikgYnJlYWs7XG5cdFx0XHRcdGUucHVzaChgPGxpPiR7aihuWzFdKX08L2xpPmApLCByICs9IDE7XG5cdFx0XHR9XG5cdFx0XHRuLnB1c2goYDx1bD4ke2Uuam9pbihcIlwiKX08L3VsPmApO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChlLm1hdGNoKC9eXFxkK1xcLlxccysoLiopJC8pKSB7XG5cdFx0XHRsZXQgZSA9IFtdO1xuXHRcdFx0Zm9yICg7IHIgPCB0Lmxlbmd0aDspIHtcblx0XHRcdFx0bGV0IG4gPSB0W3JdLm1hdGNoKC9eXFxkK1xcLlxccysoLiopJC8pO1xuXHRcdFx0XHRpZiAoIW4pIGJyZWFrO1xuXHRcdFx0XHRlLnB1c2goYDxsaT4ke2ooblsxXSl9PC9saT5gKSwgciArPSAxO1xuXHRcdFx0fVxuXHRcdFx0bi5wdXNoKGA8b2w+JHtlLmpvaW4oXCJcIil9PC9vbD5gKTtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRsZXQgYSA9IFtdO1xuXHRcdGZvciAoOyByIDwgdC5sZW5ndGggJiYgdFtyXS50cmltKCk7KSB7XG5cdFx0XHRsZXQgZSA9IHRbcl0sIG4gPSBlLnN0YXJ0c1dpdGgoXCJgYGBcIikgfHwgL14oI3sxLDZ9KVxccysvLnRlc3QoZSkgfHwgZS5zdGFydHNXaXRoKFwiPlwiKSB8fCAvXlstKitdXFxzKy8udGVzdChlKSB8fCAvXlxcZCtcXC5cXHMrLy50ZXN0KGUpO1xuXHRcdFx0aWYgKGEubGVuZ3RoID4gMCAmJiBuKSBicmVhaztcblx0XHRcdGEucHVzaChlKSwgciArPSAxO1xuXHRcdH1cblx0XHRuLnB1c2goYDxwPiR7aihhLmpvaW4oXCIgXCIpKX08L3A+YCk7XG5cdH1cblx0cmV0dXJuIG4uam9pbihcIlwiKTtcbn1cbmZ1bmN0aW9uIE4oZSwgdCwgbikge1xuXHRsZXQgciA9IGUubGFzdEluZGV4T2YoXCJcXG5cIiwgTWF0aC5tYXgoMCwgdCAtIDEpKSArIDEsIGkgPSBlLmluZGV4T2YoXCJcXG5cIiwgbiksIGEgPSBpID09PSAtMSA/IGUubGVuZ3RoIDogaTtcblx0cmV0dXJuIHtcblx0XHRiZWZvcmU6IGUuc2xpY2UoMCwgciksXG5cdFx0c2VsZWN0ZWQ6IGUuc2xpY2UociwgYSksXG5cdFx0YWZ0ZXI6IGUuc2xpY2UoYSksXG5cdFx0bGluZVN0YXJ0OiByLFxuXHRcdGxpbmVFbmQ6IGFcblx0fTtcbn1cbmZ1bmN0aW9uIFAoZSwgdCwgbikge1xuXHRsZXQgciA9IGUudmFsdWUsIGkgPSBlLnNlbGVjdGlvblN0YXJ0ID8/IDAsIGEgPSBlLnNlbGVjdGlvbkVuZCA/PyBpLCBvID0gaSAhPT0gYSwgeyBiZWZvcmU6IHMsIHNlbGVjdGVkOiBjLCBhZnRlcjogbCwgbGluZVN0YXJ0OiB1IH0gPSBOKHIsIGksIGEpO1xuXHRpZiAoIW8pIHtcblx0XHRsZXQgZSA9IGAke3R9JHtufWA7XG5cdFx0cmV0dXJuIHtcblx0XHRcdG5leHRWYWx1ZTogYCR7ci5zbGljZSgwLCBpKX0ke2V9JHtyLnNsaWNlKGEpfWAsXG5cdFx0XHRuZXh0U3RhcnQ6IGkgKyB0Lmxlbmd0aCxcblx0XHRcdG5leHRFbmQ6IGkgKyBlLmxlbmd0aFxuXHRcdH07XG5cdH1cblx0bGV0IGQgPSBjLnNwbGl0KFwiXFxuXCIpLm1hcCgoZSkgPT4gZS50cmltKCkgPyBgJHt0fSR7ZX1gIDogdC50cmltRW5kKCkpLmpvaW4oXCJcXG5cIik7XG5cdHJldHVybiB7XG5cdFx0bmV4dFZhbHVlOiBgJHtzfSR7ZH0ke2x9YCxcblx0XHRuZXh0U3RhcnQ6IHUsXG5cdFx0bmV4dEVuZDogdSArIGQubGVuZ3RoXG5cdH07XG59XG5mdW5jdGlvbiBGKGUsIHQsIG4sIHIpIHtcblx0bGV0IGkgPSBlLnZhbHVlLCBhID0gZS5zZWxlY3Rpb25TdGFydCA/PyAwLCBvID0gZS5zZWxlY3Rpb25FbmQgPz8gYSwgcyA9IGEgPT09IG8gPyByIDogaS5zbGljZShhLCBvKSwgYyA9IGAke3R9JHtzfSR7bn1gO1xuXHRyZXR1cm4ge1xuXHRcdG5leHRWYWx1ZTogYCR7aS5zbGljZSgwLCBhKX0ke2N9JHtpLnNsaWNlKG8pfWAsXG5cdFx0bmV4dFN0YXJ0OiBhICsgdC5sZW5ndGgsXG5cdFx0bmV4dEVuZDogYSArIHQubGVuZ3RoICsgcy5sZW5ndGhcblx0fTtcbn1cbmZ1bmN0aW9uIEkoZSkge1xuXHRsZXQgdCA9IGUudmFsdWUsIG4gPSBlLnNlbGVjdGlvblN0YXJ0ID8/IDAsIHIgPSBlLnNlbGVjdGlvbkVuZCA/PyBuLCBpID0gbiA9PT0gciA/IFwibGluayB0ZXh0XCIgOiB0LnNsaWNlKG4sIHIpLCBhID0gYFske2l9XShodHRwczovL2V4YW1wbGUuY29tKWA7XG5cdHJldHVybiB7XG5cdFx0bmV4dFZhbHVlOiBgJHt0LnNsaWNlKDAsIG4pfSR7YX0ke3Quc2xpY2Uocil9YCxcblx0XHRuZXh0U3RhcnQ6IG4gKyBpLmxlbmd0aCArIDMsXG5cdFx0bmV4dEVuZDogbiArIGkubGVuZ3RoICsgMyArIDE5XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvTWFya2Rvd24udHN4XG5mdW5jdGlvbiBMKHsgbGFiZWw6IGUgPSBcIk1hcmtkb3duXCIsIGhlbHBlclRleHQ6IHQgPSBcIlVzZSB0aGUgdG9vbGJhciB0byBmb3JtYXQgbWFya2Rvd24gYW5kIHRvZ2dsZSBiZXR3ZWVuIGVkaXQgYW5kIHByZXZpZXcgbW9kZXMuXCIsIHBsYWNlaG9sZGVyOiBjID0gXCJXcml0ZSBtYXJrZG93biBoZXJlLi4uXCIsIHZhbHVlOiBsID0gXCJcIiwgZGlzYWJsZWQ6IGQgPSAhMSwgY2xhc3NOYW1lOiBwID0gXCJcIiwgZWRpdG9yQ2xhc3NOYW1lOiBoID0gXCJcIiwgdG9vbGJhckNsYXNzTmFtZTogXyA9IFwiXCIsIHByZXZpZXdDbGFzc05hbWU6IHkgPSBcIlwiLCBodG1sQ2xhc3NOYW1lOiB4ID0gXCJcIiwgaWQ6IEMsIHJvd3M6IFQgPSAxMiwgb25DaGFuZ2U6IEQsIG9uVG9vbGJhckFjdGlvbjogaywgLi4uQSB9KSB7XG5cdGxldCBqID0gcigpLCBOID0gQyA/PyBgbmFicy11aS1tYXJrZG93bi0ke2oucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBMID0gaShudWxsKSwgW1IsIHpdID0gYShsKSwgW0IsIFZdID0gYShcImVkaXRcIik7XG5cdG4oKCkgPT4ge1xuXHRcdHoobCk7XG5cdH0sIFtsXSk7XG5cdGxldCBIID0gTShSKSwgVSA9IFtcblx0XHRcIm5hYnMtdWktbWFya2Rvd25cIixcblx0XHRcIm5hYnMtdWktbWFya2Rvd24tLXNpbmdsZS1wYW5lbFwiLFxuXHRcdGQgPyBcIm5hYnMtdWktbWFya2Rvd24tLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdHBcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFcgPSBbXCJuYWJzLXVpLW1hcmtkb3duX190b29sYmFyXCIsIF9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgRyA9IFtcIm5hYnMtdWktbWFya2Rvd25fX2VkaXRvclwiLCBoXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEsgPSBbXCJuYWJzLXVpLW1hcmtkb3duX19wcmV2aWV3XCIsIHldLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgcSA9IFtcIm5hYnMtdWktbWFya2Rvd25fX2h0bWxcIiwgeF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBKID0gW1xuXHRcdHtcblx0XHRcdGlkOiBcIm1vZGUtdG9nZ2xlXCIsXG5cdFx0XHRpY29uOiB2LFxuXHRcdFx0dGl0bGU6IEIgPT09IFwiZWRpdFwiID8gXCJQcmV2aWV3XCIgOiBcIkVkaXRcIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwiaGVhZGluZ1wiLFxuXHRcdFx0aWNvbjogYixcblx0XHRcdHRpdGxlOiBcIkhlYWRpbmdcIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwiYm9sZFwiLFxuXHRcdFx0aWNvbjogZyxcblx0XHRcdHRpdGxlOiBcIkJvbGRcIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwiaXRhbGljXCIsXG5cdFx0XHRpY29uOiBFLFxuXHRcdFx0dGl0bGU6IFwiSXRhbGljXCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcInF1b3RlXCIsXG5cdFx0XHRpY29uOiBmLFxuXHRcdFx0dGl0bGU6IFwiUXVvdGVcIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwiYnVsbGV0LWxpc3RcIixcblx0XHRcdGljb246IHcsXG5cdFx0XHR0aXRsZTogXCJCdWxsZXQgbGlzdFwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJudW1iZXJlZC1saXN0XCIsXG5cdFx0XHRpY29uOiBPLFxuXHRcdFx0dGl0bGU6IFwiTnVtYmVyZWQgbGlzdFwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJjb2RlXCIsXG5cdFx0XHRpY29uOiBtLFxuXHRcdFx0dGl0bGU6IFwiQ29kZVwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJsaW5rXCIsXG5cdFx0XHRpY29uOiBTLFxuXHRcdFx0dGl0bGU6IFwiTGlua1wiXG5cdFx0fVxuXHRdLCBZID0gKGUsIHQpID0+IHtcblx0XHRpZiAoZCkgcmV0dXJuO1xuXHRcdGxldCBuID0gTC5jdXJyZW50O1xuXHRcdGlmICghbikgcmV0dXJuO1xuXHRcdGxldCByID0gdChuKTtcblx0XHRyICYmIChuLnZhbHVlID0gci5uZXh0VmFsdWUsIG4uc2V0U2VsZWN0aW9uUmFuZ2Uoci5uZXh0U3RhcnQsIHIubmV4dEVuZCksIHooci5uZXh0VmFsdWUpLCBEPy4oci5uZXh0VmFsdWUpLCBrPy4oZSkpO1xuXHR9LCBYID0gKGUpID0+IHtcblx0XHRsZXQgdCA9IGUuY3VycmVudFRhcmdldC52YWx1ZTtcblx0XHR6KHQpLCBEPy4odCk7XG5cdH0sIFogPSAoZSkgPT4ge1xuXHRcdGlmIChlID09PSBcIm1vZGUtdG9nZ2xlXCIpIHtcblx0XHRcdGxldCBlID0gQiA9PT0gXCJlZGl0XCIgPyBcInByZXZpZXdcIiA6IFwiZWRpdFwiO1xuXHRcdFx0VihlKSwgaz8uKGBtb2RlLSR7ZX1gKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0c3dpdGNoIChlKSB7XG5cdFx0XHRjYXNlIFwiaGVhZGluZ1wiOlxuXHRcdFx0XHRZKFwiaGVhZGluZ1wiLCAoZSkgPT4gUChlLCBcIiMgXCIsIFwiSGVhZGluZ1wiKSk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSBcImJvbGRcIjpcblx0XHRcdFx0WShcImJvbGRcIiwgKGUpID0+IEYoZSwgXCIqKlwiLCBcIioqXCIsIFwiYm9sZCB0ZXh0XCIpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIFwiaXRhbGljXCI6XG5cdFx0XHRcdFkoXCJpdGFsaWNcIiwgKGUpID0+IEYoZSwgXCIqXCIsIFwiKlwiLCBcIml0YWxpYyB0ZXh0XCIpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIFwicXVvdGVcIjpcblx0XHRcdFx0WShcInF1b3RlXCIsIChlKSA9PiBQKGUsIFwiPiBcIiwgXCJRdW90ZVwiKSk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSBcImJ1bGxldC1saXN0XCI6XG5cdFx0XHRcdFkoXCJidWxsZXQtbGlzdFwiLCAoZSkgPT4gUChlLCBcIi0gXCIsIFwiTGlzdCBpdGVtXCIpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIFwibnVtYmVyZWQtbGlzdFwiOlxuXHRcdFx0XHRZKFwibnVtYmVyZWQtbGlzdFwiLCAoZSkgPT4gUChlLCBcIjEuIFwiLCBcIkxpc3QgaXRlbVwiKSk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSBcImNvZGVcIjpcblx0XHRcdFx0WShcImNvZGVcIiwgKGUpID0+IEYoZSwgXCJgXCIsIFwiYFwiLCBcImNvZGVcIikpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgXCJsaW5rXCI6XG5cdFx0XHRcdFkoXCJsaW5rXCIsIEkpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGRlZmF1bHQ6IGJyZWFrO1xuXHRcdH1cblx0fTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IFUsXG5cdFx0Li4uQSxcblx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLW1hcmtkb3duX19lZGl0b3JQYW5lbFwiLFxuXHRcdFx0Y2hpbGRyZW46IFtcblx0XHRcdFx0LyogQF9fUFVSRV9fICovIG8oXCJsYWJlbFwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktbWFya2Rvd25fX2xhYmVsXCIsXG5cdFx0XHRcdFx0aHRtbEZvcjogTixcblx0XHRcdFx0XHRjaGlsZHJlbjogZVxuXHRcdFx0XHR9KSxcblx0XHRcdFx0dCA/IC8qIEBfX1BVUkVfXyAqLyBvKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1tYXJrZG93bl9faGVscGVyXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IHRcblx0XHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gbyh1LCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBXLFxuXHRcdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBcIk1hcmtkb3duIGZvcm1hdHRpbmcgdG9vbGJhclwiLFxuXHRcdFx0XHRcdGl0ZW1zOiBKLm1hcCgoZSkgPT4ge1xuXHRcdFx0XHRcdFx0bGV0IHQgPSBlLmlkID09PSBcIm1vZGUtdG9nZ2xlXCI7XG5cdFx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0XHQuLi5lLFxuXHRcdFx0XHRcdFx0XHRsYWJlbDogdCA/IEIgPT09IFwiZWRpdFwiID8gXCJQcmV2aWV3XCIgOiBcIkVkaXRcIiA6IHZvaWQgMCxcblx0XHRcdFx0XHRcdFx0ZGlzYWJsZWQ6IGQgfHwgIXQgJiYgQiA9PT0gXCJwcmV2aWV3XCIsXG5cdFx0XHRcdFx0XHRcdHByZXNzZWQ6IHQgPyBCID09PSBcInByZXZpZXdcIiA6IHZvaWQgMFxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRvbk1vdXNlRG93bjogKGUpID0+IHtcblx0XHRcdFx0XHRcdGUudGFyZ2V0Py5jbG9zZXN0KFwiYnV0dG9uXCIpICYmIGUucHJldmVudERlZmF1bHQoKTtcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdG9uSXRlbVNlbGVjdDogKHsgaXRlbUlkOiBlIH0pID0+IFooZSlcblx0XHRcdFx0fSksXG5cdFx0XHRcdEIgPT09IFwiZWRpdFwiID8gLyogQF9fUFVSRV9fICovIG8oXCJ0ZXh0YXJlYVwiLCB7XG5cdFx0XHRcdFx0aWQ6IE4sXG5cdFx0XHRcdFx0cmVmOiBMLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogRyxcblx0XHRcdFx0XHRyb3dzOiBULFxuXHRcdFx0XHRcdHBsYWNlaG9sZGVyOiBjLFxuXHRcdFx0XHRcdHZhbHVlOiBSLFxuXHRcdFx0XHRcdGRpc2FibGVkOiBkLFxuXHRcdFx0XHRcdG9uQ2hhbmdlOiBYXG5cdFx0XHRcdH0pIDogbnVsbFxuXHRcdFx0XVxuXHRcdH0pLCBCID09PSBcInByZXZpZXdcIiA/IC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLW1hcmtkb3duX19wcmV2aWV3UGFuZWxcIixcblx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1tYXJrZG93bl9fcHJldmlld0xhYmVsXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBcIlJlbmRlcmVkIHByZXZpZXdcIlxuXHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBvKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBLLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogcSxcblx0XHRcdFx0XHRkYW5nZXJvdXNseVNldElubmVySFRNTDogeyBfX2h0bWw6IEggfHwgXCI8cD5QcmV2aWV3IGFwcGVhcnMgaGVyZS48L3A+XCIgfVxuXHRcdFx0XHR9KVxuXHRcdFx0fSldXG5cdFx0fSkgOiBudWxsXVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTCBhcyBNYXJrZG93biB9O1xuIiwiaW1wb3J0IHsgdXNlRWZmZWN0IGFzIGUsIHVzZU1lbW8gYXMgdCwgdXNlU3RhdGUgYXMgbiB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIHIgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvbmF2aWdhdGlvbi51dGlscy50c1xudmFyIGkgPSB7XG5cdHZlcnRpY2FsOiBcIm5hYnMtdWktbmF2aWdhdGlvbi0tdmVydGljYWxcIixcblx0aG9yaXpvbnRhbDogXCJuYWJzLXVpLW5hdmlnYXRpb24tLWhvcml6b250YWxcIlxufTtcbmZ1bmN0aW9uIGEoZSkge1xuXHRyZXR1cm4gW1xuXHRcdFwibmFicy11aS1uYXZpZ2F0aW9uX19pdGVtQ29udGVudFwiLFxuXHRcdGUgPT09IFwiY2VudGVyXCIgPyBcIm5hYnMtdWktbmF2aWdhdGlvbl9faXRlbUNvbnRlbnQtLWNlbnRlclwiIDogXCJcIixcblx0XHRlID09PSBcInJpZ2h0XCIgPyBcIm5hYnMtdWktbmF2aWdhdGlvbl9faXRlbUNvbnRlbnQtLXJpZ2h0XCIgOiBcIlwiXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL05hdmlnYXRpb24udHN4XG5mdW5jdGlvbiBvKGUpIHtcblx0bGV0IHQgPSBlLnRyaW0oKTtcblx0aWYgKCF0KSByZXR1cm4gXCIvXCI7XG5cdGxldCBbbl0gPSB0LnNwbGl0KC9bPyNdLywgMSk7XG5cdGlmICghbiB8fCBuID09PSBcIi9cIikgcmV0dXJuIFwiL1wiO1xuXHRsZXQgciA9IG4uc3RhcnRzV2l0aChcIi9cIikgPyBuIDogYC8ke259YDtcblx0cmV0dXJuIHIubGVuZ3RoID4gMSAmJiByLmVuZHNXaXRoKFwiL1wiKSA/IHIuc2xpY2UoMCwgLTEpIDogcjtcbn1cbmZ1bmN0aW9uIHMoZSkge1xuXHRpZiAoXCJwYXRoXCIgaW4gZSkgcmV0dXJuIGUucGF0aDtcbn1cbmZ1bmN0aW9uIGMoZSkge1xuXHRpZiAoXCJwYXRoXCIgaW4gZSkgcmV0dXJuIGUucGF0aDtcblx0aWYgKFwiaHJlZlwiIGluIGUpIHJldHVybiBlLmhyZWY7XG59XG5mdW5jdGlvbiBsKGUpIHtcblx0cmV0dXJuIGUuYnV0dG9uID09PSAwICYmICFlLm1ldGFLZXkgJiYgIWUuY3RybEtleSAmJiAhZS5zaGlmdEtleSAmJiAhZS5hbHRLZXk7XG59XG5mdW5jdGlvbiB1KHsgaXRlbTogZSwgYWN0aXZlSXRlbUlkOiB0LCB0ZXh0QWxpZ25tZW50OiBuLCBpdGVtQ2xhc3NOYW1lOiBpLCBvbkl0ZW1TZWxlY3Q6IHUsIG9uUGF0aE5hdmlnYXRlOiBkIH0pIHtcblx0bGV0IGYgPSBbXG5cdFx0XCJuYWJzLXVpLW5hdmlnYXRpb25fX2l0ZW1cIixcblx0XHRlLmlkID09PSB0ID8gXCJuYWJzLXVpLW5hdmlnYXRpb25fX2l0ZW0tLWFjdGl2ZVwiIDogXCJcIixcblx0XHRlLmRpc2FibGVkID8gXCJuYWJzLXVpLW5hdmlnYXRpb25fX2l0ZW0tLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdGlcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIHAgPSAodCkgPT4ge1xuXHRcdGlmIChlLmRpc2FibGVkKSB7XG5cdFx0XHR0LnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmICh1Py4oZS5pZCwgZSwgdCksIHQuZGVmYXVsdFByZXZlbnRlZCkgcmV0dXJuO1xuXHRcdGxldCBuID0gcyhlKTtcblx0XHQhbiB8fCB0eXBlb2Ygd2luZG93ID4gXCJ1XCIgfHwgbCh0KSAmJiAodC5wcmV2ZW50RGVmYXVsdCgpLCB3aW5kb3cuaGlzdG9yeS5wdXNoU3RhdGUoe30sIFwiXCIsIG4pLCBkPy4obyhuKSkpO1xuXHR9LCBtID0gYyhlKTtcblx0cmV0dXJuIG0gPyAvKiBAX19QVVJFX18gKi8gcihcImxpXCIsIHsgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyByKFwiYVwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBmLFxuXHRcdGhyZWY6IG0sXG5cdFx0XCJhcmlhLWN1cnJlbnRcIjogZS5pZCA9PT0gdCA/IFwicGFnZVwiIDogdm9pZCAwLFxuXHRcdG9uQ2xpY2s6IHAsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyByKFwic3BhblwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IGEobiksXG5cdFx0XHRjaGlsZHJlbjogZS5sYWJlbFxuXHRcdH0pXG5cdH0pIH0pIDogLyogQF9fUFVSRV9fICovIHIoXCJsaVwiLCB7IGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gcihcImJ1dHRvblwiLCB7XG5cdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRjbGFzc05hbWU6IGYsXG5cdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XCJhcmlhLWN1cnJlbnRcIjogZS5pZCA9PT0gdCA/IFwicGFnZVwiIDogdm9pZCAwLFxuXHRcdG9uQ2xpY2s6IHAsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyByKFwic3BhblwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IGEobiksXG5cdFx0XHRjaGlsZHJlbjogZS5sYWJlbFxuXHRcdH0pXG5cdH0pIH0pO1xufVxuZnVuY3Rpb24gZCh7IGl0ZW1zOiBhID0gW10sIGRpcmVjdGlvbjogYyA9IFwidmVydGljYWxcIiwgdGV4dEFsaWdubWVudDogbCA9IFwibGVmdFwiLCBhY3RpdmVJdGVtSWQ6IGQsIHN5bmNBY3RpdmVQYXRoOiBmID0gITAsIGNsYXNzTmFtZTogcCA9IFwiXCIsIGl0ZW1DbGFzc05hbWU6IG0gPSBcIlwiLCBvbkl0ZW1TZWxlY3Q6IGgsIC4uLmcgfSkge1xuXHRsZXQgXyA9IFtcblx0XHRcIm5hYnMtdWktbmF2aWdhdGlvblwiLFxuXHRcdGlbY10gPz8gaS52ZXJ0aWNhbCxcblx0XHRwXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBbdiwgeV0gPSBuKCgpID0+IHR5cGVvZiB3aW5kb3cgPiBcInVcIiA/IFwiL1wiIDogbyh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUpKTtcblx0ZSgoKSA9PiB7XG5cdFx0aWYgKCFmIHx8IHR5cGVvZiB3aW5kb3cgPiBcInVcIikgcmV0dXJuO1xuXHRcdGxldCBlID0gKCkgPT4ge1xuXHRcdFx0eShvKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSkpO1xuXHRcdH07XG5cdFx0cmV0dXJuIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicG9wc3RhdGVcIiwgZSksICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9wc3RhdGVcIiwgZSk7XG5cdH0sIFtmXSk7XG5cdGxldCBiID0gdCgoKSA9PiB7XG5cdFx0aWYgKGYpIHJldHVybiBhLmZpbmQoKGUpID0+IHtcblx0XHRcdGxldCB0ID0gcyhlKTtcblx0XHRcdHJldHVybiB0ID8gbyh0KSA9PT0gdiA6ICExO1xuXHRcdH0pPy5pZDtcblx0fSwgW1xuXHRcdGEsXG5cdFx0dixcblx0XHRmXG5cdF0pLCB4ID0gZCA/PyBiO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHIoXCJuYXZcIiwge1xuXHRcdGNsYXNzTmFtZTogXyxcblx0XHQuLi5nLFxuXHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gcihcInVsXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLW5hdmlnYXRpb25fX2xpc3RcIixcblx0XHRcdGNoaWxkcmVuOiBhLm1hcCgoZSkgPT4gLyogQF9fUFVSRV9fICovIHIodSwge1xuXHRcdFx0XHRpdGVtOiBlLFxuXHRcdFx0XHRhY3RpdmVJdGVtSWQ6IHgsXG5cdFx0XHRcdHRleHRBbGlnbm1lbnQ6IGwsXG5cdFx0XHRcdGl0ZW1DbGFzc05hbWU6IG0sXG5cdFx0XHRcdG9uSXRlbVNlbGVjdDogaCxcblx0XHRcdFx0b25QYXRoTmF2aWdhdGU6IHlcblx0XHRcdH0sIGUuaWQpKVxuXHRcdH0pXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkIGFzIE5hdmlnYXRpb24gfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIHQsIGpzeHMgYXMgbiB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9QYW5lbC50c3hcbnZhciByID0gZSgoeyBoZWFkZXI6IGUgPSBcIlBhbmVsXCIsIGZvb3Rlcjogciwgc2hvd0hlYWRlcjogaSA9ICEwLCBzaG93Rm9vdGVyOiBhID0gITEsIGNoaWxkcmVuOiBvLCBjbGFzc05hbWU6IHMgPSBcIlwiLCBoZWFkZXJDbGFzc05hbWU6IGMgPSBcIlwiLCBjb250ZW50Q2xhc3NOYW1lOiBsID0gXCJcIiwgZm9vdGVyQ2xhc3NOYW1lOiB1ID0gXCJcIiwgLi4uZCB9LCBmKSA9PiB7XG5cdGxldCBwID0gW1wibmFicy11aS1wYW5lbFwiLCBzXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIG0gPSBbXCJuYWJzLXVpLXBhbmVsX19oZWFkZXJcIiwgY10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBoID0gW1wibmFicy11aS1wYW5lbF9fY29udGVudFwiLCBsXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGcgPSBbXCJuYWJzLXVpLXBhbmVsX19mb290ZXJcIiwgdV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG4oXCJzZWN0aW9uXCIsIHtcblx0XHRyZWY6IGYsXG5cdFx0Y2xhc3NOYW1lOiBwLFxuXHRcdC4uLmQsXG5cdFx0Y2hpbGRyZW46IFtcblx0XHRcdGkgPyAvKiBAX19QVVJFX18gKi8gdChcImhlYWRlclwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogbSxcblx0XHRcdFx0Y2hpbGRyZW46IGVcblx0XHRcdH0pIDogbnVsbCxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyB0KFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdFx0XHRjaGlsZHJlbjogb1xuXHRcdFx0fSksXG5cdFx0XHRhID8gLyogQF9fUFVSRV9fICovIHQoXCJmb290ZXJcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IGcsXG5cdFx0XHRcdGNoaWxkcmVuOiByXG5cdFx0XHR9KSA6IG51bGxcblx0XHRdXG5cdH0pO1xufSk7XG5yLmRpc3BsYXlOYW1lID0gXCJQYW5lbFwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyByIGFzIFBhbmVsIH07XG4iLCJpbXBvcnQgeyB1c2VJZCBhcyBlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgdCwganN4cyBhcyBuIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL3JhZGlvYnV0dG9uLnV0aWxzLnRzXG52YXIgciA9IHtcblx0cmlnaHQ6IFwibmFicy11aS1yYWRpb2J1dHRvbi0tbGFiZWwtcmlnaHRcIixcblx0bGVmdDogXCJuYWJzLXVpLXJhZGlvYnV0dG9uLS1sYWJlbC1sZWZ0XCIsXG5cdHRvcDogXCJuYWJzLXVpLXJhZGlvYnV0dG9uLS1sYWJlbC10b3BcIixcblx0Ym90dG9tOiBcIm5hYnMtdWktcmFkaW9idXR0b24tLWxhYmVsLWJvdHRvbVwiXG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL1JhZGlvQnV0dG9uLnRzeFxuZnVuY3Rpb24gaSh7IGxhYmVsOiBpID0gXCJSYWRpbyBidXR0b25cIiwgbGFiZWxQb3NpdGlvbjogYSA9IFwicmlnaHRcIiwgY2xhc3NOYW1lOiBvID0gXCJcIiwgaW5wdXRDbGFzc05hbWU6IHMgPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogYyA9IFwiXCIsIGlkOiBsLCAuLi51IH0pIHtcblx0bGV0IGQgPSB1LmRpc2FibGVkID09PSAhMCwgZiA9IGUoKSwgcCA9IGwgPz8gYG5hYnMtdWktcmFkaW9idXR0b24tJHtmLnJlcGxhY2UoLzovZywgXCJcIil9YCwgbSA9IFtcblx0XHRcIm5hYnMtdWktcmFkaW9idXR0b25cIixcblx0XHRkID8gXCJuYWJzLXVpLXJhZGlvYnV0dG9uLS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRyW2FdID8/IHIucmlnaHQsXG5cdFx0b1xuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaCA9IFtcIm5hYnMtdWktcmFkaW9idXR0b25fX2lucHV0XCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktcmFkaW9idXR0b25fX2xhYmVsXCIsIGNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBuKFwibGFiZWxcIiwge1xuXHRcdGNsYXNzTmFtZTogbSxcblx0XHRodG1sRm9yOiBwLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHQoXCJpbnB1dFwiLCB7XG5cdFx0XHRpZDogcCxcblx0XHRcdGNsYXNzTmFtZTogaCxcblx0XHRcdHR5cGU6IFwicmFkaW9cIixcblx0XHRcdC4uLnVcblx0XHR9KSwgLyogQF9fUFVSRV9fICovIHQoXCJzcGFuXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogZyxcblx0XHRcdGNoaWxkcmVuOiBpXG5cdFx0fSldXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpIGFzIFJhZGlvQnV0dG9uIH07XG4iLCJpbXBvcnQgeyB1c2VFZmZlY3QgYXMgZSwgdXNlSWQgYXMgdCwgdXNlUmVmIGFzIG4sIHVzZVN0YXRlIGFzIHIgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBpLCBqc3hzIGFzIGEgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvc2lnbmF0dXJlLnV0aWxzLnRzXG5mdW5jdGlvbiBvKGUsIHQpIHtcblx0bGV0IG4gPSB0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRyZXR1cm4ge1xuXHRcdHg6IGUuY2xpZW50WCAtIG4ubGVmdCxcblx0XHR5OiBlLmNsaWVudFkgLSBuLnRvcFxuXHR9O1xufVxuZnVuY3Rpb24gcyhlLCB0KSB7XG5cdGlmICh0Lmxlbmd0aCAhPT0gMCkge1xuXHRcdGUuYmVnaW5QYXRoKCksIGUubW92ZVRvKHRbMF0ueCwgdFswXS55KTtcblx0XHRmb3IgKGxldCBuID0gMTsgbiA8IHQubGVuZ3RoOyBuICs9IDEpIGUubGluZVRvKHRbbl0ueCwgdFtuXS55KTtcblx0XHRlLnN0cm9rZSgpO1xuXHR9XG59XG5mdW5jdGlvbiBjKGUsIHQsIG4pIHtcblx0ZS5maWxsU3R5bGUgPSBuLCBlLmZpbGxSZWN0KDAsIDAsIHQud2lkdGgsIHQuaGVpZ2h0KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9TaWduYXR1cmUudHN4XG5mdW5jdGlvbiBsKHsgbGFiZWw6IGwgPSBcIlNpZ25hdHVyZVwiLCBoZWxwZXJUZXh0OiB1ID0gXCJVc2UgeW91ciBtb3VzZSB0byBkcmF3IHlvdXIgc2lnbmF0dXJlLlwiLCB2YWx1ZTogZCA9IFwiXCIsIGRpc2FibGVkOiBmID0gITEsIGNsYXNzTmFtZTogcCA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBtID0gXCJcIiwgaGVscGVyVGV4dENsYXNzTmFtZTogaCA9IFwiXCIsIHBhZENsYXNzTmFtZTogZyA9IFwiXCIsIGNhbnZhc0NsYXNzTmFtZTogXyA9IFwiXCIsIGlkOiB2LCB3aWR0aDogeSA9IDcyMCwgaGVpZ2h0OiBiID0gMjQwLCBiYWNrZ3JvdW5kQ29sb3I6IHggPSBcIiNmZmZmZmZcIiwgcGVuQ29sb3I6IFMgPSBcIiMwZjE3MmFcIiwgcGVuV2lkdGg6IEMgPSAyLjUsIG9uQ2hhbmdlOiB3LCBvbkJlZ2luU3Ryb2tlOiBULCBvbkVuZFN0cm9rZTogRSwgb25DbGVhcjogRCB9KSB7XG5cdGxldCBPID0gdCgpLCBrID0gdiA/PyBgbmFicy11aS1zaWduYXR1cmUtJHtPLnJlcGxhY2UoLzovZywgXCJcIil9YCwgQSA9IG4obnVsbCksIGogPSBuKG51bGwpLCBNID0gbighMSksIE4gPSBuKFtdKSwgW1AsIEZdID0gcighZCksIEkgPSBbXG5cdFx0XCJuYWJzLXVpLXNpZ25hdHVyZVwiLFxuXHRcdGYgPyBcIm5hYnMtdWktc2lnbmF0dXJlLS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRwXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBMID0gW1wibmFicy11aS1zaWduYXR1cmVfX2xhYmVsXCIsIG1dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgUiA9IFtcIm5hYnMtdWktc2lnbmF0dXJlX19oZWxwZXJcIiwgaF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCB6ID0gW1wibmFicy11aS1zaWduYXR1cmVfX3BhZFwiLCBnXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEIgPSBbXCJuYWJzLXVpLXNpZ25hdHVyZV9fY2FudmFzXCIsIF9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0ZSgoKSA9PiB7XG5cdFx0bGV0IGUgPSBBLmN1cnJlbnQ7XG5cdFx0aWYgKCFlKSByZXR1cm47XG5cdFx0bGV0IHQgPSBlLmdldENvbnRleHQoXCIyZFwiKTtcblx0XHRpZiAoIXQpIHJldHVybjtcblx0XHRsZXQgbiA9IHdpbmRvdy5kZXZpY2VQaXhlbFJhdGlvIHx8IDEsIHIgPSBNYXRoLnJvdW5kKHkpLCBpID0gTWF0aC5yb3VuZChiKTtcblx0XHRpZiAoZS53aWR0aCA9IE1hdGgucm91bmQociAqIG4pLCBlLmhlaWdodCA9IE1hdGgucm91bmQoaSAqIG4pLCBlLnN0eWxlLndpZHRoID0gYCR7cn1weGAsIGUuc3R5bGUuaGVpZ2h0ID0gYCR7aX1weGAsIGouY3VycmVudCA9IHQsIHQubGluZUNhcCA9IFwicm91bmRcIiwgdC5saW5lSm9pbiA9IFwicm91bmRcIiwgdC5saW5lV2lkdGggPSBDICogbiwgdC5zdHJva2VTdHlsZSA9IFMsIHQuc2NhbGUobiwgbiksIGModCwgZSwgeCksIGQpIHtcblx0XHRcdGxldCBlID0gbmV3IEltYWdlKCk7XG5cdFx0XHRlLm9ubG9hZCA9ICgpID0+IHtcblx0XHRcdFx0dC5jbGVhclJlY3QoMCwgMCwgciwgaSksIHQuZmlsbFN0eWxlID0geCwgdC5maWxsUmVjdCgwLCAwLCByLCBpKSwgdC5kcmF3SW1hZ2UoZSwgMCwgMCwgciwgaSksIEYoITEpO1xuXHRcdFx0fSwgZS5zcmMgPSBkO1xuXHRcdH1cblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0ai5jdXJyZW50ID0gbnVsbDtcblx0XHR9O1xuXHR9LCBbXG5cdFx0eCxcblx0XHRTLFxuXHRcdEMsXG5cdFx0ZCxcblx0XHR5LFxuXHRcdGJcblx0XSk7XG5cdGxldCBWID0gKGUpID0+IHtcblx0XHR3Py4oZS50b0RhdGFVUkwoXCJpbWFnZS9wbmdcIikpO1xuXHR9LCBIID0gKGUpID0+IHtcblx0XHRpZiAoZiB8fCBNLmN1cnJlbnQpIHJldHVybjtcblx0XHRsZXQgdCA9IEEuY3VycmVudCwgbiA9IGouY3VycmVudDtcblx0XHQhdCB8fCAhbiB8fCAoXCJwb2ludGVySWRcIiBpbiBlICYmIHR5cGVvZiBlLnBvaW50ZXJJZCA9PSBcIm51bWJlclwiICYmIHQuc2V0UG9pbnRlckNhcHR1cmUgJiYgdC5zZXRQb2ludGVyQ2FwdHVyZShlLnBvaW50ZXJJZCksIE0uY3VycmVudCA9ICEwLCBOLmN1cnJlbnQgPSBbbyhlLCB0KV0sIG4uYmVnaW5QYXRoKCksIG4ubW92ZVRvKE4uY3VycmVudFswXS54LCBOLmN1cnJlbnRbMF0ueSksIFQ/LigpKTtcblx0fSwgVSA9IChlKSA9PiB7XG5cdFx0aWYgKGYgfHwgIU0uY3VycmVudCkgcmV0dXJuO1xuXHRcdGxldCB0ID0gQS5jdXJyZW50LCBuID0gai5jdXJyZW50O1xuXHRcdGlmICghdCB8fCAhbikgcmV0dXJuO1xuXHRcdGxldCByID0gbyhlLCB0KTtcblx0XHROLmN1cnJlbnQucHVzaChyKSwgbi5saW5lVG8oci54LCByLnkpLCBuLnN0cm9rZSgpLCBGKCExKTtcblx0fSwgVyA9IChlKSA9PiB7XG5cdFx0bGV0IHQgPSBBLmN1cnJlbnQsIG4gPSBqLmN1cnJlbnQ7XG5cdFx0aWYgKCEoIXQgfHwgIW4gfHwgIU0uY3VycmVudCkpIHtcblx0XHRcdGlmIChlICYmIFwicG9pbnRlcklkXCIgaW4gZSAmJiB0eXBlb2YgZS5wb2ludGVySWQgPT0gXCJudW1iZXJcIiAmJiB0LnJlbGVhc2VQb2ludGVyQ2FwdHVyZSkgdHJ5IHtcblx0XHRcdFx0dC5yZWxlYXNlUG9pbnRlckNhcHR1cmUoZS5wb2ludGVySWQpO1xuXHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0TS5jdXJyZW50ID0gITEsIHMobiwgTi5jdXJyZW50KSwgTi5jdXJyZW50ID0gW10sIFYodCksIEU/LigpO1xuXHRcdH1cblx0fTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBhKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IEksXG5cdFx0Y2hpbGRyZW46IFtcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBMLFxuXHRcdFx0XHRpZDogYCR7a30tbGFiZWxgLFxuXHRcdFx0XHRjaGlsZHJlbjogbFxuXHRcdFx0fSksXG5cdFx0XHR1ID8gLyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFIsXG5cdFx0XHRcdGNoaWxkcmVuOiB1XG5cdFx0XHR9KSA6IG51bGwsXG5cdFx0XHQvKiBAX19QVVJFX18gKi8gYShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogeixcblx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gaShcImNhbnZhc1wiLCB7XG5cdFx0XHRcdFx0aWQ6IGssXG5cdFx0XHRcdFx0cmVmOiBBLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogQixcblx0XHRcdFx0XHRyb2xlOiBcImltZ1wiLFxuXHRcdFx0XHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IGAke2t9LWxhYmVsYCxcblx0XHRcdFx0XHRcImFyaWEtbGFiZWxcIjogbCxcblx0XHRcdFx0XHRvblBvaW50ZXJEb3duOiBILFxuXHRcdFx0XHRcdG9uUG9pbnRlck1vdmU6IFUsXG5cdFx0XHRcdFx0b25Qb2ludGVyVXA6IFcsXG5cdFx0XHRcdFx0b25Qb2ludGVyQ2FuY2VsOiBXLFxuXHRcdFx0XHRcdG9uUG9pbnRlckxlYXZlOiBXLFxuXHRcdFx0XHRcdG9uTW91c2VEb3duOiBILFxuXHRcdFx0XHRcdG9uTW91c2VNb3ZlOiBVLFxuXHRcdFx0XHRcdG9uTW91c2VVcDogVyxcblx0XHRcdFx0XHRvbk1vdXNlTGVhdmU6IFdcblx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1zaWduYXR1cmVfX3BsYWNlaG9sZGVyXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogUCA/IFwiRHJhdyBoZXJlXCIgOiBudWxsXG5cdFx0XHRcdH0pXVxuXHRcdFx0fSksXG5cdFx0XHQvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLXNpZ25hdHVyZV9fYWN0aW9uc1wiLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGkoXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktc2lnbmF0dXJlX19jbGVhckJ1dHRvblwiLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IHtcblx0XHRcdFx0XHRcdGxldCBlID0gQS5jdXJyZW50LCB0ID0gai5jdXJyZW50O1xuXHRcdFx0XHRcdFx0IWUgfHwgIXQgfHwgKHQuY2xlYXJSZWN0KDAsIDAsIGUud2lkdGgsIGUuaGVpZ2h0KSwgYyh0LCBlLCB4KSwgRighMCksIHc/LihcIlwiKSwgRD8uKCkpO1xuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0ZGlzYWJsZWQ6IGYgfHwgUCxcblx0XHRcdFx0XHRjaGlsZHJlbjogXCJDbGVhclwiXG5cdFx0XHRcdH0pXG5cdFx0XHR9KVxuXHRcdF1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGwgYXMgU2lnbmF0dXJlIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUlkIGFzIHQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBuLCBqc3hzIGFzIHIgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvU2xpZGVyLnRzeFxudmFyIGkgPSBlKCh7IGxhYmVsOiBlID0gXCJTbGlkZXJcIiwgdmFsdWU6IGkgPSAwLCBtaW46IGEgPSAwLCBtYXg6IG8gPSAxMDAsIHN0ZXA6IHMgPSAxLCBkaXNhYmxlZDogYyA9ICExLCBjbGFzc05hbWU6IGwgPSBcIlwiLCBpbnB1dENsYXNzTmFtZTogdSA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBkID0gXCJcIiwgdmFsdWVDbGFzc05hbWU6IGYgPSBcIlwiLCBpZDogcCwgb25DaGFuZ2U6IG0sIC4uLmggfSwgZykgPT4ge1xuXHRsZXQgXyA9IHQoKSwgdiA9IHAgPz8gYG5hYnMtdWktc2xpZGVyLSR7Xy5yZXBsYWNlKC86L2csIFwiXCIpfWAsIHkgPSBbXG5cdFx0XCJuYWJzLXVpLXNsaWRlclwiLFxuXHRcdGMgPyBcIm5hYnMtdWktc2xpZGVyLS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRsXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBiID0gW1wibmFicy11aS1zbGlkZXJfX2lucHV0XCIsIHVdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgeCA9IFtcIm5hYnMtdWktc2xpZGVyX19sYWJlbFwiLCBkXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFMgPSBbXCJuYWJzLXVpLXNsaWRlcl9fdmFsdWVcIiwgZl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHIoXCJkaXZcIiwge1xuXHRcdGNsYXNzTmFtZTogeSxcblx0XHRjaGlsZHJlbjogW1xuXHRcdFx0LyogQF9fUFVSRV9fICovIHIoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1zbGlkZXJfX2hlYWRlclwiLFxuXHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBuKFwibGFiZWxcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogeCxcblx0XHRcdFx0XHRodG1sRm9yOiB2LFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gbihcIm91dHB1dFwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBTLFxuXHRcdFx0XHRcdGh0bWxGb3I6IHYsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGlcblx0XHRcdFx0fSldXG5cdFx0XHR9KSxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyBuKFwiaW5wdXRcIiwge1xuXHRcdFx0XHRyZWY6IGcsXG5cdFx0XHRcdGlkOiB2LFxuXHRcdFx0XHRjbGFzc05hbWU6IGIsXG5cdFx0XHRcdHR5cGU6IFwicmFuZ2VcIixcblx0XHRcdFx0dmFsdWU6IGksXG5cdFx0XHRcdG1pbjogYSxcblx0XHRcdFx0bWF4OiBvLFxuXHRcdFx0XHRzdGVwOiBzLFxuXHRcdFx0XHRkaXNhYmxlZDogYyxcblx0XHRcdFx0b25DaGFuZ2U6IG0sXG5cdFx0XHRcdC4uLmhcblx0XHRcdH0pLFxuXHRcdFx0LyogQF9fUFVSRV9fICovIHIoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1zbGlkZXJfX3NjYWxlXCIsXG5cdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG4oXCJzcGFuXCIsIHsgY2hpbGRyZW46IGEgfSksIC8qIEBfX1BVUkVfXyAqLyBuKFwic3BhblwiLCB7IGNoaWxkcmVuOiBvIH0pXVxuXHRcdFx0fSlcblx0XHRdXG5cdH0pO1xufSk7XG5pLmRpc3BsYXlOYW1lID0gXCJTbGlkZXJcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaSBhcyBTbGlkZXIgfTtcbiIsImltcG9ydCB7IENoaWxkcmVuIGFzIGUsIGZvcndhcmRSZWYgYXMgdCwgaXNWYWxpZEVsZW1lbnQgYXMgbiwgdXNlTWVtbyBhcyByLCB1c2VTdGF0ZSBhcyBpIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBGcmFnbWVudCBhcyBhLCBqc3ggYXMgbywganN4cyBhcyBzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL3N0ZXBwZXIudXRpbHMudHNcbmZ1bmN0aW9uIGMoZSkge1xuXHRyZXR1cm4gZSA9PT0gXCJ0b3BcIiB8fCBlID09PSBcImJvdHRvbVwiID8gXCJob3Jpem9udGFsXCIgOiBcInZlcnRpY2FsXCI7XG59XG5mdW5jdGlvbiBsKGUsIHQpIHtcblx0cmV0dXJuIFtcblx0XHRcIm5hYnMtdWktc3RlcHBlclwiLFxuXHRcdGBuYWJzLXVpLXN0ZXBwZXItLSR7ZX1gLFxuXHRcdHRcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG59XG5mdW5jdGlvbiB1KGUpIHtcblx0cmV0dXJuIFtcIm5hYnMtdWktc3RlcHBlcl9fc3RlcHNcIiwgYG5hYnMtdWktc3RlcHBlcl9fc3RlcHMtLSR7ZX1gXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG59XG5mdW5jdGlvbiBkKGUpIHtcblx0cmV0dXJuIFtcIm5hYnMtdWktc3RlcHBlcl9fY29udGVudFwiLCBgbmFicy11aS1zdGVwcGVyX19jb250ZW50LS0ke2V9YF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xufVxuZnVuY3Rpb24gZih0KSB7XG5cdHJldHVybiBlLnRvQXJyYXkodCkuZmxhdE1hcCgoZSkgPT4ge1xuXHRcdGlmICghbihlKSkgcmV0dXJuIFtdO1xuXHRcdGxldCB0ID0gTnVtYmVyKGUucHJvcHMuaW5kZXgpO1xuXHRcdHJldHVybiBOdW1iZXIuaXNGaW5pdGUodCkgPyBbe1xuXHRcdFx0aW5kZXg6IHQsXG5cdFx0XHRsYWJlbDogZS5wcm9wcy5sYWJlbCA/PyBlLnByb3BzLmNoaWxkcmVuID8/IGBTdGVwICR7dH1gLFxuXHRcdFx0aWNvbjogZS5wcm9wcy5pY29uLFxuXHRcdFx0ZGlzYWJsZWQ6ICEhZS5wcm9wcy5kaXNhYmxlZFxuXHRcdH1dIDogW107XG5cdH0pLnNvcnQoKGUsIHQpID0+IGUuaW5kZXggLSB0LmluZGV4KTtcbn1cbmZ1bmN0aW9uIHAodCkge1xuXHRyZXR1cm4gZS50b0FycmF5KHQpLmZsYXRNYXAoKGUpID0+IHtcblx0XHRpZiAoIW4oZSkpIHJldHVybiBbXTtcblx0XHRsZXQgdCA9IE51bWJlcihlLnByb3BzLmluZGV4KTtcblx0XHRyZXR1cm4gTnVtYmVyLmlzRmluaXRlKHQpID8gW3tcblx0XHRcdGluZGV4OiB0LFxuXHRcdFx0Y29udGVudDogZS5wcm9wcy5jaGlsZHJlblxuXHRcdH1dIDogW107XG5cdH0pLnNvcnQoKGUsIHQpID0+IGUuaW5kZXggLSB0LmluZGV4KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9TdGVwcGVyLnRzeFxuZnVuY3Rpb24gbSh7IGNoaWxkcmVuOiBlIH0pIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBvKGEsIHsgY2hpbGRyZW46IGUgfSk7XG59XG5mdW5jdGlvbiBoKGUpIHtcblx0cmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBnKHsgY2hpbGRyZW46IGUgfSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG8oYSwgeyBjaGlsZHJlbjogZSB9KTtcbn1cbmZ1bmN0aW9uIF8oZSkge1xuXHRyZXR1cm4gbnVsbDtcbn1cbnZhciB2ID0gbSwgeSA9IGcsIGIgPSB0KCh7IGNoaWxkcmVuOiB0LCBjbGFzc05hbWU6IGEgPSBcIlwiLCBzdGVwc1Bvc2l0aW9uOiBtID0gXCJ0b3BcIiwgc3RlcHNBbGlnbm1lbnQ6IGggPSBcImxlZnRcIiwgc3RlcExhYmVsQWxpZ25tZW50OiBnID0gXCJyaWdodFwiLCBzaG93Q2VudGVyTGluZTogXyA9ICEwLCBhY3RpdmVJbmRleDogYiwgZGVmYXVsdEFjdGl2ZUluZGV4OiB4LCBvblN0ZXBDaGFuZ2U6IFMsIC4uLkMgfSwgdykgPT4ge1xuXHRsZXQgW1QsIEVdID0gaSh4KSwgeyBwYXJzZWRTdGVwczogRCwgcGFyc2VkQ29udGVudFN0ZXBzOiBPIH0gPSByKCgpID0+IHtcblx0XHRsZXQgciA9IGUudG9BcnJheSh0KSwgaSA9IHIuZmluZCgoZSkgPT4gbihlKSAmJiBlLnR5cGUgPT09IHYpLCBhID0gci5maW5kKChlKSA9PiBuKGUpICYmIGUudHlwZSA9PT0geSk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHBhcnNlZFN0ZXBzOiBmKGk/LnByb3BzLmNoaWxkcmVuKSxcblx0XHRcdHBhcnNlZENvbnRlbnRTdGVwczogcChhPy5wcm9wcy5jaGlsZHJlbilcblx0XHR9O1xuXHR9LCBbdF0pLCBrID0gRFswXT8uaW5kZXggPz8gT1swXT8uaW5kZXggPz8gMCwgQSA9IGIgPz8gVCA/PyBrLCBqID0gTy5maW5kKChlKSA9PiBlLmluZGV4ID09PSBBKSwgTSA9IGMobSksIE4gPSBbXG5cdFx0bChtLCBhKSxcblx0XHRgbmFicy11aS1zdGVwcGVyLS1sYWJlbC0ke2d9YCxcblx0XHRgbmFicy11aS1zdGVwcGVyLS1hbGlnbi0ke2h9YCxcblx0XHRfID8gXCJuYWJzLXVpLXN0ZXBwZXItLXdpdGgtY2VudGVyLWxpbmVcIiA6IFwibmFicy11aS1zdGVwcGVyLS13aXRob3V0LWNlbnRlci1saW5lXCJcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFAgPSB1KG0pLCBGID0gZChtKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwic2VjdGlvblwiLCB7XG5cdFx0cmVmOiB3LFxuXHRcdGNsYXNzTmFtZTogTixcblx0XHQuLi5DLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJuYXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBQLFxuXHRcdFx0cm9sZTogXCJ0YWJsaXN0XCIsXG5cdFx0XHRcImFyaWEtb3JpZW50YXRpb25cIjogTSxcblx0XHRcdGNoaWxkcmVuOiBELm1hcCgoZSkgPT4ge1xuXHRcdFx0XHRsZXQgdCA9IGUuaW5kZXggPT09IEE7XG5cdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0cm9sZTogXCJ0YWJcIixcblx0XHRcdFx0XHRcImFyaWEtc2VsZWN0ZWRcIjogdCxcblx0XHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogZS5kaXNhYmxlZCxcblx0XHRcdFx0XHR0YWJJbmRleDogZS5kaXNhYmxlZCA/IC0xIDogMCxcblx0XHRcdFx0XHRjbGFzc05hbWU6IFtcblx0XHRcdFx0XHRcdFwibmFicy11aS1zdGVwcGVyX19zdGVwXCIsXG5cdFx0XHRcdFx0XHR0ID8gXCJuYWJzLXVpLXN0ZXBwZXJfX3N0ZXAtLWFjdGl2ZVwiIDogXCJcIixcblx0XHRcdFx0XHRcdGUuZGlzYWJsZWQgPyBcIm5hYnMtdWktc3RlcHBlcl9fc3RlcC0tZGlzYWJsZWRcIiA6IFwiXCJcblx0XHRcdFx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHRcdFx0XHRvbkNsaWNrOiAodCkgPT4ge1xuXHRcdFx0XHRcdFx0ZS5kaXNhYmxlZCB8fCAoYiA9PT0gdm9pZCAwICYmIEUoZS5pbmRleCksIFM/LihlLmluZGV4LCB0KSk7XG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRjaGlsZHJlbjogW2UuaWNvbiA/IC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1zdGVwcGVyX19zdGVwSW5kaWNhdG9yc1wiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLXN0ZXBwZXJfX3N0ZXBJY29uXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmljb25cblx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0fSkgOiBudWxsLCAvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktc3RlcHBlcl9fc3RlcExhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5sYWJlbFxuXHRcdFx0XHRcdH0pXVxuXHRcdFx0XHR9LCBlLmluZGV4KTtcblx0XHRcdH0pXG5cdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBvKFwic2VjdGlvblwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IEYsXG5cdFx0XHRyb2xlOiBcInRhYnBhbmVsXCIsXG5cdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1zdGVwcGVyX19jb250ZW50SW5uZXJcIixcblx0XHRcdFx0Y2hpbGRyZW46IGo/LmNvbnRlbnQgPz8gbnVsbFxuXHRcdFx0fSlcblx0XHR9KV1cblx0fSk7XG59KTtcbmIuZGlzcGxheU5hbWUgPSBcIlN0ZXBwZXJcIiwgbS5kaXNwbGF5TmFtZSA9IFwiU3RlcHBlci5TdGVwc1wiLCBoLmRpc3BsYXlOYW1lID0gXCJTdGVwcGVyLlN0ZXBcIiwgZy5kaXNwbGF5TmFtZSA9IFwiU3RlcHBlci5Db250ZW50U3RlcHNcIiwgXy5kaXNwbGF5TmFtZSA9IFwiU3RlcHBlci5Db250ZW50U3RlcFwiLCBiLlN0ZXBzID0gbSwgYi5TdGVwID0gaCwgYi5Db250ZW50U3RlcHMgPSBnLCBiLkNvbnRlbnRTdGVwID0gXztcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYiBhcyBTdGVwcGVyIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyB0LCBqc3hzIGFzIG4gfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvVGFiLnRzeFxudmFyIHIgPSBlKCh7IGxhYmVsOiBlID0gXCJUYWJcIiwgY2hpbGRyZW46IHIsIHNob3dIZWFkZXI6IGkgPSAhMCwgY2xhc3NOYW1lOiBhID0gXCJcIiwgaGVhZGVyQ2xhc3NOYW1lOiBvID0gXCJcIiwgY29udGVudENsYXNzTmFtZTogcyA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBjID0gXCJcIiwgaWQ6IGwsIC4uLnUgfSwgZCkgPT4ge1xuXHRsZXQgZiA9IFtcIm5hYnMtdWktdGFiXCIsIGFdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgcCA9IFtcIm5hYnMtdWktdGFiX19oZWFkZXJcIiwgb10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBtID0gW1wibmFicy11aS10YWJfX2NvbnRlbnRcIiwgc10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBoID0gW1wibmFicy11aS10YWJfX2xhYmVsXCIsIGNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBuKFwic2VjdGlvblwiLCB7XG5cdFx0cmVmOiBkLFxuXHRcdGlkOiBsLFxuXHRcdGNsYXNzTmFtZTogZixcblx0XHQuLi51LFxuXHRcdGNoaWxkcmVuOiBbaSA/IC8qIEBfX1BVUkVfXyAqLyB0KFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogcCxcblx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gdChcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogaCxcblx0XHRcdFx0Y2hpbGRyZW46IGVcblx0XHRcdH0pXG5cdFx0fSkgOiBudWxsLCAvKiBAX19QVVJFX18gKi8gdChcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IG0sXG5cdFx0XHRjaGlsZHJlbjogclxuXHRcdH0pXVxuXHR9KTtcbn0pO1xuci5kaXNwbGF5TmFtZSA9IFwiVGFiXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHIgYXMgVGFiIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUlkIGFzIHQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBuLCBqc3hzIGFzIHIgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvVGV4dGFyZWEudHN4XG52YXIgaSA9IGUoKHsgbGFiZWw6IGUsIGNsYXNzTmFtZTogaSA9IFwiXCIsIGlucHV0Q2xhc3NOYW1lOiBhID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IG8gPSBcIlwiLCBpZDogcywgcm93czogYyA9IDQsIHJlc2l6ZTogbCA9IFwidmVydGljYWxcIiwgLi4udSB9LCBkKSA9PiB7XG5cdGxldCBmID0gdCgpLCBwID0gcyA/PyBgbmFicy11aS10ZXh0YXJlYS0ke2YucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBtID0gW1wibmFicy11aS10ZXh0YXJlYVwiLCBpXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGggPSBbXCJuYWJzLXVpLXRleHRhcmVhX19pbnB1dFwiLCBhXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGcgPSBbXCJuYWJzLXVpLXRleHRhcmVhX19sYWJlbFwiLCBvXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcihcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBtLFxuXHRcdGNoaWxkcmVuOiBbZSA/IC8qIEBfX1BVUkVfXyAqLyBuKFwibGFiZWxcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0aHRtbEZvcjogcCxcblx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0fSkgOiBudWxsLCAvKiBAX19QVVJFX18gKi8gbihcInRleHRhcmVhXCIsIHtcblx0XHRcdHJlZjogZCxcblx0XHRcdGlkOiBwLFxuXHRcdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdFx0cm93czogYyxcblx0XHRcdFwiZGF0YS1yZXNpemVcIjogbCxcblx0XHRcdC4uLnVcblx0XHR9KV1cblx0fSk7XG59KTtcbmkuZGlzcGxheU5hbWUgPSBcIlRleHRhcmVhXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGkgYXMgVGV4dGFyZWEgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSwgdXNlSWQgYXMgdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIG4sIGpzeHMgYXMgciB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy90ZXh0Ym94LnV0aWxzLnRzXG52YXIgaSA9IHtcblx0bm9uZTogXCJcIixcblx0dG9wOiBcIm5hYnMtdWktdGV4dGJveC0tbGFiZWwtdG9wXCIsXG5cdGxlZnQ6IFwibmFicy11aS10ZXh0Ym94LS1sYWJlbC1sZWZ0XCJcbn0sIGEgPSBlKCh7IGxhYmVsOiBlLCBsYWJlbFBvc2l0aW9uOiBhID0gXCJ0b3BcIiwgY2xhc3NOYW1lOiBvID0gXCJcIiwgaW5wdXRDbGFzc05hbWU6IHMgPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogYyA9IFwiXCIsIGlkOiBsLCB0eXBlOiB1ID0gXCJ0ZXh0XCIsIC4uLmQgfSwgZikgPT4ge1xuXHRsZXQgcCA9IHQoKSwgbSA9IGwgPz8gYG5hYnMtdWktdGV4dGJveC0ke3AucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBoID0gW1xuXHRcdFwibmFicy11aS10ZXh0Ym94XCIsXG5cdFx0ZSA/IGlbYV0gPz8gaS50b3AgOiBcIlwiLFxuXHRcdG9cblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGcgPSBbXCJuYWJzLXVpLXRleHRib3hfX2lucHV0XCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgXyA9IFtcIm5hYnMtdWktdGV4dGJveF9fbGFiZWxcIiwgY10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHIoXCJkaXZcIiwge1xuXHRcdGNsYXNzTmFtZTogaCxcblx0XHRjaGlsZHJlbjogW2UgPyAvKiBAX19QVVJFX18gKi8gbihcImxhYmVsXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXyxcblx0XHRcdGh0bWxGb3I6IG0sXG5cdFx0XHRjaGlsZHJlbjogZVxuXHRcdH0pIDogbnVsbCwgLyogQF9fUFVSRV9fICovIG4oXCJpbnB1dFwiLCB7XG5cdFx0XHRyZWY6IGYsXG5cdFx0XHRpZDogbSxcblx0XHRcdGNsYXNzTmFtZTogZyxcblx0XHRcdHR5cGU6IHUsXG5cdFx0XHQuLi5kXG5cdFx0fSldXG5cdH0pO1xufSk7XG5hLmRpc3BsYXlOYW1lID0gXCJUZXh0Ym94XCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGEgYXMgVGV4dGJveCB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgdCwganN4cyBhcyBuIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL3Rvb2xiYXIudXRpbHMudHNcbnZhciByID0ge1xuXHRsZWZ0OiBcIm5hYnMtdWktdG9vbGJhcl9fY29udGVudC0tbGFiZWwtbGVmdFwiLFxuXHRyaWdodDogXCJuYWJzLXVpLXRvb2xiYXJfX2NvbnRlbnQtLWxhYmVsLXJpZ2h0XCIsXG5cdHRvcDogXCJuYWJzLXVpLXRvb2xiYXJfX2NvbnRlbnQtLWxhYmVsLXRvcFwiLFxuXHRib3R0b206IFwibmFicy11aS10b29sYmFyX19jb250ZW50LS1sYWJlbC1ib3R0b21cIlxufTtcbmZ1bmN0aW9uIGkoZSkge1xuXHRyZXR1cm4gZSB8fCBcInJpZ2h0XCI7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvVG9vbGJhci50c3hcbnZhciBhID0gZShmdW5jdGlvbih7IGl0ZW1zOiBlLCBhY3RpdmVJdGVtSWQ6IGEsIGNsYXNzTmFtZTogbyA9IFwiXCIsIGJ1dHRvbkNsYXNzTmFtZTogcyA9IFwiXCIsIGljb25DbGFzc05hbWU6IGMgPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogbCA9IFwiXCIsIG9uSXRlbVNlbGVjdDogdSwgLi4uZCB9LCBmKSB7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gdChcImRpdlwiLCB7XG5cdFx0cmVmOiBmLFxuXHRcdGNsYXNzTmFtZTogW1wibmFicy11aS10b29sYmFyXCIsIG9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHRyb2xlOiBcInRvb2xiYXJcIixcblx0XHQuLi5kLFxuXHRcdGNoaWxkcmVuOiBlLm1hcCgoZSkgPT4ge1xuXHRcdFx0bGV0IG8gPSBlLmljb24sIGQgPSAhIWUubGFiZWwsIGYgPSBlLmlkID09PSBhIHx8IGUucHJlc3NlZCA9PT0gITAsIHAgPSBbXCJuYWJzLXVpLXRvb2xiYXJfX2NvbnRlbnRcIiwgcltpKGUubGFiZWxQb3NpdGlvbildXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIG0gPSBbXG5cdFx0XHRcdFwibmFicy11aS10b29sYmFyX19idXR0b25cIixcblx0XHRcdFx0ZiA/IFwibmFicy11aS10b29sYmFyX19idXR0b24tLWFjdGl2ZVwiIDogXCJcIixcblx0XHRcdFx0ZCA/IFwiXCIgOiBcIm5hYnMtdWktdG9vbGJhcl9fYnV0dG9uLS1pY29uLW9ubHlcIixcblx0XHRcdFx0c1xuXHRcdFx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGggPSBbXCJuYWJzLXVpLXRvb2xiYXJfX2ljb25cIiwgY10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBnID0gW1wibmFicy11aS10b29sYmFyX19sYWJlbFwiLCBsXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIF8gPSB0eXBlb2YgZS5sYWJlbCA9PSBcInN0cmluZ1wiID8gZS5sYWJlbCA6IGUudGl0bGU7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHQoXCJidXR0b25cIiwge1xuXHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRjbGFzc05hbWU6IG0sXG5cdFx0XHRcdGRpc2FibGVkOiBlLmRpc2FibGVkLFxuXHRcdFx0XHR0aXRsZTogZS50aXRsZSxcblx0XHRcdFx0XCJhcmlhLWxhYmVsXCI6IF8sXG5cdFx0XHRcdFwiYXJpYS1wcmVzc2VkXCI6IHR5cGVvZiBlLnByZXNzZWQgPT0gXCJib29sZWFuXCIgPyBlLnByZXNzZWQgOiB2b2lkIDAsXG5cdFx0XHRcdG9uQ2xpY2s6ICh0KSA9PiB7XG5cdFx0XHRcdFx0dT8uKHtcblx0XHRcdFx0XHRcdGl0ZW1JZDogZS5pZCxcblx0XHRcdFx0XHRcdGl0ZW06IGUsXG5cdFx0XHRcdFx0XHRldmVudDogdFxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIG4oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IHAsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFtvID8gLyogQF9fUFVSRV9fICovIHQobywge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdFx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdFx0XHRcdGZvY3VzYWJsZTogXCJmYWxzZVwiXG5cdFx0XHRcdFx0fSkgOiBudWxsLCBlLmxhYmVsID8gLyogQF9fUFVSRV9fICovIHQoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogZyxcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmxhYmVsXG5cdFx0XHRcdFx0fSkgOiBudWxsXVxuXHRcdFx0XHR9KVxuXHRcdFx0fSwgZS5pZCk7XG5cdFx0fSlcblx0fSk7XG59KTtcbmEuZGlzcGxheU5hbWUgPSBcIlRvb2xiYXJcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYSBhcyBUb29sYmFyIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExheW91dCBhcyB0IH0gZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktbGF5b3V0XCI7XG5pbXBvcnQgeyBqc3ggYXMgbiwganN4cyBhcyByIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1sYXlvdXRcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWFjY29yZGlvblwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktYXZhdGFyXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1idXR0b25zXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1jYXJkc1wiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktY2hlY2tib3hcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWNvZGVcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWNvbWJvYm94XCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1kYXRlcGlja2VyXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1kaWFsb2dcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWRyb3Bkb3dubGlzdFwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktZHJvcGRvd25tZW51XCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1keW5hbWljZm9ybVwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktZmlsZXVwbG9hZFwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktZ3JhcGhcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWdyaWRcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLW1hcmtkb3duXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1uYXZpZ2F0aW9uXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1wYW5lbFwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktcmFkaW9idXR0b25cIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXNpZ25hdHVyZVwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktc2xpZGVyXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1zdGVwcGVyXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS10YWJcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXRleHRhcmVhXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS10ZXh0Ym94XCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS10b29sYmFyXCI7XG4vLyNyZWdpb24gc3JjL1NoZWxsLnRzeFxudmFyIGkgPSBlKCh7IGhlYWRlcjogZSwgbmF2aWdhdGlvbjogciwgZm9vdGVyOiBpLCBjaGlsZHJlbjogYSwgY2xhc3NOYW1lOiBvID0gXCJcIiwgaGVhZGVyQ2xhc3NOYW1lOiBzID0gXCJcIiwgbmF2aWdhdGlvbkNsYXNzTmFtZTogYyA9IFwiXCIsIGNvbnRlbnRDbGFzc05hbWU6IGwgPSBcIlwiLCBmb290ZXJDbGFzc05hbWU6IHUgPSBcIlwiLCAuLi5kIH0sIGYpID0+IHtcblx0bGV0IHAgPSBbXCJuYWJzLXVpLXNoZWxsXCIsIG9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgbSA9IFtcIm5hYnMtdWktc2hlbGxfX2hlYWRlclwiLCBzXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGggPSBbXCJuYWJzLXVpLXNoZWxsX19uYXZpZ2F0aW9uXCIsIGNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktc2hlbGxfX2NvbnRlbnRcIiwgbF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBfID0gW1wibmFicy11aS1zaGVsbF9fZm9vdGVyXCIsIHVdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBuKFwiZGl2XCIsIHtcblx0XHRyZWY6IGYsXG5cdFx0Y2xhc3NOYW1lOiBwLFxuXHRcdC4uLmQsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBuKHQsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLXNoZWxsX19sYXlvdXRcIixcblx0XHRcdGhlYWRlcjogZSxcblx0XHRcdGZvb3RlcjogaSxcblx0XHRcdGxlZnRTaWRlUGFuZWw6IHIsXG5cdFx0XHRoZWFkZXJDbGFzc05hbWU6IG0sXG5cdFx0XHRmb290ZXJDbGFzc05hbWU6IF8sXG5cdFx0XHRsZWZ0U2lkZVBhbmVsQ2xhc3NOYW1lOiBoLFxuXHRcdFx0Y29udGVudENsYXNzTmFtZTogZyxcblx0XHRcdGNoaWxkcmVuOiBhXG5cdFx0fSlcblx0fSk7XG59KTtcbmkuZGlzcGxheU5hbWUgPSBcIlNoZWxsXCI7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvQnJhbmRpbmcudHN4XG52YXIgYSA9IGUoZnVuY3Rpb24oeyBsb2dvOiBlLCB0aXRsZTogdCwgYnlsaW5lOiBpLCBjbGFzc05hbWU6IGEgPSBcIlwiLCAuLi5vIH0sIHMpIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyByKFwiZGl2XCIsIHtcblx0XHRyZWY6IHMsXG5cdFx0Y2xhc3NOYW1lOiBbXCJuYWJzLXVpLWJyYW5kaW5nXCIsIGFdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHQuLi5vLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG4oXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYnJhbmRpbmdfX2xvZ29cIixcblx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRjaGlsZHJlbjogZVxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gcihcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1icmFuZGluZ19fdGV4dFwiLFxuXHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbihcInN0cm9uZ1wiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWJyYW5kaW5nX190aXRsZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogdFxuXHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBuKFwic3BhblwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWJyYW5kaW5nX19ieWxpbmVcIixcblx0XHRcdFx0Y2hpbGRyZW46IGlcblx0XHRcdH0pXVxuXHRcdH0pXVxuXHR9KTtcbn0pO1xuYS5kaXNwbGF5TmFtZSA9IFwiQnJhbmRpbmdcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYSBhcyBCcmFuZGluZywgaSBhcyBTaGVsbCB9O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBRUEsU0FBU0EsS0FBRSxHQUFHO0NBQ2IsSUFBSSxLQUFLLE1BQU07Q0FDZixJQUFJLE9BQU8sS0FBSyxVQUFVLE9BQU8sR0FBRyxFQUFFO0NBQ3RDLElBQUksSUFBSSxFQUFFLEtBQUs7Q0FDZixPQUFPLEVBQUUsU0FBUyxJQUFJLElBQUksS0FBSztBQUNoQztBQUNBLFNBQVNDLEtBQUUsRUFBRSxJQUFJLElBQUksT0FBTyxXQUFXLElBQUksSUFBSSxVQUFVLEdBQUcsR0FBRyxLQUFLO0NBQ25FLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLEdBQUc7RUFDM0IsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVO0NBQ1gsQ0FBQztBQUNGO0FBQ0EsU0FBU0MsSUFBRSxFQUFFLFFBQVEsR0FBRyxRQUFRLEdBQUcsZUFBZSxHQUFHLGdCQUFnQixHQUFHLG9CQUFvQixHQUFHLHFCQUFxQixHQUFHLFVBQVUsR0FBRyxXQUFXLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksd0JBQXdCLElBQUksSUFBSSx5QkFBeUIsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksT0FBTyxHQUFHLEdBQUcsS0FBSztDQUNyVCxJQUFJLElBQUksS0FBSyxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUk7RUFDbkg7RUFDQSxLQUFLLElBQUksMkNBQTJDO0VBQ3BELEtBQUssQ0FBQyxJQUFJLDBDQUEwQztFQUNwRCxDQUFDLEtBQUssSUFBSSwyQ0FBMkM7Q0FDdEQsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUlGLEtBQUUsQ0FBQyxHQUFHLElBQUlBLEtBQUUsQ0FBQztDQUNuRyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLFdBQVc7RUFDWCxPQUFPO0dBQ04sR0FBRyxLQUFLLENBQUM7R0FDVCxHQUFHLElBQUksRUFBRSxxQ0FBcUMsRUFBRSxJQUFJLENBQUM7R0FDckQsR0FBRyxJQUFJLEVBQUUsc0NBQXNDLEVBQUUsSUFBSSxDQUFDO0VBQ3ZEO0VBQ0EsR0FBRztFQUNILFVBQVU7R0FDVCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUMsTUFBRztJQUN4QixJQUFJO0lBQ0osV0FBVztJQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDbEMsV0FBVyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztLQUNqRSxVQUFVO0lBQ1gsQ0FBQztHQUNGLENBQUMsSUFBSTtHQUNXLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87SUFDeEIsV0FBVztJQUNYLFVBQVU7S0FDVCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUEsTUFBRztNQUN4QixJQUFJO01BQ0osV0FBVztPQUNWO09BQ0E7T0FDQTtNQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztNQUMxQixVQUFVO0tBQ1gsQ0FBQyxJQUFJO0tBQ1csaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVBLE1BQUc7TUFDcEIsSUFBSTtNQUNKLFdBQVcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7TUFDbEUsVUFBVTtLQUNYLENBQUM7S0FDRCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUEsTUFBRztNQUN4QixJQUFJO01BQ0osV0FBVztPQUNWO09BQ0E7T0FDQTtNQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztNQUMxQixVQUFVO0tBQ1gsQ0FBQyxJQUFJO0lBQ047R0FDRCxDQUFDO0dBQ0QsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVBLE1BQUc7SUFDeEIsSUFBSTtJQUNKLFdBQVc7SUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQ2xDLFdBQVcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7S0FDakUsVUFBVTtJQUNYLENBQUM7R0FDRixDQUFDLElBQUk7RUFDTjtDQUNELENBQUM7QUFDRjs7O0FDMUVBLFNBQVNFLEtBQUUsR0FBRyxHQUFHLEdBQUc7Q0FDbkIsSUFBSSxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksSUFBSSxJQUFJLEVBQUUsS0FBSyxNQUFNLEVBQUUsRUFBRSxDQUFDLEdBQUcsSUFBSSxFQUFFLFFBQVEsR0FBRyxHQUFHLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUM7Q0FDMUcsT0FBTyxNQUFNLFdBQVcsRUFBRSxNQUFNLEdBQUcsQ0FBQyxJQUFJO0FBQ3pDO0FBQ0EsU0FBU0MsS0FBRSxHQUFHLEdBQUcsR0FBRztDQUNuQixJQUFJLElBQUksRUFBRSxTQUFTLENBQUM7Q0FDcEIsT0FBTyxNQUFNLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLFFBQVEsTUFBTSxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDO0FBQy9FO0FBQ0EsU0FBU0MsS0FBRSxHQUFHO0NBQ2IsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztBQUN6RDtBQUdBLElBQUksS0FBQSxHQUFJQyxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUcsTUFBTSxJQUFJLFlBQVksaUJBQWlCLEdBQUcsd0JBQXdCLEdBQUcseUJBQXlCLEdBQUcsV0FBVyxJQUFJLElBQUksZUFBZSxJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksR0FBRyxHQUFHLEtBQUssR0FBRztDQUM3TyxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxxQkFBcUIsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFBLEdBQUtDLGFBQUFBLFNBQUFBLEVBQUFBLEdBQUVDLGFBQUFBLFFBQUFBLE9BQVFOLEtBQUUsR0FBRyxHQUFHLENBQUMsR0FBRztFQUNoRztFQUNBO0VBQ0E7Q0FDRCxDQUFDLENBQUM7Q0FDRixDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxHQUFHLE1BQU1BLEtBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztDQUNwQixHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDVCxJQUFJLEtBQUEsR0FBSU0sYUFBQUEsUUFBQUEsT0FBUU4sS0FBRSxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDLEdBQUc7RUFDOUM7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsV0FBVztFQUNuQyxLQUFLO0VBQ0wsSUFBSTtFQUNKLFdBQVdFLEtBQUUsQ0FBQztFQUNkLEdBQUc7RUFDSCxVQUFVLEVBQUUsS0FBSyxNQUFNO0dBQ3RCLElBQUksSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFFLEdBQUcsSUFBSSxHQUFHLEVBQUUsU0FBUyxFQUFFLE1BQU0sSUFBSSxHQUFHLEVBQUUsV0FBVyxFQUFFLE1BQU0sSUFBSTtJQUNuRjtJQUNBLElBQUksc0NBQXNDO0lBQzFDO0dBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxLQUFLLE1BQU07SUFDdkssSUFBSSxJQUFJRCxLQUFFLEdBQUcsRUFBRSxJQUFJLENBQUM7SUFDcEIsTUFBTSxLQUFLLEtBQUssRUFBRSxDQUFDLEdBQUcsSUFBSTtLQUN6QixRQUFRLEVBQUU7S0FDVixpQkFBaUI7S0FDakIsT0FBTztJQUNSLENBQUM7R0FDRjtHQUNBLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFdBQVc7SUFDbkMsV0FBVztJQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtLQUNsQyxXQUFXO0tBQ1gsVUFBVSxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO01BQ3pDLElBQUk7TUFDSixNQUFNO01BQ04sV0FBVztNQUNYLGlCQUFpQjtNQUNqQixpQkFBaUI7TUFDakIsVUFBVSxFQUFFO01BQ1osU0FBUztNQUNULFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxPQUFPLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtPQUN2RixXQUFXO09BQ1gsZUFBZTtPQUNmLFVBQVU7TUFDWCxDQUFDLENBQUM7S0FDSCxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7TUFDaEMsSUFBSTtNQUNKLE1BQU07TUFDTixXQUFXO01BQ1gsaUJBQWlCO01BQ2pCLGlCQUFpQjtNQUNqQixVQUFVLEVBQUU7TUFDWixTQUFTO01BQ1QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO09BQ3ZGLFdBQVc7T0FDWCxlQUFlO09BQ2YsVUFBVTtNQUNYLENBQUMsQ0FBQztLQUNILENBQUM7SUFDRixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFdBQVc7S0FDaEMsSUFBSTtLQUNKLFdBQVc7S0FDWCxNQUFNO0tBQ04sbUJBQW1CO0tBQ25CLFFBQVEsQ0FBQztLQUNULFVBQVUsRUFBRTtJQUNiLENBQUMsQ0FBQztHQUNILEdBQUcsRUFBRSxFQUFFO0VBQ1IsQ0FBQztDQUNGLENBQUM7QUFDRixDQUFDO0FBQ0QsRUFBRSxjQUFjOzs7O0FDeEZoQixTQUFTTSxJQUFFLEdBQUc7Q0FDYixPQUFPLENBQUMsRUFBRSxLQUFLLFVBQVUsS0FBSyxFQUFFLFNBQVM7QUFDMUM7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVk7QUFDakM7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRztDQUNoQixPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsUUFBUTtBQUN0QztBQUdBLFNBQVNDLElBQUUsRUFBRSxPQUFPLElBQUksUUFBUSxnQkFBZ0IsR0FBRyxrQkFBa0IsR0FBRyxXQUFXLElBQUksU0FBUyxPQUFPLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksZUFBZSxJQUFJLElBQUksZUFBZSxJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxJQUFJLEdBQUcsY0FBYyxHQUFHLEdBQUcsS0FBSztDQUNuUSxJQUFJLENBQUMsR0FBRyxNQUFBLEdBQUtDLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsS0FBQSxHQUFJQyxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxLQUFBLEdBQUlBLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLHdCQUF3QixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSSxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDOWIsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFRO0VBQ1AsSUFBSSxLQUFLLE1BQU07R0FDZCxFQUFFLGtCQUFrQixRQUFRLEVBQUUsV0FBVyxDQUFDLEVBQUUsUUFBUSxTQUFTLEVBQUUsTUFBTSxLQUFLLEVBQUUsV0FBVyxDQUFDLEVBQUUsUUFBUSxTQUFTLEVBQUUsTUFBTSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0VBQzdILEdBQUcsS0FBSyxNQUFNO0dBQ2IsRUFBRSxRQUFRLFlBQVksRUFBRSxDQUFDLENBQUM7RUFDM0I7RUFDQSxPQUFPLFNBQVMsaUJBQWlCLGVBQWUsQ0FBQyxHQUFHLFNBQVMsaUJBQWlCLFdBQVcsQ0FBQyxTQUFTO0dBQ2xHLFNBQVMsb0JBQW9CLGVBQWUsQ0FBQyxHQUFHLFNBQVMsb0JBQW9CLFdBQVcsQ0FBQztFQUMxRjtDQUNELEdBQUcsQ0FBQyxDQUFDLElBQUEsR0FBR0MsYUFBQUEsZ0JBQUFBLE9BQVE7RUFDZixJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsU0FBUztFQUN0QixJQUFJLFVBQVU7R0FDYixJQUFJLElBQUksRUFBRSxTQUFTLHNCQUFzQixHQUFHLElBQUksRUFBRTtHQUNsRCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUc7R0FDZCxJQUFJLElBQUksRUFBRSxPQUFPLElBQUksT0FBTyxhQUFhLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxFQUFFLFFBQVEsSUFBSSxFQUFFLE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLEtBQUssSUFBSSxHQUFHLEVBQUUsU0FBUyxFQUFFO0dBQ3RKLEVBQUUsTUFBTSxXQUFXLFNBQVMsRUFBRSxNQUFNLE1BQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLE9BQU8sR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLFFBQVEsUUFBUSxFQUFFLE1BQU0sV0FBVyxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sYUFBYTtFQUN4SjtFQUNBLE9BQU8sRUFBRSxZQUFZLEVBQUUsUUFBUSxNQUFNLGFBQWEsV0FBVyxFQUFFLEdBQUcsT0FBTyxpQkFBaUIsVUFBVSxDQUFDLEdBQUcsT0FBTyxpQkFBaUIsVUFBVSxHQUFHLENBQUMsQ0FBQyxTQUFTO0dBQ3ZKLE9BQU8sb0JBQW9CLFVBQVUsQ0FBQyxHQUFHLE9BQU8sb0JBQW9CLFVBQVUsR0FBRyxDQUFDLENBQUM7RUFDcEY7Q0FDRCxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDVCxJQUFJLEtBQUssR0FBRyxNQUFNO0VBQ2pCLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLFVBQVU7R0FDdEIsRUFBRSxlQUFlO0dBQ2pCO0VBQ0Q7RUFDQSxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsV0FBVyxHQUFHLENBQUM7Q0FDN0I7Q0FDQSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtHQUN0QyxLQUFLO0dBQ0wsTUFBTTtHQUNOLFdBQVc7R0FDWCxpQkFBaUI7R0FDakIsaUJBQWlCO0dBQ2pCLGNBQWMsS0FBSztHQUNuQixlQUFlLEdBQUcsTUFBTSxDQUFDLENBQUM7R0FDMUIsVUFBVSxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRUMsbUJBQUFBLFVBQUcsRUFBRSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDMUUsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDN0IsV0FBVztJQUNYLGVBQWU7SUFDZixVQUFVO0dBQ1gsQ0FBQyxDQUFDLEVBQUUsQ0FBQztFQUNOLENBQUMsR0FBRyxLQUFLLE9BQU8sV0FBVyxPQUFBLEdBQU1DLGlCQUFBQSxhQUFBQSxDQUFrQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQzNELEtBQUs7R0FDTCxJQUFJO0dBQ0osV0FBVztHQUNYLGNBQWM7R0FDZCxVQUFVLEVBQUUsS0FBSyxHQUFHLE1BQU07SUFDekIsSUFBSVQsSUFBRSxDQUFDLEdBQUcsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUN6QyxXQUFXO0tBQ1gsTUFBTTtLQUNOLGVBQWU7SUFDaEIsR0FBRyxXQUFXLEdBQUc7SUFDakIsSUFBSSxJQUFJQyxJQUFFLENBQUMsR0FBRyxJQUFJO0tBQ2pCO0tBQ0EsRUFBRSxXQUFXLHlDQUF5QztLQUN0RCxFQUFFLFNBQVMsdUNBQXVDO0lBQ25ELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUk7S0FDaEMsV0FBVztLQUNYLGlCQUFpQixFQUFFLFlBQVksS0FBSztJQUNyQztJQUNBLE9BQU8sRUFBRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLO0tBQ3RDLEdBQUc7S0FDSCxNQUFNLEVBQUUsV0FBVyxLQUFLLElBQUksRUFBRTtLQUM5QixVQUFVLE1BQU0sRUFBRSxHQUFHLENBQUM7S0FDdEIsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVc7TUFDWCxVQUFVO0tBQ1gsQ0FBQyxHQUFHLEVBQUUsY0FBOEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUM3QyxXQUFXO01BQ1gsVUFBVSxFQUFFO0tBQ2IsQ0FBQyxJQUFJLElBQUk7SUFDVixHQUFHQyxJQUFFLEdBQUcsQ0FBQyxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7S0FDekMsTUFBTTtLQUNOLFdBQVc7S0FDWCxVQUFVLEVBQUU7S0FDWixVQUFVLE1BQU0sRUFBRSxHQUFHLENBQUM7S0FDdEIsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVc7TUFDWCxVQUFVO0tBQ1gsQ0FBQyxHQUFHLEVBQUUsY0FBOEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUM3QyxXQUFXO01BQ1gsVUFBVSxFQUFFO0tBQ2IsQ0FBQyxJQUFJLElBQUk7SUFDVixHQUFHQSxJQUFFLEdBQUcsQ0FBQyxDQUFDO0dBQ1gsQ0FBQztFQUNGLENBQUMsR0FBRyxTQUFTLElBQUksSUFBSSxJQUFJO0NBQzFCLENBQUM7QUFDRjtBQUdBLFNBQVNRLElBQUUsR0FBRztDQUNiLElBQUksSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUMsT0FBTyxPQUFPO0NBQzVDLE9BQU8sRUFBRSxXQUFXLElBQUksTUFBTSxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxFQUFFLEVBQUUsWUFBWSxLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRTtBQUMxRjtBQUdBLElBQUksS0FBQSxHQUFJQyxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxlQUFlLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxjQUFjLFdBQVcsSUFBSSxJQUFJLFdBQVcsR0FBRyxhQUFhLElBQUksS0FBSyxZQUFZLElBQUksS0FBSyxjQUFjLEdBQUcsZ0JBQWdCLEdBQUcsZUFBZSxHQUFHLFdBQVcsSUFBSSxJQUFJLFdBQVcsR0FBRyxHQUFHLEtBQUssR0FBRztDQUNqUCxJQUFJLElBQUksRUFBRSxLQUFLLEtBQUssY0FBYyxJQUFJRCxJQUFFLENBQUMsR0FBRyxJQUFJO0VBQy9DO0VBQ0EsSUFBSSxrQ0FBa0M7RUFDdEM7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxLQUFLLE1BQU07RUFDdkMsTUFBTSxFQUFFLGVBQWUsR0FBRyxFQUFFLENBQUM7Q0FDOUIsR0FBRyxLQUFLLE1BQU07RUFDYixNQUFNLEVBQUUsZUFBZSxHQUFHLEVBQUUsQ0FBQztDQUM5QixHQUFHLEtBQUssTUFBTTtFQUNiLE1BQU0sRUFBRSxlQUFlLEdBQUcsRUFBRSxDQUFDO0NBQzlCO0NBQ0EsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztFQUMvQixLQUFLO0VBQ0wsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFUCxLQUFHO0dBQ2xDLFdBQVc7R0FDWCxPQUFPLEdBQUcsRUFBRTtHQUNaLGtCQUFrQixLQUFLLEdBQUcsRUFBRTtHQUM1QixXQUFXO0dBQ1gsZ0JBQWdDLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFSyxtQkFBQUEsVUFBRyxFQUFFLFVBQVU7SUFDaEMsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtLQUN6QixXQUFXO0tBQ1gsZUFBZTtLQUNmLFVBQVUsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztNQUN0QyxXQUFXO01BQ1gsS0FBSztNQUNMLEtBQUs7S0FDTixDQUFDLElBQUk7SUFDTixDQUFDO0lBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtLQUN6QixXQUFXO0tBQ1gsVUFBVTtJQUNYLENBQUM7SUFDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0tBQ3pCLFdBQVc7S0FDWCxlQUFlO0tBQ2YsVUFBVTtJQUNYLENBQUM7R0FDRixFQUFFLENBQUM7R0FDSCxrQkFBa0I7R0FDbEIsZUFBZTtHQUNmLGVBQWU7R0FDZixPQUFPLENBQUM7SUFDUCxPQUFPO0lBQ1AsTUFBTTtJQUNOLFdBQVcsR0FBRyxNQUFNLEVBQUUsQ0FBQztHQUN4QixHQUFHO0lBQ0YsT0FBTztJQUNQLE1BQU07SUFDTixRQUFRLENBQUM7SUFDVCxXQUFXLEdBQUcsTUFBTSxFQUFFLENBQUM7R0FDeEIsQ0FBQztFQUNGLENBQUMsSUFBSSxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLO0dBQy9CLFdBQVc7R0FDWCxNQUFNO0dBQ04sU0FBUztHQUNULFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtJQUNwQyxXQUFXO0lBQ1gsZUFBZTtJQUNmLFVBQVU7R0FDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDN0IsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLENBQUM7RUFDSCxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7R0FDaEMsTUFBTTtHQUNOLFdBQVc7R0FDWCxTQUFTO0dBQ1QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQ3BDLFdBQVc7SUFDWCxlQUFlO0lBQ2YsVUFBVTtHQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtJQUM3QixXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsQ0FBQztFQUNILENBQUM7Q0FDRixDQUFDO0FBQ0YsQ0FBQztBQUNELEVBQUUsY0FBYzs7O0FDdE1oQixJQUFJSSxPQUFJO0NBQ1AsU0FBUztDQUNULFdBQVc7Q0FDWCxPQUFPO0FBQ1I7QUFBRyxJQUFBLEtBQUEsR0FBSUMsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsVUFBVSxHQUFHLFdBQVcsSUFBSSxJQUFJLFNBQVMsSUFBSSxXQUFXLE1BQU0sSUFBSSxVQUFVLEdBQUcsS0FBSyxHQUFHO0NBQzFHLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7RUFDbEMsS0FBSztFQUNMLFdBQVc7R0FDVjtHQUNBRCxLQUFFLE1BQU1BLEtBQUU7R0FDVjtFQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztFQUMxQixNQUFNO0VBQ04sR0FBRztFQUNILFVBQVU7Q0FDWCxDQUFDO0FBQ0YsQ0FBQztBQUNELEVBQUUsY0FBYzs7O0FDakJoQixTQUFTRSxLQUFFLEdBQUc7Q0FDYixPQUFPLE1BQU0sS0FBSyxJQUFJLElBQUksT0FBTyxTQUFTLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzRjtBQUNBLFNBQVNDLEtBQUUsR0FBRyxHQUFHLEdBQUc7Q0FDbkIsT0FBTyxNQUFNLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNO0VBQ3hDLElBQUksSUFBSSxFQUFFLFdBQVcsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFLEdBQUcsSUFBSSxFQUFFLFdBQVcsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFLEdBQUcsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDLEdBQUcsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDO0VBQzdILElBQUksTUFBTSxHQUFHLE9BQU8sSUFBSTtFQUN4QixJQUFJLElBQUksSUFBSSxHQUFHLElBQUksSUFBSTtFQUN2QixRQUFRLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDakUsQ0FBQyxJQUFJO0FBQ047QUFHQSxJQUFJQyxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxFQUFHLEVBQUUsT0FBTyxHQUFHLFFBQVEsSUFBSSxLQUFLLFNBQVMsR0FBRyxXQUFXLElBQUksSUFBSSxlQUFlLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxHQUFHLEtBQUssTUFBTTtDQUN4TCxJQUFJLElBQUlILEtBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsdUJBQXVCLGdDQUFnQyxHQUFHLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUlDLEtBQUUsR0FBRyxHQUFHLENBQUM7Q0FDM0ssT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsV0FBVztFQUNuQyxLQUFLO0VBQ0wsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQ2xDLFdBQVc7R0FDWCxVQUFVLEVBQUUsS0FBSyxNQUFNO0lBQ3RCLElBQUksSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksRUFBRSxVQUFVLFFBQVEsRUFBRSxXQUFXLENBQUMsR0FBRyxJQUFJLEVBQUUsV0FBVyxRQUFRLEVBQUUsWUFBWSxDQUFDLEdBQUcsSUFBSSxFQUFFLFdBQVcsUUFBUSxFQUFFLFlBQVksQ0FBQztJQUMxTCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxXQUFXO0tBQ25DLFdBQVc7S0FDWCxVQUFVO01BQ1QsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtPQUMvQixXQUFXLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO09BQ2hFLFVBQVUsRUFBRTtNQUNiLENBQUMsSUFBSTtNQUNMLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87T0FDNUIsV0FBVyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztPQUNqRSxVQUFVLEVBQUU7TUFDYixDQUFDLElBQUk7TUFDTCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO09BQzVCLFdBQVcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7T0FDakUsVUFBVSxFQUFFO01BQ2IsQ0FBQyxJQUFJO0tBQ047SUFDRCxHQUFHLEVBQUUsRUFBRTtHQUNSLENBQUM7RUFDRixDQUFDO0NBQ0YsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7OztBQzVDaEIsSUFBSUcsT0FBSTtDQUNQLE9BQU87Q0FDUCxNQUFNO0NBQ04sS0FBSztDQUNMLFFBQVE7QUFDVDtBQUFHQyxJQUFBQSxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxPQUFPLElBQUksWUFBWSxlQUFlLElBQUksU0FBUyxXQUFXLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksSUFBSSxHQUFHLFVBQVUsR0FBRyxHQUFHLEtBQUssR0FBRztDQUN4SyxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxvQkFBb0IsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUk7RUFDcEU7RUFDQSxJQUFJLCtCQUErQjtFQUNuQ0gsS0FBRSxNQUFNQSxLQUFFO0VBQ1Y7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUN0SixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO0VBQ2pDLFdBQVc7RUFDWCxTQUFTO0VBQ1QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0dBQ3JDLEtBQUs7R0FDTCxJQUFJO0dBQ0osV0FBVztHQUNYLE1BQU07R0FDTixVQUFVO0dBQ1YsR0FBRztFQUNKLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtHQUM3QixXQUFXO0dBQ1gsVUFBVTtFQUNYLENBQUMsQ0FBQztDQUNILENBQUM7QUFDRixDQUFDO0FBQ0QsSUFBRSxjQUFjOzs7QUM1QmhCLElBQUlJLE9BQUk7Q0FDUCxNQUFNO0NBQ04sS0FBSztDQUNMLE1BQU07Q0FDTixRQUFRO0FBQ1Q7QUFBRyxJQUFBLEtBQUEsR0FBSUMsYUFBQUEsV0FBQUEsRUFBRyxFQUFFLE1BQU0sR0FBRyxVQUFVLElBQUksUUFBUSxpQkFBaUIsSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRyxPQUFPLEdBQUcsV0FBVyxJQUFJLElBQUksY0FBYyxJQUFJLElBQUksZUFBZSxJQUFJLElBQUksR0FBRyxLQUFLLE1BQU07Q0FDekssSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSTtFQUMxRDtFQUNBLElBQUksNEJBQTRCO0VBQ2hDLElBQUksbUNBQW1DO0VBQ3ZDO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSTtFQUNoQztFQUNBLDBCQUEwQjtFQUMxQjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksRUFBRSxRQUFRLFNBQVMsSUFBSSxHQUFHLElBQUksRUFBRSxNQUFNLElBQUk7Q0FDM0UsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsV0FBVztFQUNuQyxLQUFLO0VBQ0wsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7R0FDdEMsV0FBVztHQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtJQUNwQyxXQUFXO0lBQ1gsVUFBVUQsS0FBRTtHQUNiLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtJQUM3QixXQUFXO0lBQ1gsVUFBVSxLQUFLO0dBQ2hCLENBQUMsQ0FBQztFQUNILENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztHQUM1QixXQUFXO0dBQ1gsVUFBVSxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQ3ZDLFdBQVc7SUFDWCxVQUFVLEVBQUUsS0FBSyxHQUFHLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFFBQVE7S0FDbkQsV0FBVztLQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUNwQyxXQUFXO01BQ1gsVUFBVSxJQUFJO0tBQ2YsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzdCLFdBQVc7TUFDWCxVQUFVLEtBQUs7S0FDaEIsQ0FBQyxDQUFDO0lBQ0gsR0FBRyxDQUFDLENBQUM7R0FDTixDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDOUIsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDO0VBQ0YsQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7QUFDRCxFQUFFLGNBQWM7OztBQ2xEaEIsU0FBU0UsS0FBRSxHQUFHO0NBQ2IsT0FBTyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUU7QUFDbkM7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixJQUFJLElBQUlELEtBQUUsQ0FBQztDQUNYLE9BQU8sT0FBTyxLQUFLLFlBQVksT0FBTyxLQUFLLFdBQVcsR0FBRyxNQUFNLEVBQUU7QUFDbEU7QUFDQSxTQUFTRSxJQUFFLEdBQUcsR0FBRztDQUNoQixPQUFPLEVBQUUsU0FBUyxRQUFRO0FBQzNCO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUc7Q0FDaEIsT0FBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLE1BQU0sTUFBTSxFQUFFLFVBQVUsQ0FBQyxLQUFLO0FBQzNEO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLFlBQVk7QUFDN0I7QUFHQSxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxPQUFPLEdBQUcsY0FBYyxHQUFHLFdBQVcsSUFBSSxDQUFDLEdBQUcsV0FBVyxJQUFJLFFBQVEsV0FBVyxJQUFJLElBQUksSUFBSSxHQUFHLFVBQVUsR0FBRyxhQUFhLEdBQUcsZUFBZSxHQUFHLFNBQVMsR0FBRyxRQUFRLEdBQUcsV0FBVyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQ2pPLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsS0FBQSxHQUFJQyxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxJQUFJLHlCQUF5QixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSSxLQUFLLG9CQUFvQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSSxNQUFNLEtBQUssR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQyxhQUFBQSxTQUFBQSxDQUFFLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSUwsSUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJLElBQUlGLElBQUUsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLEdBQUcsTUFBQSxHQUFLTyxhQUFBQSxTQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtBLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtBLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxHQUFHLEtBQUEsR0FBSUMsYUFBQUEsUUFBQUEsT0FBUTtFQUN4UixJQUFJLElBQUlMLElBQUUsQ0FBQztFQUNYLE9BQU8sRUFBRSxRQUFRLE1BQU07R0FDdEIsSUFBSSxJQUFJQSxJQUFFSCxJQUFFLENBQUMsQ0FBQztHQUNkLE9BQU8sRUFBRSxXQUFXLEtBQUssRUFBRSxTQUFTLENBQUM7RUFDdEMsQ0FBQztDQUNGLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDO0VBQ3BCLE9BQU87RUFDUCxPQUFPO0VBQ1AsVUFBVSxDQUFDO0VBQ1gsUUFBUSxDQUFDO0NBQ1YsR0FBRyxHQUFHLENBQUMsSUFBSTtDQUNYLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLEtBQUssRUFBRSxDQUFDO0NBQ1QsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUEsR0FBR1MsYUFBQUEsVUFBQUEsT0FBUTtFQUNuQixLQUFLLEVBQUUsVUFBVSxFQUFFLEVBQUUsV0FBVyxJQUFJLElBQUksRUFBRSxTQUFTLENBQUM7Q0FDckQsR0FBRyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsSUFBQSxHQUFHQSxhQUFBQSxVQUFBQSxPQUFRO0VBQzFCLElBQUksS0FBSyxNQUFNO0dBQ2QsRUFBRSxXQUFXLEVBQUUsa0JBQWtCLFFBQVEsQ0FBQyxFQUFFLFFBQVEsU0FBUyxFQUFFLE1BQU0sS0FBSyxFQUFFLENBQUMsQ0FBQztFQUMvRTtFQUNBLE9BQU8sU0FBUyxpQkFBaUIsZUFBZSxDQUFDLFNBQVM7R0FDekQsU0FBUyxvQkFBb0IsZUFBZSxDQUFDO0VBQzlDO0NBQ0QsR0FBRyxDQUFDLENBQUM7Q0FDTCxJQUFJLEtBQUssR0FBRyxNQUFNO0VBQ2pCLEtBQUssRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSVQsSUFBRSxDQUFDLElBQUksRUFBRTtDQUM3QyxHQUFHLEtBQUssTUFBTTtFQUNiLElBQUksSUFBSSxFQUFFO0VBQ1YsSUFBSSxHQUFHO0dBQ04sSUFBSSxZQUFZLEdBQUc7SUFDbEIsRUFBRSxNQUFNLElBQUk7SUFDWjtHQUNEO0dBQ0EsRUFBRSxZQUFZLEVBQUUsRUFBRSxPQUFPLENBQUM7RUFDM0I7Q0FDRCxHQUFHLEtBQUssTUFBTTtFQUNiLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDO0NBQ3pCLEdBQUcsS0FBSyxNQUFNO0VBQ2IsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7Q0FDbkIsR0FBRyxLQUFLLE1BQU07RUFDYixFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxPQUFPLEtBQUssR0FBRyxFQUFFLENBQUM7Q0FDOUIsR0FBRyxLQUFLLE1BQU07RUFDYixJQUFJLEVBQUUsUUFBUSxhQUFhO0dBQzFCLEVBQUUsZUFBZSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxJQUFJLEVBQUUsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDO0dBQzlFO0VBQ0Q7RUFDQSxJQUFJLEVBQUUsUUFBUSxXQUFXO0dBQ3hCLEVBQUUsZUFBZSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDO0dBQ3REO0VBQ0Q7RUFDQSxJQUFJLEVBQUUsUUFBUSxTQUFTO0dBQ3RCLE1BQU0sRUFBRSxlQUFlLEdBQUcsRUFBRSxDQUFDO0dBQzdCO0VBQ0Q7RUFDQSxJQUFJLEVBQUUsUUFBUSxVQUFVO0dBQ3ZCLEVBQUUsZUFBZSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO0dBQzlCO0VBQ0Q7RUFDQSxJQUFJLENBQUM7Q0FDTixHQUFHLElBQUksSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztFQUNyQyxLQUFLO0VBQ0wsSUFBSTtFQUNKLE1BQU07RUFDTixpQkFBaUI7RUFDakIscUJBQXFCO0VBQ3JCLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIseUJBQXlCLEVBQUUsS0FBSyxHQUFHLEVBQUUsVUFBVSxNQUFNLEtBQUs7RUFDMUQsV0FBVztFQUNYLFVBQVU7RUFDVixhQUFhO0VBQ2IsT0FBTztFQUNQLFNBQVM7RUFDVCxRQUFRO0VBQ1IsVUFBVTtFQUNWLFdBQVc7RUFDWCxHQUFHO0NBQ0osQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0VBQy9CLEtBQUs7RUFDTCxJQUFJO0VBQ0osTUFBTTtFQUNOLGlCQUFpQjtFQUNqQixxQkFBcUI7RUFDckIsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQixXQUFXO0VBQ1gsVUFBVTtFQUNWLGFBQWE7RUFDYixPQUFPO0VBQ1AsU0FBUztFQUNULFFBQVE7RUFDUixVQUFVO0VBQ1YsV0FBVztFQUNYLEdBQUc7Q0FDSixDQUFDO0NBQ0QsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixLQUFLO0VBQ0wsV0FBVztHQUNWO0dBQ0EsSUFBSSwyQkFBMkI7R0FDL0IsSUFBSSwrQkFBK0I7R0FDbkM7RUFDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFDMUIsVUFBVSxDQUFDLEdBQUcsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztHQUMxQyxJQUFJO0dBQ0osV0FBVztHQUNYLE1BQU07R0FDTixjQUFjO0dBQ2QsVUFBVSxFQUFFLFdBQVcsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNuRCxXQUFXO0lBQ1gsTUFBTTtJQUNOLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakIsVUFBVTtHQUNYLENBQUMsSUFBSSxFQUFFLEtBQUssR0FBRyxNQUFNO0lBQ3BCLElBQUksSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssTUFBTSxFQUFFLE9BQU8sSUFBSTtLQUNuRDtLQUNBLE1BQU0sSUFBSSxxQ0FBcUM7S0FDL0MsSUFBSSx1Q0FBdUM7S0FDM0MsSUFBSSxtQ0FBbUM7S0FDdkMsRUFBRSxXQUFXLHVDQUF1QztJQUNyRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7SUFDMUIsT0FBTyxJQUFJLE1BQU0sT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUNoRCxJQUFJLEdBQUcsRUFBRSxVQUFVO0tBQ25CLFdBQVc7S0FDWCxNQUFNO0tBQ04saUJBQWlCO0tBQ2pCLGlCQUFpQjtLQUNqQixVQUFVO0tBQ1YsY0FBYyxNQUFNLEVBQUUsZUFBZTtLQUNyQyxlQUFlLEVBQUUsQ0FBQztLQUNsQixvQkFBb0IsRUFBRSxDQUFDO0tBQ3ZCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDbkMsV0FBVztNQUNYLFVBQVU7S0FDWCxDQUFDO0lBQ0YsR0FBRyxNQUFNLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDckMsSUFBSSxHQUFHLEVBQUUsVUFBVTtLQUNuQixXQUFXO0tBQ1gsTUFBTTtLQUNOLGlCQUFpQjtLQUNqQixpQkFBaUI7S0FDakIsVUFBVTtLQUNWLGNBQWMsTUFBTSxFQUFFLGVBQWU7S0FDckMsZUFBZSxFQUFFLENBQUM7S0FDbEIsb0JBQW9CLEVBQUUsQ0FBQztLQUN2QixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ25DLFdBQVc7TUFDWCxVQUFVO0tBQ1gsQ0FBQztJQUNGLEdBQUcsTUFBTSxJQUFJLEVBQUUsV0FBVyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0tBQ3RELElBQUksR0FBRyxFQUFFLFVBQVU7S0FDbkIsV0FBVztLQUNYLE1BQU07S0FDTixpQkFBaUI7S0FDakIsaUJBQWlCO0tBQ2pCLFVBQVU7S0FDVixjQUFjLE1BQU0sRUFBRSxlQUFlO0tBQ3JDLGVBQWUsRUFBRSxDQUFDO0tBQ2xCLG9CQUFvQixFQUFFLENBQUM7S0FDdkIsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVc7TUFDWCxVQUFVRCxLQUFFLENBQUM7S0FDZCxDQUFDLEdBQUcsRUFBRSxjQUE4QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzdDLFdBQVc7TUFDWCxVQUFVLEVBQUU7S0FDYixDQUFDLElBQUksSUFBSTtJQUNWLEdBQUdFLElBQUUsR0FBRyxDQUFDLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztLQUN0QyxJQUFJLEdBQUcsRUFBRSxVQUFVO0tBQ25CLFdBQVc7S0FDWCxNQUFNO0tBQ04saUJBQWlCO0tBQ2pCLGlCQUFpQjtLQUNqQixVQUFVO0tBQ1YsY0FBYyxNQUFNLEVBQUUsZUFBZTtLQUNyQyxlQUFlLEVBQUUsQ0FBQztLQUNsQixvQkFBb0IsRUFBRSxDQUFDO0tBQ3ZCLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUNwQyxXQUFXO01BQ1gsVUFBVUYsS0FBRSxDQUFDO0tBQ2QsQ0FBQyxHQUFHLEVBQUUsY0FBOEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUM3QyxXQUFXO01BQ1gsVUFBVSxFQUFFO0tBQ2IsQ0FBQyxJQUFJLElBQUk7SUFDVixHQUFHRSxJQUFFLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztLQUMxQyxJQUFJLEdBQUcsRUFBRSxVQUFVO0tBQ25CLFdBQVc7S0FDWCxNQUFNO0tBQ04saUJBQWlCO0tBQ2pCLGlCQUFpQjtLQUNqQixVQUFVO0tBQ1YsY0FBYyxNQUFNLEVBQUUsZUFBZTtLQUNyQyxlQUFlLEVBQUUsQ0FBQztLQUNsQixvQkFBb0IsRUFBRSxDQUFDO0tBQ3ZCLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUNwQyxXQUFXO01BQ1gsVUFBVUYsS0FBRSxDQUFDO0tBQ2QsQ0FBQyxHQUFHLEVBQUUsY0FBOEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUM3QyxXQUFXO01BQ1gsVUFBVSxFQUFFO0tBQ2IsQ0FBQyxJQUFJLElBQUk7SUFDVixHQUFHRSxJQUFFLEdBQUcsQ0FBQyxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87S0FDdEMsSUFBSSxHQUFHLEVBQUUsVUFBVTtLQUNuQixXQUFXO0tBQ1gsTUFBTTtLQUNOLGlCQUFpQjtLQUNqQixpQkFBaUI7S0FDakIsVUFBVTtLQUNWLGNBQWMsTUFBTSxFQUFFLGVBQWU7S0FDckMsZUFBZSxFQUFFLENBQUM7S0FDbEIsb0JBQW9CLEVBQUUsQ0FBQztLQUN2QixVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDcEMsV0FBVztNQUNYLFVBQVVGLEtBQUUsQ0FBQztLQUNkLENBQUMsR0FBRyxFQUFFLGNBQThCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDN0MsV0FBVztNQUNYLFVBQVUsRUFBRTtLQUNiLENBQUMsSUFBSSxJQUFJO0lBQ1YsR0FBR0UsSUFBRSxHQUFHLENBQUMsQ0FBQztHQUNYLENBQUM7RUFDRixDQUFDLElBQUksSUFBSTtDQUNWLENBQUM7QUFDRixDQUFDO0FBQ0QsRUFBRSxjQUFjOzs7QUNsUGhCLElBQUlTLE9BQUk7Q0FDUCxNQUFNO0NBQ04sS0FBSztDQUNMLE1BQU07QUFDUDtBQUFHQyxJQUFBQSxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxFQUFHLEVBQUUsT0FBTyxHQUFHLGVBQWUsSUFBSSxPQUFPLFdBQVcsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxXQUFXLElBQUksQ0FBQyxHQUFHLElBQUksR0FBRyxPQUFPLEdBQUcsVUFBVSxHQUFHLFNBQVMsR0FBRyxlQUFlLEdBQUcsR0FBRyxLQUFLLE1BQU07Q0FDL00sSUFBSSxLQUFBLEdBQUlDLGFBQUFBLE1BQUFBLENBQUUsR0FBRyxJQUFJLEtBQUssc0JBQXNCLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJO0VBQ3RFO0VBQ0EsSUFBSUgsS0FBRSxNQUFNQSxLQUFFLE1BQU07RUFDcEI7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUMxSixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLFdBQVc7RUFDWCxVQUFVLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztHQUN6QyxXQUFXO0dBQ1gsU0FBUztHQUNULFVBQVU7RUFDWCxDQUFDLElBQUksTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztHQUNyQyxLQUFLO0dBQ0wsSUFBSTtHQUNKLFdBQVc7R0FDWCxNQUFNO0dBQ04sT0FBTyxNQUFNLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSztHQUNwQyxVQUFVLE1BQU07SUFDZixJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsa0JBQWtCO0lBQ2hDLElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLGFBQWE7R0FDNUM7R0FDQSxXQUFXLE1BQU07SUFDaEIsSUFBSSxDQUFDLEdBQUcsSUFBSSxLQUFLLEVBQUUsT0FBTyxVQUFVLEtBQUssT0FBTyxFQUFFLE9BQU8sT0FBTyxDQUFDO0dBQ2xFO0dBQ0EsR0FBRztFQUNKLENBQUMsQ0FBQztDQUNILENBQUM7QUFDRixDQUFDO0FBQ0QsSUFBRSxjQUFjOzs7QUNsQ2hCLElBQUlJLE9BQUk7QUFDUixTQUFTQyxLQUFFLEdBQUc7Q0FDYixPQUFPLE1BQU0sS0FBSyxFQUFFLGlCQUFpQkQsSUFBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLE1BQU0sQ0FBQyxFQUFFLGFBQWEsVUFBVSxLQUFLLEVBQUUsYUFBYSxhQUFhLE1BQU0sTUFBTTtBQUMvSDtBQUNBLElBQUksS0FBQSxHQUFJRSxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUcsYUFBYSxHQUFHLFFBQVEsR0FBRyxRQUFRLEdBQUcsWUFBWSxJQUFJLENBQUMsR0FBRyxZQUFZLElBQUksQ0FBQyxHQUFHLGdCQUFnQixHQUFHLHNCQUFzQixJQUFJLENBQUMsR0FBRyxlQUFlLElBQUksQ0FBQyxHQUFHLHNCQUFzQixHQUFHLFlBQVksSUFBSSxVQUFVLFdBQVcsSUFBSSxJQUFJLG1CQUFtQixJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxzQkFBc0IsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxXQUFXLEdBQUcsVUFBVSxHQUFHLFVBQVUsR0FBRyxHQUFHLEtBQUssR0FBRztDQUNsYixJQUFJLEtBQUEsR0FBSUMsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxJQUFJLHlCQUFBLEdBQXdCQyxhQUFBQSxNQUFBQSxDQUFFLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUksK0JBQUEsR0FBOEJBLGFBQUFBLE1BQUFBLENBQUUsQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSSxFQUFFLG9CQUFvQixJQUFJLEVBQUUscUJBQXFCLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxNQUFNLENBQUMsQ0FBQyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJLE1BQU0sSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDcnFCLFFBQUEsR0FBT0MsYUFBQUEsVUFBQUEsT0FBUTtFQUNkLElBQUksSUFBSSxFQUFFO0VBQ1YsSUFBSSxDQUFDLEdBQUc7RUFDUixJQUFJLEVBQUUsVUFBVSxTQUFTLHlCQUF5QixjQUFjLFNBQVMsZ0JBQWdCLE1BQU0sR0FBRyxJQUFJO0dBQ3JHLElBQUksSUFBSSxFQUFFLGNBQWMsQ0FBQztHQUN6QixJQUFJLEdBQUcsT0FBTyxFQUFFLE1BQU0sU0FBUztJQUM5QixFQUFFLFNBQVMsTUFBTSxHQUFHLEVBQUUsVUFBVTtHQUNqQztFQUNELFFBQVEsQ0FBQztFQUNULElBQUksSUFBSUosS0FBRSxDQUFDO0VBQ1gsT0FBTyxFQUFFLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNLElBQUksRUFBRSxNQUFNLFNBQVM7R0FDckQsRUFBRSxTQUFTLE1BQU0sR0FBRyxFQUFFLFVBQVU7RUFDakM7Q0FDRCxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87RUFDakMsV0FBVztFQUNYLE1BQU07RUFDTixVQUFVLE1BQU07R0FDZixDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsaUJBQWlCLElBQUk7RUFDM0M7RUFDQSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxXQUFXO0dBQ3RDLE1BQU0sTUFBTTtJQUNYLElBQUksRUFBRSxVQUFVLEdBQUcsT0FBTyxLQUFLLFlBQVk7S0FDMUMsRUFBRSxDQUFDO0tBQ0g7SUFDRDtJQUNBLE1BQU0sRUFBRSxVQUFVO0dBQ25CO0dBQ0EsV0FBVztHQUNYLE1BQU07R0FDTixjQUFjO0dBQ2QsbUJBQW1CO0dBQ25CLG9CQUFvQjtHQUNwQixVQUFVLEtBQUs7R0FDZixZQUFZLE1BQU07SUFDakIsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLGtCQUFrQjtJQUNoQyxJQUFJLEVBQUUsUUFBUSxZQUFZLEdBQUc7S0FDNUIsRUFBRSxlQUFlLEdBQUcsSUFBSTtLQUN4QjtJQUNEO0lBQ0EsSUFBSSxFQUFFLFFBQVEsU0FBUyxDQUFDLEVBQUUsU0FBUztJQUNuQyxJQUFJLElBQUlBLEtBQUUsRUFBRSxPQUFPO0lBQ25CLElBQUksRUFBRSxXQUFXLEdBQUc7S0FDbkIsRUFBRSxlQUFlLEdBQUcsRUFBRSxRQUFRLE1BQU07S0FDcEM7SUFDRDtJQUNBLElBQUksSUFBSSxTQUFTLGVBQWUsSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsU0FBUztJQUMzRCxJQUFJLEVBQUUsVUFBVTtLQUNmLENBQUMsQ0FBQyxLQUFLLE1BQU0sS0FBSyxDQUFDLEVBQUUsUUFBUSxTQUFTLENBQUMsT0FBTyxFQUFFLGVBQWUsR0FBRyxFQUFFLE1BQU07S0FDMUU7SUFDRDtJQUNBLENBQUMsQ0FBQyxLQUFLLE1BQU0sS0FBSyxDQUFDLEVBQUUsUUFBUSxTQUFTLENBQUMsT0FBTyxFQUFFLGVBQWUsR0FBRyxFQUFFLE1BQU07R0FDM0U7R0FDQSxHQUFHO0dBQ0gsVUFBVTtJQUNULElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7S0FDL0IsV0FBVztLQUNYLFVBQVUsTUFBTSxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO01BQzNDLFdBQVc7TUFDWCxJQUFJO01BQ0osVUFBVTtLQUNYLENBQUMsSUFBSTtJQUNOLENBQUMsSUFBSTtJQUNMLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDNUIsSUFBSTtLQUNKLFdBQVc7S0FDWCxVQUFVO0lBQ1gsQ0FBQyxJQUFJO0lBQ1csaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUN4QixXQUFXO0tBQ1gsVUFBVTtJQUNYLENBQUM7SUFDRCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0tBQy9CLFdBQVc7S0FDWCxVQUFVO0lBQ1gsQ0FBQyxJQUFJO0dBQ047RUFDRCxDQUFDO0NBQ0YsQ0FBQztBQUNGLENBQUM7QUFDRCxFQUFFLGNBQWM7OztBQ3JGaEIsU0FBU0ssS0FBRSxHQUFHO0NBQ2IsT0FBTyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUU7QUFDbkM7QUFDQSxTQUFTQyxLQUFFLEdBQUcsR0FBRztDQUNoQixPQUFPLEVBQUUsU0FBUyxRQUFRO0FBQzNCO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUcsR0FBRztDQUNuQixPQUFPLEtBQUssTUFBTSxRQUFRLE1BQU07QUFDakM7QUFHQSxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxPQUFPLEdBQUcsY0FBYyxHQUFHLFdBQVcsSUFBSSxDQUFDLEdBQUcsV0FBVyxJQUFJLFFBQVEsV0FBVyxJQUFJLElBQUksVUFBVSxHQUFHLGVBQWUsR0FBRyxJQUFJLEdBQUcsVUFBVSxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQ3pMLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLHdCQUF3QixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUN4RTtFQUNBLElBQUksbUNBQW1DO0VBQ3ZDO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSUYsSUFBRSxHQUFHLEdBQUcsQ0FBQztDQUMxQyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO0VBQ2xDLEtBQUs7RUFDTCxJQUFJO0VBQ0osV0FBVztFQUNYLFVBQVU7RUFDVixPQUFPLEtBQUssS0FBSztFQUNqQixjQUFjLEtBQUssS0FBSztFQUN4QixXQUFXLE1BQU07R0FDaEIsSUFBSSxJQUFJLEVBQUUsT0FBTyxVQUFVLEtBQUssT0FBTyxFQUFFLE9BQU87R0FDaEQsSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7RUFDakI7RUFDQSxHQUFHO0VBQ0gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7R0FDMUMsT0FBTztHQUNQLFVBQVUsQ0FBQztHQUNYLFVBQVU7RUFDWCxDQUFDLElBQUksTUFBTSxFQUFFLEtBQUssR0FBRyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0dBQ3RELE9BQU8sRUFBRTtHQUNULFVBQVUsRUFBRTtHQUNaLFVBQVVGLEtBQUUsQ0FBQztFQUNkLEdBQUdDLEtBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQ2IsQ0FBQztBQUNGLENBQUM7QUFDRCxFQUFFLGNBQWM7OztBQ3ZDaEIsU0FBU0ksSUFBRSxHQUFHO0NBQ2IsT0FBTyxDQUFDLEVBQUUsS0FBSyxVQUFVLEtBQUssRUFBRSxTQUFTO0FBQzFDO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxFQUFFLFNBQVMsRUFBRSxZQUFZO0FBQ2pDO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUc7Q0FDaEIsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLFFBQVE7QUFDdEM7QUFHQSxTQUFTLEVBQUUsRUFBRSxPQUFPLElBQUksUUFBUSxnQkFBZ0IsR0FBRyxrQkFBa0IsR0FBRyxXQUFXLElBQUksU0FBUyxPQUFPLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksZUFBZSxJQUFJLElBQUksZUFBZSxJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxJQUFJLEdBQUcsY0FBYyxHQUFHLEdBQUcsS0FBSztDQUNuUSxJQUFJLENBQUMsR0FBRyxNQUFBLEdBQUtDLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsS0FBQSxHQUFJQyxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxLQUFBLEdBQUlBLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLHdCQUF3QixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSSxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDOWIsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFRO0VBQ1AsSUFBSSxLQUFLLE1BQU07R0FDZCxFQUFFLGtCQUFrQixRQUFRLEVBQUUsV0FBVyxDQUFDLEVBQUUsUUFBUSxTQUFTLEVBQUUsTUFBTSxLQUFLLEVBQUUsV0FBVyxDQUFDLEVBQUUsUUFBUSxTQUFTLEVBQUUsTUFBTSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0VBQzdILEdBQUcsS0FBSyxNQUFNO0dBQ2IsRUFBRSxRQUFRLFlBQVksRUFBRSxDQUFDLENBQUM7RUFDM0I7RUFDQSxPQUFPLFNBQVMsaUJBQWlCLGVBQWUsQ0FBQyxHQUFHLFNBQVMsaUJBQWlCLFdBQVcsQ0FBQyxTQUFTO0dBQ2xHLFNBQVMsb0JBQW9CLGVBQWUsQ0FBQyxHQUFHLFNBQVMsb0JBQW9CLFdBQVcsQ0FBQztFQUMxRjtDQUNELEdBQUcsQ0FBQyxDQUFDLElBQUEsR0FBR0MsYUFBQUEsZ0JBQUFBLE9BQVE7RUFDZixJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsU0FBUztFQUN0QixJQUFJLFVBQVU7R0FDYixJQUFJLElBQUksRUFBRSxTQUFTLHNCQUFzQixHQUFHLElBQUksRUFBRTtHQUNsRCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUc7R0FDZCxJQUFJLElBQUksRUFBRSxPQUFPLElBQUksT0FBTyxhQUFhLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxFQUFFLFFBQVEsSUFBSSxFQUFFLE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLEtBQUssSUFBSSxHQUFHLEVBQUUsU0FBUyxFQUFFO0dBQ3RKLEVBQUUsTUFBTSxXQUFXLFNBQVMsRUFBRSxNQUFNLE1BQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLE9BQU8sR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLFFBQVEsUUFBUSxFQUFFLE1BQU0sV0FBVyxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sYUFBYTtFQUN4SjtFQUNBLE9BQU8sRUFBRSxZQUFZLEVBQUUsUUFBUSxNQUFNLGFBQWEsV0FBVyxFQUFFLEdBQUcsT0FBTyxpQkFBaUIsVUFBVSxDQUFDLEdBQUcsT0FBTyxpQkFBaUIsVUFBVSxHQUFHLENBQUMsQ0FBQyxTQUFTO0dBQ3ZKLE9BQU8sb0JBQW9CLFVBQVUsQ0FBQyxHQUFHLE9BQU8sb0JBQW9CLFVBQVUsR0FBRyxDQUFDLENBQUM7RUFDcEY7Q0FDRCxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDVCxJQUFJLEtBQUssR0FBRyxNQUFNO0VBQ2pCLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLFVBQVU7R0FDdEIsRUFBRSxlQUFlO0dBQ2pCO0VBQ0Q7RUFDQSxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsV0FBVyxHQUFHLENBQUM7Q0FDN0I7Q0FDQSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtHQUN0QyxLQUFLO0dBQ0wsTUFBTTtHQUNOLFdBQVc7R0FDWCxpQkFBaUI7R0FDakIsaUJBQWlCO0dBQ2pCLGNBQWMsS0FBSztHQUNuQixlQUFlLEdBQUcsTUFBTSxDQUFDLENBQUM7R0FDMUIsVUFBVSxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRUMsbUJBQUFBLFVBQUcsRUFBRSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDMUUsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDN0IsV0FBVztJQUNYLGVBQWU7SUFDZixVQUFVO0dBQ1gsQ0FBQyxDQUFDLEVBQUUsQ0FBQztFQUNOLENBQUMsR0FBRyxLQUFLLE9BQU8sV0FBVyxPQUFBLEdBQU1DLGlCQUFBQSxhQUFBQSxDQUFrQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQzNELEtBQUs7R0FDTCxJQUFJO0dBQ0osV0FBVztHQUNYLGNBQWM7R0FDZCxVQUFVLEVBQUUsS0FBSyxHQUFHLE1BQU07SUFDekIsSUFBSVIsSUFBRSxDQUFDLEdBQUcsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUN6QyxXQUFXO0tBQ1gsTUFBTTtLQUNOLGVBQWU7SUFDaEIsR0FBRyxXQUFXLEdBQUc7SUFDakIsSUFBSSxJQUFJQyxJQUFFLENBQUMsR0FBRyxJQUFJO0tBQ2pCO0tBQ0EsRUFBRSxXQUFXLHlDQUF5QztLQUN0RCxFQUFFLFNBQVMsdUNBQXVDO0lBQ25ELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUk7S0FDaEMsV0FBVztLQUNYLGlCQUFpQixFQUFFLFlBQVksS0FBSztJQUNyQztJQUNBLE9BQU8sRUFBRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLO0tBQ3RDLEdBQUc7S0FDSCxNQUFNLEVBQUUsV0FBVyxLQUFLLElBQUksRUFBRTtLQUM5QixVQUFVLE1BQU0sRUFBRSxHQUFHLENBQUM7S0FDdEIsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVc7TUFDWCxVQUFVO0tBQ1gsQ0FBQyxHQUFHLEVBQUUsY0FBOEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUM3QyxXQUFXO01BQ1gsVUFBVSxFQUFFO0tBQ2IsQ0FBQyxJQUFJLElBQUk7SUFDVixHQUFHQyxJQUFFLEdBQUcsQ0FBQyxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7S0FDekMsTUFBTTtLQUNOLFdBQVc7S0FDWCxVQUFVLEVBQUU7S0FDWixVQUFVLE1BQU0sRUFBRSxHQUFHLENBQUM7S0FDdEIsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVc7TUFDWCxVQUFVO0tBQ1gsQ0FBQyxHQUFHLEVBQUUsY0FBOEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUM3QyxXQUFXO01BQ1gsVUFBVSxFQUFFO0tBQ2IsQ0FBQyxJQUFJLElBQUk7SUFDVixHQUFHQSxJQUFFLEdBQUcsQ0FBQyxDQUFDO0dBQ1gsQ0FBQztFQUNGLENBQUMsR0FBRyxTQUFTLElBQUksSUFBSSxJQUFJO0NBQzFCLENBQUM7QUFDRjs7O0FDNUdBLElBQUlPLE1BQUk7Q0FDUCxPQUFPO0NBQ1AsTUFBTTtDQUNOLEtBQUs7Q0FDTCxRQUFRO0FBQ1Q7QUFBR0MsSUFBQUEsT0FBQUEsR0FBSUMsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsT0FBTyxJQUFJLFlBQVksZUFBZSxJQUFJLFNBQVMsV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksR0FBRyxVQUFVLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDeEssSUFBSSxLQUFBLEdBQUlDLGFBQUFBLE1BQUFBLENBQUUsR0FBRyxJQUFJLEtBQUssb0JBQW9CLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJO0VBQ3BFO0VBQ0EsSUFBSSwrQkFBK0I7RUFDbkNILElBQUUsTUFBTUEsSUFBRTtFQUNWO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDdEosT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsU0FBUztFQUNqQyxXQUFXO0VBQ1gsU0FBUztFQUNULFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztHQUNyQyxLQUFLO0dBQ0wsSUFBSTtHQUNKLFdBQVc7R0FDWCxNQUFNO0dBQ04sVUFBVTtHQUNWLEdBQUc7RUFDSixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7R0FDN0IsV0FBVztHQUNYLFVBQVU7RUFDWCxDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYztBQUdoQixJQUFJSSxNQUFJO0NBQ1AsT0FBTztDQUNQLE1BQU07Q0FDTixLQUFLO0NBQ0wsUUFBUTtBQUNUO0FBR0EsU0FBU0MsSUFBRSxFQUFFLE9BQU8sSUFBSSxnQkFBZ0IsZUFBZSxJQUFJLFNBQVMsV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksR0FBRyxHQUFHLEtBQUs7Q0FDckosSUFBSSxJQUFJLEVBQUUsYUFBYSxDQUFDLEdBQUcsS0FBQSxHQUFJRixhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLHVCQUF1QixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUM5RjtFQUNBLElBQUksa0NBQWtDO0VBQ3RDQyxJQUFFLE1BQU1BLElBQUU7RUFDVjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQzVKLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7RUFDakMsV0FBVztFQUNYLFNBQVM7RUFDVCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDckMsSUFBSTtHQUNKLFdBQVc7R0FDWCxNQUFNO0dBQ04sR0FBRztFQUNKLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtHQUM3QixXQUFXO0dBQ1gsVUFBVTtFQUNYLENBQUMsQ0FBQztDQUNILENBQUM7QUFDRjtBQUdBLElBQUlFLE9BQUFBLEdBQUlKLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxPQUFPLEdBQUcsV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksR0FBRyxNQUFNLElBQUksR0FBRyxRQUFRLElBQUksWUFBWSxHQUFHLEtBQUssTUFBTTtDQUNuSixJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxvQkFBb0IsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUNqUCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLFdBQVc7RUFDWCxVQUFVLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztHQUN6QyxXQUFXO0dBQ1gsU0FBUztHQUNULFVBQVU7RUFDWCxDQUFDLElBQUksTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsWUFBWTtHQUN4QyxLQUFLO0dBQ0wsSUFBSTtHQUNKLFdBQVc7R0FDWCxNQUFNO0dBQ04sZUFBZTtHQUNmLEdBQUc7RUFDSixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYztBQUdoQixJQUFJSSxNQUFJO0NBQ1AsTUFBTTtDQUNOLEtBQUs7Q0FDTCxNQUFNO0FBQ1A7QUFBR0MsSUFBQUEsT0FBQUEsR0FBSU4sYUFBQUEsV0FBQUEsRUFBRyxFQUFFLE9BQU8sR0FBRyxlQUFlLElBQUksT0FBTyxXQUFXLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksSUFBSSxHQUFHLE1BQU0sSUFBSSxRQUFRLEdBQUcsS0FBSyxNQUFNO0NBQ3pKLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLG1CQUFtQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUNuRTtFQUNBLElBQUlJLElBQUUsTUFBTUEsSUFBRSxNQUFNO0VBQ3BCO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDcEosT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDekMsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0VBQ1gsQ0FBQyxJQUFJLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDckMsS0FBSztHQUNMLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLEdBQUc7RUFDSixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYztBQUdoQixTQUFTRSxJQUFFLEdBQUc7Q0FDYixPQUFPLE9BQU8sS0FBSyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxRQUFRLENBQUM7QUFDdkQ7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPLENBQUMsS0FBSyxFQUFFLFNBQVMsWUFBWSxDQUFDRCxJQUFFLEVBQUUsVUFBVSxJQUFJLENBQUMsSUFBSSxPQUFPLFlBQVksT0FBTyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsT0FBTyxDQUFDLEdBQUdFLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2STtBQUNBLFNBQVNBLElBQUUsR0FBRztDQUNiLElBQUksQ0FBQyxLQUFLLENBQUNGLElBQUUsQ0FBQyxHQUFHLE9BQU87Q0FDeEIsSUFBSSxFQUFFLFlBQVksS0FBSyxHQUFHLE9BQU8sRUFBRTtDQUNuQyxJQUFJLE1BQU0sUUFBUSxFQUFFLElBQUksS0FBSyxFQUFFLEtBQUssU0FBUyxHQUFHLE9BQU8sRUFBRSxLQUFLO0NBQzlELFFBQVEsRUFBRSxNQUFWO0VBQ0MsS0FBSyxXQUFXLE9BQU8sQ0FBQztFQUN4QixLQUFLO0VBQ0wsS0FBSyxVQUFVLE9BQU87RUFDdEIsS0FBSyxVQUFVLE9BQU9DLElBQUUsQ0FBQztFQUN6QixTQUFTLE9BQU87Q0FDakI7QUFDRDtBQUNBLFNBQVNFLElBQUUsR0FBRyxHQUFHO0NBQ2hCLElBQUksQ0FBQyxLQUFLLENBQUNILElBQUUsQ0FBQyxHQUFHLE9BQU87Q0FDeEIsSUFBSSxFQUFFLFNBQVMsWUFBWUEsSUFBRSxFQUFFLFVBQVUsR0FBRztFQUMzQyxJQUFJLElBQUlBLElBQUUsQ0FBQyxJQUFJLElBQUksQ0FBQztFQUNwQixPQUFPLE9BQU8sWUFBWSxPQUFPLFFBQVEsRUFBRSxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUFPLENBQUMsR0FBR0csSUFBRSxHQUFHLEVBQUUsT0FBTyxLQUFLLElBQUlELElBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztDQUNqSDtDQUNBLElBQUksRUFBRSxTQUFTLFdBQVcsT0FBTyxNQUFNLENBQUM7Q0FDeEMsSUFBSSxFQUFFLFNBQVMsV0FBVztFQUN6QixJQUFJLE1BQU0sTUFBTSxLQUFLLE1BQU0sT0FBTztFQUNsQyxJQUFJLElBQUksT0FBTyxTQUFTLE9BQU8sQ0FBQyxHQUFHLEVBQUU7RUFDckMsT0FBTyxPQUFPLE1BQU0sQ0FBQyxJQUFJLEtBQUs7Q0FDL0I7Q0FDQSxJQUFJLEVBQUUsU0FBUyxVQUFVO0VBQ3hCLElBQUksTUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPO0VBQ2xDLElBQUksSUFBSSxPQUFPLFdBQVcsT0FBTyxDQUFDLENBQUM7RUFDbkMsT0FBTyxPQUFPLE1BQU0sQ0FBQyxJQUFJLEtBQUs7Q0FDL0I7Q0FDQSxPQUFPLEtBQUs7QUFDYjtBQUNBLFNBQVNFLElBQUUsR0FBRztDQUNiLE9BQU8sQ0FBQyxLQUFLLENBQUNKLElBQUUsQ0FBQyxJQUFJLFlBQVksTUFBTSxRQUFRLEVBQUUsSUFBSSxLQUFLLEVBQUUsS0FBSyxTQUFTLElBQUksVUFBVSxFQUFFLFNBQVMsV0FBVyxFQUFFLGNBQWMsS0FBSyxLQUFLLEVBQUUsWUFBWSxLQUFLLGFBQWEsWUFBWSxFQUFFLFNBQVMsWUFBWSxRQUFRLEVBQUUsU0FBUyxXQUFXLE9BQU8sRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDLFlBQVksTUFBTSxZQUFZLFlBQVksV0FBVyxFQUFFLFNBQVMsWUFBWSxTQUFTO0FBQ3RWO0FBR0EsSUFBSUssTUFBSTtDQUNQLE1BQU07Q0FDTixZQUFZLENBQUM7QUFDZDtBQUNBLFNBQVNDLElBQUUsRUFBRSxRQUFRLEdBQUcsTUFBTSxHQUFHLE9BQU8sR0FBRyxVQUFVLEtBQUs7Q0FDekQsSUFBSSxJQUFJLEVBQUUsU0FBUyxHQUFHLElBQUksRUFBRSxhQUFhLElBQUlGLElBQUUsQ0FBQyxHQUFHLElBQUksS0FBS0YsSUFBRSxDQUFDO0NBQy9ELElBQUksTUFBTSxTQUFTO0VBQ2xCLElBQUksSUFBSSxNQUFNLFFBQVEsRUFBRSxJQUFJLElBQUksRUFBRSxPQUFPLENBQUM7RUFDMUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsWUFBWTtHQUNwQyxXQUFXO0dBQ1gsVUFBVTtJQUNPLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7S0FDM0IsV0FBVztLQUNYLFVBQVU7SUFDWCxDQUFDO0lBQ0QsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsS0FBSztLQUMxQixXQUFXO0tBQ1gsVUFBVTtJQUNYLENBQUMsSUFBSTtJQUNXLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDeEIsV0FBVztLQUNYLFVBQVUsRUFBRSxLQUFLLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFTixLQUFHO01BQzNDLE9BQU8sT0FBTyxDQUFDO01BQ2YsTUFBTTtNQUNOLFNBQVMsTUFBTTtNQUNmLGdCQUFnQixFQUFFLENBQUM7S0FDcEIsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ2QsQ0FBQztHQUNGO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsT0FBTyxNQUFNLGFBQTZCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFQyxLQUFHO0VBQzlDLE9BQU87RUFDUCxNQUFNO0VBQ04sT0FBTyxPQUFPLEtBQUssRUFBRTtFQUNyQixhQUFhLE9BQU8sRUFBRSxXQUFXLEVBQUU7RUFDbkMsV0FBVyxNQUFNLEVBQUUsRUFBRSxPQUFPLEtBQUs7Q0FDbEMsQ0FBQyxJQUFJLE1BQU0sU0FBeUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVMLEtBQUc7RUFDeEMsT0FBTztFQUNQLFNBQVMsTUFBTSxDQUFDO0VBQ2hCLFdBQVcsTUFBTSxFQUFFLEVBQUUsT0FBTyxPQUFPO0NBQ3BDLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVPLEtBQUc7RUFDekIsT0FBTztFQUNQLE1BQU0sTUFBTSxTQUFTLE1BQU0sYUFBYSxNQUFNLFdBQVcsV0FBVztFQUNwRSxNQUFNLE1BQU0sUUFBUSxJQUFJLE1BQU0sYUFBYSxNQUFNLFdBQVcsUUFBUSxLQUFLO0VBQ3pFLE9BQU8sT0FBTyxLQUFLLEVBQUU7RUFDckIsYUFBYSxPQUFPLEVBQUUsV0FBVyxFQUFFO0VBQ25DLFdBQVcsTUFBTTtHQUNoQixJQUFJLElBQUksRUFBRSxPQUFPO0dBQ2pCLElBQUksTUFBTSxPQUFPO0lBQ2hCLEVBQUUsTUFBTSxLQUFLLEtBQUssT0FBTyxTQUFTLEdBQUcsRUFBRSxDQUFDO0lBQ3hDO0dBQ0Q7R0FDQSxJQUFJLE1BQU0sYUFBYSxNQUFNLFVBQVU7SUFDdEMsRUFBRSxNQUFNLEtBQUssS0FBSyxPQUFPLFdBQVcsQ0FBQyxDQUFDO0lBQ3RDO0dBQ0Q7R0FDQSxFQUFFLENBQUM7RUFDSjtDQUNELENBQUM7QUFDRjtBQUNBLElBQUksS0FBQSxHQUFJTixhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxRQUFRLEdBQUcsT0FBTyxHQUFHLFVBQVUsR0FBRyxXQUFXLElBQUksSUFBSSxJQUFJLEdBQUcsVUFBVSxJQUFJLENBQUMsR0FBRyxHQUFHLEtBQUssR0FBRztDQUM3RyxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyx1QkFBdUIsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUksS0FBSyxFQUFFLFNBQVMsV0FBVyxJQUFJVyxLQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtFLGFBQUFBLFNBQUFBLE9BQVFKLElBQUUsR0FBRyxLQUFLRixJQUFFLENBQUMsQ0FBQyxDQUFDO0NBQzFJLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLEVBQUVFLElBQUUsR0FBRyxLQUFLRixJQUFFLENBQUMsQ0FBQyxDQUFDO0NBQ2xCLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztDQUNULElBQUksSUFBSUQsSUFBRSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxFQUFFLFNBQVMsZ0JBQWdCLElBQUksRUFBRSxhQUFhLElBQUk7RUFDNUU7RUFDQSxJQUFJLGtDQUFrQztFQUN0QztDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssTUFBTTtFQUN2QyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7Q0FDWjtDQUNBLE9BQU8sSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUNuQyxLQUFLO0VBQ0wsSUFBSTtFQUNKLFdBQVc7RUFDWCxpQkFBaUI7RUFDakIsR0FBRztFQUNILFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztHQUNuQyxXQUFXO0dBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQ25DLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxHQUFHLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDaEMsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLElBQUksSUFBSTtFQUNWLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztHQUM1QixXQUFXO0dBQ1gsVUFBVSxPQUFPLFFBQVEsRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNyRixXQUFXO0lBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVNLEtBQUc7S0FDOUIsUUFBUTtLQUNSLE1BQU07S0FDTixPQUFPLEVBQUU7S0FDVCxXQUFXLE1BQU0sRUFBRTtNQUNsQixHQUFHO09BQ0YsSUFBSUgsSUFBRSxHQUFHLENBQUM7S0FDWixDQUFDO0lBQ0YsQ0FBQztHQUNGLEdBQUcsQ0FBQyxDQUFDO0VBQ04sQ0FBQyxDQUFDO0NBQ0gsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQzdCLEtBQUs7RUFDTCxJQUFJO0VBQ0osV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87R0FDbkMsV0FBVztHQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNuQyxXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsR0FBRyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQ2hDLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxJQUFJLElBQUk7RUFDVixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDNUIsV0FBVztHQUNYLFVBQVUsT0FBTyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDckYsV0FBVztJQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFRyxLQUFHO0tBQzlCLFFBQVE7S0FDUixNQUFNO0tBQ04sT0FBTyxFQUFFO0tBQ1QsV0FBVyxNQUFNLEVBQUU7TUFDbEIsR0FBRztPQUNGLElBQUlILElBQUUsR0FBRyxDQUFDO0tBQ1osQ0FBQztJQUNGLENBQUM7R0FDRixHQUFHLENBQUMsQ0FBQztFQUNOLENBQUMsQ0FBQztDQUNILENBQUM7QUFDRixDQUFDO0FBQ0QsRUFBRSxjQUFjOzs7QUMvUmhCLFNBQVNLLEtBQUUsR0FBRztDQUNiLE9BQU8sS0FBSyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBQSxDQUFHLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxXQUFXLEdBQUcsSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7QUFDNUo7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLEdBQUcsSUFBSUQsS0FBRSxDQUFDO0NBQ3hGLE9BQU8sQ0FBQyxtQkFBRyxJQUFJLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNqQztBQUNBLFNBQVNFLElBQUUsR0FBRyxHQUFHO0NBQ2hCLElBQUksSUFBSSxFQUFFLEtBQUssWUFBWSxHQUFHLEtBQUssRUFBRSxRQUFRLEdBQUEsQ0FBSSxZQUFZO0NBQzdELE9BQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLFNBQVMsSUFBSSxJQUFJLEVBQUUsV0FBVyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLFdBQVcsR0FBRyxJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUksTUFBTTtBQUN2SDtBQUNBLFNBQVNDLElBQUUsR0FBRyxHQUFHO0NBQ2hCLElBQUksRUFBRSxXQUFXLEdBQUcsT0FBTztFQUMxQixlQUFlO0VBQ2YsZUFBZSxDQUFDO0NBQ2pCO0NBQ0EsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7Q0FDakIsS0FBSyxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUUsTUFBTSxNQUFNRCxJQUFFLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFBLENBQUcsS0FBSyxDQUFDO0NBQ3hELE9BQU87RUFDTixlQUFlO0VBQ2YsZUFBZTtDQUNoQjtBQUNEO0FBR0EsU0FBUyxFQUFFLEVBQUUsT0FBTyxJQUFJLHlDQUF5QyxhQUFhLElBQUksbUVBQW1FLFFBQVEsSUFBSSxJQUFJLFlBQVksSUFBSSxDQUFDLEdBQUcsVUFBVSxJQUFJLENBQUMsR0FBRyxVQUFVLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxzQkFBc0IsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsaUJBQWlCLEdBQUcsR0FBRyxLQUFLO0NBQ25aLElBQUksS0FBQSxHQUFJRSxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLHNCQUFzQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssS0FBQSxHQUFJQyxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQyxhQUFBQSxTQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLElBQUlMLElBQUUsR0FBRyxDQUFDLEdBQUcsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLEtBQUssR0FBRyxJQUFJLEtBQUssR0FBRyxJQUFJO0VBQ3pKO0VBQ0EsSUFBSSxpQ0FBaUM7RUFDckMsSUFBSSxrQ0FBa0M7RUFDdEM7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxNQUFNO0VBQ25YLElBQUksRUFBRSxlQUFlLEdBQUcsZUFBZSxNQUFNRSxJQUFFLE1BQU0sS0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7RUFDckUsSUFBSTtHQUNILGVBQWU7R0FDZixlQUFlO0dBQ2YsUUFBUTtFQUNULENBQUM7Q0FDRixHQUFHLFVBQVU7RUFDWixLQUFLLEVBQUUsU0FBUyxNQUFNO0NBQ3ZCLEdBQUcsS0FBSyxNQUFNO0VBQ2IsRUFBRSxFQUFFLE9BQU8sT0FBTyxPQUFPLEdBQUcsRUFBRSxPQUFPLFFBQVE7Q0FDOUMsR0FBRyxLQUFLLE1BQU07RUFDYixFQUFFLGVBQWUsR0FBRyxLQUFLLEVBQUUsQ0FBQyxDQUFDO0NBQzlCLEdBQUcsS0FBSyxNQUFNO0VBQ2IsRUFBRSxlQUFlLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDO0NBQ3pELEdBQUcsS0FBSyxNQUFNO0VBQ2IsRUFBRSxlQUFlLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFLGFBQWEsT0FBTyxNQUFNO0NBQ2hFLEdBQUcsS0FBSyxNQUFNO0VBQ2IsQ0FBQyxFQUFFLFFBQVEsV0FBVyxFQUFFLFFBQVEsU0FBUyxFQUFFLGVBQWUsR0FBRyxFQUFFO0NBQ2hFO0NBQ0EsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsR0FBRztFQUNILFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87R0FDbEMsV0FBVztHQUNYLE1BQU07R0FDTixVQUFVLElBQUksS0FBSztHQUNuQixjQUFjO0dBQ2QsaUJBQWlCLElBQUksU0FBUyxLQUFLO0dBQ25DLFNBQVM7R0FDVCxXQUFXO0dBQ1gsWUFBWTtHQUNaLGFBQWE7R0FDYixRQUFRO0dBQ1IsVUFBVTtJQUNPLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7S0FDMUIsS0FBSztLQUNMLElBQUk7S0FDSixXQUFXO0tBQ1gsTUFBTTtLQUNOLFFBQVE7S0FDUixVQUFVO0tBQ1YsVUFBVTtLQUNWLGNBQWM7S0FDZCxPQUFPO0tBQ1AsVUFBVTtJQUNYLENBQUM7SUFDZSxpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0tBQ3hCLFdBQVc7S0FDWCxVQUFVO01BQ08saUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtPQUN6QixXQUFXO09BQ1gsVUFBVTtNQUNYLENBQUM7TUFDRCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO09BQzdCLFdBQVc7T0FDWCxVQUFVO01BQ1gsQ0FBQyxJQUFJO01BQ1csaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsUUFBUTtPQUN6QixXQUFXO09BQ1gsVUFBVSxDQUFDLEVBQUUsU0FBUyxJQUFJLGFBQWEsRUFBRSxLQUFLLElBQUksTUFBTSx1QkFBdUIsSUFBSSxzQkFBc0IsZ0JBQWdCO01BQzFILENBQUM7S0FDRjtJQUNELENBQUM7SUFDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0tBQzNCLE1BQU07S0FDTixXQUFXO0tBQ1gsVUFBVTtLQUNWLFVBQVUsTUFBTTtNQUNmLEVBQUUsZ0JBQWdCLEdBQUcsRUFBRTtLQUN4QjtLQUNBLFVBQVU7SUFDWCxDQUFDO0dBQ0Y7RUFDRCxDQUFDO0NBQ0YsQ0FBQztBQUNGOzs7QUMzR0EsU0FBU0ksSUFBRSxFQUFFLGNBQWMsR0FBRyxVQUFVLEdBQUcsYUFBYSxHQUFHLG1CQUFtQixHQUFHLFVBQVUsR0FBRyxvQkFBb0IsR0FBRyxrQkFBa0IsR0FBRyxhQUFhLEdBQUcsbUJBQW1CLEtBQUs7Q0FDakwsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsTUFBTTtFQUNOLGNBQWM7RUFDZCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7R0FDdEMsTUFBTTtHQUNOLFdBQVc7R0FDWCxTQUFTO0dBQ1QsY0FBYyxJQUFJLG1CQUFtQjtHQUNyQyxPQUFPLElBQUksbUJBQW1CO0dBQzlCLFVBQVUsSUFBSSxNQUFNO0VBQ3JCLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxLQUFLLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87R0FDL0MsV0FBVztHQUNYLGdCQUFnQixFQUFFO0dBQ2xCLFVBQVUsQ0FBQyxFQUFFLFNBQXlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDOUMsV0FBVztJQUNYLFVBQVUsRUFBRTtHQUNiLENBQUMsR0FBRyxFQUFFLE1BQU0sS0FBSyxNQUFNO0lBQ3RCLElBQUksSUFBSSxFQUFFLEVBQUUsUUFBUSxFQUFFLElBQUksSUFBSSxFQUFFLFNBQVMsUUFBUSxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksRUFBRSxpQkFBaUIsNEJBQTRCLEVBQUU7SUFDbkgsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtLQUNsQyxNQUFNO0tBQ04sV0FBVztNQUNWO01BQ0EsSUFBSSxnQ0FBZ0M7TUFDcEMsSUFBSSxrQ0FBa0M7S0FDdkMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0tBQzFCLFVBQVU7S0FDVixlQUFlLEVBQUUsR0FBRyxFQUFFLEVBQUU7S0FDeEIscUJBQXFCLEVBQUUsR0FBRyxFQUFFLEVBQUU7S0FDOUIsZUFBZSxJQUFJLFNBQVM7S0FDNUIsYUFBYSxFQUFFO0tBQ2YsT0FBTyxJQUFJLElBQUksRUFBRTtLQUNqQixVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDcEMsV0FBVyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7TUFDbEQsZUFBZTtLQUNoQixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDN0IsV0FBVztNQUNYLFVBQVUsRUFBRTtLQUNiLENBQUMsQ0FBQztJQUNILEdBQUcsRUFBRSxFQUFFO0dBQ1IsQ0FBQyxDQUFDO0VBQ0gsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0NBQ1YsQ0FBQztBQUNGO0FBR0EsSUFBSUMsTUFBSTtDQUNQLElBQUk7Q0FDSixPQUFPO0NBQ1AsT0FBTztFQUNOO0dBQ0MsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sVUFBVTtFQUNYO0VBQ0E7R0FDQyxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixVQUFVO0VBQ1g7RUFDQTtHQUNDLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLFVBQVU7RUFDWDtFQUNBO0dBQ0MsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sVUFBVTtFQUNYO0VBQ0E7R0FDQyxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07RUFDUDtDQUNEO0FBQ0Q7QUFBR0MsSUFBQUEsTUFBSSxDQUFDRCxHQUFDO0FBQUdFLElBQUFBLE1BQUk7Q0FDZixJQUFJO0NBQ0osT0FBTztDQUNQLE9BQU87RUFDTjtHQUNDLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLFVBQVU7RUFDWDtFQUNBO0dBQ0MsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sVUFBVTtFQUNYO0VBQ0E7R0FDQyxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixVQUFVO0VBQ1g7RUFDQTtHQUNDLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLFVBQVU7RUFDWDtFQUNBO0dBQ0MsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sZUFBZTtFQUNoQjtDQUNEO0FBQ0Q7QUFBR0MsSUFBQUEsTUFBSSxDQUFDRCxHQUFDO0FBQUdFLElBQUFBLE1BQUk7Q0FDZixRQUFRO0NBQ1IsUUFBUTtDQUNSLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsWUFBWTtDQUNaLFVBQVU7Q0FDVixXQUFXO0NBQ1gsU0FBUztDQUNULE1BQU07QUFDUDtBQUFHQyxJQUFBQSxNQUFJO0NBQ04sUUFBUTtFQUNQLE9BQU87RUFDUCxRQUFRO0NBQ1Q7Q0FDQSxRQUFRO0VBQ1AsT0FBTztFQUNQLFFBQVE7Q0FDVDtDQUNBLFdBQVc7RUFDVixPQUFPO0VBQ1AsUUFBUTtDQUNUO0NBQ0EsU0FBUztFQUNSLE9BQU87RUFDUCxRQUFRO0NBQ1Q7Q0FDQSxZQUFZO0VBQ1gsT0FBTztFQUNQLFFBQVE7Q0FDVDtDQUNBLFVBQVU7RUFDVCxPQUFPO0VBQ1AsUUFBUTtDQUNUO0NBQ0EsV0FBVztFQUNWLE9BQU87RUFDUCxRQUFRO0NBQ1Q7Q0FDQSxTQUFTO0VBQ1IsT0FBTztFQUNQLFFBQVE7Q0FDVDtBQUNEO0FBQUdDLElBQUFBLE1BQUk7Q0FDTixRQUFRO0NBQ1Isb0JBQW9CO0FBQ3JCO0FBQUdDLElBQUFBLE1BQUk7QUFBSUMsSUFBQUEsTUFBSTtBQUFLQyxJQUFBQSxNQUFJO0NBQ3ZCLDBCQUEwQjtDQUMxQix3QkFBd0I7Q0FDeEIsdUJBQXVCO0NBQ3ZCLHNCQUFzQjtBQUN2QjtBQUFHQyxJQUFBQSxZQUFVLE9BQU8sU0FBUyxPQUFPLGdCQUFnQixTQUFTLE9BQU8sV0FBVyxJQUFJLEdBQUcsS0FBSyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsRUFBRSxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFBS0MsSUFBQUEsUUFBTSxHQUFHLEdBQUcsTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxDQUFDLENBQUM7QUFBR0MsSUFBQUEsT0FBSyxHQUFHLE1BQU1ILElBQUUsR0FBRyxFQUFFLElBQUksUUFBUTtBQUFNSSxJQUFBQSxPQUFLLEdBQUcsR0FBRyxHQUFHLE1BQU07Q0FDalEsSUFBSSxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sQ0FBQztDQUMvRCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsT0FBTztFQUNwQixTQUFTLENBQUM7RUFDVixPQUFPO0NBQ1I7Q0FDQSxJQUFJLElBQUlELElBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSTtDQUN4QixJQUFJLENBQUMsS0FBSyxFQUFFLFNBQVMsY0FBYyxFQUFFLFNBQVMsZUFBZSxFQUFFLE1BQU0sTUFBTSxFQUFFLFdBQVcsSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsRUFBRSxTQUFTLGNBQWMsQ0FBQyxDQUFDLEdBQUcsT0FBTztFQUM5SixTQUFTLENBQUM7RUFDVixPQUFPO0NBQ1I7Q0FDQSxJQUFJLEVBQUUsU0FBUyxnQkFBZ0IsRUFBRSxTQUFTLGNBQWM7RUFDdkQsSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLFNBQVMsSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxTQUFTLGVBQWUsQ0FBQyxDQUFDLEdBQUcsT0FBTztHQUN0RyxTQUFTLENBQUM7R0FDVixPQUFPO0VBQ1I7RUFDQSxJQUFJLG9CQUFvQixJQUFJLElBQUk7RUFDaEMsS0FBSyxJQUFJLEtBQUssR0FBRztHQUNoQixJQUFJLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxHQUFHLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSTtHQUMzRSxJQUFJLEdBQUcsU0FBUyxnQkFBZ0IsR0FBRyxTQUFTLGNBQWM7R0FDMUQsSUFBSSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU0sS0FBSyxDQUFDO0dBQzVCLEVBQUUsS0FBSyxFQUFFLElBQUksR0FBRyxFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7RUFDbEM7RUFDQSxNQUFNLEdBQUcsTUFBTTtHQUNkLElBQUksSUFBSSxDQUFDLENBQUMsR0FBRyxvQkFBb0IsSUFBSSxJQUFJO0dBQ3pDLE9BQU8sRUFBRSxTQUFTLElBQUk7SUFDckIsSUFBSSxJQUFJLEVBQUUsSUFBSTtJQUNkLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEdBQUc7SUFDcEIsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDO0lBQ3JCLEVBQUUsSUFBSSxDQUFDO0lBQ1AsSUFBSSxJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUNyQixLQUFLLElBQUksS0FBSyxHQUFHLEVBQUUsS0FBSyxDQUFDO0dBQzFCO0dBQ0EsT0FBTyxDQUFDO0VBQ1QsRUFBQSxDQUFHLEdBQUcsQ0FBQyxHQUFHLE9BQU87R0FDaEIsU0FBUyxDQUFDO0dBQ1YsT0FBTztFQUNSO0NBQ0Q7Q0FDQSxPQUFPO0VBQ04sU0FBUyxDQUFDO0VBQ1YsT0FBTztDQUNSO0FBQ0Q7QUFBR0UsSUFBQUEsUUFBTSxHQUFHLEdBQUcsSUFBSSxNQUFNO0NBQ3hCLElBQUksSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLFFBQVEsUUFBUSxHQUFHO0NBQ3BDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxFQUFFO0NBQ2xCLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sSUFBSSxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksRUFBRSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJO0NBQy9FLEtBQUssSUFBSSxLQUFLLEdBQUc7RUFDaEIsSUFBSSxJQUFJO0VBQ1IsT0FBTyxFQUFFLFNBQVMsSUFBSTtHQUNyQixJQUFJLElBQUksRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUk7R0FDNUIsSUFBSSxJQUFJLEVBQUUsTUFBTSxJQUFJLENBQUMsR0FBRyxFQUFFLFNBQVMsTUFBTSxFQUFFLEtBQUssQ0FBQyxHQUFHLElBQUksS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsVUFBVSxHQUFHO0lBQ3RGLElBQUksSUFBSSxFQUFFLE1BQU0sR0FBRyxDQUFDO0lBQ3BCLE9BQU8sRUFBRSxJQUFJLEtBQUssR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDLE1BQU0sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUk7R0FDaEU7RUFDRDtFQUNBLElBQUksSUFBSSxFQUFFLFNBQVMsSUFBSSxHQUFHLEVBQUUsR0FBRyxNQUFNO0VBQ3JDLElBQUksRUFBRSxVQUFVLEdBQUc7R0FDbEIsSUFBSTtHQUNKO0VBQ0Q7RUFDQSxJQUFJLEVBQUUsU0FBUyxLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsVUFBVSxHQUFHO0NBQ3REO0NBQ0EsSUFBSSxFQUFFLFNBQVMsS0FBSyxFQUFFLFNBQVMsS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsVUFBVSxHQUFHLE9BQU87Q0FDckUsSUFBSSxJQUFJLEVBQUUsTUFBTSxHQUFHLENBQUM7Q0FDcEIsT0FBTyxFQUFFLElBQUksS0FBSyxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUMsTUFBTSxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSTtBQUNoRTtBQUFHLElBQUEsS0FBQSxHQUFJQyxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxXQUFXLEdBQUcsY0FBYyxJQUFJLFNBQVMsU0FBUyxJQUFJLFVBQVUsVUFBVSxHQUFHLGtCQUFrQixJQUFJaEIsS0FBRyxZQUFZLEdBQUcsYUFBYSxHQUFHLEdBQUcsTUFBTSxHQUFHO0NBQ3BLLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxTQUFTLElBQUksSUFBSU8sSUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLE1BQU0sb0JBQW9CLEtBQUEsR0FBSVUsYUFBQUEsUUFBQUEsT0FBUSxLQUFLLEVBQUUsU0FBUyxJQUFJLElBQUksTUFBTSxxQkFBcUJiLE1BQUlGLEtBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUEsR0FBSWdCLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtDLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLENBQUMsR0FBRyxDQUFDLElBQUksTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRTtFQUNuVixPQUFPO0VBQ1AsU0FBUztFQUNULFNBQVM7Q0FDVixDQUFDLEdBQUcsS0FBQSxHQUFJRCxhQUFBQSxPQUFBQSxDQUFFLENBQUM7Q0FDWCxDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxFQUFFLFVBQVU7Q0FDYixHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUEsR0FBR0UsYUFBQUEsVUFBQUEsT0FBUTtFQUNoQixHQUFHLE1BQU07R0FDUixJQUFJLElBQUksQ0FBQztHQUNULEtBQUssSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLE9BQU87R0FDdEMsT0FBTztFQUNSLENBQUM7Q0FDRixHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUEsR0FBR0EsYUFBQUEsVUFBQUEsT0FBUTtFQUNoQixJQUFJLG9CQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQztFQUN4QixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssSUFBSSxLQUFLLEVBQUUsT0FBTyxFQUFFLFNBQVMsVUFBVSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsUUFBUTtFQUMzRixHQUFHLE1BQU0sRUFBRSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUM7Q0FDMUIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0NBQ1QsSUFBSSxNQUFBLEdBQUtILGFBQUFBLFFBQUFBLE9BQVEsYUFBYSxFQUFFLFFBQVEsSUFBSSxFQUFFLFFBQVEsVUFBVSxFQUFFLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUEsR0FBSUksYUFBQUEsWUFBQUEsRUFBRyxHQUFHLEdBQUcsTUFBTTtFQUNwRyxJQUFJLEVBQUUsT0FBTyxHQUFHLFNBQVMsR0FBRyxTQUFTLE1BQU0sRUFBRTtFQUM3QyxPQUFPO0dBQ04sSUFBSSxJQUFJLEVBQUUsT0FBTyxLQUFLO0dBQ3RCLElBQUksSUFBSSxFQUFFLE1BQU0sS0FBSztFQUN0QjtDQUNELEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxZQUFBQSxFQUFHLEdBQUcsTUFBTTtFQUN2QixJQUFJLElBQUksRUFBRSxTQUFTLHNCQUFzQjtFQUN6QyxJQUFJLENBQUMsR0FBRztFQUNSLElBQUksSUFBSWYsSUFBRSxJQUFJLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxRQUFRLEdBQUcsRUFBRSxNQUFNLEVBQUUsU0FBUyxHQUFHLENBQUM7RUFDakUsR0FBRyxNQUFNO0dBQ1IsSUFBSSxJQUFJO0lBQ1AsSUFBSUssSUFBRTtJQUNOLE1BQU07SUFDTixPQUFPLEdBQUcsS0FBS04sSUFBRSxHQUFHLEdBQUcsRUFBRSxTQUFTO0lBQ2xDLE9BQU8sRUFBRTtJQUNULFFBQVEsRUFBRTtJQUNWLEdBQUcsRUFBRSxJQUFJLEVBQUUsUUFBUTtJQUNuQixHQUFHLEVBQUUsSUFBSSxFQUFFLFNBQVM7SUFDcEIsV0FBVyxLQUFLLElBQUk7R0FDckIsR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUM7R0FDZixPQUFPLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLEdBQUc7RUFDekIsQ0FBQztDQUNGLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUEsR0FBSWdCLGFBQUFBLFlBQUFBLEVBQUcsR0FBRyxNQUFNO0VBQzNCLE1BQU0sS0FBSyxHQUFHLE1BQU07R0FDbkIsSUFBSSxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsV0FBVyxLQUFLLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxXQUFXLEtBQUssRUFBRSxTQUFTLEtBQUssRUFBRSxXQUFXLEtBQUssRUFBRSxTQUFTLENBQUMsR0FBRyxPQUFPO0dBQ2hKLElBQUksSUFBSSxRQUFRLEVBQUUsU0FBUztHQUMzQixJQUFJLEdBQUc7SUFDTixJQUFJLElBQUlQLElBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUNwQixJQUFJLENBQUMsRUFBRSxXQUFXLENBQUMsRUFBRSxPQUFPLE9BQU87SUFDbkMsSUFBSSxFQUFFO0dBQ1A7R0FDQSxPQUFPLENBQUMsR0FBRyxHQUFHO0lBQ2IsSUFBSUgsSUFBRTtJQUNOLFFBQVE7SUFDUixNQUFNO0lBQ04sT0FBTztJQUNQLFdBQVcsS0FBSyxJQUFJO0dBQ3JCLENBQUM7RUFDRixDQUFDO0NBQ0YsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsTUFBQSxHQUFLVSxhQUFBQSxZQUFBQSxFQUFHLEdBQUcsTUFBTTtFQUM1QixJQUFJLEdBQUcsT0FBTztHQUNiLEdBQUc7SUFDRixJQUFJLEVBQUU7RUFDUixFQUFFLEdBQUcsRUFBRSxTQUFTLFFBQVE7R0FDdkIsSUFBSSxDQUFDLEdBQUc7R0FDUixFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7R0FDZDtFQUNEO0VBQ0EsRUFBRSxhQUFhLEVBQUUsRUFBRSxRQUFRLEdBQUcsRUFBRSxJQUFJO0NBQ3JDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFBLEdBQUtBLGFBQUFBLFlBQUFBLEVBQUcsR0FBRyxNQUFNO0VBQ3pCLEVBQUUsU0FBUyxVQUFVLEVBQUUsYUFBYSxHQUFHLE9BQU87R0FDN0MsR0FBRztJQUNGLElBQUksRUFBRTtFQUNSLEVBQUUsR0FBRyxFQUFFLEVBQUUsUUFBUSxHQUFHLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBRSxVQUFVLEVBQUUsS0FBSztDQUNuRCxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxZQUFBQSxPQUFRO0VBQ3JCLElBQUksTUFBTSxDQUFDLENBQUM7Q0FDYixHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsWUFBQUEsRUFBRyxHQUFHLE1BQU07RUFDdkIsSUFBSSxFQUFFLGVBQWUsR0FBRyxFQUFFLGdCQUFnQixHQUFHLEVBQUUsQ0FBQyxHQUFHLE1BQU0sUUFBUTtHQUNoRSxLQUFLLE1BQU0sTUFBTSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxHQUFHLEVBQUUsQ0FBQztHQUN0QztFQUNEO0VBQ0EsSUFBSSxJQUFJLEVBQUUsU0FBUyxzQkFBc0IsR0FBRyxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxDQUFDO0VBQ3hFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRztFQUNkLElBQUksRUFBRSxHQUFHLEdBQUcsR0FBRyxNQUFNLEVBQUUsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDO0VBQzlDLEVBQUU7R0FDRCxJQUFJO0dBQ0osU0FBUyxJQUFJLEVBQUU7R0FDZixTQUFTLElBQUksRUFBRTtHQUNmLFdBQVcsRUFBRTtFQUNkLENBQUM7Q0FDRixHQUFHO0VBQ0Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsWUFBQUEsRUFBRyxNQUFNO0VBQ2pCLElBQUksRUFBRSxXQUFXLEdBQUc7RUFDcEIsRUFBRSxJQUFJLEdBQUcsTUFBTSxXQUFXLEVBQUUsSUFBSSxHQUFHLEVBQUUsQ0FBQztFQUN0QyxJQUFJLElBQUksRUFBRTtFQUNWLEVBQUUsY0FBYyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUU7R0FDdkMsV0FBVztHQUNYLFFBQVEsRUFBRTtHQUNWLFFBQVEsRUFBRTtHQUNWLGNBQWMsRUFBRTtHQUNoQixjQUFjLEVBQUU7RUFDakIsQ0FBQztDQUNGLEdBQUc7RUFDRjtFQUNBO0VBQ0E7Q0FDRCxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxZQUFBQSxFQUFHLE1BQU07RUFDakIsRUFBRSxlQUFlO0VBQ2pCLElBQUksSUFBSSxFQUFFLFNBQVMsc0JBQXNCO0VBQ3pDLElBQUksQ0FBQyxHQUFHO0VBQ1IsSUFBSSxJQUFJLEVBQUUsVUFBVSxFQUFFLE1BQU0sSUFBSSxFQUFFLFVBQVUsRUFBRSxLQUFLLElBQUksQ0FBQyxFQUFFLFNBQVM7RUFDbkUsR0FBRyxNQUFNO0dBQ1IsSUFBSSxJQUFJVCxLQUFHLEVBQUUsUUFBUSxHQUFHSixLQUFHQyxHQUFDO0dBQzVCLElBQUksTUFBTSxFQUFFLE9BQU8sT0FBTztHQUMxQixJQUFJLEtBQUssSUFBSSxFQUFFLFdBQVcsRUFBRSxPQUFPLEtBQUssSUFBSSxFQUFFLFdBQVcsRUFBRTtHQUMzRCxPQUFPO0lBQ04sT0FBTztJQUNQLFNBQVMsSUFBSSxJQUFJO0lBQ2pCLFNBQVMsSUFBSSxJQUFJO0dBQ2xCO0VBQ0QsQ0FBQztDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFRO0VBQ1AsSUFBSSxDQUFDLEdBQUc7RUFDUixJQUFJLEtBQUssTUFBTTtHQUNkLElBQUksRUFBRSxjQUFjLEVBQUUsV0FBVztHQUNqQyxJQUFJLElBQUksRUFBRSxTQUFTLHNCQUFzQjtHQUN6QyxLQUFLLEdBQUcsTUFBTSxFQUFFLEtBQUssTUFBTTtJQUMxQixJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksT0FBTztJQUMxQixJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsTUFBTSxFQUFFLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQyxHQUFHLElBQUk7S0FDcEQsR0FBRztLQUNILEdBQUcsSUFBSSxFQUFFO0tBQ1QsR0FBRyxJQUFJLEVBQUU7SUFDVjtJQUNBLE9BQU8sSUFBSSxDQUFDLEdBQUc7R0FDaEIsQ0FBQyxDQUFDO0VBQ0gsR0FBRyxLQUFLLE1BQU07R0FDYixFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsSUFBSTtFQUN0QztFQUNBLE9BQU8sU0FBUyxpQkFBaUIsZUFBZSxDQUFDLEdBQUcsU0FBUyxpQkFBaUIsYUFBYSxDQUFDLFNBQVM7R0FDcEcsU0FBUyxvQkFBb0IsZUFBZSxDQUFDLEdBQUcsU0FBUyxvQkFBb0IsYUFBYSxDQUFDO0VBQzVGO0NBQ0QsR0FBRztFQUNGO0VBQ0E7RUFDQTtDQUNELENBQUMsSUFBQSxHQUFHVyxhQUFBQSxVQUFBQSxPQUFRO0VBQ1gsSUFBSSxDQUFDLEdBQUc7RUFDUixJQUFJLEtBQUssTUFBTTtHQUNkLElBQUksRUFBRSxjQUFjLEVBQUUsV0FBVztHQUNqQyxJQUFJLElBQUksRUFBRSxVQUFVLEVBQUUsUUFBUSxJQUFJLEVBQUUsVUFBVSxFQUFFO0dBQ2hELEdBQUcsT0FBTztJQUNULEdBQUc7SUFDSCxTQUFTLEVBQUUsZUFBZTtJQUMxQixTQUFTLEVBQUUsZUFBZTtHQUMzQixFQUFFO0VBQ0gsR0FBRyxLQUFLLE1BQU07R0FDYixFQUFFLGNBQWMsRUFBRSxjQUFjLEVBQUUsU0FBUyxzQkFBc0IsRUFBRSxTQUFTLEdBQUcsRUFBRSxJQUFJO0VBQ3RGO0VBQ0EsT0FBTyxTQUFTLGlCQUFpQixlQUFlLENBQUMsR0FBRyxTQUFTLGlCQUFpQixhQUFhLENBQUMsU0FBUztHQUNwRyxTQUFTLG9CQUFvQixlQUFlLENBQUMsR0FBRyxTQUFTLG9CQUFvQixhQUFhLENBQUM7RUFDNUY7Q0FDRCxHQUFHLENBQUMsQ0FBQyxDQUFDO0NBQ04sSUFBSSxLQUFLO0VBQ1I7RUFDQSxJQUFJLHFDQUFxQztFQUN6QztDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxVQUFVLElBQUksd0JBQXdCO0NBQy9GLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsS0FBSztFQUNMLFdBQVc7RUFDWCxHQUFHO0VBQ0gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQ25DLFdBQVc7R0FDWCxLQUFLO0dBQ0wsZUFBZTtHQUNmLFNBQVM7R0FDVCxNQUFNO0dBQ04sZUFBZTtHQUNmLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDbEMsV0FBVztJQUNYLE1BQU07SUFDTixlQUFlO0lBQ2YsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsS0FBSztLQUNoQyxXQUFXO0tBQ1gsV0FBVztLQUNYLFVBQVUsQ0FBQyxFQUFFLEtBQUssTUFBTTtNQUN2QixJQUFJLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxHQUFHLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSTtNQUMzRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsT0FBTztNQUNyQixJQUFJLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVEsTUFBTSxHQUFHLEtBQUssRUFBRSxJQUFJLEVBQUUsU0FBUyxLQUFLLEVBQUUsSUFBSSxFQUFFLFNBQVMsTUFBTTtNQUN6RyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLLEVBQUUsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO09BQ3BFLFdBQVc7T0FDWCxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVE7T0FDcEIsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTO09BQ3JCLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUTtPQUNwQixJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVM7TUFDdEIsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO09BQzdCLFdBQVc7T0FDWCxHQUFHO09BQ0gsR0FBRyxJQUFJO09BQ1AsVUFBVSxFQUFFO01BQ2IsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUU7S0FDWixDQUFDLEdBQUcsRUFBRSxLQUFLLE1BQU07TUFDaEIsSUFBSSxJQUFJTCxLQUFHLEVBQUUsT0FBTyxFQUFFLEtBQUssR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsS0FBSyxFQUFFLFNBQVMsS0FBSyxLQUFLLEdBQUcsSUFBSTtPQUMxRyxXQUFXO1FBQ1Y7UUFDQSxFQUFFLFNBQVMsWUFBWTtRQUN2QixFQUFFLFNBQVMsZUFBZTtRQUMxQixFQUFFLFNBQVMsYUFBYTtRQUN4QixFQUFFLFNBQVMsZ0JBQWdCO1FBQzNCLEVBQUUsU0FBUyxjQUFjO1FBQ3pCLEVBQUUsU0FBUyxlQUFlO1FBQzFCLEVBQUUsU0FBUyxhQUFhO1FBQ3hCLE1BQU0sRUFBRSxNQUFNO09BQ2YsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO09BQzFCLGdCQUFnQixNQUFNLEVBQUUsR0FBRyxFQUFFLEVBQUU7T0FDL0IsTUFBTTtPQUNOLGVBQWUsQ0FBQztNQUNqQjtNQUNBLElBQUksRUFBRSxTQUFTLFVBQVU7T0FDeEIsSUFBSSxJQUFJLEVBQUUsUUFBUSxHQUFHLElBQUksRUFBRSxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUk7T0FDNUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtRQUN0RSxHQUFHO1FBQ0gsSUFBSTtRQUNKLElBQUk7UUFDSixHQUFHO09BQ0osQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO1FBQzdCLFdBQVc7UUFDWCxHQUFHO1FBQ0gsR0FBRztRQUNILFVBQVUsRUFBRSxLQUFLLEdBQUcsTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztTQUNwRCxHQUFHO1NBQ0gsSUFBSSxNQUFNLElBQUksSUFBSTtTQUNsQixVQUFVO1FBQ1gsR0FBRyxHQUFHLEVBQUUsR0FBRyxRQUFRLEdBQUcsQ0FBQztPQUN4QixDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRTtNQUNaO01BQ0EsSUFBSSxFQUFFLFNBQVMsWUFBWTtPQUMxQixJQUFJLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUUsUUFBUSxHQUFHLENBQUMsR0FBRyxJQUFJO1FBQ3BELEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFO1FBQ2hCLEdBQUcsRUFBRSxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUU7UUFDdEIsR0FBRyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRTtRQUNoQyxHQUFHLEVBQUUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFO09BQ25CLENBQUMsQ0FBQyxLQUFLLEdBQUc7T0FDVixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLLEVBQUUsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxXQUFXO1FBQ3ZFLEdBQUc7UUFDSCxRQUFRO09BQ1QsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO1FBQzdCLFdBQVc7UUFDWCxHQUFHO1FBQ0gsR0FBRztRQUNILFVBQVUsRUFBRSxLQUFLLEdBQUcsTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztTQUNwRCxHQUFHO1NBQ0gsSUFBSSxNQUFNLElBQUksSUFBSTtTQUNsQixVQUFVO1FBQ1gsR0FBRyxHQUFHLEVBQUUsR0FBRyxRQUFRLEdBQUcsQ0FBQztPQUN4QixDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRTtNQUNaO01BQ0EsSUFBSSxFQUFFLFNBQVMsV0FBVztPQUN6QixJQUFJLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUUsUUFBUSxHQUFHLENBQUMsR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsR0FBRyxJQUFJO1FBQzVFLEtBQUssRUFBRSxFQUFFLEdBQUcsRUFBRTtRQUNkLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUTtRQUNyQixLQUFLLEVBQUUsSUFBSSxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUk7UUFDNUIsS0FBSztRQUNMLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxJQUFJLEdBQUcsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsUUFBUSxHQUFHLEdBQUc7UUFDeEUsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLElBQUksR0FBRyxFQUFFLElBQUksRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFLEVBQUUsR0FBRztRQUMxRDtPQUNELENBQUMsQ0FBQyxLQUFLLEdBQUc7T0FDVixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLLEVBQUUsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO1FBQ3BFLEdBQUc7UUFDSCxHQUFHO09BQ0osQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO1FBQzdCLFdBQVc7UUFDWCxHQUFHO1FBQ0gsR0FBRztRQUNILFVBQVUsRUFBRSxLQUFLLEdBQUcsTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztTQUNwRCxHQUFHO1NBQ0gsSUFBSSxNQUFNLElBQUksSUFBSTtTQUNsQixVQUFVO1FBQ1gsR0FBRyxHQUFHLEVBQUUsR0FBRyxRQUFRLEdBQUcsQ0FBQztPQUN4QixDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRTtNQUNaO01BQ0EsSUFBSSxFQUFFLFNBQVMsV0FBVztPQUN6QixJQUFJLElBQUk7UUFDUCxHQUFHLEVBQUUsSUFBSSxFQUFFLFFBQVEsSUFBSSxHQUFHLEVBQUU7UUFDNUIsR0FBRyxFQUFFLElBQUksRUFBRSxRQUFRLElBQUksR0FBRyxFQUFFO1FBQzVCLEdBQUcsRUFBRSxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxFQUFFLFNBQVM7UUFDckMsR0FBRyxFQUFFLElBQUksRUFBRSxRQUFRLElBQUksR0FBRyxFQUFFLElBQUksRUFBRTtRQUNsQyxHQUFHLEVBQUUsSUFBSSxFQUFFLFFBQVEsSUFBSSxHQUFHLEVBQUUsSUFBSSxFQUFFO1FBQ2xDLEdBQUcsRUFBRSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsU0FBUztPQUM1QixDQUFDLENBQUMsS0FBSyxHQUFHO09BQ1YsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsV0FBVztRQUN2RSxHQUFHO1FBQ0gsUUFBUTtPQUNULENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtRQUM3QixXQUFXO1FBQ1gsR0FBRztRQUNILEdBQUc7UUFDSCxVQUFVLEVBQUUsS0FBSyxHQUFHLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7U0FDcEQsR0FBRztTQUNILElBQUksTUFBTSxJQUFJLElBQUk7U0FDbEIsVUFBVTtRQUNYLEdBQUcsR0FBRyxFQUFFLEdBQUcsUUFBUSxHQUFHLENBQUM7T0FDeEIsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUU7TUFDWjtNQUNBLElBQUksSUFBSSxFQUFFLFNBQVMsZUFBZSxFQUFFLFNBQVMsZUFBZSxLQUFLO01BQ2pFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLEtBQUssRUFBRSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7T0FDcEUsR0FBRztPQUNILEdBQUcsRUFBRTtPQUNMLEdBQUcsRUFBRTtPQUNMLE9BQU8sRUFBRTtPQUNULFFBQVEsRUFBRTtPQUNWLElBQUk7TUFDTCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7T0FDN0IsV0FBVztPQUNYLEdBQUc7T0FDSCxHQUFHO09BQ0gsVUFBVSxFQUFFLEtBQUssR0FBRyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO1FBQ3BELEdBQUc7UUFDSCxJQUFJLE1BQU0sSUFBSSxJQUFJO1FBQ2xCLFVBQVU7T0FDWCxHQUFHLEdBQUcsRUFBRSxHQUFHLFFBQVEsR0FBRyxDQUFDO01BQ3hCLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFO0tBQ1osQ0FBQyxDQUFDO0lBQ0gsQ0FBQztHQUNGLENBQUM7RUFDRixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLEdBQUc7R0FDeEIsY0FBYztHQUNkLFVBQVU7R0FDVixhQUFhO0dBQ2IsbUJBQW1CO0dBQ25CLFVBQVU7R0FDVixvQkFBb0I7R0FDcEIsa0JBQWtCO0dBQ2xCLGFBQWE7R0FDYixtQkFBbUI7RUFDcEIsQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7OztBQ2prQkQsSUFBSU8sTUFBSTtDQUNQLFNBQVM7Q0FDVCxXQUFXO0NBQ1gsT0FBTztBQUNSO0FBQUdDLElBQUFBLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLENBQUUsU0FBUyxFQUFFLFVBQVUsR0FBRyxXQUFXLElBQUksSUFBSSxTQUFTLElBQUksV0FBVyxNQUFNLElBQUksVUFBVSxHQUFHLEtBQUssR0FBRztDQUMxRyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0VBQ2xDLEtBQUs7RUFDTCxXQUFXO0dBQ1Y7R0FDQUYsSUFBRSxNQUFNQSxJQUFFO0dBQ1Y7RUFDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFDMUIsTUFBTTtFQUNOLEdBQUc7RUFDSCxVQUFVO0NBQ1gsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7QUFHaEIsSUFBSUcsTUFBSTtBQUNSLFNBQVNDLElBQUUsR0FBRztDQUNiLE9BQU8sTUFBTSxLQUFLLEVBQUUsaUJBQWlCRCxHQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsTUFBTSxDQUFDLEVBQUUsYUFBYSxVQUFVLEtBQUssRUFBRSxhQUFhLGFBQWEsTUFBTSxNQUFNO0FBQy9IO0FBQ0EsSUFBSUUsT0FBQUEsR0FBSUgsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsT0FBTyxHQUFHLGFBQWEsR0FBRyxRQUFRLEdBQUcsUUFBUSxHQUFHLFlBQVksSUFBSSxDQUFDLEdBQUcsWUFBWSxJQUFJLENBQUMsR0FBRyxnQkFBZ0IsR0FBRyxzQkFBc0IsSUFBSSxDQUFDLEdBQUcsZUFBZSxLQUFLLENBQUMsR0FBRyxzQkFBc0IsR0FBRyxZQUFZLElBQUksVUFBVSxXQUFXLElBQUksSUFBSSxtQkFBbUIsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksc0JBQXNCLEtBQUssSUFBSSxrQkFBa0IsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksV0FBVyxHQUFHLFVBQVUsSUFBSSxVQUFVLElBQUksR0FBRyxNQUFNLElBQUk7Q0FDeGIsSUFBSSxLQUFBLEdBQUlJLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBSyx5QkFBQSxHQUF3QkMsYUFBQUEsTUFBQUEsQ0FBRSxDQUFDLENBQUMsUUFBUSxNQUFNLEVBQUUsS0FBSyxLQUFLLCtCQUFBLEdBQThCQSxhQUFBQSxNQUFBQSxDQUFFLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUksR0FBRyxvQkFBb0IsS0FBSyxHQUFHLHFCQUFxQixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sS0FBSyxNQUFNLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxPQUFPLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsS0FBSyxDQUFDLCtCQUErQixFQUFFLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQ3ZyQixRQUFBLEdBQU9DLGFBQUFBLFVBQUFBLE9BQVE7RUFDZCxJQUFJLElBQUksRUFBRTtFQUNWLElBQUksQ0FBQyxHQUFHO0VBQ1IsSUFBSSxFQUFFLFVBQVUsU0FBUyx5QkFBeUIsY0FBYyxTQUFTLGdCQUFnQixNQUFNLEdBQUcsSUFBSTtHQUNyRyxJQUFJLElBQUksRUFBRSxjQUFjLENBQUM7R0FDekIsSUFBSSxHQUFHLE9BQU8sRUFBRSxNQUFNLFNBQVM7SUFDOUIsRUFBRSxTQUFTLE1BQU0sR0FBRyxFQUFFLFVBQVU7R0FDakM7RUFDRCxRQUFRLENBQUM7RUFDVCxJQUFJLElBQUlKLElBQUUsQ0FBQztFQUNYLE9BQU8sRUFBRSxTQUFTLElBQUksRUFBRSxFQUFFLENBQUMsTUFBTSxJQUFJLEVBQUUsTUFBTSxTQUFTO0dBQ3JELEVBQUUsU0FBUyxNQUFNLEdBQUcsRUFBRSxVQUFVO0VBQ2pDO0NBQ0QsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0VBQ2pDLFdBQVc7RUFDWCxNQUFNO0VBQ04sVUFBVSxNQUFNO0dBQ2YsQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLGlCQUFpQixJQUFJO0VBQzNDO0VBQ0EsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsV0FBVztHQUN0QyxNQUFNLE1BQU07SUFDWCxJQUFJLEVBQUUsVUFBVSxHQUFHLE9BQU8sTUFBTSxZQUFZO0tBQzNDLEdBQUcsQ0FBQztLQUNKO0lBQ0Q7SUFDQSxPQUFPLEdBQUcsVUFBVTtHQUNyQjtHQUNBLFdBQVc7R0FDWCxNQUFNO0dBQ04sY0FBYztHQUNkLG1CQUFtQjtHQUNuQixvQkFBb0I7R0FDcEIsVUFBVSxNQUFNO0dBQ2hCLFlBQVksTUFBTTtJQUNqQixJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsa0JBQWtCO0lBQ2hDLElBQUksRUFBRSxRQUFRLFlBQVksSUFBSTtLQUM3QixFQUFFLGVBQWUsR0FBRyxJQUFJO0tBQ3hCO0lBQ0Q7SUFDQSxJQUFJLEVBQUUsUUFBUSxTQUFTLENBQUMsRUFBRSxTQUFTO0lBQ25DLElBQUksSUFBSUEsSUFBRSxFQUFFLE9BQU87SUFDbkIsSUFBSSxFQUFFLFdBQVcsR0FBRztLQUNuQixFQUFFLGVBQWUsR0FBRyxFQUFFLFFBQVEsTUFBTTtLQUNwQztJQUNEO0lBQ0EsSUFBSSxJQUFJLFNBQVMsZUFBZSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsRUFBRSxTQUFTO0lBQzNELElBQUksRUFBRSxVQUFVO0tBQ2YsQ0FBQyxDQUFDLEtBQUssTUFBTSxLQUFLLENBQUMsRUFBRSxRQUFRLFNBQVMsQ0FBQyxPQUFPLEVBQUUsZUFBZSxHQUFHLEVBQUUsTUFBTTtLQUMxRTtJQUNEO0lBQ0EsQ0FBQyxDQUFDLEtBQUssTUFBTSxLQUFLLENBQUMsRUFBRSxRQUFRLFNBQVMsQ0FBQyxPQUFPLEVBQUUsZUFBZSxHQUFHLEVBQUUsTUFBTTtHQUMzRTtHQUNBLEdBQUc7R0FDSCxVQUFVO0lBQ1QsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtLQUNoQyxXQUFXO0tBQ1gsVUFBVSxNQUFNLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE1BQU07TUFDM0MsV0FBVztNQUNYLElBQUk7TUFDSixVQUFVO0tBQ1gsQ0FBQyxJQUFJO0lBQ04sQ0FBQyxJQUFJO0lBQ0wsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUM1QixJQUFJO0tBQ0osV0FBVztLQUNYLFVBQVU7SUFDWCxDQUFDLElBQUk7SUFDVyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQ3hCLFdBQVc7S0FDWCxVQUFVO0lBQ1gsQ0FBQztJQUNELEtBQXFCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7S0FDaEMsV0FBVztLQUNYLFVBQVU7SUFDWCxDQUFDLElBQUk7R0FDTjtFQUNELENBQUM7Q0FDRixDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYztBQUdoQixJQUFJLEtBQUssT0FBTyxNQUFNO0NBQ3JCLElBQUksSUFBSSxNQUFNLE1BQU0sQ0FBQztDQUNyQixJQUFJLENBQUMsRUFBRSxJQUFJLE1BQU0sTUFBTSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsUUFBUTtDQUM3RCxPQUFPLEVBQUUsS0FBSztBQUNmO0FBQ0EsU0FBU0ssSUFBRSxHQUFHO0NBQ2IsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLFFBQVEsRUFBRSxPQUFPLEdBQUcsT0FBTztFQUMzQyxTQUFTO0VBQ1QsVUFBVTtFQUNWLGlCQUFpQjtHQUNoQjtHQUNBO0dBQ0E7RUFDRDtFQUNBLGVBQWU7RUFDZixTQUFTLENBQUM7Q0FDWDtDQUNBLElBQUksSUFBSSxFQUFFLFFBQVEsS0FBSyxPQUFPO0VBQzdCLE1BQU07RUFDTixVQUFVLENBQUM7RUFDWCxZQUFZLENBQUM7RUFDYixXQUFXLENBQUM7RUFDWixVQUFVLENBQUM7RUFDWCxXQUFXO0VBQ1gsUUFBUTtFQUNSLEdBQUc7Q0FDSixFQUFFO0NBQ0YsT0FBTztFQUNOLFNBQVMsRUFBRSxXQUFXO0VBQ3RCLFVBQVUsRUFBRSxZQUFZO0VBQ3hCLGlCQUFpQixFQUFFLGlCQUFpQixTQUFTLEVBQUUsa0JBQWtCO0dBQ2hFO0dBQ0E7R0FDQTtFQUNEO0VBQ0EsZUFBZSxFQUFFLGlCQUFpQjtFQUNsQyxnQkFBZ0IsRUFBRTtFQUNsQixhQUFhLEVBQUU7RUFDZixRQUFRO0dBQ1Asc0JBQXNCLEVBQUUsUUFBUSx3QkFBd0IsQ0FBQztHQUN6RCxlQUFlLEVBQUUsUUFBUSxlQUFlLFNBQVMsRUFBRSxPQUFPLGdCQUFnQjtJQUN6RTtJQUNBO0lBQ0E7SUFDQTtHQUNEO0VBQ0Q7RUFDQSxTQUFTO0NBQ1Y7QUFDRDtBQUNBLFNBQVNDLElBQUUsR0FBRyxHQUFHO0NBQ2hCLE9BQU8sTUFBTSxTQUFTLFNBQVMsTUFBTSxjQUFjLGFBQWEsTUFBTSxZQUFZLE1BQU0sWUFBWSxXQUFXLE1BQU0sWUFBWSxZQUFZO0FBQzlJO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxNQUFNLFNBQVMsU0FBUyxNQUFNLGNBQWMsYUFBYSxNQUFNLGFBQWEsYUFBYSxNQUFNLFlBQVksWUFBWTtBQUMvSDtBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLElBQUksR0FBRyxRQUFRLE9BQU8sRUFBRSxLQUFLLE9BQU87RUFDbkMsT0FBTyxNQUFNLE9BQU8sWUFBWSxPQUFPLENBQUM7RUFDeEMsT0FBTztDQUNSLEVBQUU7QUFDSDtBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLElBQUksQ0FBQyxHQUFHLFlBQVksT0FBT0osSUFBRSxLQUFLLENBQUM7Q0FDbkMsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLFdBQVcsSUFBSSxPQUFPLFFBQVEsRUFBRSxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUFPO0VBQ3BHLElBQUksSUFBSSxFQUFFLFdBQVcsSUFBSUMsSUFBRSxFQUFFLE1BQU0sRUFBRSxNQUFNLEdBQUcsSUFBSUMsSUFBRSxFQUFFLE1BQU0sR0FBRyxJQUFJLEdBQUcsV0FBVyxNQUFNLFlBQVksYUFBYSxNQUFNLFdBQVcsV0FBVyxNQUFNLFNBQVMsU0FBUyxLQUFLO0VBQ3pLLE9BQU87R0FDTixLQUFLLEdBQUcsT0FBTztHQUNmLE9BQU8sRUFBRSxTQUFTO0dBQ2xCLE1BQU07R0FDTixVQUFVLEdBQUcsWUFBWSxDQUFDO0dBQzFCLFlBQVksR0FBRyxjQUFjLENBQUM7R0FDOUIsV0FBVyxHQUFHLGFBQWEsQ0FBQztHQUM1QixVQUFVLEdBQUcsWUFBWSxFQUFFLElBQUksQ0FBQztHQUNoQyxRQUFRO0dBQ1IsV0FBVyxHQUFHLGFBQWE7R0FDM0IsT0FBTyxHQUFHO0dBQ1YsVUFBVSxHQUFHO0dBQ2IsU0FBUyxHQUFHLFdBQVdDLElBQUUsRUFBRSxJQUFJO0dBQy9CLFFBQVEsR0FBRyxVQUFVO0VBQ3RCO0NBQ0QsQ0FBQztDQUNELE9BQU9ILElBQUU7RUFDUixTQUFTLEdBQUc7RUFDWixVQUFVLEdBQUc7RUFDYixpQkFBaUIsR0FBRztFQUNwQixlQUFlLEdBQUc7RUFDbEIsZ0JBQWdCLEdBQUc7RUFDbkIsYUFBYSxHQUFHO0VBQ2hCLFFBQVEsR0FBRztFQUNYLFNBQVM7Q0FDVixDQUFDO0FBQ0Y7QUFDQSxTQUFTLEdBQUcsR0FBRztDQUNkLElBQUksR0FBRztFQUNOLElBQUksT0FBTyxLQUFLLFVBQVU7R0FDekIsSUFBSSxJQUFJLEtBQUssTUFBTSxDQUFDO0dBQ3BCLElBQUksQ0FBQyxLQUFLLE9BQU8sS0FBSyxVQUFVLE1BQU0sTUFBTSw2Q0FBNkM7R0FDekYsT0FBTztFQUNSO0VBQ0EsT0FBTztDQUNSO0FBQ0Q7QUFDQSxlQUFlSyxJQUFFLEdBQUcsR0FBRztDQUN0QixJQUFJLE1BQU0sS0FBSyxHQUFHLE9BQU8sT0FBTyxLQUFLLGFBQWEsRUFBRSxJQUFJLE9BQU8sS0FBSyxXQUFXLE9BQU8sS0FBSyxHQUFBLENBQUksQ0FBQyxJQUFJO0FBQ3JHO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUc7Q0FDaEIsT0FBTyxFQUFFLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0FBQ2xDO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUcsR0FBRztDQUNuQixJQUFJLElBQUksRUFBRTtDQUNWLE9BQU8sS0FBSyxPQUFPLE9BQU8sTUFBTSxPQUFPLENBQUM7QUFDekM7QUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUN2QixJQUFJLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxZQUFZO0NBQzdCLE9BQU8sRUFBRSxRQUFRLE1BQU0sRUFBRSxXQUFXLEtBQUssRUFBRSxNQUFNLE1BQU1DLElBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRSxPQUFPLE1BQU07RUFDOUcsSUFBSSxLQUFLLEVBQUUsRUFBRSxRQUFRLEdBQUEsQ0FBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQzVDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQztFQUNoQixJQUFJLElBQUksRUFBRSxFQUFFO0VBQ1osSUFBSSxFQUFFLFNBQVMsV0FBVztHQUN6QixJQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sQ0FBQztHQUNoQyxJQUFJLE1BQU0sU0FBUyxPQUFPLE1BQU0sQ0FBQztFQUNsQztFQUNBLE9BQU9BLElBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDO0NBQ3JDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUNwQixJQUFJLENBQUMsR0FBRyxPQUFPO0NBQ2YsSUFBSSxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVM7Q0FDM0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLFVBQVUsT0FBTztDQUM5QixJQUFJLElBQUksRUFBRSxjQUFjLFFBQVEsSUFBSTtDQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTTtFQUM1QixJQUFJLElBQUksRUFBRSxFQUFFLFlBQVksSUFBSSxFQUFFLEVBQUU7RUFDaEMsT0FBTyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSTtDQUMzQixDQUFDO0FBQ0Y7QUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUN2QixJQUFJLENBQUMsR0FBRyxPQUFPLEVBQUUsS0FBSyxHQUFHLE9BQU87RUFDL0IsTUFBTTtFQUNOLEtBQUssUUFBUTtFQUNiLEtBQUs7RUFDTCxVQUFVO0NBQ1gsRUFBRTtDQUNGLElBQUksSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLFFBQVEsQ0FBQztDQUNqQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsV0FBVyxPQUFPLEVBQUUsS0FBSyxHQUFHLE9BQU87RUFDL0MsTUFBTTtFQUNOLEtBQUssUUFBUTtFQUNiLEtBQUs7RUFDTCxVQUFVO0NBQ1gsRUFBRTtDQUNGLElBQUksb0JBQW9CLElBQUksSUFBSTtDQUNoQyxFQUFFLFNBQVMsTUFBTTtFQUNoQixJQUFJLElBQUlBLElBQUUsRUFBRSxFQUFFLEtBQUssV0FBVyxJQUFJLEVBQUUsSUFBSSxDQUFDO0VBQ3pDLElBQUksR0FBRztHQUNOLEVBQUUsS0FBSyxDQUFDO0dBQ1I7RUFDRDtFQUNBLEVBQUUsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDO0NBQ2IsQ0FBQztDQUNELElBQUksSUFBSSxDQUFDO0NBQ1QsT0FBTyxNQUFNLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE9BQU87RUFDbEQsSUFBSSxJQUFJLFNBQVM7RUFDakIsRUFBRSxLQUFLO0dBQ04sTUFBTTtHQUNOLEtBQUs7R0FDTCxZQUFZO0dBQ1osV0FBVyxFQUFFO0dBQ2IsV0FBVztFQUNaLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsU0FBUyxHQUFHLE1BQU07R0FDbkMsRUFBRSxLQUFLO0lBQ04sTUFBTTtJQUNOLEtBQUssR0FBRyxFQUFFLE9BQU87SUFDakIsS0FBSztJQUNMLFVBQVU7SUFDVixZQUFZO0dBQ2IsQ0FBQztFQUNGLENBQUM7Q0FDRixDQUFDLEdBQUc7QUFDTDtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUNwQixJQUFJLEtBQUssR0FBRyxPQUFPO0NBQ25CLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDLElBQUk7Q0FDekIsT0FBTyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFDeEI7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLEtBQUssTUFBTSxPQUFPO0NBQ3RCLElBQUksRUFBRSxXQUFXLGNBQWMsT0FBTyxLQUFLLFVBQVUsT0FBTyxJQUFJLEtBQUssYUFBYSxLQUFLLEdBQUc7RUFDekYsT0FBTztFQUNQLFVBQVU7RUFDVix1QkFBdUI7Q0FDeEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0NBQ1gsSUFBSSxFQUFFLFdBQVcsYUFBYSxPQUFPLEtBQUssVUFBVSxPQUFPLElBQUksS0FBSyxhQUFhLEtBQUssR0FBRztFQUN4RixPQUFPO0VBQ1AsdUJBQXVCO0NBQ3hCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztDQUNYLEtBQUssRUFBRSxXQUFXLFVBQVUsRUFBRSxTQUFTLFlBQVksT0FBTyxLQUFLLFlBQVksYUFBYSxPQUFPO0VBQzlGLElBQUksSUFBSSxJQUFJLEtBQUssQ0FBQztFQUNsQixJQUFJLENBQUMsT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEdBQUcsT0FBTyxJQUFJLEtBQUssZUFBZSxLQUFLLEdBQUcsRUFBRSxXQUFXLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0NBQ3pHO0NBQ0EsS0FBSyxFQUFFLFdBQVcsY0FBYyxFQUFFLFNBQVMsZ0JBQWdCLE9BQU8sS0FBSyxZQUFZLGFBQWEsT0FBTztFQUN0RyxJQUFJLElBQUksSUFBSSxLQUFLLENBQUM7RUFDbEIsSUFBSSxDQUFDLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxHQUFHLE9BQU8sSUFBSSxLQUFLLGVBQWUsS0FBSyxHQUFHO0dBQ3RFLFdBQVc7R0FDWCxXQUFXO0VBQ1osQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0NBQ1o7Q0FDQSxPQUFPRCxJQUFFLENBQUM7QUFDWDtBQUNBLFNBQVNFLElBQUUsR0FBRyxHQUFHO0NBQ2hCLElBQUksSUFBSSxFQUFFLGFBQWE7Q0FDdkIsSUFBSSxNQUFNLFFBQVEsT0FBTztFQUN4QixNQUFNO0VBQ04sT0FBTztDQUNSO0NBQ0EsSUFBSSxJQUFJLEVBQUUsS0FBSyxNQUFNLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxRQUFRLE1BQU0sT0FBTyxLQUFLLFlBQVksT0FBTyxTQUFTLENBQUMsQ0FBQztDQUN2RixPQUFPLE1BQU0sVUFBVTtFQUN0QixNQUFNO0VBQ04sT0FBTyxFQUFFO0NBQ1YsSUFBSSxFQUFFLFdBQVcsSUFBSTtFQUNwQixNQUFNO0VBQ04sT0FBTztDQUNSLElBQUksTUFBTSxRQUFRO0VBQ2pCLE1BQU07RUFDTixPQUFPLEVBQUUsUUFBUSxHQUFHLE1BQU0sSUFBSSxHQUFHLENBQUM7Q0FDbkMsSUFBSSxNQUFNLFFBQVE7RUFDakIsTUFBTTtFQUNOLE9BQU8sRUFBRSxRQUFRLEdBQUcsTUFBTSxJQUFJLEdBQUcsQ0FBQyxJQUFJLEVBQUU7Q0FDekMsSUFBSSxNQUFNLFFBQVE7RUFDakIsTUFBTTtFQUNOLE9BQU8sS0FBSyxJQUFJLEdBQUcsQ0FBQztDQUNyQixJQUFJLE1BQU0sUUFBUTtFQUNqQixNQUFNO0VBQ04sT0FBTyxLQUFLLElBQUksR0FBRyxDQUFDO0NBQ3JCLElBQUk7RUFDSCxNQUFNO0VBQ04sT0FBTztDQUNSO0FBQ0Q7QUFDQSxTQUFTLEdBQUcsR0FBRztDQUNkLE9BQU8sRUFBRSxTQUFTLFNBQVMsS0FBSyxFQUFFLFVBQVUsUUFBUSxFQUFFLFVBQVUsS0FBSyxJQUFJLE1BQU0sRUFBRSxTQUFTLFVBQVUsR0FBRyxLQUFLLE1BQU0sRUFBRSxLQUFLLE1BQU0sSUFBSSxLQUFLLGFBQWEsS0FBSyxHQUFHO0VBQzVKLHVCQUF1QjtFQUN2Qix1QkFBdUI7Q0FDeEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLEtBQUs7QUFDbEI7QUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDcEIsSUFBSSxNQUFNLEdBQUcsT0FBTztDQUNwQixJQUFJLEtBQUssTUFBTSxPQUFPO0NBQ3RCLElBQUksS0FBSyxNQUFNLE9BQU87Q0FDdEIsSUFBSSxNQUFNLFVBQVU7RUFDbkIsSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDO0VBQy9CLElBQUksT0FBTyxTQUFTLENBQUMsS0FBSyxPQUFPLFNBQVMsQ0FBQyxHQUFHLE9BQU8sSUFBSTtDQUMxRDtDQUNBLElBQUksTUFBTSxVQUFVLE1BQU0sWUFBWTtFQUNyQyxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7RUFDdkUsSUFBSSxDQUFDLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLE1BQU0sQ0FBQyxHQUFHLE9BQU8sSUFBSTtDQUN0RDtDQUNBLE9BQU8sTUFBTSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUlGLElBQUUsQ0FBQyxDQUFDLENBQUMsY0FBY0EsSUFBRSxDQUFDLENBQUM7QUFDOUQ7QUFDQSxTQUFTQSxJQUFFLEdBQUc7Q0FDYixJQUFJLEtBQUssTUFBTSxPQUFPO0NBQ3RCLElBQUksT0FBTyxLQUFLLFVBQVUsT0FBTztDQUNqQyxJQUFJLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxXQUFXLE9BQU8sT0FBTyxDQUFDO0NBQ2xFLElBQUksYUFBYSxNQUFNLE9BQU8sRUFBRSxZQUFZO0NBQzVDLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxPQUFPLEVBQUUsS0FBSyxNQUFNQSxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQ3pELElBQUksT0FBTyxLQUFLLFVBQVUsSUFBSTtFQUM3QixPQUFPLEtBQUssVUFBVSxDQUFDO0NBQ3hCLFFBQVE7RUFDUCxPQUFPO0NBQ1I7Q0FDQSxPQUFPLE9BQU8sQ0FBQztBQUNoQjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDakIsT0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLEVBQUUsY0FBYyxFQUFFLE1BQU07RUFDakQsV0FBVyxFQUFFO0VBQ2IsV0FBVztDQUNaLElBQUksRUFBRSxjQUFjLFFBQVE7RUFDM0IsV0FBVyxFQUFFO0VBQ2IsV0FBVztDQUNaLElBQUksT0FBTztBQUNaO0FBQ0EsU0FBU0csSUFBRSxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxLQUFLLE1BQU0sT0FBTztDQUN0QixJQUFJLE1BQU0sVUFBVSxNQUFNLFlBQVk7RUFDckMsSUFBSSxJQUFJLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQztFQUMxQixPQUFPLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxJQUFJLEtBQUssTUFBTSxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxFQUFFO0NBQ2xIO0NBQ0EsT0FBT0gsSUFBRSxDQUFDO0FBQ1g7QUFDQSxTQUFTSSxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLEVBQUUsV0FBVyxjQUFjLEVBQUUsU0FBUyxXQUFXLE9BQU8sTUFBTTtDQUNsRSxJQUFJLEVBQUUsV0FBVyxZQUFZLEVBQUUsU0FBUyxVQUFVO0VBQ2pELElBQUksSUFBSSxPQUFPLENBQUM7RUFDaEIsT0FBTyxPQUFPLFNBQVMsQ0FBQyxJQUFJLElBQUk7Q0FDakM7Q0FDQSxPQUFPLEVBQUUsU0FBUyxVQUFVLEVBQUUsU0FBUyxhQUFhLEtBQUssT0FBTztBQUNqRTtBQUNBLFNBQVMsR0FBRyxHQUFHO0NBQ2QsSUFBSSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsWUFBWTtDQUM3QixPQUFPLE1BQU0sVUFBVSxNQUFNLFVBQVUsSUFBSTtBQUM1QztBQUNBLFNBQVMsR0FBRyxHQUFHO0NBQ2QsT0FBTyxNQUFNLFNBQVMsS0FBSyxFQUFFLFlBQVk7QUFDMUM7QUFHQSxTQUFTLEdBQUcsRUFBRSxTQUFTLEdBQUcsT0FBTyxHQUFHLE9BQU8sR0FBRyxVQUFVLEdBQUcsUUFBUSxLQUFLO0NBQ3ZFLElBQUksQ0FBQyxHQUFHLE1BQUEsR0FBS0MsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDO0NBQ2hCLFFBQUEsR0FBT2QsYUFBQUEsVUFBQUEsT0FBUTtFQUNkLEVBQUUsQ0FBQztDQUNKLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVILEtBQUc7RUFDN0IsT0FBTyxZQUFZO0VBQ25CLGNBQWMsWUFBWTtFQUMxQixnQkFBZ0I7RUFDaEIsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsUUFBd0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUVrQixtQkFBQUEsVUFBRyxFQUFFLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUV0QixLQUFHO0dBQzlELFNBQVM7R0FDVCxTQUFTO0dBQ1QsVUFBVTtFQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVBLEtBQUc7R0FDeEIsZUFBZSxFQUFFLENBQUM7R0FDbEIsVUFBVTtFQUNYLENBQUMsQ0FBQyxFQUFFLENBQUM7RUFDTCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQ2xDLFdBQVc7R0FDWCxVQUFVLEVBQUUsUUFBUSxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUMsS0FBSyxNQUFNO0lBQ2hELElBQUksSUFBSW1CLElBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJO0lBQzFCLE9BQU8sRUFBRSxXQUFXLGNBQWMsRUFBRSxTQUFTLFlBQTRCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7S0FDbkYsV0FBVztLQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtNQUN4RixXQUFXO01BQ1gsT0FBTyxNQUFNLFNBQVMsU0FBUztNQUMvQixXQUFXLE1BQU07T0FDaEIsSUFBSSxJQUFJLEVBQUUsT0FBTyxVQUFVO09BQzNCLEdBQUcsT0FBTztRQUNULEdBQUc7U0FDRixFQUFFLE1BQU07T0FDVixFQUFFO01BQ0g7TUFDQSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7T0FDdEMsT0FBTztPQUNQLFVBQVU7TUFDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7T0FDL0IsT0FBTztPQUNQLFVBQVU7TUFDWCxDQUFDLENBQUM7S0FDSCxDQUFDLENBQUM7SUFDSCxHQUFHLEVBQUUsR0FBRyxJQUFJLEVBQUUsV0FBVyxZQUFZLEVBQUUsU0FBUyxTQUF5QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO0tBQ25GLFdBQVc7S0FDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsTUFBTSxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7TUFDeEYsV0FBVztNQUNYLE9BQU87TUFDUCxXQUFXLE1BQU07T0FDaEIsSUFBSSxJQUFJQyxJQUFFLEVBQUUsT0FBTyxPQUFPLENBQUM7T0FDM0IsR0FBRyxPQUFPO1FBQ1QsR0FBRztTQUNGLEVBQUUsTUFBTTtPQUNWLEVBQUU7TUFDSDtNQUNBLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtPQUN0QyxPQUFPO09BQ1AsVUFBVTtNQUNYLENBQUMsR0FBRyxFQUFFLFFBQVEsS0FBSyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO09BQ3BELE9BQU8sT0FBTyxFQUFFLEtBQUs7T0FDckIsVUFBVSxFQUFFO01BQ2IsR0FBRyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztLQUNyQixDQUFDLENBQUM7SUFDSCxHQUFHLEVBQUUsR0FBRyxJQUFJLEVBQUUsV0FBVyxhQUE2QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO0tBQ2hFLFdBQVc7S0FDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsTUFBTSxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFlBQVk7TUFDMUYsV0FBVztNQUNYLE9BQU87TUFDUCxXQUFXLE1BQU07T0FDaEIsSUFBSSxJQUFJQSxJQUFFLEVBQUUsT0FBTyxPQUFPLENBQUM7T0FDM0IsR0FBRyxPQUFPO1FBQ1QsR0FBRztTQUNGLEVBQUUsTUFBTTtPQUNWLEVBQUU7TUFDSDtLQUNELENBQUMsQ0FBQztJQUNILEdBQUcsRUFBRSxHQUFHLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7S0FDdEMsV0FBVztLQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztNQUN2RixXQUFXO01BQ1gsTUFBTSxFQUFFLFdBQVcsWUFBWSxFQUFFLFNBQVMsV0FBVyxXQUFXLEVBQUUsU0FBUyxTQUFTLFNBQVM7TUFDN0YsT0FBTztNQUNQLFdBQVcsTUFBTTtPQUNoQixJQUFJLElBQUlBLElBQUUsRUFBRSxPQUFPLE9BQU8sQ0FBQztPQUMzQixHQUFHLE9BQU87UUFDVCxHQUFHO1NBQ0YsRUFBRSxNQUFNO09BQ1YsRUFBRTtNQUNIO0tBQ0QsQ0FBQyxDQUFDO0lBQ0gsR0FBRyxFQUFFLEdBQUc7R0FDVCxDQUFDO0VBQ0YsQ0FBQztDQUNGLENBQUM7QUFDRjtBQUNBLElBQUksS0FBQSxHQUFJbkIsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsTUFBTSxHQUFHLFFBQVEsR0FBRyxZQUFZLEdBQUcsWUFBWSxHQUFHLE1BQU0sR0FBRyxjQUFjLEdBQUcsa0JBQWtCLEdBQUcsa0JBQWtCLElBQUksWUFBWSxHQUFHLGtCQUFrQixHQUFHLFNBQVMsR0FBRyxRQUFRLEtBQUssS0FBSyxXQUFXLElBQUksSUFBSSxVQUFVLElBQUksR0FBRyxVQUFVLEtBQUssUUFBUSxZQUFZLEtBQUssQ0FBQyxHQUFHLFlBQVksS0FBSyxDQUFDLEdBQUcsV0FBVyxLQUFLLENBQUMsR0FBRyxVQUFVLEtBQUssQ0FBQyxHQUFHLFlBQVksS0FBSyxDQUFDLEdBQUcsV0FBVyxLQUFLLElBQUksY0FBYyxJQUFJLG1CQUFtQixJQUFJLGdCQUFnQixJQUFJLGNBQWMsSUFBSSxTQUFTLElBQUksaUJBQWlCLElBQUksR0FBRyxNQUFNLElBQUk7Q0FDaGdCLElBQUksQ0FBQyxHQUFHLE1BQUEsR0FBS29CLGFBQUFBLFNBQUFBLE9BQVEsSUFBSWIsSUFBRSxDQUFDLElBQUksSUFBSUksSUFBRSxDQUFDLElBQUlKLElBQUUsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksT0FBQSxHQUFNYSxhQUFBQSxTQUFBQSxDQUFFLEtBQUssUUFBUSxHQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtBLGFBQUFBLFNBQUFBLENBQUUsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksT0FBQSxHQUFNQSxhQUFBQSxTQUFBQSxDQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksT0FBQSxHQUFNQSxhQUFBQSxTQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsRUFBRSxHQUFHLENBQUMsR0FBRyxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsRUFBRSxHQUFHLENBQUMsR0FBRyxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsaUJBQWtCLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxFQUFFLFlBQVksRUFBRSxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLGlCQUFrQixJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsSUFBSSxHQUFHLENBQUMsSUFBSSxNQUFBLEdBQUtBLGFBQUFBLFNBQUFBLENBQUUsSUFBSSxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsSUFBSSxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxHQUFHLE1BQUEsR0FBS2hCLGFBQUFBLE9BQUFBLENBQUUsRUFBRSxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsT0FBQUEsQ0FBRSxDQUFDLEdBQUcsSUFBSSxNQUFNO0NBQ2poQixDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxJQUFJO0dBQ0gsSUFBSSxJQUFJLEdBQUcsQ0FBQztHQUNaLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLFFBQVEsRUFBRSxFQUFFLElBQUksR0FBRyxHQUFHLEtBQUssR0FBRyxRQUFRLFFBQVE7RUFDL0QsU0FBUyxHQUFHO0dBQ1gsSUFBSSxJQUFJLGFBQWEsUUFBUSxJQUFvQixzQkFBTSwyQkFBMkI7R0FDbEYsR0FBRyxFQUFFLE9BQU8sR0FBRyxLQUFLLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSyxRQUFRO0VBQ3JEO0NBQ0QsR0FBRztFQUNGO0VBQ0E7RUFDQTtDQUNELENBQUMsSUFBQSxHQUFHRSxhQUFBQSxVQUFBQSxPQUFRO0VBQ1gsSUFBSSxHQUFHO0dBQ04sRUFBRUMsSUFBRSxDQUFDLENBQUM7R0FDTjtFQUNEO0VBQ0EsSUFBSSxHQUFHO0dBQ04sRUFBRUksSUFBRSxDQUFDLENBQUM7R0FDTjtFQUNEO0VBQ0EsSUFBSSxHQUFHLFFBQVE7R0FDZCxFQUFFSixJQUFFLEVBQUUsTUFBTSxDQUFDO0dBQ2I7RUFDRDtFQUNBLElBQUksR0FBRyxZQUFZO0dBQ2xCLEVBQUVJLElBQUUsRUFBRSxVQUFVLENBQUM7R0FDakI7RUFDRDtFQUNBLEVBQUVKLElBQUUsS0FBSyxDQUFDLENBQUM7Q0FDWixHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxJQUFBLEdBQUdELGFBQUFBLFVBQUFBLE9BQVE7RUFDWCxNQUFNLEVBQUUsQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0NBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBQSxHQUFHQSxhQUFBQSxVQUFBQSxPQUFRO0VBQ2hCLElBQUksSUFBSSxJQUFJQyxJQUFFLENBQUMsSUFBSSxJQUFJSSxJQUFFLENBQUMsSUFBSSxHQUFHLFNBQVNKLElBQUUsRUFBRSxNQUFNLElBQUlJLElBQUUsR0FBRyxVQUFVO0VBQ3ZFLEVBQUUsRUFBRSxZQUFZLEVBQUUsR0FBRyxFQUFFLGVBQWUsRUFBRSxFQUFFLFdBQVcsR0FBRyxFQUFFLG1CQUFtQixFQUFFLEVBQUUsY0FBYyxHQUFHLElBQUksTUFBTTtHQUMzRyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUM7R0FDakIsT0FBTyxFQUFFLElBQUksRUFBRSxjQUFjLEdBQUc7RUFDakMsQ0FBQztDQUNGLEdBQUc7RUFDRjtFQUNBO0VBQ0E7Q0FDRCxDQUFDLElBQUEsR0FBR0wsYUFBQUEsVUFBQUEsT0FBUTtFQUNYLElBQUksSUFBSSxDQUFDO0VBQ1QsUUFBUSxZQUFZO0dBQ25CLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSTtJQUNqQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRTtJQUNiLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxLQUFLLE1BQU0sUUFBUSxJQUFJO0tBQ3BDTSxJQUFFLEdBQUcsQ0FBQztLQUNOQSxJQUFFLEdBQUcsQ0FBQztLQUNOQSxJQUFFLElBQUksQ0FBQztLQUNQQSxJQUFFLEdBQUcsQ0FBQztJQUNQLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQztJQUNaLElBQUksR0FBRyxDQUFDLEdBQUcsR0FBRztJQUNkLElBQUksR0FBRztLQUNOLElBQUksSUFBSUwsSUFBRSxDQUFDO0tBQ1gsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUUsZUFBZSxFQUFFLEVBQUUsV0FBVyxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsRUFBRSxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlHLE9BQU8sSUFBSSxHQUFHO0tBQ2IsSUFBSSxJQUFJSSxJQUFFLENBQUM7S0FDWCxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsWUFBWSxFQUFFLEdBQUcsRUFBRSxlQUFlLEVBQUUsRUFBRSxXQUFXLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxFQUFFLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDOUcsT0FBTyxJQUFJLEdBQUcsUUFBUTtLQUNyQixJQUFJLElBQUlKLElBQUUsRUFBRSxNQUFNO0tBQ2xCLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxZQUFZLEVBQUUsR0FBRyxFQUFFLGVBQWUsRUFBRSxFQUFFLFdBQVcsR0FBRyxFQUFFLGtCQUFrQixFQUFFLEVBQUUsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUM5RyxPQUFPLElBQUksR0FBRyxZQUFZO0tBQ3pCLElBQUksSUFBSUksSUFBRSxFQUFFLFVBQVU7S0FDdEIsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUUsZUFBZSxFQUFFLEVBQUUsV0FBVyxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsRUFBRSxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlHO0lBQ0EsTUFBTSxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxFQUFFLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxHQUFHLEVBQUUsSUFBSTtHQUNwSSxTQUFTLEdBQUc7SUFDWCxJQUFJLEdBQUc7SUFDUCxJQUFJLElBQUksYUFBYSxRQUFRLElBQW9CLHNCQUFNLDhCQUE4QjtJQUNyRixHQUFHLEVBQUUsT0FBTyxHQUFHLEtBQUssQ0FBQztHQUN0QixVQUFVO0lBQ1QsS0FBSyxHQUFHLENBQUMsQ0FBQztHQUNYO0VBQ0QsRUFBQSxDQUFHLFNBQVM7R0FDWCxJQUFJLENBQUM7RUFDTjtDQUNELEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUMsSUFBQSxHQUFHTCxhQUFBQSxVQUFBQSxPQUFRO0VBQ1gsR0FBRyxVQUFVO0NBQ2QsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFBLEdBQUdBLGFBQUFBLFVBQUFBLE9BQVE7RUFDakIsR0FBRyxVQUFVO0NBQ2QsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFBLEdBQUdBLGFBQUFBLFVBQUFBLE9BQVE7RUFDaEIsSUFBSSxPQUFPLFlBQVksQ0FBQyxHQUFHO0VBQzNCLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSTtHQUNmLFdBQVc7R0FDWCxVQUFVO0dBQ1YsWUFBWTtHQUNaLE1BQU07R0FDTixTQUFTO0dBQ1QsU0FBUztFQUNWO0VBQ0EsUUFBUSxZQUFZO0dBQ25CLElBQUk7SUFDSCxJQUFJLElBQUksR0FBRztJQUNYLElBQUksQ0FBQyxHQUFHO0lBQ1IsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUU7SUFDYixJQUFJLElBQUksTUFBTSxFQUFFLEdBQUcsQ0FBQztJQUNwQixJQUFJLEdBQUc7SUFDUCxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7S0FDckIsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxLQUFLLENBQUM7S0FDMUI7SUFDRDtJQUNBLEVBQUUsRUFBRSxJQUFJLEdBQUcsR0FBRyxFQUFFLGNBQWMsRUFBRSxLQUFLLE1BQU0sR0FBRyxLQUFLLEVBQUUsSUFBSTtHQUMxRCxTQUFTLEdBQUc7SUFDWCxJQUFJLEdBQUc7SUFDUCxJQUFJLElBQUksYUFBYSxRQUFRLElBQW9CLHNCQUFNLDZCQUE2QjtJQUNwRixHQUFHLEVBQUUsT0FBTyxHQUFHLEtBQUssQ0FBQztHQUN0QixVQUFVO0lBQ1QsS0FBSyxHQUFHLENBQUMsQ0FBQztHQUNYO0VBQ0QsRUFBQSxDQUFHLFNBQVM7R0FDWCxJQUFJLENBQUM7RUFDTjtDQUNELEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELElBQUksSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLFdBQVcsTUFBTSxJQUFJLEtBQUssRUFBRSxpQkFBaUIsYUFBYSxRQUFRLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLE9BQU8sWUFBWSxPQUFPLFFBQVEsS0FBSyxPQUFPLFlBQVksT0FBTyxRQUFRLElBQUksT0FBTyxVQUFVLEtBQUEsR0FBSWdCLGFBQUFBLFFBQUFBLE9BQVEsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUMsR0FBRztFQUN6UjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUMsR0FBRyxLQUFBLEdBQUlBLGFBQUFBLFFBQUFBLE9BQVEsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRztFQUNwQztFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUMsR0FBRyxLQUFLLElBQUksTUFBTSxFQUFFLFNBQVMsRUFBRSxRQUFRLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQztDQUM5RyxDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxNQUFNLEtBQUssRUFBRSxDQUFDO0NBQ2YsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0NBQ1QsSUFBSSxNQUFBLEdBQUtBLGFBQUFBLFFBQUFBLE9BQVEsSUFBSSxJQUFJLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLEdBQUc7RUFDOUM7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUMsR0FBRyxNQUFBLEdBQUtBLGFBQUFBLFFBQUFBLE9BQVE7RUFDaEIsSUFBSSxvQkFBb0IsSUFBSSxJQUFJO0VBQ2hDLE9BQU8sS0FBSyxHQUFHLFNBQVMsTUFBTTtHQUM3QixJQUFJLElBQUksRUFBRTtHQUNWLEVBQUUsSUFBSSxLQUFLLFFBQVEsTUFBTSxLQUFLLFlBQVksT0FBTyxDQUFDLENBQUM7RUFDcEQsQ0FBQyxHQUFHO0NBQ0wsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO0NBQ1YsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFRO0VBQ1AsS0FBSyxFQUFFLFNBQVMsS0FBSyxHQUFHLE9BQU8sS0FBSyxHQUFHLEVBQUU7Q0FDMUMsR0FBRztFQUNGO0VBQ0EsRUFBRTtFQUNGO0NBQ0QsQ0FBQztDQUNELElBQUksS0FBQSxHQUFJQSxhQUFBQSxRQUFBQSxPQUFRLEdBQUcsSUFBSSxHQUFHLEtBQUssSUFBSSxNQUFNLENBQUMsR0FBRztFQUM1QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxHQUFHLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxTQUFTLE1BQU0sQ0FBQyxDQUFDLFFBQVEsS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLEVBQUUsUUFBUSxNQUFNLEVBQUUsU0FBUyxPQUFPLENBQUMsQ0FBQyxNQUFNLElBQUksR0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLLENBQUMsSUFBSSxJQUFJLEdBQUcsS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssS0FBSyxJQUFJLEVBQUUsUUFBUSxLQUFLLEVBQUUsR0FBRyxLQUFLLEVBQUUsTUFBTSxJQUFJLEVBQUUsR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxHQUFHLFNBQVMsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsUUFBQUEsT0FBUTtFQUNqVSxJQUFJLG9CQUFvQixJQUFJLElBQUk7RUFDaEMsT0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNO0dBQzFCLEVBQUUsSUFBSVIsSUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDcEIsQ0FBQyxHQUFHLE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsTUFBTSxDQUFDLENBQUMsQ0FBQztDQUNuRSxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLEdBQUcsVUFBVSxFQUFFO0NBQ2hCLEdBQUcsQ0FBQyxFQUFFLENBQUM7Q0FDUCxJQUFJLE1BQUEsR0FBS1EsYUFBQUEsUUFBQUEsT0FBUTtFQUNoQixJQUFJLG9CQUFvQixJQUFJLElBQUk7RUFDaEMsT0FBTyxFQUFFLFNBQVMsTUFBTTtHQUN2QixJQUFJLElBQUlMLElBQUUsR0FBRyxDQUFDO0dBQ2QsRUFBRSxTQUFTLFVBQVUsRUFBRSxJQUFJLEVBQUUsS0FBSyxHQUFHLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxHQUFHLENBQUMsR0FBRztFQUMzRCxDQUFDLEdBQUc7Q0FDTCxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFBLEdBQUtLLGFBQUFBLFFBQUFBLE9BQVEsRUFBRSxRQUFRLE1BQU0sRUFBRSxTQUFTLFVBQVUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsS0FBSyxNQUFNUixJQUFFLEVBQUUsS0FBSyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxNQUFNLFVBQVUsR0FBRyxTQUFTLEtBQUssR0FBRyxPQUFPLE1BQU0sR0FBRyxJQUFJLENBQUMsQ0FBQztDQUN6TCxTQUFTLEdBQUcsR0FBRztFQUNkLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQztDQUNiO0NBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztFQUNqQixJQUFJLE9BQU87R0FDVixHQUFHO0lBQ0YsSUFBSTtFQUNOLEVBQUUsR0FBRyxFQUFFLENBQUM7Q0FDVDtDQUNBLFNBQVMsR0FBRyxHQUFHO0VBQ2QsR0FBRyxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7Q0FDeEI7Q0FDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7RUFDcEIsSUFBSSxJQUFJLEtBQUssRUFBRSxNQUFNLElBQUksRUFBRSxFQUFFO0VBQzdCLE9BQU8sSUFBSSxFQUFFO0dBQ1osS0FBSztHQUNMLFVBQVU7R0FDVixRQUFRO0dBQ1IsT0FBTztFQUNSLENBQUMsSUFBSUUsSUFBRSxHQUFHLENBQUM7Q0FDWjtDQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7RUFDakIsSUFBSSxJQUFJRixJQUFFLEdBQUcsR0FBRyxDQUFDO0VBQ2pCLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxHQUFHLEVBQUUsQ0FBQztDQUNsQjtDQUNBLFNBQVMsR0FBRyxHQUFHO0VBQ2QsT0FBTyxHQUFHLEVBQUUsS0FBSyxHQUFHLE1BQU1BLElBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxJQUFJLEVBQUUsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRSxJQUFJO0NBQy9FO0NBQ0EsU0FBUyxLQUFLO0VBQ2IsR0FBRyxJQUFJLEdBQUcsRUFBRSxJQUFJO0NBQ2pCO0NBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztFQUNqQixJQUFJLElBQUlBLElBQUUsR0FBRyxHQUFHLENBQUM7RUFDakIsR0FBRztHQUNGLE9BQU87R0FDUCxPQUFPLEVBQUUsR0FBRyxFQUFFO0VBQ2YsQ0FBQztDQUNGO0NBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztFQUNqQixHQUFHLEVBQUUsS0FBSyxHQUFHLE1BQU1BLElBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJO0NBQzlEO0NBQ0EsU0FBUyxHQUFHLEdBQUc7RUFDZCxJQUFJLE1BQU07R0FDVCxJQUFJLElBQUksSUFBSSxJQUFJLENBQUM7R0FDakIsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRztFQUMzQyxDQUFDO0NBQ0Y7Q0FDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7RUFDcEIsSUFBSSxNQUFNLFFBQVE7RUFDbEIsSUFBSSxJQUFJQSxJQUFFLEdBQUcsR0FBRyxDQUFDO0VBQ2pCLElBQUksTUFBTTtHQUNULElBQUksTUFBTSxVQUFVLE9BQU8sb0JBQW9CLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsSUFBSSxJQUFJO0dBQ3RGLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQztHQUNqQixPQUFPLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxHQUFHO0VBQ3BDLENBQUM7Q0FDRjtDQUNBLFNBQVMsR0FBRyxHQUFHO0VBQ2QsSUFBSSxNQUFNLFFBQVE7R0FDakIsSUFBSSxNQUFNLFVBQVU7SUFDbkIsSUFBSSxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsU0FBUyxVQUFVLEVBQUUsR0FBRztJQUNoRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsS0FBSztLQUNqQixtQkFBbUIsSUFBSSxJQUFJLENBQUM7S0FDNUI7SUFDRDtJQUNBLEdBQUcsb0JBQW9CLElBQUksSUFBSSxDQUFDQSxJQUFFLEVBQUUsS0FBSyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsSUFBSSxJQUFJLENBQUM7SUFDMUY7R0FDRDtHQUNBLElBQUksTUFBTTtJQUNULElBQUksSUFBSSxJQUFJLElBQUksQ0FBQztJQUNqQixPQUFPLEdBQUcsU0FBUyxNQUFNO0tBQ3hCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQztJQUMxQixDQUFDLEdBQUc7R0FDTCxDQUFDO0VBQ0Y7Q0FDRDtDQUNBLElBQUksS0FBS0QsSUFBRSxnQkFBZ0IsRUFBRSxHQUFHLEtBQUssRUFBRSxVQUFVLE1BQU0sU0FBUyxJQUFJLEtBQUssR0FBRyxLQUFLLEVBQUUsUUFBUSxNQUFNLEVBQUUsU0FBUyxHQUFHLEtBQUssRUFBRSxRQUFRLHlCQUF5QixDQUFDLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxRQUFRLGlCQUFpQixDQUFDLEVBQUEsQ0FBRyxLQUFLLE1BQU0sTUFBTSxpQkFBaUIsaUJBQWlCLE9BQU8sTUFBTSxjQUFjLGFBQWEsR0FBRyxXQUFXLE1BQU0saUJBQWlCLGlCQUFpQixHQUFHLFdBQVcsTUFBTSxlQUFlLFVBQVUsSUFBSSxFQUFFLFFBQVEsTUFBTSxFQUFFLFNBQVMsT0FBTyxDQUFDLENBQUMsU0FBUyxNQUFNLEVBQUUsQ0FBQyxDQUFDLE9BQU8sT0FBTyxHQUFHLEtBQUssT0FBTyxJQUFJLEtBQUssSUFBSSxFQUFFLFdBQVcsY0FBYyxDQUFDLEdBQUcsS0FBSztDQUMvaEIsU0FBUyxLQUFLO0VBQ2IsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsWUFBWSxFQUFFLFVBQVU7R0FDaEQsTUFBTSxTQUFTLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU8sRUFBRSxXQUFXLGlEQUFpRCxDQUFDO0dBQzlHLEVBQUUsS0FBSyxNQUFNO0lBQ1osSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUU7SUFDdkIsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUMvQixXQUFXO0tBQ1gsT0FBTztNQUNOLE9BQU8sTUFBTSxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sS0FBSyxXQUFXLEdBQUcsRUFBRSxNQUFNO01BQ2pFLFVBQVUsTUFBTSxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsRUFBRTtLQUN4QztJQUNELEdBQUcsRUFBRSxHQUFHO0dBQ1QsQ0FBQztHQUNlLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU8sRUFBRSxXQUFXLCtDQUErQyxDQUFDO0VBQ3ZGLEVBQUUsQ0FBQztDQUNKO0NBQ0EsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixLQUFLO0VBQ0wsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVO0dBQ08saUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztJQUN4QixXQUFXO0lBQ1gsVUFBVTtLQUNULEtBQXFCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7TUFDL0IsV0FBVztNQUNYLE1BQU07TUFDTixPQUFPO01BQ1AsYUFBYTtNQUNiLFdBQVcsTUFBTTtPQUNoQixHQUFHLEVBQUUsT0FBTyxLQUFLLEdBQUcsRUFBRSxDQUFDO01BQ3hCO0tBQ0QsQ0FBQyxJQUFJO0tBQ0wsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsU0FBUztNQUMvQixXQUFXO01BQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxXQUFXLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtPQUMzRixXQUFXO09BQ1gsT0FBTyxLQUFLO09BQ1osV0FBVyxNQUFNO1FBQ2hCLElBQUksSUFBSSxFQUFFLE9BQU8sU0FBUztRQUMxQixFQUFFLENBQUMsR0FBRyxtQkFBbUIsSUFBSSxJQUFJLENBQUM7T0FDbkM7T0FDQSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7UUFDdEMsT0FBTztRQUNQLFVBQVU7T0FDWCxDQUFDLEdBQUcsR0FBRyxLQUFLLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7UUFDN0MsT0FBTyxFQUFFO1FBQ1QsVUFBVSxFQUFFO09BQ2IsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO01BQ1gsQ0FBQyxDQUFDO0tBQ0gsQ0FBQyxJQUFJO0tBQ0wsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsU0FBUztNQUMvQixXQUFXO01BQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxZQUFZLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtPQUM1RixXQUFXO09BQ1gsT0FBTyxPQUFPLENBQUM7T0FDZixXQUFXLE1BQU07UUFDaEIsSUFBSSxJQUFJLE9BQU8sRUFBRSxPQUFPLEtBQUs7UUFDN0IsRUFBRSxPQUFPLFNBQVMsQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUM7T0FDN0M7T0FDQSxXQUFXLEVBQUUsbUJBQW1CO1FBQy9CO1FBQ0E7UUFDQTtPQUNELEVBQUEsQ0FBRyxLQUFLLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7UUFDekMsT0FBTyxPQUFPLENBQUM7UUFDZixVQUFVO09BQ1gsR0FBRyxDQUFDLENBQUM7TUFDTixDQUFDLENBQUM7S0FDSCxDQUFDLElBQUk7SUFDTjtHQUNELENBQUM7R0FDRCxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQzdCLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxJQUFJO0dBQ0wsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUM3QixXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsSUFBSTtHQUNXLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87SUFDeEIsV0FBVztJQUNYLFVBQVU7S0FDTyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO01BQ3hCLFdBQVc7TUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO09BQ3BDLFdBQVc7T0FDWCxPQUFPO09BQ1AsVUFBVSxDQUFDLEdBQUcsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztRQUMzQyxXQUFXO1FBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsTUFBTSxFQUFFLFVBQVU7U0FDN0MsTUFBTSxTQUFTLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE1BQU07VUFDN0MsV0FBVztVQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7V0FDcEMsTUFBTTtXQUNOLFNBQVM7V0FDVCxXQUFXLE1BQU0sR0FBRyxFQUFFLE9BQU8sT0FBTztXQUNwQyxjQUFjO1VBQ2YsQ0FBQztTQUNGLENBQUM7U0FDRCxFQUFFLEtBQUssTUFBTTtVQUNaLElBQUksSUFBSSxHQUFHLGNBQWMsRUFBRSxNQUFNLEtBQUssRUFBRSxVQUFVLEtBQUssSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7VUFDckUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtXQUM5QixXQUFXO1dBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztZQUNsQyxXQUFXO1lBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO2FBQ3RDLFdBQVc7YUFDWCxNQUFNO2FBQ04sZUFBZSxHQUFHLENBQUM7YUFDbkIsVUFBVSxDQUFDLEVBQUU7YUFDYixjQUFjLEdBQUcsRUFBRSxRQUFRO2FBQzNCLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUMsR0FBRyxFQUFFLFdBQTJCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLEdBQUcsY0FBYyxFQUFFLE1BQU0sRUFBRSxZQUFZLElBQUksQ0FBQyxJQUFJLElBQUk7WUFDckssQ0FBQyxHQUFHLE1BQU0sRUFBRSxhQUFhLEVBQUUsU0FBUyxZQUE0QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO2FBQzNFLFdBQVdBLElBQUUsdUJBQXVCLElBQUksZ0NBQWdDLEVBQUU7YUFDMUUsT0FBTyxHQUFHLEVBQUUsRUFBRSxRQUFRLEVBQUU7YUFDeEIsV0FBVyxNQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsT0FBTyxLQUFLO2FBQ3pDLFVBQVU7Y0FDTyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO2VBQzNCLE9BQU87ZUFDUCxVQUFVO2NBQ1gsQ0FBQztjQUNlLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7ZUFDM0IsT0FBTztlQUNQLFVBQVU7Y0FDWCxDQUFDO2NBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtlQUMzQixPQUFPO2VBQ1AsVUFBVTtjQUNYLENBQUM7YUFDRjtZQUNELENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUzthQUMvQixXQUFXQSxJQUFFLHVCQUF1QixJQUFJLGdDQUFnQyxFQUFFO2FBQzFFLE1BQU07YUFDTixPQUFPLEVBQUUsRUFBRSxRQUFRO2FBQ25CLGFBQWE7YUFDYixXQUFXLE1BQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLEtBQUs7WUFDMUMsQ0FBQyxJQUFJLElBQUk7V0FDVixDQUFDO1VBQ0YsR0FBRyxFQUFFLEdBQUc7U0FDVCxDQUFDO1NBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtVQUN2QixXQUFXO1VBQ1gsVUFBVTtTQUNYLENBQUM7UUFDRixFQUFFLENBQUM7T0FDSixDQUFDLENBQUM7TUFDSCxDQUFDO0tBQ0YsQ0FBQztLQUNlLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87TUFDeEIsV0FBVztNQUNYLE9BQU8sRUFBRSxRQUFRLEdBQUcsR0FBRyxJQUFJO01BQzNCLFdBQVcsTUFBTTtPQUNoQixJQUFJLElBQUksRUFBRTtPQUNWLEdBQUcsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFLFVBQVU7TUFDakM7TUFDQSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO09BQ3BDLFdBQVc7T0FDWCxVQUFVLENBQUMsR0FBRyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTLEVBQUUsVUFBVTtRQUN2RCxLQUFLLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE1BQU07U0FDaEMsV0FBVztTQUNYLE9BQU8sRUFBRSxRQUFRLEdBQUcsR0FBRyxJQUFJO1NBQzNCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE1BQU0sRUFBRSxTQUFTLEdBQUcsQ0FBQztRQUNsRCxDQUFDLElBQUk7UUFDTCxHQUFHLEtBQUssR0FBRyxNQUFNO1NBQ2hCLElBQUksRUFBRSxTQUFTLFNBQVM7VUFDdkIsSUFBSSxJQUFJLEVBQUUsY0FBYyxXQUFXLElBQUksRUFBRSxJQUFJLENBQUM7VUFDOUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtXQUM5QixXQUFXO1dBQ1gsT0FBTyxFQUFFLFFBQVEsR0FBRyxFQUFFLElBQUk7V0FDMUIsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtZQUNqQyxTQUFTO1lBQ1QsV0FBVztZQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7YUFDckMsV0FBVzthQUNYLE1BQU07YUFDTixlQUFlLEdBQUcsQ0FBQzthQUNuQixVQUFVO2NBQ08saUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsSUFBSSxTQUFTLE9BQU8sQ0FBQztjQUMzQyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLENBQUM7Y0FDekIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsQ0FBQyxFQUFFLGFBQWEsR0FBRyxPQUFPLEVBQUUsQ0FBQzthQUNwRTtZQUNELENBQUM7V0FDRixDQUFDO1VBQ0YsR0FBRyxFQUFFLEdBQUc7U0FDVDtTQUNBLElBQUksQ0FBQyxFQUFFLEtBQUssT0FBTztTQUNuQixJQUFJLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxZQUFZLEdBQUcsSUFBSUMsSUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLE9BQU87U0FDOUUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsTUFBTTtVQUM5QixXQUFXRCxJQUFFLHlCQUF5QixJQUFJLG9DQUFvQyxFQUFFO1VBQ2hGLE9BQU8sRUFBRSxRQUFRLEdBQUcsRUFBRSxJQUFJO1VBQzFCLFVBQVU7V0FDVCxNQUFNLFNBQVMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtZQUM3QyxXQUFXO1lBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUzthQUNwQyxNQUFNO2FBQ04sU0FBUzthQUNULFdBQVcsTUFBTSxHQUFHLEdBQUcsR0FBRyxFQUFFLE9BQU8sT0FBTzthQUMxQyxjQUFjLGNBQWM7WUFDN0IsQ0FBQztXQUNGLENBQUM7V0FDRCxFQUFFLEtBQUssTUFBTTtZQUNaLElBQUksSUFBSUssS0FBRyxJQUFJLEtBQUssRUFBQSxHQUFLLEVBQUUsTUFBTSxFQUFFLElBQUk7WUFDdkMsT0FBTyxLQUFLLEVBQUUsV0FBVyxFQUFFLFdBQVcsY0FBYyxFQUFFLFNBQVMsWUFBNEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTthQUNsRyxXQUFXO2FBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtjQUNyQyxXQUFXO2NBQ1gsT0FBTyxNQUFNLFNBQVMsU0FBUztjQUMvQixXQUFXLE1BQU07ZUFDaEIsSUFBSSxJQUFJLEVBQUUsT0FBTyxVQUFVO2VBQzNCLEdBQUcsT0FBTztnQkFDVCxHQUFHLEtBQUssQ0FBQztpQkFDUixFQUFFLE1BQU07ZUFDVixFQUFFO2NBQ0g7Y0FDQSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7ZUFDdEMsT0FBTztlQUNQLFVBQVU7Y0FDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7ZUFDL0IsT0FBTztlQUNQLFVBQVU7Y0FDWCxDQUFDLENBQUM7YUFDSCxDQUFDO1lBQ0YsR0FBRyxFQUFFLEdBQUcsSUFBSSxFQUFFLFdBQVcsWUFBWSxFQUFFLFNBQVMsU0FBeUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTthQUNoRixXQUFXO2FBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtjQUNyQyxXQUFXO2NBQ1gsT0FBTztjQUNQLFdBQVcsTUFBTTtlQUNoQixJQUFJLElBQUlDLElBQUUsRUFBRSxPQUFPLE9BQU8sQ0FBQztlQUMzQixHQUFHLE9BQU87Z0JBQ1QsR0FBRyxLQUFLLENBQUM7aUJBQ1IsRUFBRSxNQUFNO2VBQ1YsRUFBRTtjQUNIO2NBQ0EsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO2VBQ3RDLE9BQU87ZUFDUCxVQUFVO2NBQ1gsQ0FBQyxHQUFHLEVBQUUsUUFBUSxLQUFLLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7ZUFDcEQsT0FBTyxPQUFPLEVBQUUsS0FBSztlQUNyQixVQUFVLEVBQUU7Y0FDYixHQUFHLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO2FBQ3JCLENBQUM7WUFDRixHQUFHLEVBQUUsR0FBRyxJQUFJLEVBQUUsV0FBVyxhQUE2QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO2FBQzdELFdBQVc7YUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxZQUFZO2NBQ3ZDLFdBQVc7Y0FDWCxPQUFPO2NBQ1AsV0FBVyxNQUFNO2VBQ2hCLElBQUksSUFBSUEsSUFBRSxFQUFFLE9BQU8sT0FBTyxDQUFDO2VBQzNCLEdBQUcsT0FBTztnQkFDVCxHQUFHLEtBQUssQ0FBQztpQkFDUixFQUFFLE1BQU07ZUFDVixFQUFFO2NBQ0g7YUFDRCxDQUFDO1lBQ0YsR0FBRyxFQUFFLEdBQUcsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTthQUNuQyxXQUFXO2FBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztjQUNwQyxXQUFXO2NBQ1gsTUFBTSxFQUFFLFdBQVcsWUFBWSxFQUFFLFNBQVMsV0FBVyxXQUFXLEVBQUUsU0FBUyxTQUFTLFNBQVM7Y0FDN0YsT0FBTztjQUNQLFdBQVcsTUFBTTtlQUNoQixJQUFJLElBQUlBLElBQUUsRUFBRSxPQUFPLE9BQU8sQ0FBQztlQUMzQixHQUFHLE9BQU87Z0JBQ1QsR0FBRyxLQUFLLENBQUM7aUJBQ1IsRUFBRSxNQUFNO2VBQ1YsRUFBRTtjQUNIO2FBQ0QsQ0FBQztZQUNGLEdBQUcsRUFBRSxHQUFHLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE1BQU07YUFDbkMsV0FBVzthQUNYLE9BQU9ILElBQUUsRUFBRSxFQUFFLE1BQU0sQ0FBQzthQUNwQixVQUFVLEdBQUcsR0FBRyxHQUFHLENBQUM7WUFDckIsR0FBRyxFQUFFLEdBQUc7V0FDVCxDQUFDO1dBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtZQUN2QixXQUFXO1lBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTzthQUNsQyxXQUFXO2FBQ1gsVUFBVSxDQUFDLEtBQUssSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUVLLG1CQUFBQSxVQUFHLEVBQUUsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO2NBQ2pGLFdBQVc7Y0FDWCxNQUFNO2NBQ04sZUFBZSxHQUFHLENBQUM7Y0FDbkIsVUFBVTthQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtjQUMvQixXQUFXO2NBQ1gsTUFBTTtjQUNOLFNBQVM7Y0FDVCxVQUFVO2FBQ1gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO2NBQ3BDLFdBQVc7Y0FDWCxNQUFNO2NBQ04sZUFBZSxHQUFHLEdBQUcsQ0FBQztjQUN0QixVQUFVO2FBQ1gsQ0FBQyxJQUFJLE1BQU0sS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtjQUMzQyxXQUFXO2NBQ1gsTUFBTTtjQUNOLGVBQWUsR0FBRyxHQUFHLENBQUM7Y0FDdEIsVUFBVTthQUNYLENBQUMsSUFBSSxJQUFJO1lBQ1YsQ0FBQztXQUNGLENBQUM7VUFDRjtTQUNELEdBQUcsRUFBRSxHQUFHO1FBQ1QsQ0FBQztRQUNELEtBQUssSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtTQUNoQyxXQUFXO1NBQ1gsT0FBTyxFQUFFLFFBQVEsR0FBRyxHQUFHLElBQUk7U0FDM0IsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTSxFQUFFLFNBQVMsR0FBRyxDQUFDO1FBQ2xELENBQUMsSUFBSTtPQUNOLEVBQUUsQ0FBQyxDQUFDO01BQ0wsQ0FBQztLQUNGLENBQUM7S0FDRCxNQUFNLEdBQUcsU0FBeUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztNQUMxQyxXQUFXO01BQ1gsVUFBVSxDQUFDLEtBQXFCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFdBQVc7T0FDNUMsV0FBVztPQUNYLGNBQWM7T0FDZCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87UUFDbkMsV0FBVztRQUNYLFVBQVU7T0FDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7UUFDOUIsV0FBVztRQUNYLE9BQU87UUFDUCxVQUFVLENBQUMsR0FBRyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTLEVBQUUsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsTUFBTSxFQUFFLFVBQVU7U0FDM0YsTUFBTSxTQUFTLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE1BQU07VUFDN0MsV0FBVztVQUNYLFVBQVUsR0FBRztTQUNkLENBQUM7U0FDRCxFQUFFLEtBQUssR0FBRyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxNQUFNO1VBQ3ZDLFdBQVc7VUFDWCxVQUFVO1dBQ1QsTUFBTSxJQUFJLFFBQVEsT0FBTztXQUN6QixNQUFNLEtBQUssR0FBRyxJQUFJLEVBQUUsR0FBRyxJQUFJLFFBQVE7V0FDbkMsR0FBRyxJQUFJLEVBQUUsR0FBRyxLQUFLO1VBQ2xCO1NBQ0QsR0FBRyxFQUFFLEdBQUcsQ0FBQztTQUNPLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE1BQU07VUFDdkIsV0FBVztVQUNYLFVBQVUsQ0FBQyxhQUFhLEdBQUcsTUFBTTtTQUNsQyxDQUFDO1FBQ0YsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO09BQ1IsQ0FBQyxDQUFDO01BQ0gsQ0FBQyxJQUFJLE1BQU0sR0FBRyxTQUF5QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxXQUFXO09BQ25ELFdBQVc7T0FDWCxjQUFjO09BQ2QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO1FBQ25DLFdBQVc7UUFDWCxVQUFVO09BQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO1FBQzVCLFdBQVc7UUFDWCxVQUFVLEdBQUcsS0FBSyxLQUFLO09BQ3hCLENBQUMsQ0FBQztNQUNILENBQUMsSUFBSSxJQUFJO0tBQ1YsQ0FBQyxJQUFJO0lBQ047R0FDRCxDQUFDO0dBQ0QsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztJQUM3QixXQUFXO0lBQ1gsVUFBVTtLQUNPLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7TUFDM0IsV0FBVztNQUNYLE1BQU07TUFDTixlQUFlLEVBQUUsQ0FBQztNQUNsQixVQUFVLE1BQU07TUFDaEIsVUFBVTtLQUNYLENBQUM7S0FDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO01BQzNCLFdBQVc7TUFDWCxNQUFNO01BQ04sZUFBZSxHQUFHLE1BQU0sS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUM7TUFDMUMsVUFBVSxNQUFNO01BQ2hCLFVBQVU7S0FDWCxDQUFDO0tBQ2UsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsUUFBUSxFQUFFLFVBQVU7TUFDckM7TUFDQSxJQUFJO01BQ0o7TUFDQTtLQUNELEVBQUUsQ0FBQztLQUNhLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7TUFDM0IsV0FBVztNQUNYLE1BQU07TUFDTixlQUFlLEdBQUcsTUFBTSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO01BQzlDLFVBQVUsS0FBSyxJQUFJO01BQ25CLFVBQVU7S0FDWCxDQUFDO0tBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtNQUMzQixXQUFXO01BQ1gsTUFBTTtNQUNOLGVBQWUsRUFBRSxJQUFJLENBQUM7TUFDdEIsVUFBVSxLQUFLLElBQUk7TUFDbkIsVUFBVTtLQUNYLENBQUM7SUFDRjtHQUNELENBQUMsSUFBSTtHQUNMLEtBQXFCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLElBQUk7SUFDMUIsU0FBUztJQUNULE9BQU8sR0FBRztJQUNWLE9BQU8sR0FBRztJQUNWLGdCQUFnQixHQUFHLElBQUk7SUFDdkIsU0FBUyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUM7R0FDOUIsQ0FBQyxJQUFJO0VBQ047Q0FDRCxDQUFDO0FBQ0YsQ0FBQztBQUNELEVBQUUsY0FBYzs7O0FDdnFDaEIsSUFBSUUsTUFBSTtDQUNQLE1BQU07Q0FDTixPQUFPO0NBQ1AsS0FBSztDQUNMLFFBQVE7QUFDVDtBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLE9BQU8sS0FBSztBQUNiO0FBR0EsSUFBSUMsT0FBQUEsR0FBSUMsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsT0FBTyxHQUFHLGNBQWMsR0FBRyxXQUFXLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGVBQWUsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksY0FBYyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQ3RLLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87RUFDL0IsS0FBSztFQUNMLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFDMUQsTUFBTTtFQUNOLEdBQUc7RUFDSCxVQUFVLEVBQUUsS0FBSyxNQUFNO0dBQ3RCLElBQUksSUFBSSxFQUFFLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLEtBQUssRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLENBQUMsNEJBQTRCSCxJQUFFQyxJQUFFLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUk7SUFDeko7SUFDQSxJQUFJLG9DQUFvQztJQUN4QyxJQUFJLEtBQUs7SUFDVDtHQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxPQUFPLEVBQUUsU0FBUyxXQUFXLEVBQUUsUUFBUSxFQUFFO0dBQ25NLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7SUFDbEMsTUFBTTtJQUNOLFdBQVc7SUFDWCxVQUFVLEVBQUU7SUFDWixPQUFPLEVBQUU7SUFDVCxjQUFjO0lBQ2QsZ0JBQWdCLE9BQU8sRUFBRSxXQUFXLFlBQVksRUFBRSxVQUFVLEtBQUs7SUFDakUsVUFBVSxNQUFNO0tBQ2YsSUFBSTtNQUNILFFBQVEsRUFBRTtNQUNWLE1BQU07TUFDTixPQUFPO0tBQ1IsQ0FBQztJQUNGO0lBQ0EsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsUUFBUTtLQUNuQyxXQUFXO0tBQ1gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLEdBQUc7TUFDbkMsV0FBVztNQUNYLGVBQWU7TUFDZixXQUFXO0tBQ1osQ0FBQyxJQUFJLE1BQU0sRUFBRSxRQUF3QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzlDLFdBQVc7TUFDWCxVQUFVLEVBQUU7S0FDYixDQUFDLElBQUksSUFBSTtJQUNWLENBQUM7R0FDRixHQUFHLEVBQUUsRUFBRTtFQUNSLENBQUM7Q0FDRixDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYztBQUdoQixTQUFTRyxJQUFFLEVBQUUsT0FBTyxHQUFHLFNBQVMsR0FBRyxHQUFHLEtBQUssR0FBRztDQUM3QyxPQUFxQiwyQkFBRSxjQUFjLE9BQU8sT0FBTyxPQUFPO0VBQ3pELE9BQU87RUFDUCxNQUFNO0VBQ04sU0FBUztFQUNULGFBQWE7RUFDYixRQUFRO0VBQ1IsZUFBZTtFQUNmLGFBQWE7RUFDYixLQUFLO0VBQ0wsbUJBQW1CO0NBQ3BCLEdBQUcsQ0FBQyxHQUFHLElBQWtCLDJCQUFFLGNBQWMsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxNQUFvQiwyQkFBRSxjQUFjLFFBQVE7RUFDN0csZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixHQUFHO0NBQ0osQ0FBQyxDQUFDO0FBQ0g7QUFDQSxJQUFJQyxNQUFrQiwyQkFBRSxXQUFXRCxHQUFDO0FBR3BDLFNBQVNFLElBQUUsRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdDLE9BQXFCLDJCQUFFLGNBQWMsT0FBTyxPQUFPLE9BQU87RUFDekQsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDUixlQUFlO0VBQ2YsYUFBYTtFQUNiLEtBQUs7RUFDTCxtQkFBbUI7Q0FDcEIsR0FBRyxDQUFDLEdBQUcsSUFBa0IsMkJBQUUsY0FBYyxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQW9CLDJCQUFFLGNBQWMsUUFBUTtFQUM3RyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLENBQUM7QUFDSDtBQUNBLElBQUlDLE1BQWtCLDJCQUFFLFdBQVdELEdBQUM7QUFHcEMsU0FBU0UsSUFBRSxFQUFFLE9BQU8sR0FBRyxTQUFTLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDN0MsT0FBcUIsMkJBQUUsY0FBYyxPQUFPLE9BQU8sT0FBTztFQUN6RCxPQUFPO0VBQ1AsTUFBTTtFQUNOLFNBQVM7RUFDVCxhQUFhO0VBQ2IsUUFBUTtFQUNSLGVBQWU7RUFDZixhQUFhO0VBQ2IsS0FBSztFQUNMLG1CQUFtQjtDQUNwQixHQUFHLENBQUMsR0FBRyxJQUFrQiwyQkFBRSxjQUFjLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksTUFBb0IsMkJBQUUsY0FBYyxRQUFRO0VBQzdHLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsR0FBRztDQUNKLENBQUMsQ0FBQztBQUNIO0FBQ0EsSUFBSUMsTUFBa0IsMkJBQUUsV0FBV0QsR0FBQztBQUdwQyxTQUFTRSxJQUFFLEVBQUUsT0FBTyxHQUFHLFNBQVMsR0FBRyxHQUFHLEtBQUssR0FBRztDQUM3QyxPQUFxQiwyQkFBRSxjQUFjLE9BQU8sT0FBTyxPQUFPO0VBQ3pELE9BQU87RUFDUCxNQUFNO0VBQ04sU0FBUztFQUNULGFBQWE7RUFDYixRQUFRO0VBQ1IsZUFBZTtFQUNmLGFBQWE7RUFDYixLQUFLO0VBQ0wsbUJBQW1CO0NBQ3BCLEdBQUcsQ0FBQyxHQUFHLElBQWtCLDJCQUFFLGNBQWMsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxNQUFvQiwyQkFBRSxjQUFjLFFBQVE7RUFDN0csZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixHQUFHO0NBQ0osQ0FBQyxHQUFpQiwyQkFBRSxjQUFjLFFBQVE7RUFDekMsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixHQUFHO0NBQ0osQ0FBQyxDQUFDO0FBQ0g7QUFDQSxJQUFJQyxNQUFrQiwyQkFBRSxXQUFXRCxHQUFDO0FBR3BDLFNBQVNFLElBQUUsRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdDLE9BQXFCLDJCQUFFLGNBQWMsT0FBTyxPQUFPLE9BQU87RUFDekQsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDUixlQUFlO0VBQ2YsYUFBYTtFQUNiLEtBQUs7RUFDTCxtQkFBbUI7Q0FDcEIsR0FBRyxDQUFDLEdBQUcsSUFBa0IsMkJBQUUsY0FBYyxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQW9CLDJCQUFFLGNBQWMsUUFBUTtFQUM3RyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLENBQUM7QUFDSDtBQUNBLElBQUlDLE1BQWtCLDJCQUFFLFdBQVdELEdBQUM7QUFHcEMsU0FBUyxFQUFFLEVBQUUsT0FBTyxHQUFHLFNBQVMsR0FBRyxHQUFHLEtBQUssR0FBRztDQUM3QyxPQUFxQiwyQkFBRSxjQUFjLE9BQU8sT0FBTyxPQUFPO0VBQ3pELE9BQU87RUFDUCxNQUFNO0VBQ04sU0FBUztFQUNULGFBQWE7RUFDYixRQUFRO0VBQ1IsZUFBZTtFQUNmLGFBQWE7RUFDYixLQUFLO0VBQ0wsbUJBQW1CO0NBQ3BCLEdBQUcsQ0FBQyxHQUFHLElBQWtCLDJCQUFFLGNBQWMsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxNQUFvQiwyQkFBRSxjQUFjLFFBQVE7RUFDN0csZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixHQUFHO0NBQ0osQ0FBQyxDQUFDO0FBQ0g7QUFDQSxJQUFJRSxNQUFrQiwyQkFBRSxXQUFXLENBQUM7QUFHcEMsU0FBUyxFQUFFLEVBQUUsT0FBTyxHQUFHLFNBQVMsR0FBRyxHQUFHLEtBQUssR0FBRztDQUM3QyxPQUFxQiwyQkFBRSxjQUFjLE9BQU8sT0FBTyxPQUFPO0VBQ3pELE9BQU87RUFDUCxNQUFNO0VBQ04sU0FBUztFQUNULGFBQWE7RUFDYixRQUFRO0VBQ1IsZUFBZTtFQUNmLGFBQWE7RUFDYixLQUFLO0VBQ0wsbUJBQW1CO0NBQ3BCLEdBQUcsQ0FBQyxHQUFHLElBQWtCLDJCQUFFLGNBQWMsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxNQUFvQiwyQkFBRSxjQUFjLFFBQVE7RUFDN0csZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixHQUFHO0NBQ0osQ0FBQyxDQUFDO0FBQ0g7QUFDQSxJQUFJLElBQWtCLDJCQUFFLFdBQVcsQ0FBQztBQUdwQyxTQUFTLEVBQUUsRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdDLE9BQXFCLDJCQUFFLGNBQWMsT0FBTyxPQUFPLE9BQU87RUFDekQsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDUixlQUFlO0VBQ2YsYUFBYTtFQUNiLEtBQUs7RUFDTCxtQkFBbUI7Q0FDcEIsR0FBRyxDQUFDLEdBQUcsSUFBa0IsMkJBQUUsY0FBYyxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQW9CLDJCQUFFLGNBQWMsUUFBUTtFQUM3RyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLENBQUM7QUFDSDtBQUNBLElBQUksSUFBa0IsMkJBQUUsV0FBVyxDQUFDO0FBR3BDLFNBQVNDLElBQUUsRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdDLE9BQXFCLDJCQUFFLGNBQWMsT0FBTyxPQUFPLE9BQU87RUFDekQsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDUixlQUFlO0VBQ2YsYUFBYTtFQUNiLEtBQUs7RUFDTCxtQkFBbUI7Q0FDcEIsR0FBRyxDQUFDLEdBQUcsSUFBa0IsMkJBQUUsY0FBYyxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQW9CLDJCQUFFLGNBQWMsUUFBUTtFQUM3RyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLENBQUM7QUFDSDtBQUNBLElBQUksSUFBa0IsMkJBQUUsV0FBV0EsR0FBQztBQUdwQyxTQUFTLEVBQUUsR0FBRztDQUNiLE9BQU8sRUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLE9BQU87QUFDckk7QUFDQSxTQUFTLEVBQUUsR0FBRztDQUNiLElBQUksSUFBSSxFQUFFLEtBQUs7Q0FDZixPQUFPLDJCQUEyQixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSTtBQUNwRDtBQUNBLFNBQVMsRUFBRSxHQUFHO0NBQ2IsSUFBSSxJQUFJLEVBQUUsQ0FBQztDQUNYLE9BQU8sSUFBSSxFQUFFLFFBQVEsNkJBQTZCLEdBQUcsR0FBRyxNQUFNLFlBQVksRUFBRSxDQUFDLEVBQUUsOENBQThDLEVBQUUsS0FBSyxHQUFHLElBQUksRUFBRSxRQUFRLG9CQUFvQixxQkFBcUIsR0FBRyxJQUFJLEVBQUUsUUFBUSxnQkFBZ0IscUJBQXFCLEdBQUcsSUFBSSxFQUFFLFFBQVEsZ0JBQWdCLGFBQWEsR0FBRyxJQUFJLEVBQUUsUUFBUSxjQUFjLGFBQWEsR0FBRyxJQUFJLEVBQUUsUUFBUSxnQkFBZ0IsZUFBZSxHQUFHLElBQUksRUFBRSxRQUFRLGNBQWMsaUJBQWlCLEdBQUc7QUFDbGI7QUFDQSxTQUFTLEVBQUUsR0FBRztDQUNiLElBQUksSUFBSSxFQUFFLE1BQU0sTUFBTSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJO0NBQzVELE9BQU8sSUFBSSxFQUFFLFNBQVM7RUFDckIsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLENBQUMsRUFBRSxLQUFLLEdBQUc7R0FDZCxLQUFLO0dBQ0w7RUFDRDtFQUNBLElBQUksRUFBRSxXQUFXLEtBQUssR0FBRztHQUN4QixJQUFJLElBQUksQ0FBQztHQUNULEtBQUssS0FBSyxHQUFHLElBQUksRUFBRSxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUMsV0FBVyxLQUFLLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxHQUFHLEtBQUs7R0FDMUUsSUFBSSxFQUFFLFdBQVcsS0FBSyxJQUFJLEVBQUUsS0FBSyxjQUFjLEVBQUUsRUFBRSxLQUFLLElBQUksQ0FBQyxFQUFFLGNBQWM7R0FDN0U7RUFDRDtFQUNBLElBQUksSUFBSSxFQUFFLE1BQU0sbUJBQW1CO0VBQ25DLElBQUksR0FBRztHQUNOLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQztHQUNiLEVBQUUsS0FBSyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEdBQUcsS0FBSztHQUMxQztFQUNEO0VBQ0EsSUFBSSxFQUFFLFdBQVcsR0FBRyxHQUFHO0dBQ3RCLElBQUksSUFBSSxDQUFDO0dBQ1QsT0FBTyxJQUFJLEVBQUUsVUFBVSxFQUFFLEVBQUUsQ0FBQyxXQUFXLEdBQUcsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsUUFBUSxRQUFRLEVBQUUsQ0FBQyxHQUFHLEtBQUs7R0FDckYsRUFBRSxLQUFLLGVBQWUsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFLGNBQWM7R0FDNUQ7RUFDRDtFQUNBLElBQUksRUFBRSxNQUFNLGdCQUFnQixHQUFHO0dBQzlCLElBQUksSUFBSSxDQUFDO0dBQ1QsT0FBTyxJQUFJLEVBQUUsU0FBUztJQUNyQixJQUFJLElBQUksRUFBRSxFQUFFLENBQUMsTUFBTSxnQkFBZ0I7SUFDbkMsSUFBSSxDQUFDLEdBQUc7SUFDUixFQUFFLEtBQUssT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLE1BQU0sR0FBRyxLQUFLO0dBQ3JDO0dBQ0EsRUFBRSxLQUFLLE9BQU8sRUFBRSxLQUFLLEVBQUUsRUFBRSxNQUFNO0dBQy9CO0VBQ0Q7RUFDQSxJQUFJLEVBQUUsTUFBTSxnQkFBZ0IsR0FBRztHQUM5QixJQUFJLElBQUksQ0FBQztHQUNULE9BQU8sSUFBSSxFQUFFLFNBQVM7SUFDckIsSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFDLE1BQU0sZ0JBQWdCO0lBQ25DLElBQUksQ0FBQyxHQUFHO0lBQ1IsRUFBRSxLQUFLLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxNQUFNLEdBQUcsS0FBSztHQUNyQztHQUNBLEVBQUUsS0FBSyxPQUFPLEVBQUUsS0FBSyxFQUFFLEVBQUUsTUFBTTtHQUMvQjtFQUNEO0VBQ0EsSUFBSSxJQUFJLENBQUM7RUFDVCxPQUFPLElBQUksRUFBRSxVQUFVLEVBQUUsRUFBRSxDQUFDLEtBQUssSUFBSTtHQUNwQyxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxXQUFXLEtBQUssS0FBSyxlQUFlLEtBQUssQ0FBQyxLQUFLLEVBQUUsV0FBVyxHQUFHLEtBQUssWUFBWSxLQUFLLENBQUMsS0FBSyxZQUFZLEtBQUssQ0FBQztHQUNqSSxJQUFJLEVBQUUsU0FBUyxLQUFLLEdBQUc7R0FDdkIsRUFBRSxLQUFLLENBQUMsR0FBRyxLQUFLO0VBQ2pCO0VBQ0EsRUFBRSxLQUFLLE1BQU0sRUFBRSxFQUFFLEtBQUssR0FBRyxDQUFDLEVBQUUsS0FBSztDQUNsQztDQUNBLE9BQU8sRUFBRSxLQUFLLEVBQUU7QUFDakI7QUFDQSxTQUFTLEVBQUUsR0FBRyxHQUFHLEdBQUc7Q0FDbkIsSUFBSSxJQUFJLEVBQUUsWUFBWSxNQUFNLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxNQUFNLENBQUMsR0FBRyxJQUFJLE1BQU0sS0FBSyxFQUFFLFNBQVM7Q0FDdkcsT0FBTztFQUNOLFFBQVEsRUFBRSxNQUFNLEdBQUcsQ0FBQztFQUNwQixVQUFVLEVBQUUsTUFBTSxHQUFHLENBQUM7RUFDdEIsT0FBTyxFQUFFLE1BQU0sQ0FBQztFQUNoQixXQUFXO0VBQ1gsU0FBUztDQUNWO0FBQ0Q7QUFDQSxTQUFTLEVBQUUsR0FBRyxHQUFHLEdBQUc7Q0FDbkIsSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsa0JBQWtCLEdBQUcsSUFBSSxFQUFFLGdCQUFnQixHQUFHLElBQUksTUFBTSxHQUFHLEVBQUUsUUFBUSxHQUFHLFVBQVUsR0FBRyxPQUFPLEdBQUcsV0FBVyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUM7Q0FDaEosSUFBSSxDQUFDLEdBQUc7RUFDUCxJQUFJLElBQUksR0FBRyxJQUFJO0VBQ2YsT0FBTztHQUNOLFdBQVcsR0FBRyxFQUFFLE1BQU0sR0FBRyxDQUFDLElBQUksSUFBSSxFQUFFLE1BQU0sQ0FBQztHQUMzQyxXQUFXLElBQUksRUFBRTtHQUNqQixTQUFTLElBQUksRUFBRTtFQUNoQjtDQUNEO0NBQ0EsSUFBSSxJQUFJLEVBQUUsTUFBTSxJQUFJLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxLQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSTtDQUMvRSxPQUFPO0VBQ04sV0FBVyxHQUFHLElBQUksSUFBSTtFQUN0QixXQUFXO0VBQ1gsU0FBUyxJQUFJLEVBQUU7Q0FDaEI7QUFDRDtBQUNBLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3RCLElBQUksSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLGtCQUFrQixHQUFHLElBQUksRUFBRSxnQkFBZ0IsR0FBRyxJQUFJLE1BQU0sSUFBSSxJQUFJLEVBQUUsTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSSxJQUFJO0NBQ3JILE9BQU87RUFDTixXQUFXLEdBQUcsRUFBRSxNQUFNLEdBQUcsQ0FBQyxJQUFJLElBQUksRUFBRSxNQUFNLENBQUM7RUFDM0MsV0FBVyxJQUFJLEVBQUU7RUFDakIsU0FBUyxJQUFJLEVBQUUsU0FBUyxFQUFFO0NBQzNCO0FBQ0Q7QUFDQSxTQUFTLEVBQUUsR0FBRztDQUNiLElBQUksSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLGtCQUFrQixHQUFHLElBQUksRUFBRSxnQkFBZ0IsR0FBRyxJQUFJLE1BQU0sSUFBSSxjQUFjLEVBQUUsTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJLElBQUksRUFBRTtDQUMxSCxPQUFPO0VBQ04sV0FBVyxHQUFHLEVBQUUsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLEVBQUUsTUFBTSxDQUFDO0VBQzNDLFdBQVcsSUFBSSxFQUFFLFNBQVM7RUFDMUIsU0FBUyxJQUFJLEVBQUUsU0FBUyxJQUFJO0NBQzdCO0FBQ0Q7QUFHQSxTQUFTLEVBQUUsRUFBRSxPQUFPLElBQUksWUFBWSxZQUFZLElBQUksaUZBQWlGLGFBQWEsSUFBSSwwQkFBMEIsT0FBTyxJQUFJLElBQUksVUFBVSxJQUFJLENBQUMsR0FBRyxXQUFXLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxlQUFlLElBQUksSUFBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLElBQUksVUFBVSxHQUFHLGlCQUFpQixHQUFHLEdBQUcsS0FBSztDQUNyWSxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxvQkFBb0IsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLEtBQUEsR0FBSUMsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0MsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxNQUFNO0NBQzlHLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLEVBQUUsQ0FBQztDQUNKLEdBQUcsQ0FBQyxDQUFDLENBQUM7Q0FDTixJQUFJLElBQUksRUFBRSxDQUFDLEdBQUcsSUFBSTtFQUNqQjtFQUNBO0VBQ0EsSUFBSSwrQkFBK0I7RUFDbkM7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSTtFQUM1UjtHQUNDLElBQUk7R0FDSixNQUFNUDtHQUNOLE9BQU8sTUFBTSxTQUFTLFlBQVk7RUFDbkM7RUFDQTtHQUNDLElBQUk7R0FDSixNQUFNRTtHQUNOLE9BQU87RUFDUjtFQUNBO0dBQ0MsSUFBSTtHQUNKLE1BQU1KO0dBQ04sT0FBTztFQUNSO0VBQ0E7R0FDQyxJQUFJO0dBQ0osTUFBTTtHQUNOLE9BQU87RUFDUjtFQUNBO0dBQ0MsSUFBSTtHQUNKLE1BQU1KO0dBQ04sT0FBTztFQUNSO0VBQ0E7R0FDQyxJQUFJO0dBQ0osTUFBTTtHQUNOLE9BQU87RUFDUjtFQUNBO0dBQ0MsSUFBSTtHQUNKLE1BQU07R0FDTixPQUFPO0VBQ1I7RUFDQTtHQUNDLElBQUk7R0FDSixNQUFNRTtHQUNOLE9BQU87RUFDUjtFQUNBO0dBQ0MsSUFBSTtHQUNKLE1BQU1PO0dBQ04sT0FBTztFQUNSO0NBQ0QsR0FBRyxLQUFLLEdBQUcsTUFBTTtFQUNoQixJQUFJLEdBQUc7RUFDUCxJQUFJLElBQUksRUFBRTtFQUNWLElBQUksQ0FBQyxHQUFHO0VBQ1IsSUFBSSxJQUFJLEVBQUUsQ0FBQztFQUNYLE1BQU0sRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLGtCQUFrQixFQUFFLFdBQVcsRUFBRSxPQUFPLEdBQUcsRUFBRSxFQUFFLFNBQVMsR0FBRyxJQUFJLEVBQUUsU0FBUyxHQUFHLElBQUksQ0FBQztDQUNsSCxHQUFHLEtBQUssTUFBTTtFQUNiLElBQUksSUFBSSxFQUFFLGNBQWM7RUFDeEIsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDO0NBQ1osR0FBRyxLQUFLLE1BQU07RUFDYixJQUFJLE1BQU0sZUFBZTtHQUN4QixJQUFJLElBQUksTUFBTSxTQUFTLFlBQVk7R0FDbkMsRUFBRSxDQUFDLEdBQUcsSUFBSSxRQUFRLEdBQUc7R0FDckI7RUFDRDtFQUNBLFFBQVEsR0FBUjtHQUNDLEtBQUs7SUFDSixFQUFFLFlBQVksTUFBTSxFQUFFLEdBQUcsTUFBTSxTQUFTLENBQUM7SUFDekM7R0FDRCxLQUFLO0lBQ0osRUFBRSxTQUFTLE1BQU0sRUFBRSxHQUFHLE1BQU0sTUFBTSxXQUFXLENBQUM7SUFDOUM7R0FDRCxLQUFLO0lBQ0osRUFBRSxXQUFXLE1BQU0sRUFBRSxHQUFHLEtBQUssS0FBSyxhQUFhLENBQUM7SUFDaEQ7R0FDRCxLQUFLO0lBQ0osRUFBRSxVQUFVLE1BQU0sRUFBRSxHQUFHLE1BQU0sT0FBTyxDQUFDO0lBQ3JDO0dBQ0QsS0FBSztJQUNKLEVBQUUsZ0JBQWdCLE1BQU0sRUFBRSxHQUFHLE1BQU0sV0FBVyxDQUFDO0lBQy9DO0dBQ0QsS0FBSztJQUNKLEVBQUUsa0JBQWtCLE1BQU0sRUFBRSxHQUFHLE9BQU8sV0FBVyxDQUFDO0lBQ2xEO0dBQ0QsS0FBSztJQUNKLEVBQUUsU0FBUyxNQUFNLEVBQUUsR0FBRyxLQUFLLEtBQUssTUFBTSxDQUFDO0lBQ3ZDO0dBQ0QsS0FBSyxRQUNKLEVBQUUsUUFBUSxDQUFDO0VBR2I7Q0FDRDtDQUNBLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87R0FDbkMsV0FBVztHQUNYLFVBQVU7SUFDTyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0tBQzFCLFdBQVc7S0FDWCxTQUFTO0tBQ1QsVUFBVTtJQUNYLENBQUM7SUFDRCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQzVCLFdBQVc7S0FDWCxVQUFVO0lBQ1gsQ0FBQyxJQUFJO0lBQ1csaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVaLEtBQUc7S0FDcEIsV0FBVztLQUNYLGNBQWM7S0FDZCxPQUFPLEVBQUUsS0FBSyxNQUFNO01BQ25CLElBQUksSUFBSSxFQUFFLE9BQU87TUFDakIsT0FBTztPQUNOLEdBQUc7T0FDSCxPQUFPLElBQUksTUFBTSxTQUFTLFlBQVksU0FBUyxLQUFLO09BQ3BELFVBQVUsS0FBSyxDQUFDLEtBQUssTUFBTTtPQUMzQixTQUFTLElBQUksTUFBTSxZQUFZLEtBQUs7TUFDckM7S0FDRCxDQUFDO0tBQ0QsY0FBYyxNQUFNO01BQ25CLEVBQUUsUUFBUSxRQUFRLFFBQVEsS0FBSyxFQUFFLGVBQWU7S0FDakQ7S0FDQSxlQUFlLEVBQUUsUUFBUSxRQUFRLEVBQUUsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsTUFBTSxTQUF5QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxZQUFZO0tBQzVDLElBQUk7S0FDSixLQUFLO0tBQ0wsV0FBVztLQUNYLE1BQU07S0FDTixhQUFhO0tBQ2IsT0FBTztLQUNQLFVBQVU7S0FDVixVQUFVO0lBQ1gsQ0FBQyxJQUFJO0dBQ047RUFDRCxDQUFDLEdBQUcsTUFBTSxZQUE0QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0dBQzlDLFdBQVc7R0FDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDbkMsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDNUIsV0FBVztJQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDbEMsV0FBVztLQUNYLHlCQUF5QixFQUFFLFFBQVEsS0FBSywrQkFBK0I7SUFDeEUsQ0FBQztHQUNGLENBQUMsQ0FBQztFQUNILENBQUMsSUFBSSxJQUFJO0NBQ1YsQ0FBQztBQUNGOzs7QUM3ZkEsSUFBSWlCLE9BQUk7Q0FDUCxVQUFVO0NBQ1YsWUFBWTtBQUNiO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTztFQUNOO0VBQ0EsTUFBTSxXQUFXLDRDQUE0QztFQUM3RCxNQUFNLFVBQVUsMkNBQTJDO0NBQzVELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztBQUMzQjtBQUdBLFNBQVNDLElBQUUsR0FBRztDQUNiLElBQUksSUFBSSxFQUFFLEtBQUs7Q0FDZixJQUFJLENBQUMsR0FBRyxPQUFPO0NBQ2YsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLFFBQVEsQ0FBQztDQUMzQixJQUFJLENBQUMsS0FBSyxNQUFNLEtBQUssT0FBTztDQUM1QixJQUFJLElBQUksRUFBRSxXQUFXLEdBQUcsSUFBSSxJQUFJLElBQUk7Q0FDcEMsT0FBTyxFQUFFLFNBQVMsS0FBSyxFQUFFLFNBQVMsR0FBRyxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUMzRDtBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLElBQUksVUFBVSxHQUFHLE9BQU8sRUFBRTtBQUMzQjtBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLElBQUksVUFBVSxHQUFHLE9BQU8sRUFBRTtDQUMxQixJQUFJLFVBQVUsR0FBRyxPQUFPLEVBQUU7QUFDM0I7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPLEVBQUUsV0FBVyxLQUFLLENBQUMsRUFBRSxXQUFXLENBQUMsRUFBRSxXQUFXLENBQUMsRUFBRSxZQUFZLENBQUMsRUFBRTtBQUN4RTtBQUNBLFNBQVNDLElBQUUsRUFBRSxNQUFNLEdBQUcsY0FBYyxHQUFHLGVBQWUsR0FBRyxlQUFlLEdBQUcsY0FBYyxHQUFHLGdCQUFnQixLQUFLO0NBQ2hILElBQUksSUFBSTtFQUNQO0VBQ0EsRUFBRSxPQUFPLElBQUkscUNBQXFDO0VBQ2xELEVBQUUsV0FBVyx1Q0FBdUM7RUFDcEQ7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxLQUFLLE1BQU07RUFDdkMsSUFBSSxFQUFFLFVBQVU7R0FDZixFQUFFLGVBQWU7R0FDakI7RUFDRDtFQUNBLElBQUksSUFBSSxFQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsRUFBRSxrQkFBa0I7RUFDekMsSUFBSSxJQUFJSCxJQUFFLENBQUM7RUFDWCxDQUFDLEtBQUssT0FBTyxTQUFTLE9BQU9FLElBQUUsQ0FBQyxNQUFNLEVBQUUsZUFBZSxHQUFHLE9BQU8sUUFBUSxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJSCxJQUFFLENBQUMsQ0FBQztDQUN4RyxHQUFHLElBQUlFLElBQUUsQ0FBQztDQUNWLE9BQU8sSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTSxFQUFFLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLEtBQUs7RUFDckUsV0FBVztFQUNYLE1BQU07RUFDTixnQkFBZ0IsRUFBRSxPQUFPLElBQUksU0FBUyxLQUFLO0VBQzNDLFNBQVM7RUFDVCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0dBQ25DLFdBQVdILElBQUUsQ0FBQztHQUNkLFVBQVUsRUFBRTtFQUNiLENBQUM7Q0FDRixDQUFDLEVBQUUsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNLEVBQUUsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtFQUN2RSxNQUFNO0VBQ04sV0FBVztFQUNYLFVBQVUsRUFBRTtFQUNaLGdCQUFnQixFQUFFLE9BQU8sSUFBSSxTQUFTLEtBQUs7RUFDM0MsU0FBUztFQUNULFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7R0FDbkMsV0FBV0EsSUFBRSxDQUFDO0dBQ2QsVUFBVSxFQUFFO0VBQ2IsQ0FBQztDQUNGLENBQUMsRUFBRSxDQUFDO0FBQ0w7QUFDQSxTQUFTLEVBQUUsRUFBRSxPQUFPLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxZQUFZLGVBQWUsSUFBSSxRQUFRLGNBQWMsR0FBRyxnQkFBZ0IsSUFBSSxDQUFDLEdBQUcsV0FBVyxJQUFJLElBQUksZUFBZSxJQUFJLElBQUksY0FBYyxHQUFHLEdBQUcsS0FBSztDQUM3TCxJQUFJLElBQUk7RUFDUDtFQUNBRCxLQUFFLE1BQU1BLEtBQUU7RUFDVjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtPLGFBQUFBLFNBQUFBLE9BQVEsT0FBTyxTQUFTLE1BQU0sTUFBTUwsSUFBRSxPQUFPLFNBQVMsUUFBUSxDQUFDO0NBQ3JHLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLElBQUksQ0FBQyxLQUFLLE9BQU8sU0FBUyxLQUFLO0VBQy9CLElBQUksVUFBVTtHQUNiLEVBQUVBLElBQUUsT0FBTyxTQUFTLFFBQVEsQ0FBQztFQUM5QjtFQUNBLE9BQU8sT0FBTyxpQkFBaUIsWUFBWSxDQUFDLFNBQVMsT0FBTyxvQkFBb0IsWUFBWSxDQUFDO0NBQzlGLEdBQUcsQ0FBQyxDQUFDLENBQUM7Q0FDTixJQUFJLEtBQUEsR0FBSU0sYUFBQUEsUUFBQUEsT0FBUTtFQUNmLElBQUksR0FBRyxPQUFPLEVBQUUsTUFBTSxNQUFNO0dBQzNCLElBQUksSUFBSUwsSUFBRSxDQUFDO0dBQ1gsT0FBTyxJQUFJRCxJQUFFLENBQUMsTUFBTSxJQUFJLENBQUM7RUFDMUIsQ0FBQyxDQUFDLEVBQUU7Q0FDTCxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxHQUFHLElBQUksS0FBSztDQUNiLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO0dBQ2pDLFdBQVc7R0FDWCxVQUFVLEVBQUUsS0FBSyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUksS0FBRztJQUMzQyxNQUFNO0lBQ04sY0FBYztJQUNkLGVBQWU7SUFDZixlQUFlO0lBQ2YsY0FBYztJQUNkLGdCQUFnQjtHQUNqQixHQUFHLEVBQUUsRUFBRSxDQUFDO0VBQ1QsQ0FBQztDQUNGLENBQUM7QUFDRjs7O0FDekdBLElBQUlHLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxRQUFRLElBQUksU0FBUyxRQUFRLEdBQUcsWUFBWSxJQUFJLENBQUMsR0FBRyxZQUFZLElBQUksQ0FBQyxHQUFHLFVBQVUsR0FBRyxXQUFXLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxHQUFHLEtBQUssTUFBTTtDQUM5TSxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDMU8sT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsV0FBVztFQUNuQyxLQUFLO0VBQ0wsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVO0dBQ1QsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtJQUMvQixXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsSUFBSTtHQUNXLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDeEIsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDO0dBQ0QsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtJQUMvQixXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsSUFBSTtFQUNOO0NBQ0QsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7OztBQ3RCaEIsSUFBSUMsT0FBSTtDQUNQLE9BQU87Q0FDUCxNQUFNO0NBQ04sS0FBSztDQUNMLFFBQVE7QUFDVDtBQUdBLFNBQVNDLElBQUUsRUFBRSxPQUFPLElBQUksZ0JBQWdCLGVBQWUsSUFBSSxTQUFTLFdBQVcsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsR0FBRyxLQUFLO0NBQ3JKLElBQUksSUFBSSxFQUFFLGFBQWEsQ0FBQyxHQUFHLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyx1QkFBdUIsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUk7RUFDOUY7RUFDQSxJQUFJLGtDQUFrQztFQUN0Q0YsS0FBRSxNQUFNQSxLQUFFO0VBQ1Y7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUM1SixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO0VBQ2pDLFdBQVc7RUFDWCxTQUFTO0VBQ1QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0dBQ3JDLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLEdBQUc7RUFDSixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7R0FDN0IsV0FBVztHQUNYLFVBQVU7RUFDWCxDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0Y7OztBQzVCQSxTQUFTRyxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLElBQUksRUFBRSxzQkFBc0I7Q0FDaEMsT0FBTztFQUNOLEdBQUcsRUFBRSxVQUFVLEVBQUU7RUFDakIsR0FBRyxFQUFFLFVBQVUsRUFBRTtDQUNsQjtBQUNEO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxFQUFFLFdBQVcsR0FBRztFQUNuQixFQUFFLFVBQVUsR0FBRyxFQUFFLE9BQU8sRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0VBQ3RDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSyxHQUFHLEVBQUUsT0FBTyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7RUFDN0QsRUFBRSxPQUFPO0NBQ1Y7QUFDRDtBQUNBLFNBQVNDLElBQUUsR0FBRyxHQUFHLEdBQUc7Q0FDbkIsRUFBRSxZQUFZLEdBQUcsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFLE9BQU8sRUFBRSxNQUFNO0FBQ3BEO0FBR0EsU0FBU0MsSUFBRSxFQUFFLE9BQU8sSUFBSSxhQUFhLFlBQVksSUFBSSwwQ0FBMEMsT0FBTyxJQUFJLElBQUksVUFBVSxJQUFJLENBQUMsR0FBRyxXQUFXLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLHFCQUFxQixJQUFJLElBQUksY0FBYyxJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxJQUFJLEdBQUcsT0FBTyxJQUFJLEtBQUssUUFBUSxJQUFJLEtBQUssaUJBQWlCLElBQUksV0FBVyxVQUFVLElBQUksV0FBVyxVQUFVLElBQUksS0FBSyxVQUFVLEdBQUcsZUFBZSxHQUFHLGFBQWEsR0FBRyxTQUFTLEtBQUs7Q0FDdmEsSUFBSSxLQUFBLEdBQUlDLGFBQUFBLE1BQUFBLENBQUUsR0FBRyxJQUFJLEtBQUsscUJBQXFCLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxLQUFBLEdBQUlDLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxPQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsT0FBQUEsQ0FBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQyxhQUFBQSxTQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLElBQUk7RUFDckk7RUFDQSxJQUFJLGdDQUFnQztFQUNwQztDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDdFIsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFRO0VBQ1AsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLENBQUMsR0FBRztFQUNSLElBQUksSUFBSSxFQUFFLFdBQVcsSUFBSTtFQUN6QixJQUFJLENBQUMsR0FBRztFQUNSLElBQUksSUFBSSxPQUFPLG9CQUFvQixHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDO0VBQ3pFLElBQUksRUFBRSxRQUFRLEtBQUssTUFBTSxJQUFJLENBQUMsR0FBRyxFQUFFLFNBQVMsS0FBSyxNQUFNLElBQUksQ0FBQyxHQUFHLEVBQUUsTUFBTSxRQUFRLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxTQUFTLEdBQUcsRUFBRSxLQUFLLEVBQUUsVUFBVSxHQUFHLEVBQUUsVUFBVSxTQUFTLEVBQUUsV0FBVyxTQUFTLEVBQUUsWUFBWSxJQUFJLEdBQUcsRUFBRSxjQUFjLEdBQUcsRUFBRSxNQUFNLEdBQUcsQ0FBQyxHQUFHSixJQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRztHQUNuUCxJQUFJLElBQUksSUFBSSxNQUFNO0dBQ2xCLEVBQUUsZUFBZTtJQUNoQixFQUFFLFVBQVUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsWUFBWSxHQUFHLEVBQUUsU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxVQUFVLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0dBQ25HLEdBQUcsRUFBRSxNQUFNO0VBQ1o7RUFDQSxhQUFhO0dBQ1osRUFBRSxVQUFVO0VBQ2I7Q0FDRCxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELElBQUksS0FBSyxNQUFNO0VBQ2QsSUFBSSxFQUFFLFVBQVUsV0FBVyxDQUFDO0NBQzdCLEdBQUcsS0FBSyxNQUFNO0VBQ2IsSUFBSSxLQUFLLEVBQUUsU0FBUztFQUNwQixJQUFJLElBQUksRUFBRSxTQUFTLElBQUksRUFBRTtFQUN6QixDQUFDLEtBQUssQ0FBQyxNQUFNLGVBQWUsS0FBSyxPQUFPLEVBQUUsYUFBYSxZQUFZLEVBQUUscUJBQXFCLEVBQUUsa0JBQWtCLEVBQUUsU0FBUyxHQUFHLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxVQUFVLENBQUNGLElBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLFVBQVUsR0FBRyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxHQUFHLElBQUk7Q0FDak8sR0FBRyxLQUFLLE1BQU07RUFDYixJQUFJLEtBQUssQ0FBQyxFQUFFLFNBQVM7RUFDckIsSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUU7RUFDekIsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHO0VBQ2QsSUFBSSxJQUFJQSxJQUFFLEdBQUcsQ0FBQztFQUNkLEVBQUUsUUFBUSxLQUFLLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0NBQ3hELEdBQUcsS0FBSyxNQUFNO0VBQ2IsSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUU7RUFDekIsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLFVBQVU7R0FDOUIsSUFBSSxLQUFLLGVBQWUsS0FBSyxPQUFPLEVBQUUsYUFBYSxZQUFZLEVBQUUsdUJBQXVCLElBQUk7SUFDM0YsRUFBRSxzQkFBc0IsRUFBRSxTQUFTO0dBQ3BDLFFBQVEsQ0FBQztHQUNULEVBQUUsVUFBVSxDQUFDLEdBQUdDLElBQUUsR0FBRyxFQUFFLE9BQU8sR0FBRyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLElBQUk7RUFDNUQ7Q0FDRDtDQUNBLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztFQUNYLFVBQVU7R0FDTyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQ3hCLFdBQVc7SUFDWCxJQUFJLEdBQUcsRUFBRTtJQUNULFVBQVU7R0FDWCxDQUFDO0dBQ0QsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUM1QixXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsSUFBSTtHQUNXLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87SUFDeEIsV0FBVztJQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtLQUN0QyxJQUFJO0tBQ0osS0FBSztLQUNMLFdBQVc7S0FDWCxNQUFNO0tBQ04sbUJBQW1CLEdBQUcsRUFBRTtLQUN4QixjQUFjO0tBQ2QsZUFBZTtLQUNmLGVBQWU7S0FDZixhQUFhO0tBQ2IsaUJBQWlCO0tBQ2pCLGdCQUFnQjtLQUNoQixhQUFhO0tBQ2IsYUFBYTtLQUNiLFdBQVc7S0FDWCxjQUFjO0lBQ2YsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQzVCLFdBQVc7S0FDWCxlQUFlO0tBQ2YsVUFBVSxJQUFJLGNBQWM7SUFDN0IsQ0FBQyxDQUFDO0dBQ0gsQ0FBQztHQUNlLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDeEIsV0FBVztJQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7S0FDckMsTUFBTTtLQUNOLFdBQVc7S0FDWCxlQUFlO01BQ2QsSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUU7TUFDekIsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLFVBQVUsR0FBRyxHQUFHLEVBQUUsT0FBTyxFQUFFLE1BQU0sR0FBR0MsSUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLEdBQUcsSUFBSTtLQUNwRjtLQUNBLFVBQVUsS0FBSztLQUNmLFVBQVU7SUFDWCxDQUFDO0dBQ0YsQ0FBQztFQUNGO0NBQ0QsQ0FBQztBQUNGOzs7QUN4SEEsSUFBSUssT0FBQUEsR0FBSUMsYUFBQUEsV0FBQUEsRUFBRyxFQUFFLE9BQU8sSUFBSSxVQUFVLE9BQU8sSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxLQUFLLE1BQU0sSUFBSSxHQUFHLFVBQVUsSUFBSSxDQUFDLEdBQUcsV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksSUFBSSxHQUFHLFVBQVUsR0FBRyxHQUFHLEtBQUssTUFBTTtDQUNyTyxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxrQkFBa0IsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUk7RUFDbEU7RUFDQSxJQUFJLDZCQUE2QjtFQUNqQztDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUM5TSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLFdBQVc7RUFDWCxVQUFVO0dBQ08saUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztJQUN4QixXQUFXO0lBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0tBQ3JDLFdBQVc7S0FDWCxTQUFTO0tBQ1QsVUFBVTtJQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtLQUMvQixXQUFXO0tBQ1gsU0FBUztLQUNULFVBQVU7SUFDWCxDQUFDLENBQUM7R0FDSCxDQUFDO0dBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztJQUMxQixLQUFLO0lBQ0wsSUFBSTtJQUNKLFdBQVc7SUFDWCxNQUFNO0lBQ04sT0FBTztJQUNQLEtBQUs7SUFDTCxLQUFLO0lBQ0wsTUFBTTtJQUNOLFVBQVU7SUFDVixVQUFVO0lBQ1YsR0FBRztHQUNKLENBQUM7R0FDZSxpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0lBQ3hCLFdBQVc7SUFDWCxlQUFlO0lBQ2YsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUM7R0FDbEcsQ0FBQztFQUNGO0NBQ0QsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7OztBQzFDaEIsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxNQUFNLFNBQVMsTUFBTSxXQUFXLGVBQWU7QUFDdkQ7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRztDQUNoQixPQUFPO0VBQ047RUFDQSxvQkFBb0I7RUFDcEI7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFDM0I7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPLENBQUMsMEJBQTBCLDJCQUEyQixHQUFHLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztBQUMzRjtBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLE9BQU8sQ0FBQyw0QkFBNEIsNkJBQTZCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0FBQy9GO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBT0MsYUFBQUEsU0FBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsTUFBTTtFQUNsQyxJQUFJLEVBQUEsR0FBQ0MsYUFBQUEsZUFBQUEsQ0FBRSxDQUFDLEdBQUcsT0FBTyxDQUFDO0VBQ25CLElBQUksSUFBSSxPQUFPLEVBQUUsTUFBTSxLQUFLO0VBQzVCLE9BQU8sT0FBTyxTQUFTLENBQUMsSUFBSSxDQUFDO0dBQzVCLE9BQU87R0FDUCxPQUFPLEVBQUUsTUFBTSxTQUFTLEVBQUUsTUFBTSxZQUFZLFFBQVE7R0FDcEQsTUFBTSxFQUFFLE1BQU07R0FDZCxVQUFVLENBQUMsQ0FBQyxFQUFFLE1BQU07RUFDckIsQ0FBQyxJQUFJLENBQUM7Q0FDUCxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLO0FBQ3BDO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBT0YsYUFBQUEsU0FBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsTUFBTTtFQUNsQyxJQUFJLEVBQUEsR0FBQ0MsYUFBQUEsZUFBQUEsQ0FBRSxDQUFDLEdBQUcsT0FBTyxDQUFDO0VBQ25CLElBQUksSUFBSSxPQUFPLEVBQUUsTUFBTSxLQUFLO0VBQzVCLE9BQU8sT0FBTyxTQUFTLENBQUMsSUFBSSxDQUFDO0dBQzVCLE9BQU87R0FDUCxTQUFTLEVBQUUsTUFBTTtFQUNsQixDQUFDLElBQUksQ0FBQztDQUNQLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsUUFBUSxFQUFFLEtBQUs7QUFDcEM7QUFHQSxTQUFTLEVBQUUsRUFBRSxVQUFVLEtBQUs7Q0FDM0IsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVFLG1CQUFBQSxVQUFHLEVBQUUsVUFBVSxFQUFFLENBQUM7QUFDNUM7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPO0FBQ1I7QUFDQSxTQUFTLEVBQUUsRUFBRSxVQUFVLEtBQUs7Q0FDM0IsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVELG1CQUFBQSxVQUFHLEVBQUUsVUFBVSxFQUFFLENBQUM7QUFDNUM7QUFDQSxTQUFTLEVBQUUsR0FBRztDQUNiLE9BQU87QUFDUjtBQUNBLElBQUksSUFBSTtBQUFHLElBQUEsSUFBSTtBQUFHRSxJQUFBQSxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxFQUFHLEVBQUUsVUFBVSxHQUFHLFdBQVcsSUFBSSxJQUFJLGVBQWUsSUFBSSxPQUFPLGdCQUFnQixJQUFJLFFBQVEsb0JBQW9CLElBQUksU0FBUyxnQkFBZ0IsSUFBSSxDQUFDLEdBQUcsYUFBYSxHQUFHLG9CQUFvQixHQUFHLGNBQWMsR0FBRyxHQUFHLEtBQUssTUFBTTtDQUMvTyxJQUFJLENBQUMsR0FBRyxNQUFBLEdBQUtDLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxHQUFHLEVBQUUsYUFBYSxHQUFHLG9CQUFvQixPQUFBLEdBQU1DLGFBQUFBLFFBQUFBLE9BQVE7RUFDdEUsSUFBSSxJQUFJUixhQUFBQSxTQUFFLFFBQVEsQ0FBQyxHQUFHLElBQUksRUFBRSxNQUFNLE9BQUEsR0FBTUMsYUFBQUEsZUFBQUEsQ0FBRSxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsR0FBRyxJQUFJLEVBQUUsTUFBTSxPQUFBLEdBQU1BLGFBQUFBLGVBQUFBLENBQUUsQ0FBQyxLQUFLLEVBQUUsU0FBUyxDQUFDO0VBQ3JHLE9BQU87R0FDTixhQUFhRixJQUFFLEdBQUcsTUFBTSxRQUFRO0dBQ2hDLG9CQUFvQkcsSUFBRSxHQUFHLE1BQU0sUUFBUTtFQUN4QztDQUNELEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsU0FBUyxHQUFHLElBQUksS0FBSyxLQUFLLEdBQUcsSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLFVBQVUsQ0FBQyxHQUFHLElBQUlQLElBQUUsQ0FBQyxHQUFHLElBQUk7RUFDOUdDLElBQUUsR0FBRyxDQUFDO0VBQ04sMEJBQTBCO0VBQzFCLDBCQUEwQjtFQUMxQixJQUFJLHNDQUFzQztDQUMzQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJQyxJQUFFLENBQUMsR0FBRyxJQUFJQyxJQUFFLENBQUM7Q0FDOUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsV0FBVztFQUNuQyxLQUFLO0VBQ0wsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDbkMsV0FBVztHQUNYLE1BQU07R0FDTixvQkFBb0I7R0FDcEIsVUFBVSxFQUFFLEtBQUssTUFBTTtJQUN0QixJQUFJLElBQUksRUFBRSxVQUFVO0lBQ3BCLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87S0FDL0IsTUFBTTtLQUNOLGlCQUFpQjtLQUNqQixpQkFBaUIsRUFBRTtLQUNuQixVQUFVLEVBQUUsV0FBVyxLQUFLO0tBQzVCLFdBQVc7TUFDVjtNQUNBLElBQUksa0NBQWtDO01BQ3RDLEVBQUUsV0FBVyxvQ0FBb0M7S0FDbEQsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0tBQzFCLFVBQVUsTUFBTTtNQUNmLEVBQUUsYUFBYSxNQUFNLEtBQUssS0FBSyxFQUFFLEVBQUUsS0FBSyxHQUFHLElBQUksRUFBRSxPQUFPLENBQUM7S0FDMUQ7S0FDQSxVQUFVLENBQUMsRUFBRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzdDLFdBQVc7TUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO09BQ25DLFdBQVc7T0FDWCxVQUFVLEVBQUU7TUFDYixDQUFDO0tBQ0YsQ0FBQyxJQUFJLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDcEMsV0FBVztNQUNYLFVBQVUsRUFBRTtLQUNiLENBQUMsQ0FBQztJQUNILEdBQUcsRUFBRSxLQUFLO0dBQ1gsQ0FBQztFQUNGLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsV0FBVztHQUNoQyxXQUFXO0dBQ1gsTUFBTTtHQUNOLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDbEMsV0FBVztJQUNYLFVBQVUsR0FBRyxXQUFXO0dBQ3pCLENBQUM7RUFDRixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYyxXQUFXLEVBQUUsY0FBYyxpQkFBaUIsSUFBRSxjQUFjLGdCQUFnQixFQUFFLGNBQWMsd0JBQXdCLEVBQUUsY0FBYyx1QkFBdUIsSUFBRSxRQUFRLEdBQUcsSUFBRSxPQUFPTSxLQUFHLElBQUUsZUFBZSxHQUFHLElBQUUsY0FBYzs7O0FDOUd4TyxJQUFJSyxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxFQUFHLEVBQUUsT0FBTyxJQUFJLE9BQU8sVUFBVSxHQUFHLFlBQVksSUFBSSxDQUFDLEdBQUcsV0FBVyxJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsS0FBSyxNQUFNO0NBQ2xMLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDak8sT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsV0FBVztFQUNuQyxLQUFLO0VBQ0wsSUFBSTtFQUNKLFdBQVc7RUFDWCxHQUFHO0VBQ0gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDdkMsV0FBVztHQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDbEMsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDO0VBQ0YsQ0FBQyxJQUFJLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDbkMsV0FBVztHQUNYLFVBQVU7RUFDWCxDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYzs7O0FDbkJoQixJQUFJQyxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxFQUFHLEVBQUUsT0FBTyxHQUFHLFdBQVcsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLEdBQUcsUUFBUSxJQUFJLFlBQVksR0FBRyxLQUFLLE1BQU07Q0FDbkosSUFBSSxLQUFBLEdBQUlDLGFBQUFBLE1BQUFBLENBQUUsR0FBRyxJQUFJLEtBQUssb0JBQW9CLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDalAsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDekMsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0VBQ1gsQ0FBQyxJQUFJLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFlBQVk7R0FDeEMsS0FBSztHQUNMLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLGVBQWU7R0FDZixHQUFHO0VBQ0osQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7OztBQ2xCaEIsSUFBSUMsTUFBSTtDQUNQLE1BQU07Q0FDTixLQUFLO0NBQ0wsTUFBTTtBQUNQO0FBQUdDLElBQUFBLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxPQUFPLEdBQUcsZUFBZSxJQUFJLE9BQU8sV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksR0FBRyxNQUFNLElBQUksUUFBUSxHQUFHLEtBQUssTUFBTTtDQUN6SixJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxtQkFBbUIsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUk7RUFDbkU7RUFDQSxJQUFJSCxJQUFFLE1BQU1BLElBQUUsTUFBTTtFQUNwQjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQ3BKLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztFQUNYLFVBQVUsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0dBQ3pDLFdBQVc7R0FDWCxTQUFTO0dBQ1QsVUFBVTtFQUNYLENBQUMsSUFBSSxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0dBQ3JDLEtBQUs7R0FDTCxJQUFJO0dBQ0osV0FBVztHQUNYLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7OztBQ3pCaEIsSUFBSUksTUFBSTtDQUNQLE1BQU07Q0FDTixPQUFPO0NBQ1AsS0FBSztDQUNMLFFBQVE7QUFDVDtBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLE9BQU8sS0FBSztBQUNiO0FBR0EsSUFBSUMsT0FBQUEsR0FBSUMsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsT0FBTyxHQUFHLGNBQWMsR0FBRyxXQUFXLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGVBQWUsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksY0FBYyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQ3RLLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87RUFDL0IsS0FBSztFQUNMLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFDMUQsTUFBTTtFQUNOLEdBQUc7RUFDSCxVQUFVLEVBQUUsS0FBSyxNQUFNO0dBQ3RCLElBQUksSUFBSSxFQUFFLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLEtBQUssRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLENBQUMsNEJBQTRCSCxJQUFFQyxJQUFFLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUk7SUFDeko7SUFDQSxJQUFJLG9DQUFvQztJQUN4QyxJQUFJLEtBQUs7SUFDVDtHQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxPQUFPLEVBQUUsU0FBUyxXQUFXLEVBQUUsUUFBUSxFQUFFO0dBQ25NLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7SUFDbEMsTUFBTTtJQUNOLFdBQVc7SUFDWCxVQUFVLEVBQUU7SUFDWixPQUFPLEVBQUU7SUFDVCxjQUFjO0lBQ2QsZ0JBQWdCLE9BQU8sRUFBRSxXQUFXLFlBQVksRUFBRSxVQUFVLEtBQUs7SUFDakUsVUFBVSxNQUFNO0tBQ2YsSUFBSTtNQUNILFFBQVEsRUFBRTtNQUNWLE1BQU07TUFDTixPQUFPO0tBQ1IsQ0FBQztJQUNGO0lBQ0EsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsUUFBUTtLQUNuQyxXQUFXO0tBQ1gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLEdBQUc7TUFDbkMsV0FBVztNQUNYLGVBQWU7TUFDZixXQUFXO0tBQ1osQ0FBQyxJQUFJLE1BQU0sRUFBRSxRQUF3QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzlDLFdBQVc7TUFDWCxVQUFVLEVBQUU7S0FDYixDQUFDLElBQUksSUFBSTtJQUNWLENBQUM7R0FDRixHQUFHLEVBQUUsRUFBRTtFQUNSLENBQUM7Q0FDRixDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYzs7O0FDekJoQixJQUFJRyxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxFQUFHLEVBQUUsUUFBUSxHQUFHLFlBQVksR0FBRyxRQUFRLEdBQUcsVUFBVSxHQUFHLFdBQVcsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUkscUJBQXFCLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksR0FBRyxLQUFLLE1BQU07Q0FDeE0sSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUMxUyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0VBQy9CLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFQyxLQUFHO0dBQzlCLFdBQVc7R0FDWCxRQUFRO0dBQ1IsUUFBUTtHQUNSLGVBQWU7R0FDZixpQkFBaUI7R0FDakIsaUJBQWlCO0dBQ2pCLHdCQUF3QjtHQUN4QixrQkFBa0I7R0FDbEIsVUFBVTtFQUNYLENBQUM7Q0FDRixDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYztBQUdoQixJQUFJLEtBQUEsR0FBSUQsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsTUFBTSxHQUFHLE9BQU8sR0FBRyxRQUFRLEdBQUcsV0FBVyxJQUFJLElBQUksR0FBRyxLQUFLLEdBQUc7Q0FDaEYsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixLQUFLO0VBQ0wsV0FBVyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztFQUMzRCxHQUFHO0VBQ0gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQ25DLFdBQVc7R0FDWCxlQUFlO0dBQ2YsVUFBVTtFQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztHQUM1QixXQUFXO0dBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0lBQ3RDLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQzdCLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxDQUFDO0VBQ0gsQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7QUFDRCxFQUFFLGNBQWMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyN119