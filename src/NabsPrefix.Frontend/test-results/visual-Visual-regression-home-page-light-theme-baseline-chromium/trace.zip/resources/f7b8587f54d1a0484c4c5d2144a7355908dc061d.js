const StrictMode = __vite__cjsImport0_react["StrictMode"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5bd21436";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=5bd21436";
// Nabs UI required styles (order is important)
import "/node_modules/@net-advantage/nabs-ui-themes/dist/nabs-ui-themes.css";
import "/node_modules/@net-advantage/nabs-ui-themes-light/dist/nabs-ui-themes-light.css";
import "/node_modules/@net-advantage/nabs-ui-themes-dark/dist/nabs-ui-themes-dark.css";
import "/node_modules/@net-advantage/nabs-ui-shell/dist/nabs-ui-shell.css";
import "/src/App.css";
import App from "/src/App.tsx";
var _jsxFileName = "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/main.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5bd21436";
// Default theme and density
document.documentElement.classList.add("nabs-ui-theme-dark", "nabs-ui-density-compact");
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 21,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 20,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7O0FBRzNCLE9BQU87QUFDUCxPQUFPO0FBQ1AsT0FBTztBQUNQLE9BQU87QUFDUCxPQUFPO0FBRVAsT0FBTyxTQUFTOzs7O0FBR2hCLFNBQVMsZ0JBQWdCLFVBQVUsSUFDakMsc0JBQ0EseUJBQ0Y7QUFFQSxXQUFXLFNBQVMsZUFBZSxNQUFNLENBQUUsQ0FBQyxDQUFDLE9BQzNDLHdCQUFDLFlBQUQsWUFDRSx3QkFBQyxLQUFELENBQU07Ozs7U0FDSTs7OztRQUNkIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tIFwicmVhY3QtZG9tL2NsaWVudFwiO1xuXG4vLyBOYWJzIFVJIHJlcXVpcmVkIHN0eWxlcyAob3JkZXIgaXMgaW1wb3J0YW50KVxuaW1wb3J0IFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS10aGVtZXMvc3R5bGUuY3NzXCI7XG5pbXBvcnQgXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXRoZW1lcy1saWdodC9zdHlsZS5jc3NcIjtcbmltcG9ydCBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktdGhlbWVzLWRhcmsvc3R5bGUuY3NzXCI7XG5pbXBvcnQgXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXNoZWxsL3N0eWxlLmNzc1wiO1xuaW1wb3J0IFwiLi9BcHAuY3NzXCI7XG5cbmltcG9ydCBBcHAgZnJvbSBcIi4vQXBwLnRzeFwiO1xuXG4vLyBEZWZhdWx0IHRoZW1lIGFuZCBkZW5zaXR5XG5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LmFkZChcbiAgXCJuYWJzLXVpLXRoZW1lLWRhcmtcIixcbiAgXCJuYWJzLXVpLWRlbnNpdHktY29tcGFjdFwiXG4pO1xuXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicm9vdFwiKSEpLnJlbmRlcihcbiAgPFN0cmljdE1vZGU+XG4gICAgPEFwcCAvPlxuICA8L1N0cmljdE1vZGU+XG4pOyJdfQ==