import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pages/Settings/SettingsPage.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Panel } from "/node_modules/.vite/deps/@net-advantage_nabs-ui-shell.js?v=5bd21436";
var _jsxFileName = "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Settings/SettingsPage.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5bd21436";
export function SettingsPage() {
	return /* @__PURE__ */ _jsxDEV(Panel, {
		header: "Settings",
		children: /* @__PURE__ */ _jsxDEV("p", { children: "Settings content goes here." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
}
_c = SettingsPage;
var _c;
$RefreshReg$(_c, "SettingsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/Pages/Settings/SettingsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Settings/SettingsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Settings/SettingsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Settings/SettingsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhOzs7QUFFdEIsT0FBTyxTQUFTLGVBQWU7Q0FDN0IsT0FDRSx3QkFBQyxPQUFEO0VBQU8sUUFBTztZQUNaLHdCQUFDLEtBQUQsWUFBRyw4QkFBOEI7Ozs7O0NBQzVCOzs7OztBQUVYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNldHRpbmdzUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFuZWwgfSBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1zaGVsbFwiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNldHRpbmdzUGFnZSgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFBhbmVsIGhlYWRlcj1cIlNldHRpbmdzXCI+XHJcbiAgICAgIDxwPlNldHRpbmdzIGNvbnRlbnQgZ29lcyBoZXJlLjwvcD5cclxuICAgIDwvUGFuZWw+XHJcbiAgKTtcclxufVxyXG4iXX0=