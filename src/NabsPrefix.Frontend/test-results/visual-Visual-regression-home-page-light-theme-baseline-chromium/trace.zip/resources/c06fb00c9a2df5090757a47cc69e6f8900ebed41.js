import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { Shell, Branding, Navigation, Button } from "/node_modules/.vite/deps/@net-advantage_nabs-ui-shell.js?v=5bd21436";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5bd21436";
import { ThemeViewModel } from "/src/ShellComponents/theme.view-model.ts";
import { HomePage } from "/src/Pages/Home/HomePage.tsx";
import { ElectricCarsPage } from "/src/Pages/ElectricCars/ElectricCarsPage.tsx";
import { WeatherPage } from "/src/Pages/Weather/WeatherPage.tsx";
import { SettingsPage } from "/src/Pages/Settings/SettingsPage.tsx";
var _jsxFileName = "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/App.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5bd21436";
var _s = $RefreshSig$();
const navItems = [
	{
		id: "home",
		label: "Home"
	},
	{
		id: "electric-cars",
		label: "Electric Cars"
	},
	{
		id: "weather",
		label: "Weather"
	},
	{
		id: "settings",
		label: "Settings"
	}
];
function ThemeToggle() {
	const themeViewModel = new ThemeViewModel();
	const toggle = () => {
		const root = document.documentElement;
		themeViewModel.toggleTheme(root);
	};
	return /* @__PURE__ */ _jsxDEV(Button, {
		onClick: toggle,
		children: "Toggle theme"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 10
	}, this);
}
_c = ThemeToggle;
export default function App() {
	_s();
	const [activePageId, setActivePageId] = useState("home");
	const activePage = useMemo(() => {
		if (activePageId === "electric-cars") {
			return /* @__PURE__ */ _jsxDEV(ElectricCarsPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 14
			}, this);
		}
		if (activePageId === "weather") {
			return /* @__PURE__ */ _jsxDEV(WeatherPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 14
			}, this);
		}
		if (activePageId === "settings") {
			return /* @__PURE__ */ _jsxDEV(SettingsPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 14
			}, this);
		}
		return /* @__PURE__ */ _jsxDEV(HomePage, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 12
		}, this);
	}, [activePageId]);
	return /* @__PURE__ */ _jsxDEV(Shell, {
		header: /* @__PURE__ */ _jsxDEV(Branding, {
			logo: /* @__PURE__ */ _jsxDEV("span", {
				className: "app-logo-bg",
				"aria-label": "Nabs logo",
				role: "img",
				style: {
					width: "32px",
					height: "32px",
					display: "inline-block"
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 13
			}, this),
			title: "Nabs UI App",
			byline: "React starter template"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 9
		}, this),
		navigation: /* @__PURE__ */ _jsxDEV(Navigation, {
			direction: "vertical",
			textAlignment: "left",
			activeItemId: activePageId,
			items: navItems,
			onItemSelect: (id) => setActivePageId(id)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 9
		}, this),
		footer: /* @__PURE__ */ _jsxDEV("div", {
			style: {
				padding: "0.5rem 1.25rem",
				fontSize: "0.875rem",
				display: "flex",
				justifyContent: "space-between",
				alignItems: "center"
			},
			children: [/* @__PURE__ */ _jsxDEV("span", { children: [
				"© ",
				new Date().getFullYear(),
				" Your Company"
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV(ThemeToggle, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 9
		}, this),
		children: activePage
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 5
	}, this);
}
_s(App, "qoA0LfPvLQT2SpzOqjsa1KtoYXw=");
_c2 = App;
var _c, _c2;
$RefreshReg$(_c, "ThemeToggle");
$RefreshReg$(_c2, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxPQUNBLFVBQ0EsWUFDQSxjQUNLO0FBQ1AsU0FBUyxTQUFTLGdCQUFnQjtBQUNsQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG9CQUFvQjs7OztBQUU3QixNQUFNLFdBQVc7Q0FDZjtFQUFFLElBQUk7RUFBUSxPQUFPO0NBQU87Q0FDNUI7RUFBRSxJQUFJO0VBQWlCLE9BQU87Q0FBZ0I7Q0FDOUM7RUFBRSxJQUFJO0VBQVcsT0FBTztDQUFVO0NBQ2xDO0VBQUUsSUFBSTtFQUFZLE9BQU87Q0FBVztBQUN0QztBQUlBLFNBQVMsY0FBYztDQUNyQixNQUFNLGlCQUFpQixJQUFJLGVBQWU7Q0FFMUMsTUFBTSxlQUFlO0VBQ25CLE1BQU0sT0FBTyxTQUFTO0VBQ3RCLGVBQWUsWUFBWSxJQUFJO0NBQ2pDO0NBRUEsT0FBTyx3QkFBQyxRQUFEO0VBQVEsU0FBUztZQUFRO0NBQW9COzs7OztBQUN0RDs7QUFFQSxlQUFlLFNBQVMsTUFBTTs7Q0FDNUIsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQW9CLE1BQU07Q0FFbEUsTUFBTSxhQUFhLGNBQWM7RUFDL0IsSUFBSSxpQkFBaUIsaUJBQWlCO0dBQ3BDLE9BQU8sd0JBQUMsa0JBQUQsQ0FBbUI7Ozs7O0VBQzVCO0VBRUEsSUFBSSxpQkFBaUIsV0FBVztHQUM5QixPQUFPLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7RUFDdkI7RUFFQSxJQUFJLGlCQUFpQixZQUFZO0dBQy9CLE9BQU8sd0JBQUMsY0FBRCxDQUFlOzs7OztFQUN4QjtFQUVBLE9BQU8sd0JBQUMsVUFBRCxDQUFXOzs7OztDQUNwQixHQUFHLENBQUMsWUFBWSxDQUFDO0NBRWpCLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFFBQ0Usd0JBQUMsVUFBRDtHQUNFLE1BQ0Usd0JBQUMsUUFBRDtJQUNFLFdBQVU7SUFDVixjQUFXO0lBQ1gsTUFBSztJQUNMLE9BQU87S0FBRSxPQUFPO0tBQVEsUUFBUTtLQUFRLFNBQVM7SUFBZTtHQUNqRTs7Ozs7R0FFSCxPQUFNO0dBQ04sUUFBTztFQUNSOzs7OztFQUVILFlBQ0Usd0JBQUMsWUFBRDtHQUNFLFdBQVU7R0FDVixlQUFjO0dBQ2QsY0FBYztHQUNkLE9BQU87R0FDUCxlQUFlLE9BQWUsZ0JBQWdCLEVBQWU7RUFDOUQ7Ozs7O0VBRUgsUUFDRSx3QkFBQyxPQUFEO0dBQ0UsT0FBTztJQUNMLFNBQVM7SUFDVCxVQUFVO0lBQ1YsU0FBUztJQUNULGdCQUFnQjtJQUNoQixZQUFZO0dBQ2Q7YUFQRixDQVNFLHdCQUFDLFFBQUQ7SUFBTTtJQUFHLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtJQUFFO0dBQW1COzs7O2FBQ3JELHdCQUFDLGFBQUQsQ0FBYzs7OztXQUNYOzs7Ozs7WUFHTjtDQUNJOzs7OztBQUVYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgU2hlbGwsXG4gIEJyYW5kaW5nLFxuICBOYXZpZ2F0aW9uLFxuICBCdXR0b24sXG59IGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXNoZWxsXCI7XG5pbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgVGhlbWVWaWV3TW9kZWwgfSBmcm9tIFwiLi9TaGVsbENvbXBvbmVudHMvdGhlbWUudmlldy1tb2RlbFwiO1xuaW1wb3J0IHsgSG9tZVBhZ2UgfSBmcm9tIFwiLi9QYWdlcy9Ib21lL0hvbWVQYWdlXCI7XG5pbXBvcnQgeyBFbGVjdHJpY0NhcnNQYWdlIH0gZnJvbSBcIi4vUGFnZXMvRWxlY3RyaWNDYXJzL0VsZWN0cmljQ2Fyc1BhZ2VcIjtcbmltcG9ydCB7IFdlYXRoZXJQYWdlIH0gZnJvbSBcIi4vUGFnZXMvV2VhdGhlci9XZWF0aGVyUGFnZVwiO1xuaW1wb3J0IHsgU2V0dGluZ3NQYWdlIH0gZnJvbSBcIi4vUGFnZXMvU2V0dGluZ3MvU2V0dGluZ3NQYWdlXCI7XG5cbmNvbnN0IG5hdkl0ZW1zID0gW1xuICB7IGlkOiBcImhvbWVcIiwgbGFiZWw6IFwiSG9tZVwiIH0sXG4gIHsgaWQ6IFwiZWxlY3RyaWMtY2Fyc1wiLCBsYWJlbDogXCJFbGVjdHJpYyBDYXJzXCIgfSxcbiAgeyBpZDogXCJ3ZWF0aGVyXCIsIGxhYmVsOiBcIldlYXRoZXJcIiB9LFxuICB7IGlkOiBcInNldHRpbmdzXCIsIGxhYmVsOiBcIlNldHRpbmdzXCIgfSxcbl07XG5cbnR5cGUgQXBwUGFnZUlkID0gKHR5cGVvZiBuYXZJdGVtcylbbnVtYmVyXVtcImlkXCJdO1xuXG5mdW5jdGlvbiBUaGVtZVRvZ2dsZSgpIHtcbiAgY29uc3QgdGhlbWVWaWV3TW9kZWwgPSBuZXcgVGhlbWVWaWV3TW9kZWwoKTtcblxuICBjb25zdCB0b2dnbGUgPSAoKSA9PiB7XG4gICAgY29uc3Qgcm9vdCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudDtcbiAgICB0aGVtZVZpZXdNb2RlbC50b2dnbGVUaGVtZShyb290KTtcbiAgfTtcblxuICByZXR1cm4gPEJ1dHRvbiBvbkNsaWNrPXt0b2dnbGV9PlRvZ2dsZSB0aGVtZTwvQnV0dG9uPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbYWN0aXZlUGFnZUlkLCBzZXRBY3RpdmVQYWdlSWRdID0gdXNlU3RhdGU8QXBwUGFnZUlkPihcImhvbWVcIik7XG5cbiAgY29uc3QgYWN0aXZlUGFnZSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmIChhY3RpdmVQYWdlSWQgPT09IFwiZWxlY3RyaWMtY2Fyc1wiKSB7XG4gICAgICByZXR1cm4gPEVsZWN0cmljQ2Fyc1BhZ2UgLz47XG4gICAgfVxuXG4gICAgaWYgKGFjdGl2ZVBhZ2VJZCA9PT0gXCJ3ZWF0aGVyXCIpIHtcbiAgICAgIHJldHVybiA8V2VhdGhlclBhZ2UgLz47XG4gICAgfVxuXG4gICAgaWYgKGFjdGl2ZVBhZ2VJZCA9PT0gXCJzZXR0aW5nc1wiKSB7XG4gICAgICByZXR1cm4gPFNldHRpbmdzUGFnZSAvPjtcbiAgICB9XG5cbiAgICByZXR1cm4gPEhvbWVQYWdlIC8+O1xuICB9LCBbYWN0aXZlUGFnZUlkXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8U2hlbGxcbiAgICAgIGhlYWRlcj17XG4gICAgICAgIDxCcmFuZGluZ1xuICAgICAgICAgIGxvZ289e1xuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXBwLWxvZ28tYmdcIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiTmFicyBsb2dvXCJcbiAgICAgICAgICAgICAgcm9sZT1cImltZ1wiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjMycHhcIiwgaGVpZ2h0OiBcIjMycHhcIiwgZGlzcGxheTogXCJpbmxpbmUtYmxvY2tcIiB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICB9XG4gICAgICAgICAgdGl0bGU9XCJOYWJzIFVJIEFwcFwiXG4gICAgICAgICAgYnlsaW5lPVwiUmVhY3Qgc3RhcnRlciB0ZW1wbGF0ZVwiXG4gICAgICAgIC8+XG4gICAgICB9XG4gICAgICBuYXZpZ2F0aW9uPXtcbiAgICAgICAgPE5hdmlnYXRpb25cbiAgICAgICAgICBkaXJlY3Rpb249XCJ2ZXJ0aWNhbFwiXG4gICAgICAgICAgdGV4dEFsaWdubWVudD1cImxlZnRcIlxuICAgICAgICAgIGFjdGl2ZUl0ZW1JZD17YWN0aXZlUGFnZUlkfVxuICAgICAgICAgIGl0ZW1zPXtuYXZJdGVtc31cbiAgICAgICAgICBvbkl0ZW1TZWxlY3Q9eyhpZDogc3RyaW5nKSA9PiBzZXRBY3RpdmVQYWdlSWQoaWQgYXMgQXBwUGFnZUlkKX1cbiAgICAgICAgLz5cbiAgICAgIH1cbiAgICAgIGZvb3Rlcj17XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgcGFkZGluZzogXCIwLjVyZW0gMS4yNXJlbVwiLFxuICAgICAgICAgICAgZm9udFNpemU6IFwiMC44NzVyZW1cIixcbiAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxuICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4+wqkge25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0gWW91ciBDb21wYW55PC9zcGFuPlxuICAgICAgICAgIDxUaGVtZVRvZ2dsZSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIH1cbiAgICA+XG4gICAgICB7YWN0aXZlUGFnZX1cbiAgICA8L1NoZWxsPlxuICApO1xufSJdfQ==