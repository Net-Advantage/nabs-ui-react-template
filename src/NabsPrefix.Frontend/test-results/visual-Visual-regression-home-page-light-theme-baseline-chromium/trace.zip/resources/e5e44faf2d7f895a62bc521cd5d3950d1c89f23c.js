import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pages/ElectricCars/ElectricCarsPage.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Cards, Panel } from "/node_modules/.vite/deps/@net-advantage_nabs-ui-shell.js?v=5bd21436";
import { ElectricCarsPageViewModel } from "/src/Pages/ElectricCars/ElectricCarsPage.view-model.ts";
var _jsxFileName = "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/ElectricCars/ElectricCarsPage.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5bd21436";
const electricCarsPageViewModel = new ElectricCarsPageViewModel();
export function ElectricCarsPage() {
	const cards = electricCarsPageViewModel.electricCarModel.map((car) => ({
		id: car.id,
		header: car.type,
		content: /* @__PURE__ */ _jsxDEV("ul", { children: [
			/* @__PURE__ */ _jsxDEV("li", { children: [
				"Range: ",
				car.rangeMiles,
				" miles"
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("li", { children: [
				"Battery: ",
				car.batteryKWh,
				" kWh"
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("li", { children: ["Drive: ", car.driveType] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("li", { children: ["Charging: ", car.chargeSpeed] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 9
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this),
		actions: car.description
	}));
	return /* @__PURE__ */ _jsxDEV(Panel, {
		header: "Electric Cars",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: electricCarsPageViewModel.topicPrompt }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(Cards, {
			"aria-label": "Electric car card list",
			columns: 2,
			layout: "N",
			items: cards
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_c = ElectricCarsPage;
var _c;
$RefreshReg$(_c, "ElectricCarsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/Pages/ElectricCars/ElectricCarsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/ElectricCars/ElectricCarsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/ElectricCars/ElectricCarsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/ElectricCars/ElectricCarsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxPQUFPLGFBQWE7QUFDN0IsU0FBUyxpQ0FBaUM7OztBQUUxQyxNQUFNLDRCQUE0QixJQUFJLDBCQUEwQjtBQUVoRSxPQUFPLFNBQVMsbUJBQW1CO0NBQ2pDLE1BQU0sUUFBUSwwQkFBMEIsaUJBQWlCLEtBQUssU0FBUztFQUNyRSxJQUFJLElBQUk7RUFDUixRQUFRLElBQUk7RUFDWixTQUNFLHdCQUFDLE1BQUQ7R0FDRSx3QkFBQyxNQUFEO0lBQUk7SUFBUSxJQUFJO0lBQVc7R0FBVTs7Ozs7R0FDckMsd0JBQUMsTUFBRDtJQUFJO0lBQVUsSUFBSTtJQUFXO0dBQVE7Ozs7O0dBQ3JDLHdCQUFDLE1BQUQsYUFBSSxXQUFRLElBQUksU0FBYzs7Ozs7R0FDOUIsd0JBQUMsTUFBRCxhQUFJLGNBQVcsSUFBSSxXQUFnQjs7Ozs7RUFDakM7Ozs7O0VBRU4sU0FBUyxJQUFJO0NBQ2YsRUFBRTtDQUVGLE9BQ0Usd0JBQUMsT0FBRDtFQUFPLFFBQU87WUFBZCxDQUNFLHdCQUFDLEtBQUQsWUFBSSwwQkFBMEIsWUFBZTs7OztZQUM3Qyx3QkFBQyxPQUFEO0dBQU8sY0FBVztHQUF5QixTQUFTO0dBQUcsUUFBTztHQUFJLE9BQU87RUFBUTs7OztVQUM1RTs7Ozs7O0FBRVgiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRWxlY3RyaWNDYXJzUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2FyZHMsIFBhbmVsIH0gZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktc2hlbGxcIjtcclxuaW1wb3J0IHsgRWxlY3RyaWNDYXJzUGFnZVZpZXdNb2RlbCB9IGZyb20gXCIuL0VsZWN0cmljQ2Fyc1BhZ2Uudmlldy1tb2RlbFwiO1xyXG5cclxuY29uc3QgZWxlY3RyaWNDYXJzUGFnZVZpZXdNb2RlbCA9IG5ldyBFbGVjdHJpY0NhcnNQYWdlVmlld01vZGVsKCk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRWxlY3RyaWNDYXJzUGFnZSgpIHtcclxuICBjb25zdCBjYXJkcyA9IGVsZWN0cmljQ2Fyc1BhZ2VWaWV3TW9kZWwuZWxlY3RyaWNDYXJNb2RlbC5tYXAoKGNhcikgPT4gKHtcclxuICAgIGlkOiBjYXIuaWQsXHJcbiAgICBoZWFkZXI6IGNhci50eXBlLFxyXG4gICAgY29udGVudDogKFxyXG4gICAgICA8dWw+XHJcbiAgICAgICAgPGxpPlJhbmdlOiB7Y2FyLnJhbmdlTWlsZXN9IG1pbGVzPC9saT5cclxuICAgICAgICA8bGk+QmF0dGVyeToge2Nhci5iYXR0ZXJ5S1dofSBrV2g8L2xpPlxyXG4gICAgICAgIDxsaT5Ecml2ZToge2Nhci5kcml2ZVR5cGV9PC9saT5cclxuICAgICAgICA8bGk+Q2hhcmdpbmc6IHtjYXIuY2hhcmdlU3BlZWR9PC9saT5cclxuICAgICAgPC91bD5cclxuICAgICksXHJcbiAgICBhY3Rpb25zOiBjYXIuZGVzY3JpcHRpb24sXHJcbiAgfSkpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFBhbmVsIGhlYWRlcj1cIkVsZWN0cmljIENhcnNcIj5cclxuICAgICAgPHA+e2VsZWN0cmljQ2Fyc1BhZ2VWaWV3TW9kZWwudG9waWNQcm9tcHR9PC9wPlxyXG4gICAgICA8Q2FyZHMgYXJpYS1sYWJlbD1cIkVsZWN0cmljIGNhciBjYXJkIGxpc3RcIiBjb2x1bW5zPXsyfSBsYXlvdXQ9XCJOXCIgaXRlbXM9e2NhcmRzfSAvPlxyXG4gICAgPC9QYW5lbD5cclxuICApO1xyXG59XHJcbiJdfQ==