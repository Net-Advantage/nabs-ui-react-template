import { n as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=5bd21436";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=5bd21436";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom.js?v=5bd21436";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=5bd21436";
//#region node_modules/@net-advantage/nabs-ui-layout/dist/nabs-ui-layout.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function n$27({ as: t = "div", className: n = "", children: r, ...i }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(t, {
		className: n,
		...i,
		children: r
	});
}
function r$1({ header: r, footer: i, leftSidePanel: a, rightSidePanel: o, children: s, className: c = "", headerClassName: l = "", footerClassName: u = "", leftSidePanelClassName: d = "", rightSidePanelClassName: f = "", contentClassName: p = "", ...m }) {
	let h = r != null && r !== !1, g = i != null && i !== !1, _ = a != null && a !== !1, v = o != null && o !== !1, y = [
		"nabs-ui-layout__body",
		_ && v ? "nabs-ui-layout__body--with-both-panels" : "",
		_ && !v ? "nabs-ui-layout__body--with-left-panel" : "",
		!_ && v ? "nabs-ui-layout__body--with-right-panel" : ""
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: ["nabs-ui-layout", c].filter(Boolean).join(" "),
		...m,
		children: [
			h ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(n$27, {
				as: "header",
				className: "nabs-ui-layout__headerWrapper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: ["nabs-ui-layout__header", l].filter(Boolean).join(" "),
					children: r
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: y,
				children: [
					_ ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(n$27, {
						as: "aside",
						className: [
							"nabs-ui-layout__panel",
							"nabs-ui-layout__panel--left",
							d
						].filter(Boolean).join(" "),
						children: a
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(n$27, {
						as: "section",
						className: ["nabs-ui-layout__content", p].filter(Boolean).join(" "),
						children: s
					}),
					v ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(n$27, {
						as: "aside",
						className: [
							"nabs-ui-layout__panel",
							"nabs-ui-layout__panel--right",
							f
						].filter(Boolean).join(" "),
						children: o
					}) : null
				]
			}),
			g ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(n$27, {
				as: "footer",
				className: "nabs-ui-layout__footerWrapper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: ["nabs-ui-layout__footer", u].filter(Boolean).join(" "),
					children: i
				})
			}) : null
		]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-accordion/dist/nabs-ui-accordion.js
function s$12(e, t, n) {
	let r = e ?? [], i = new Set(t.map((e) => e.id)), a = r.filter((e, t, n) => i.has(e) && n.indexOf(e) === t);
	return n === "single" ? a.slice(0, 1) : a;
}
function c$11(e, t, n) {
	let r = e.includes(t);
	return n === "single" ? r ? [] : [t] : r ? e.filter((e) => e !== t) : [...e, t];
}
function l$10(e) {
	return ["nabs-ui-accordion", e].filter(Boolean).join(" ");
}
var u = (0, import_react.forwardRef)(function({ items: e, mode: u = "multiple", expandedItemIds: d, defaultExpandedItemIds: f, onExpandedItemIdsChange: p, className: m = "", itemClassName: h = "", triggerClassName: g = "", panelClassName: _ = "", id: v, ...y }, b) {
	let x = (0, import_react.useId)(), S = v ?? `nabs-ui-accordion-${x.replace(/:/g, "")}`, [C, w] = (0, import_react.useState)((0, import_react.useMemo)(() => s$12(f, e, u), [
		f,
		e,
		u
	]));
	(0, import_react.useEffect)(() => {
		w((t) => s$12(t, e, u));
	}, [e, u]);
	let T = (0, import_react.useMemo)(() => s$12(d === void 0 ? C : d, e, u), [
		d,
		C,
		e,
		u
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		ref: b,
		id: S,
		className: l$10(m),
		...y,
		children: e.map((e) => {
			let t = T.includes(e.id), n = `${S}-panel-${e.id}`, r = `${S}-trigger-${e.id}`, i = [
				"nabs-ui-accordion__item",
				t ? "nabs-ui-accordion__item--expanded" : "",
				h
			].filter(Boolean).join(" "), s = ["nabs-ui-accordion__trigger", g].filter(Boolean).join(" "), l = ["nabs-ui-accordion__panel", _].filter(Boolean).join(" "), f = (t) => {
				let n = c$11(T, e.id, u);
				d === void 0 && w(n), p?.({
					itemId: e.id,
					expandedItemIds: n,
					event: t
				});
			};
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: i,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "m-0",
					children: t ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						id: r,
						type: "button",
						className: s,
						"aria-expanded": "true",
						"aria-controls": n,
						disabled: e.disabled,
						onClick: f,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.header }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nabs-ui-accordion__triggerIcon",
							"aria-hidden": "true",
							children: "+"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						id: r,
						type: "button",
						className: s,
						"aria-expanded": "false",
						"aria-controls": n,
						disabled: e.disabled,
						onClick: f,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.header }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nabs-ui-accordion__triggerIcon",
							"aria-hidden": "true",
							children: "+"
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: n,
					className: l,
					role: "region",
					"aria-labelledby": r,
					hidden: !t,
					children: e.content
				})]
			}, e.id);
		})
	});
});
u.displayName = "Accordion";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-avatar/dist/nabs-ui-avatar.js
var import_react_dom = require_react_dom();
function u$8(e) {
	return !!(e && "type" in e && e.type === "divider");
}
function d$7(e) {
	return e.label ?? e.children ?? "Menu item";
}
function f$7(e, t) {
	return e.value ?? e.label ?? `item-${t}`;
}
function p$6({ label: e = "Menu", triggerContent: p, triggerAriaLabel: m, menuAlign: h = "start", items: g = [], className: _ = "", triggerClassName: v = "", menuClassName: y = "", itemClassName: b = "", dividerClassName: x = "", id: S, onItemSelect: C, ...w }) {
	let [T, E] = (0, import_react.useState)(!1), D = (0, import_react.useRef)(null), O = (0, import_react.useRef)(null), k = (0, import_react.useRef)(null), A = (0, import_react.useId)(), j = S ?? `nabs-ui-dropdownmenu-${A.replace(/:/g, "")}`, M = ["nabs-ui-dropdownmenu", _].filter(Boolean).join(" "), N = ["nabs-ui-dropdownmenu__trigger", v].filter(Boolean).join(" "), P = ["nabs-ui-dropdownmenu__menu", y].filter(Boolean).join(" "), F = ["nabs-ui-dropdownmenu__item", b].filter(Boolean).join(" "), I = ["nabs-ui-dropdownmenu__divider", x].filter(Boolean).join(" ");
	(0, import_react.useEffect)(() => {
		let e = (e) => {
			e.target instanceof Node && D.current && !D.current.contains(e.target) && k.current && !k.current.contains(e.target) && E(!1);
		}, t = (e) => {
			e.key === "Escape" && E(!1);
		};
		return document.addEventListener("pointerdown", e), document.addEventListener("keydown", t), () => {
			document.removeEventListener("pointerdown", e), document.removeEventListener("keydown", t);
		};
	}, []), (0, import_react.useLayoutEffect)(() => {
		if (!T || !O.current) return;
		let e = () => {
			let e = O.current?.getBoundingClientRect(), t = k.current?.getBoundingClientRect(), n = k.current;
			if (!e || !t || !n) return;
			let r = Math.max(e.width, t.width), i = window.innerWidth - r - 8, a = h === "end" ? e.right - r : e.left, o = Math.max(8, Math.min(a, i)), s = Math.max(8, e.bottom + 10);
			n.style.position = "fixed", n.style.top = `${s}px`, n.style.left = `${o}px`, n.style.right = "auto", n.style.minWidth = `${r}px`, n.style.visibility = "visible";
		};
		return k.current && (k.current.style.visibility = "hidden"), e(), window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0);
		};
	}, [h, T]);
	let L = (e, t) => {
		if (E(!1), e.disabled) {
			t.preventDefault();
			return;
		}
		C?.(e, t), e.onSelect?.(e, t);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: D,
		className: M,
		...w,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			ref: O,
			type: "button",
			className: N,
			"aria-haspopup": "menu",
			"aria-controls": j,
			"aria-label": m ?? e,
			onClick: () => E((e) => !e),
			children: p ?? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-dropdownmenu__triggerLabel",
				children: e
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-dropdownmenu__triggerChevron",
				"aria-hidden": "true",
				children: "▾"
			})] })
		}), T && typeof document < "u" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: k,
			id: j,
			className: P,
			"aria-label": e,
			children: g.map((e, t) => {
				if (u$8(e)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: I,
					role: "separator",
					"aria-hidden": "true"
				}, `divider-${t}`);
				let n = d$7(e), r = [
					F,
					e.disabled ? "nabs-ui-dropdownmenu__item--disabled" : "",
					e.danger ? "nabs-ui-dropdownmenu__item--danger" : ""
				].filter(Boolean).join(" "), i = {
					className: r,
					"aria-disabled": e.disabled || void 0
				};
				return e.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					...i,
					href: e.disabled ? void 0 : e.href,
					onClick: (t) => L(e, t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemLabel",
						children: n
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemDescription",
						children: e.description
					}) : null]
				}, f$7(e, t)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: r,
					disabled: e.disabled,
					onClick: (t) => L(e, t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemLabel",
						children: n
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemDescription",
						children: e.description
					}) : null]
				}, f$7(e, t));
			})
		}), document.body) : null]
	});
}
function m$5(e) {
	let t = e.trim().split(/\s+/).filter(Boolean);
	return t.length === 0 ? "?" : t.slice(0, 2).map((e) => e[0]?.toUpperCase() ?? "").join("");
}
var h = (0, import_react.forwardRef)(function({ authenticated: e = !1, name: t = "Guest user", avatarUrl: n = "", loginHref: r, profileHref: i = "#", logoutHref: a = "#", onLoginClick: o, onProfileClick: u, onLogoutClick: d, className: f = "", menuLabel: h, ...g }, _) {
	let v = t.trim() || "Guest user", y = m$5(v), b = [
		"nabs-ui-avatar",
		e ? "nabs-ui-avatar--authenticated" : "nabs-ui-avatar--unauthenticated",
		f
	].filter(Boolean).join(" "), x = (e) => {
		o && (e.preventDefault(), o(e));
	}, S = (e) => {
		u && (e.preventDefault(), u(e));
	}, C = (e) => {
		d && (e.preventDefault(), d(e));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: _,
		className: b,
		...g,
		children: e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(p$6, {
			className: "nabs-ui-avatar__menuRoot",
			label: `${v} account menu`,
			triggerAriaLabel: h ?? `${v} account menu`,
			menuAlign: "end",
			triggerContent: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "nabs-ui-avatar__avatar",
					"aria-hidden": "true",
					children: n ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						className: "nabs-ui-avatar__image",
						src: n,
						alt: ""
					}) : y
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "nabs-ui-avatar__name",
					children: v
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "nabs-ui-avatar__chevron",
					"aria-hidden": "true",
					children: "▾"
				})
			] }),
			triggerClassName: "nabs-ui-avatar__trigger",
			menuClassName: "nabs-ui-avatar__menu",
			itemClassName: "nabs-ui-avatar__menuItem",
			items: [{
				label: "Profile",
				href: i,
				onSelect: (e, t) => S(t)
			}, {
				label: "Logout",
				href: a,
				danger: !0,
				onSelect: (e, t) => C(t)
			}]
		}) : r ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			className: "nabs-ui-avatar__login",
			href: r,
			onClick: x,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-avatar__avatar nabs-ui-avatar__avatar--placeholder",
				"aria-hidden": "true",
				children: y
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-avatar__loginText",
				children: "Login"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "nabs-ui-avatar__login",
			onClick: x,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-avatar__avatar nabs-ui-avatar__avatar--placeholder",
				"aria-hidden": "true",
				children: y
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-avatar__loginText",
				children: "Login"
			})]
		})
	});
});
h.displayName = "Avatar";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-buttons/dist/nabs-ui-buttons.js
var n$24 = {
	primary: "nabs-ui-button--primary",
	secondary: "nabs-ui-button--secondary",
	ghost: "nabs-ui-button--ghost"
};
var r = (0, import_react.forwardRef)(function({ children: e, className: r = "", variant: i = "primary", type: a = "button", ...o }, s) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref: s,
		className: [
			"nabs-ui-button",
			n$24[i] ?? n$24.primary,
			r
		].filter(Boolean).join(" "),
		type: a,
		...o,
		children: e
	});
});
r.displayName = "Button";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-cards/dist/nabs-ui-cards.js
function r$25(e) {
	return e === void 0 ? 1 : Number.isFinite(e) ? Math.min(12, Math.max(1, Math.floor(e))) : 1;
}
function i$21(e, t, n) {
	return t === "Z" ? [...e].sort((t, r) => {
		let i = e.findIndex((e) => e.id === t.id), a = e.findIndex((e) => e.id === r.id), o = Math.floor(i / n), s = Math.floor(a / n);
		if (o !== s) return o - s;
		let c = i % n, l = a % n;
		return (o % 2 == 0 ? c : n - 1 - c) - (s % 2 == 0 ? l : n - 1 - l);
	}) : e;
}
var a$1 = (0, import_react.forwardRef)(({ items: e, layout: a = "N", columns: o, className: s = "", itemClassName: c = "", headerClassName: l = "", contentClassName: u = "", actionsClassName: d = "", ...f }, p) => {
	let m = r$25(o), h = ["nabs-ui-cards", s].filter(Boolean).join(" "), g = ["nabs-ui-cards__grid", `nabs-ui-cards__grid--columns-${m}`].filter(Boolean).join(" "), _ = i$21(e, a, m);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		ref: p,
		className: h,
		...f,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: g,
			children: _.map((e) => {
				let r = ["nabs-ui-cards__card", c].filter(Boolean).join(" "), i = e.header != null && e.header !== !1, a = e.content != null && e.content !== !1, o = e.actions != null && e.actions !== !1;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: r,
					children: [
						i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
							className: ["nabs-ui-cards__header", l].filter(Boolean).join(" "),
							children: e.header
						}) : null,
						a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: ["nabs-ui-cards__content", u].filter(Boolean).join(" "),
							children: e.content
						}) : null,
						o ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: ["nabs-ui-cards__actions", d].filter(Boolean).join(" "),
							children: e.actions
						}) : null
					]
				}, e.id);
			})
		})
	});
});
a$1.displayName = "Cards";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-checkbox/dist/nabs-ui-checkbox.js
var i$20 = {
	right: "nabs-ui-checkbox--label-right",
	left: "nabs-ui-checkbox--label-left",
	top: "nabs-ui-checkbox--label-top",
	bottom: "nabs-ui-checkbox--label-bottom"
};
var a$2 = (0, import_react.forwardRef)(function({ label: e = "Checkbox", labelPosition: a = "right", className: o = "", inputClassName: s = "", labelClassName: c = "", id: l, disabled: u, ...d }, f) {
	let p = (0, import_react.useId)(), m = l ?? `nabs-ui-checkbox-${p.replace(/:/g, "")}`, h = [
		"nabs-ui-checkbox",
		u ? "nabs-ui-checkbox--disabled" : "",
		i$20[a] ?? i$20.right,
		o
	].filter(Boolean).join(" "), g = ["nabs-ui-checkbox__input", s].filter(Boolean).join(" "), _ = ["nabs-ui-checkbox__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: h,
		htmlFor: m,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: f,
			id: m,
			className: g,
			type: "checkbox",
			disabled: u,
			...d
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: _,
			children: e
		})]
	});
});
a$2.displayName = "Checkbox";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-code/dist/nabs-ui-code.js
var r$23 = {
	html: "HTML",
	css: "CSS",
	json: "JSON",
	csharp: "C#"
};
var i = (0, import_react.forwardRef)(({ code: e, language: i = "html", showLineNumbers: a = !1, wrap: o = !1, title: s, className: c = "", preClassName: l = "", codeClassName: u = "", ...d }, f) => {
	let p = ["nabs-ui-code", c].filter(Boolean).join(" "), m = [
		"nabs-ui-code__pre",
		o ? "nabs-ui-code__pre--wrap" : "",
		a ? "nabs-ui-code__pre--lineNumbers" : "",
		l
	].filter(Boolean).join(" "), h = [
		"nabs-ui-code__snippet",
		`nabs-ui-code__snippet--${i}`,
		u
	].filter(Boolean).join(" "), g = e.replace(/\r\n/g, "\n"), _ = g.split("\n");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref: f,
		className: p,
		...d,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "nabs-ui-code__header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-code__language",
				children: r$23[i]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-code__title",
				children: s ?? "Snippet"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: m,
			children: a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
				className: h,
				children: _.map((e, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "nabs-ui-code__line",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-code__lineNumber",
						children: r + 1
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-code__lineText",
						children: e || " "
					})]
				}, r))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
				className: h,
				children: g
			})
		})]
	});
});
i.displayName = "Code";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-combobox/dist/nabs-ui-combobox.js
function c$9(e) {
	return e.label ?? e.children ?? e.value;
}
function l$8(e) {
	let t = c$9(e);
	return typeof t == "string" || typeof t == "number" ? `${t}` : e.value;
}
function u$7(e, t) {
	return e.value || `item-${t}`;
}
function d$6(e, t) {
	return t == null ? null : e.find((e) => e.value === t) ?? null;
}
function f$6(e) {
	return e.trim().toLowerCase();
}
var p = (0, import_react.forwardRef)(function({ items: e = [], value: p, defaultValue: m, allowNull: h = !1, nullLabel: g = "None", className: _ = "", id: v, disabled: y, placeholder: b, onValueChange: x, onFocus: S, onBlur: C, onKeyDown: w, ...T }, E) {
	let D = (0, import_react.useId)(), O = (0, import_react.useRef)(null), k = `nabs-ui-combobox-list-${D.replace(/:/g, "")}`, A = v ?? `nabs-ui-combobox-${D.replace(/:/g, "")}`, j = p !== void 0, [M, N] = (0, import_react.useState)(m ?? null), P = j ? p : M, F = d$6(e, P), I = F ? l$8(F) : P ?? "", [L, R] = (0, import_react.useState)(!1), [z, B] = (0, import_react.useState)(I), [V, H] = (0, import_react.useState)(0), U = (0, import_react.useMemo)(() => {
		let t = f$6(z);
		return e.filter((e) => {
			let n = f$6(l$8(e));
			return t.length === 0 || n.includes(t);
		});
	}, [e, z]), W = h ? [{
		value: "",
		label: g,
		disabled: !1,
		__null: !0
	}, ...U] : U;
	(0, import_react.useEffect)(() => {
		L || B(I);
	}, [L, I]), (0, import_react.useEffect)(() => {
		V >= W.length && H(W.length === 0 ? 0 : W.length - 1);
	}, [V, W.length]), (0, import_react.useEffect)(() => {
		let e = (e) => {
			O.current && e.target instanceof Node && !O.current.contains(e.target) && R(!1);
		};
		return document.addEventListener("pointerdown", e), () => {
			document.removeEventListener("pointerdown", e);
		};
	}, []);
	let G = (e, t) => {
		j || N(e), x?.(e, t), R(!1), B(t ? l$8(t) : "");
	}, K = (e) => {
		let t = W[e];
		if (t) {
			if ("__null" in t) {
				G(null, null);
				return;
			}
			t.disabled || G(t.value, t);
		}
	}, q = (e) => {
		R(!0), B(I), H(0), S?.(e);
	}, J = (e) => {
		R(!1), B(I), C?.(e);
	}, Y = (e) => {
		R(!0), B(e.target.value), H(0);
	}, X = (e) => {
		if (e.key === "ArrowDown") {
			e.preventDefault(), R(!0), H((e) => Math.min(e + 1, Math.max(W.length - 1, 0)));
			return;
		}
		if (e.key === "ArrowUp") {
			e.preventDefault(), R(!0), H((e) => Math.max(e - 1, 0));
			return;
		}
		if (e.key === "Enter") {
			L && (e.preventDefault(), K(V));
			return;
		}
		if (e.key === "Escape") {
			e.preventDefault(), R(!1), B(I);
			return;
		}
		w?.(e);
	}, Z = L ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref: E,
		id: A,
		role: "combobox",
		"aria-haspopup": "listbox",
		"aria-autocomplete": "list",
		"aria-expanded": "true",
		"aria-controls": k,
		"aria-activedescendant": W[V] ? `${k}-option-${V}` : void 0,
		className: "nabs-ui-combobox__input",
		disabled: y,
		placeholder: b,
		value: z,
		onFocus: q,
		onBlur: J,
		onChange: Y,
		onKeyDown: X,
		...T
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref: E,
		id: A,
		role: "combobox",
		"aria-haspopup": "listbox",
		"aria-autocomplete": "list",
		"aria-expanded": "false",
		"aria-controls": k,
		className: "nabs-ui-combobox__input",
		disabled: y,
		placeholder: b,
		value: z,
		onFocus: q,
		onBlur: J,
		onChange: Y,
		onKeyDown: X,
		...T
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: O,
		className: [
			"nabs-ui-combobox",
			L ? "nabs-ui-combobox--open" : "",
			y ? "nabs-ui-combobox--disabled" : "",
			_
		].filter(Boolean).join(" "),
		children: [Z, L ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: k,
			className: "nabs-ui-combobox__popup",
			role: "listbox",
			"aria-label": "Combobox options",
			children: W.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-combobox__empty",
				role: "option",
				"aria-disabled": "true",
				"aria-selected": "false",
				children: "No options found"
			}) : W.map((e, t) => {
				let n = "__null" in e, r = !n && P === e.value, i = [
					"nabs-ui-combobox__option",
					t === V ? "nabs-ui-combobox__option--active" : "",
					r ? "nabs-ui-combobox__option--selected" : "",
					n ? "nabs-ui-combobox__option--null" : "",
					e.disabled ? "nabs-ui-combobox__option--disabled" : ""
				].filter(Boolean).join(" ");
				return n ? P === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "true",
					"aria-disabled": "false",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: g
					})
				}, "null") : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "false",
					"aria-disabled": "false",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: g
					})
				}, "null") : e.disabled ? r ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "true",
					"aria-disabled": "true",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: c$9(e)
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionDescription",
						children: e.description
					}) : null]
				}, u$7(e, t)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "false",
					"aria-disabled": "true",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: c$9(e)
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionDescription",
						children: e.description
					}) : null]
				}, u$7(e, t)) : r ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "true",
					"aria-disabled": "false",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: c$9(e)
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionDescription",
						children: e.description
					}) : null]
				}, u$7(e, t)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: `${k}-option-${t}`,
					className: i,
					role: "option",
					"aria-selected": "false",
					"aria-disabled": "false",
					tabIndex: -1,
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => K(t),
					onMouseEnter: () => H(t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionLabel",
						children: c$9(e)
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-combobox__optionDescription",
						children: e.description
					}) : null]
				}, u$7(e, t));
			})
		}) : null]
	});
});
p.displayName = "Combobox";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-datepicker/dist/nabs-ui-datepicker.js
var i$18 = {
	none: "nabs-ui-datepicker--label-none",
	top: "nabs-ui-datepicker--label-top",
	left: "nabs-ui-datepicker--label-left"
};
var a$3 = (0, import_react.forwardRef)(({ label: e, labelPosition: a = "top", className: o = "", inputClassName: s = "", labelClassName: c = "", allowNull: l = !1, id: u, value: d, onChange: f, onValueChange: p, ...m }, h) => {
	let g = (0, import_react.useId)(), _ = u ?? `nabs-ui-datepicker-${g.replace(/:/g, "")}`, v = [
		"nabs-ui-datepicker",
		e ? i$18[a] ?? i$18.top : "",
		o
	].filter(Boolean).join(" "), y = ["nabs-ui-datepicker__input", s].filter(Boolean).join(" "), b = ["nabs-ui-datepicker__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: v,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: b,
			htmlFor: _,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: h,
			id: _,
			className: y,
			type: "date",
			value: d === void 0 ? void 0 : d ?? "",
			onChange: (e) => {
				f?.(e), p?.(l && e.target.value === "" ? null : e.target.value, e);
			},
			...m
		})]
	});
});
a$3.displayName = "DatePicker";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-dialog/dist/nabs-ui-dialog.js
var o$9 = "a[href], area[href], button:not([disabled]), input:not([disabled]):not([type=\"hidden\"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex=\"-1\"])";
function s$9(e) {
	return Array.from(e.querySelectorAll(o$9)).filter((e) => !e.hasAttribute("disabled") && e.getAttribute("aria-hidden") !== "true");
}
var c = (0, import_react.forwardRef)(function({ title: e, description: o, header: c, footer: l, showHeader: u = !0, showFooter: d = !0, onRequestClose: f, closeOnBackdropClick: p = !0, closeOnEscape: m = !0, initialFocusSelector: h, dialogRole: g = "dialog", className: _ = "", backdropClassName: v = "", headerClassName: y = "", descriptionClassName: b = "", contentClassName: x = "", footerClassName: S = "", onKeyDown: C, tabIndex: w, children: T, ...E }, D) {
	let O = (0, import_react.useRef)(null), k = (0, import_react.useRef)(null), A = `nabs-ui-dialog-title-${(0, import_react.useId)().replace(/:/g, "")}`, j = `nabs-ui-dialog-description-${(0, import_react.useId)().replace(/:/g, "")}`, M = E["aria-labelledby"], N = E["aria-describedby"], P = !c && !!e, F = !!o, I = u && (!!c || P), L = d && l != null, R = M ?? (P ? A : void 0), z = N ?? (F ? j : void 0), B = ["nabs-ui-dialog__backdrop", v].filter(Boolean).join(" "), V = ["nabs-ui-dialog", _].filter(Boolean).join(" "), H = ["nabs-ui-dialog__header", y].filter(Boolean).join(" "), U = ["nabs-ui-dialog__description", b].filter(Boolean).join(" "), W = ["nabs-ui-dialog__content", x].filter(Boolean).join(" "), G = ["nabs-ui-dialog__footer", S].filter(Boolean).join(" ");
	return (0, import_react.useEffect)(() => {
		let e = O.current;
		if (!e) return;
		if (k.current = document.activeElement instanceof HTMLElement ? document.activeElement : null, h) try {
			let t = e.querySelector(h);
			if (t) return t.focus(), () => {
				k.current?.focus(), k.current = null;
			};
		} catch {}
		let t = s$9(e);
		return t.length > 0 ? t[0].focus() : e.focus(), () => {
			k.current?.focus(), k.current = null;
		};
	}, [h]), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: B,
		role: "presentation",
		onClick: (e) => {
			!p || e.target !== e.currentTarget || f?.();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			ref: (e) => {
				if (O.current = e, typeof D == "function") {
					D(e);
					return;
				}
				D && (D.current = e);
			},
			className: V,
			role: g,
			"aria-modal": "true",
			"aria-labelledby": R,
			"aria-describedby": z,
			tabIndex: w ?? -1,
			onKeyDown: (e) => {
				if (C?.(e), e.defaultPrevented) return;
				if (e.key === "Escape" && m) {
					e.preventDefault(), f?.();
					return;
				}
				if (e.key !== "Tab" || !O.current) return;
				let t = s$9(O.current);
				if (t.length === 0) {
					e.preventDefault(), O.current.focus();
					return;
				}
				let n = document.activeElement, r = t[0], i = t[t.length - 1];
				if (e.shiftKey) {
					(!n || n === r || !O.current.contains(n)) && (e.preventDefault(), i.focus());
					return;
				}
				(!n || n === i || !O.current.contains(n)) && (e.preventDefault(), r.focus());
			},
			...E,
			children: [
				I ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: H,
					children: c ?? (P ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "nabs-ui-dialog__title",
						id: A,
						children: e
					}) : null)
				}) : null,
				F ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: j,
					className: U,
					children: o
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: W,
					children: T
				}),
				L ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: G,
					children: l
				}) : null
			]
		})
	});
});
c.displayName = "Dialog";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-dropdownlist/dist/nabs-ui-dropdownlist.js
function i$16(e) {
	return e.label ?? e.children ?? e.value;
}
function a$14(e, t) {
	return e.value || `item-${t}`;
}
function o$8(e, t, n) {
	return e || t === null || n === null;
}
var s = (0, import_react.forwardRef)(function({ items: e = [], value: s, defaultValue: c, allowNull: l = !1, nullLabel: u = "None", className: d = "", onChange: f, onValueChange: p, id: m, disabled: h, ...g }, _) {
	let v = (0, import_react.useId)(), y = m ?? `nabs-ui-dropdownlist-${v.replace(/:/g, "")}`, b = [
		"nabs-ui-dropdownlist",
		h ? "nabs-ui-dropdownlist--disabled" : "",
		d
	].filter(Boolean).join(" "), x = o$8(l, s, c);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		ref: _,
		id: y,
		className: b,
		disabled: h,
		value: s ?? void 0,
		defaultValue: c ?? void 0,
		onChange: (e) => {
			let t = e.target.value === "" ? null : e.target.value;
			p?.(t, e), f?.(e);
		},
		...g,
		children: [x ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			disabled: !l,
			children: u
		}) : null, e.map((e, t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: e.value,
			disabled: e.disabled,
			children: i$16(e)
		}, a$14(e, t)))]
	});
});
s.displayName = "DropdownList";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-dropdownmenu/dist/nabs-ui-dropdownmenu.js
function l$7(e) {
	return !!(e && "type" in e && e.type === "divider");
}
function u$6(e) {
	return e.label ?? e.children ?? "Menu item";
}
function d$5(e, t) {
	return e.value ?? e.label ?? `item-${t}`;
}
function f({ label: f = "Menu", triggerContent: p, triggerAriaLabel: m, menuAlign: h = "start", items: g = [], className: _ = "", triggerClassName: v = "", menuClassName: y = "", itemClassName: b = "", dividerClassName: x = "", id: S, onItemSelect: C, ...w }) {
	let [T, E] = (0, import_react.useState)(!1), D = (0, import_react.useRef)(null), O = (0, import_react.useRef)(null), k = (0, import_react.useRef)(null), A = (0, import_react.useId)(), j = S ?? `nabs-ui-dropdownmenu-${A.replace(/:/g, "")}`, M = ["nabs-ui-dropdownmenu", _].filter(Boolean).join(" "), N = ["nabs-ui-dropdownmenu__trigger", v].filter(Boolean).join(" "), P = ["nabs-ui-dropdownmenu__menu", y].filter(Boolean).join(" "), F = ["nabs-ui-dropdownmenu__item", b].filter(Boolean).join(" "), I = ["nabs-ui-dropdownmenu__divider", x].filter(Boolean).join(" ");
	(0, import_react.useEffect)(() => {
		let e = (e) => {
			e.target instanceof Node && D.current && !D.current.contains(e.target) && k.current && !k.current.contains(e.target) && E(!1);
		}, t = (e) => {
			e.key === "Escape" && E(!1);
		};
		return document.addEventListener("pointerdown", e), document.addEventListener("keydown", t), () => {
			document.removeEventListener("pointerdown", e), document.removeEventListener("keydown", t);
		};
	}, []), (0, import_react.useLayoutEffect)(() => {
		if (!T || !O.current) return;
		let e = () => {
			let e = O.current?.getBoundingClientRect(), t = k.current?.getBoundingClientRect(), n = k.current;
			if (!e || !t || !n) return;
			let r = Math.max(e.width, t.width), i = window.innerWidth - r - 8, a = h === "end" ? e.right - r : e.left, o = Math.max(8, Math.min(a, i)), s = Math.max(8, e.bottom + 10);
			n.style.position = "fixed", n.style.top = `${s}px`, n.style.left = `${o}px`, n.style.right = "auto", n.style.minWidth = `${r}px`, n.style.visibility = "visible";
		};
		return k.current && (k.current.style.visibility = "hidden"), e(), window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0);
		};
	}, [h, T]);
	let L = (e, t) => {
		if (E(!1), e.disabled) {
			t.preventDefault();
			return;
		}
		C?.(e, t), e.onSelect?.(e, t);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: D,
		className: M,
		...w,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			ref: O,
			type: "button",
			className: N,
			"aria-haspopup": "menu",
			"aria-controls": j,
			"aria-label": m ?? f,
			onClick: () => E((e) => !e),
			children: p ?? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-dropdownmenu__triggerLabel",
				children: f
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-dropdownmenu__triggerChevron",
				"aria-hidden": "true",
				children: "▾"
			})] })
		}), T && typeof document < "u" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: k,
			id: j,
			className: P,
			"aria-label": f,
			children: g.map((e, t) => {
				if (l$7(e)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: I,
					role: "separator",
					"aria-hidden": "true"
				}, `divider-${t}`);
				let n = u$6(e), r = [
					F,
					e.disabled ? "nabs-ui-dropdownmenu__item--disabled" : "",
					e.danger ? "nabs-ui-dropdownmenu__item--danger" : ""
				].filter(Boolean).join(" "), i = {
					className: r,
					"aria-disabled": e.disabled || void 0
				};
				return e.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					...i,
					href: e.disabled ? void 0 : e.href,
					onClick: (t) => L(e, t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemLabel",
						children: n
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemDescription",
						children: e.description
					}) : null]
				}, d$5(e, t)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: r,
					disabled: e.disabled,
					onClick: (t) => L(e, t),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemLabel",
						children: n
					}), e.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-dropdownmenu__itemDescription",
						children: e.description
					}) : null]
				}, d$5(e, t));
			})
		}), document.body) : null]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-dynamicform/dist/nabs-ui-dynamicform.js
var o$6 = {
	right: "nabs-ui-checkbox--label-right",
	left: "nabs-ui-checkbox--label-left",
	top: "nabs-ui-checkbox--label-top",
	bottom: "nabs-ui-checkbox--label-bottom"
};
var s$7 = (0, import_react.forwardRef)(function({ label: e = "Checkbox", labelPosition: t = "right", className: r = "", inputClassName: s = "", labelClassName: c = "", id: l, disabled: u, ...d }, f) {
	let p = (0, import_react.useId)(), m = l ?? `nabs-ui-checkbox-${p.replace(/:/g, "")}`, h = [
		"nabs-ui-checkbox",
		u ? "nabs-ui-checkbox--disabled" : "",
		o$6[t] ?? o$6.right,
		r
	].filter(Boolean).join(" "), g = ["nabs-ui-checkbox__input", s].filter(Boolean).join(" "), _ = ["nabs-ui-checkbox__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: h,
		htmlFor: m,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: f,
			id: m,
			className: g,
			type: "checkbox",
			disabled: u,
			...d
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: _,
			children: e
		})]
	});
});
s$7.displayName = "Checkbox";
var c$7 = {
	right: "nabs-ui-radiobutton--label-right",
	left: "nabs-ui-radiobutton--label-left",
	top: "nabs-ui-radiobutton--label-top",
	bottom: "nabs-ui-radiobutton--label-bottom"
};
function l$6({ label: e = "Radio button", labelPosition: t = "right", className: r = "", inputClassName: o = "", labelClassName: s = "", id: l, ...u }) {
	let d = u.disabled === !0, f = (0, import_react.useId)(), p = l ?? `nabs-ui-radiobutton-${f.replace(/:/g, "")}`, m = [
		"nabs-ui-radiobutton",
		d ? "nabs-ui-radiobutton--disabled" : "",
		c$7[t] ?? c$7.right,
		r
	].filter(Boolean).join(" "), h = ["nabs-ui-radiobutton__input", o].filter(Boolean).join(" "), g = ["nabs-ui-radiobutton__label", s].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: m,
		htmlFor: p,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: p,
			className: h,
			type: "radio",
			...u
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: g,
			children: e
		})]
	});
}
var u$5 = (0, import_react.forwardRef)(({ label: e, className: t = "", inputClassName: r = "", labelClassName: o = "", id: s, rows: c = 4, resize: l = "vertical", ...u }, d) => {
	let f = (0, import_react.useId)(), p = s ?? `nabs-ui-textarea-${f.replace(/:/g, "")}`, m = ["nabs-ui-textarea", t].filter(Boolean).join(" "), h = ["nabs-ui-textarea__input", r].filter(Boolean).join(" "), g = ["nabs-ui-textarea__label", o].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: m,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: g,
			htmlFor: p,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			ref: d,
			id: p,
			className: h,
			rows: c,
			"data-resize": l,
			...u
		})]
	});
});
u$5.displayName = "Textarea";
var d$4 = {
	none: "",
	top: "nabs-ui-textbox--label-top",
	left: "nabs-ui-textbox--label-left"
};
var f$5 = (0, import_react.forwardRef)(({ label: e, labelPosition: t = "top", className: r = "", inputClassName: o = "", labelClassName: s = "", id: c, type: l = "text", ...u }, f) => {
	let p = (0, import_react.useId)(), m = c ?? `nabs-ui-textbox-${p.replace(/:/g, "")}`, h = [
		"nabs-ui-textbox",
		e ? d$4[t] ?? d$4.top : "",
		r
	].filter(Boolean).join(" "), g = ["nabs-ui-textbox__input", o].filter(Boolean).join(" "), _ = ["nabs-ui-textbox__label", s].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: h,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: _,
			htmlFor: m,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: f,
			id: m,
			className: g,
			type: l,
			...u
		})]
	});
});
f$5.displayName = "Textbox";
function p$5(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function m$4(e) {
	return !e || e.type !== "object" || !p$5(e.properties) ? {} : Object.fromEntries(Object.entries(e.properties).map(([e, t]) => [e, h$5(t)]));
}
function h$5(e) {
	if (!e || !p$5(e)) return "";
	if (e.default !== void 0) return e.default;
	if (Array.isArray(e.enum) && e.enum.length > 0) return e.enum[0];
	switch (e.type) {
		case "boolean": return !1;
		case "integer":
		case "number": return "";
		case "object": return m$4(e);
		default: return "";
	}
}
function g$4(e, t) {
	if (!e || !p$5(e)) return t;
	if (e.type === "object" && p$5(e.properties)) {
		let n = p$5(t) ? t : {};
		return Object.fromEntries(Object.entries(e.properties).map(([e, t]) => [e, g$4(t, n[e] === void 0 ? h$5(t) : n[e])]));
	}
	if (e.type === "boolean") return t === !0;
	if (e.type === "integer") {
		if (t === "" || t == null) return "";
		let e = Number.parseInt(String(t), 10);
		return Number.isNaN(e) ? "" : e;
	}
	if (e.type === "number") {
		if (t === "" || t == null) return "";
		let e = Number.parseFloat(String(t));
		return Number.isNaN(e) ? "" : e;
	}
	return t ?? "";
}
function _$4(e) {
	return !e || !p$5(e) ? "textbox" : Array.isArray(e.enum) && e.enum.length > 0 ? "radio" : e.type === "string" ? e.maxLength !== void 0 && e.maxLength > 50 ? "textarea" : "textbox" : e.type === "integer" ? "int" : e.type === "number" ? String(e.format ?? "").toLowerCase() === "decimal" ? "decimal" : "double" : e.type === "boolean" ? "bool" : "textbox";
}
var v$4 = {
	type: "object",
	properties: {}
};
function y$4({ schema: e, name: t, value: n, onChange: r }) {
	let o = e.title ?? t, c = e.description, d = _$4(e), p = n ?? h$5(e);
	if (d === "radio") {
		let n = Array.isArray(e.enum) ? e.enum : [];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
			className: "nabs-ui-dynamicform__fieldset",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "nabs-ui-dynamicform__legend",
					children: o
				}),
				c ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "nabs-ui-dynamicform__description",
					children: c
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nabs-ui-dynamicform__radioGroup",
					children: n.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(l$6, {
						label: String(e),
						name: t,
						checked: p === e,
						onChange: () => r(e)
					}, String(e)))
				})
			]
		});
	}
	return d === "textarea" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$5, {
		label: o,
		rows: 5,
		value: String(p ?? ""),
		placeholder: String(e.default ?? ""),
		onChange: (e) => r(e.target.value)
	}) : d === "bool" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s$7, {
		label: o,
		checked: p === !0,
		onChange: (e) => r(e.target.checked)
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f$5, {
		label: o,
		type: d === "int" || d === "decimal" || d === "double" ? "number" : "text",
		step: d === "int" ? 1 : d === "decimal" || d === "double" ? "any" : void 0,
		value: String(p ?? ""),
		placeholder: String(e.default ?? ""),
		onChange: (e) => {
			let t = e.target.value;
			if (d === "int") {
				r(t === "" ? "" : Number.parseInt(t, 10));
				return;
			}
			if (d === "decimal" || d === "double") {
				r(t === "" ? "" : Number.parseFloat(t));
				return;
			}
			r(t);
		}
	});
}
var b = (0, import_react.forwardRef)(function({ schema: e, value: o, onChange: s, className: c = "", id: l, disabled: u = !1, ...d }, f) {
	let h = (0, import_react.useId)(), _ = l ?? `nabs-ui-dynamicform-${h.replace(/:/g, "")}`, b = e && e.type === "object" ? e : v$4, [x, S] = (0, import_react.useState)(() => g$4(b, o ?? m$4(b)));
	(0, import_react.useEffect)(() => {
		S(g$4(b, o ?? m$4(b)));
	}, [b, o]);
	let C = p$5(x) ? x : {}, w = b.title ?? "Dynamic form", T = b.description, E = [
		"nabs-ui-dynamicform",
		u ? "nabs-ui-dynamicform--disabled" : "",
		c
	].filter(Boolean).join(" "), D = (e) => {
		S(e), s?.(e);
	};
	return u ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: f,
		id: _,
		className: E,
		"aria-disabled": "true",
		...d,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-dynamicform__header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__title",
				children: w
			}), T ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__description",
				children: T
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-dynamicform__fields",
			children: Object.entries(b.properties ?? {}).map(([e, t]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__field",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(y$4, {
					schema: t,
					name: e,
					value: C[e],
					onChange: (n) => D({
						...C,
						[e]: g$4(t, n)
					})
				})
			}, e))
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: f,
		id: _,
		className: E,
		...d,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-dynamicform__header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__title",
				children: w
			}), T ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__description",
				children: T
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-dynamicform__fields",
			children: Object.entries(b.properties ?? {}).map(([e, t]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-dynamicform__field",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(y$4, {
					schema: t,
					name: e,
					value: C[e],
					onChange: (n) => D({
						...C,
						[e]: g$4(t, n)
					})
				})
			}, e))
		})]
	});
});
b.displayName = "DynamicForm";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-fileupload/dist/nabs-ui-fileupload.js
function a$11(e) {
	return e ? (Array.isArray(e) ? e : String(e).split(",")).map((e) => e.trim().toLowerCase()).filter(Boolean).map((e) => e.startsWith(".") ? e : `.${e}`) : [];
}
function o$5(e, t) {
	let n = String(e).split(",").map((e) => e.trim().toLowerCase()).filter(Boolean), r = a$11(t);
	return [.../* @__PURE__ */ new Set([...n, ...r])];
}
function s$6(e, t) {
	let n = e.name.toLowerCase(), r = (e.type ?? "").toLowerCase();
	return t === "*/*" ? !0 : t.endsWith("/*") ? r.startsWith(t.slice(0, -1)) : t.startsWith(".") ? n.endsWith(t) : r === t;
}
function c$6(e, t) {
	if (t.length === 0) return {
		acceptedFiles: e,
		rejectedFiles: []
	};
	let n = [], r = [];
	for (let i of e) (t.some((e) => s$6(i, e)) ? n : r).push(i);
	return {
		acceptedFiles: n,
		rejectedFiles: r
	};
}
function l({ label: a = "Drop files here or click Browse files", description: s = "Drag and drop files into the drop zone or choose them manually.", accept: l = "", extensions: u = [], multiple: d = !0, disabled: f = !1, className: p = "", surfaceClassName: m = "", labelClassName: h = "", descriptionClassName: g = "", buttonClassName: _ = "", inputClassName: v = "", id: y, onFilesSelected: b, ...x }) {
	let S = (0, import_react.useId)(), C = y ?? `nabs-ui-fileupload-${S.replace(/:/g, "")}`, w = (0, import_react.useRef)(null), [T, E] = (0, import_react.useState)(!1), D = o$5(l, u), O = D.length > 0 ? D.join(",") : void 0, k = [
		"nabs-ui-fileupload",
		f ? "nabs-ui-fileupload--disabled" : "",
		T ? "nabs-ui-fileupload--drag-over" : "",
		p
	].filter(Boolean).join(" "), A = ["nabs-ui-fileupload__surface", m].filter(Boolean).join(" "), j = ["nabs-ui-fileupload__label", h].filter(Boolean).join(" "), M = ["nabs-ui-fileupload__description", g].filter(Boolean).join(" "), N = ["nabs-ui-fileupload__button", _].filter(Boolean).join(" "), P = ["nabs-ui-fileupload__input", v].filter(Boolean).join(" "), F = (e, t) => {
		let { acceptedFiles: n, rejectedFiles: r } = c$6(Array.from(e ?? []), D);
		b?.({
			acceptedFiles: n,
			rejectedFiles: r,
			source: t
		});
	}, I = () => {
		f || w.current?.click();
	}, L = (e) => {
		F(e.target.files, "input"), e.target.value = "";
	}, R = (e) => {
		e.preventDefault(), f || E(!0);
	}, z = (e) => {
		e.preventDefault(), e.currentTarget === e.target && E(!1);
	}, B = (e) => {
		e.preventDefault(), E(!1), !f && F(e.dataTransfer.files, "drop");
	}, V = (e) => {
		(e.key === "Enter" || e.key === " ") && (e.preventDefault(), I());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: k,
		...x,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: A,
			role: "button",
			tabIndex: f ? -1 : 0,
			"aria-label": a,
			"data-disabled": f ? "true" : void 0,
			onClick: I,
			onKeyDown: V,
			onDragOver: R,
			onDragLeave: z,
			onDrop: B,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: w,
					id: C,
					className: P,
					type: "file",
					accept: O,
					multiple: d,
					disabled: f,
					"aria-label": a,
					title: a,
					onChange: L
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nabs-ui-fileupload__content",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: j,
							children: a
						}),
						s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: M,
							children: s
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "nabs-ui-fileupload__meta",
							children: [D.length > 0 ? `Accepted: ${D.join(", ")}` : "Accepted: all files", d ? " • multiple files" : " • single file"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: N,
					disabled: f,
					onClick: (e) => {
						e.stopPropagation(), I();
					},
					children: "Browse files"
				})
			]
		})
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-graph/dist/nabs-ui-graph.js
function c$1({ toolboxLabel: e, toolsets: t, isCollapsed: n, isEdgeToolEnabled: r, edgeHint: i, activeToolIdsBySet: a, onToggleCollapse: c, onToolClick: l, onToolDoubleClick: u }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "nabs-ui-graph__toolbox",
		role: "toolbar",
		"aria-label": e,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "nabs-ui-graph__toolboxToggle",
			onClick: c,
			"aria-label": n ? "Expand toolbox" : "Collapse toolbox",
			title: n ? "Expand toolbox" : "Collapse toolbox",
			children: n ? ">" : "<"
		}), !n && t.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-graph__toolset",
			"data-toolset": e.id,
			children: [e.label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-graph__toolsetTitle",
				children: e.label
			}), e.tools.map((t) => {
				let n = a[e.id] === t.id, c = t.kind === "edge", d = c && !r, f = t.iconClassName ?? `nabs-ui-graph__toolIcon--${t.id}`;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: [
						"nabs-ui-graph__tool",
						n ? "nabs-ui-graph__tool--active" : "",
						d ? "nabs-ui-graph__tool--disabled" : ""
					].filter(Boolean).join(" "),
					disabled: d,
					onClick: () => l(t, e.id),
					onDoubleClick: () => u(t, e.id),
					"data-active": n ? "true" : "false",
					"data-tool": t.id,
					title: c ? i : t.label,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: ["nabs-ui-graph__toolIcon", f].join(" "),
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-graph__toolLabel",
						children: t.label
					})]
				}, t.id);
			})]
		}, e.id))]
	});
}
var l$2 = {
	id: "simple-graph-toolset",
	label: "Simple Graph Toolset",
	tools: [
		{
			id: "square",
			label: "Square",
			kind: "node",
			nodeType: "square"
		},
		{
			id: "circle",
			label: "Circle",
			kind: "node",
			nodeType: "circle"
		},
		{
			id: "rectangle",
			label: "Rectangle",
			kind: "node",
			nodeType: "rectangle"
		},
		{
			id: "hexagon",
			label: "Hexagon",
			kind: "node",
			nodeType: "hexagon"
		},
		{
			id: "edge",
			label: "Edge",
			kind: "edge"
		}
	]
};
var u$1 = [l$2];
var d = {
	id: "agentic-workflow-toolset",
	label: "Agentic Workflow",
	tools: [
		{
			id: "initiative",
			label: "Initiative",
			kind: "node",
			nodeType: "initiative"
		},
		{
			id: "scenario",
			label: "Scenario",
			kind: "node",
			nodeType: "scenario"
		},
		{
			id: "lifecycle",
			label: "Lifecycle",
			kind: "node",
			nodeType: "lifecycle"
		},
		{
			id: "context",
			label: "Context",
			kind: "node",
			nodeType: "context"
		},
		{
			id: "connector",
			label: "Connector",
			kind: "edge",
			iconClassName: "nabs-ui-graph__toolIcon--edge"
		}
	]
};
var f$1 = [d];
var p$4 = {
	square: "Square",
	circle: "Circle",
	rectangle: "Rectangle",
	hexagon: "Hexagon",
	initiative: "Initiative",
	scenario: "Scenario",
	lifecycle: "Lifecycle",
	context: "Context",
	edge: "Edge"
};
var m$3 = {
	square: {
		width: 100,
		height: 100
	},
	circle: {
		width: 100,
		height: 100
	},
	rectangle: {
		width: 140,
		height: 90
	},
	hexagon: {
		width: 120,
		height: 104
	},
	initiative: {
		width: 180,
		height: 110
	},
	scenario: {
		width: 190,
		height: 100
	},
	lifecycle: {
		width: 126,
		height: 126
	},
	context: {
		width: 190,
		height: 124
	}
};
var h$4 = {
	simple: "square",
	"agentic-workflow": "initiative"
};
var g$3 = .5;
var _$3 = 2.5;
var v$3 = {
	"initiative->initiative": "Extend",
	"initiative->scenario": "ResultIn",
	"scenario->lifecycle": "Use",
	"context->lifecycle": "UsedBy"
};
var y$3 = () => typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(16).slice(2)}`;
var ee$1 = (e, t, n) => Math.min(n, Math.max(t, e));
var b$4 = (e, t) => v$3[`${e}->${t}`] ?? null;
var x$2 = (e, t, n, r) => {
	let i = e.find((e) => e.id === n), a = e.find((e) => e.id === r);
	if (!i || !a) return {
		allowed: !1,
		label: null
	};
	let o = b$4(i.type, a.type);
	if (!o || i.type === "scenario" && a.type === "lifecycle" && t.some((t) => t.fromId === n ? e.find((e) => e.id === t.toId)?.type === "lifecycle" : !1)) return {
		allowed: !1,
		label: null
	};
	if (i.type === "initiative" && a.type === "initiative") {
		if (t.some((t) => t.toId === r ? e.find((e) => e.id === t.fromId)?.type === "initiative" : !1)) return {
			allowed: !1,
			label: null
		};
		let i = /* @__PURE__ */ new Map();
		for (let n of t) {
			let t = e.find((e) => e.id === n.fromId), r = e.find((e) => e.id === n.toId);
			if (t?.type !== "initiative" || r?.type !== "initiative") continue;
			let a = i.get(n.fromId) ?? [];
			a.push(n.toId), i.set(n.fromId, a);
		}
		if (((e, t) => {
			let n = [e], r = /* @__PURE__ */ new Set();
			for (; n.length > 0;) {
				let e = n.pop();
				if (!e || r.has(e)) continue;
				if (e === t) return !0;
				r.add(e);
				let a = i.get(e) ?? [];
				for (let e of a) n.push(e);
			}
			return !1;
		})(r, n)) return {
			allowed: !1,
			label: null
		};
	}
	return {
		allowed: !0,
		label: o
	};
};
var te$1 = (e, t, n = 4) => {
	let r = e.trim().replace(/\s+/g, " ");
	if (!r) return [""];
	let i = Math.max(9, Math.floor((t - 16) / 6.4)), a = r.split(" "), o = [], s = "";
	for (let e of a) {
		let t = e;
		for (; t.length > i;) {
			let e = t.slice(0, i - 1) + "-";
			if (t = t.slice(i - 1), s.length > 0 && (o.push(s), s = ""), o.push(e), o.length >= n) {
				let e = o.slice(0, n);
				return e[n - 1] = `${e[n - 1].slice(0, Math.max(1, i - 1))}…`, e;
			}
		}
		let r = s.length > 0 ? `${s} ${t}` : t;
		if (r.length <= i) {
			s = r;
			continue;
		}
		if (s.length > 0 && o.push(s), s = t, o.length >= n) break;
	}
	if (s.length > 0 && o.length < n && o.push(s), o.length <= n) return o;
	let c = o.slice(0, n);
	return c[n - 1] = `${c[n - 1].slice(0, Math.max(1, i - 1))}…`, c;
};
var S = (0, import_react.forwardRef)(function({ className: e, toolboxLabel: l = "Tools", toolset: d = "simple", toolsets: v, ToolboxComponent: b = c$1, onShapeAdd: S, onShapeMove: C, ...ne }, w) {
	let T = d, E = !!(v && v.length > 0), D = h$4[T], O = !E && T === "agentic-workflow", k = (0, import_react.useMemo)(() => v && v.length > 0 ? v : T === "agentic-workflow" ? f$1 : u$1, [T, v]), A = (0, import_react.useRef)(null), [j, M] = (0, import_react.useState)([]), [N, P] = (0, import_react.useState)([]), [F, I] = (0, import_react.useState)(D), [re, L] = (0, import_react.useState)({}), [R, ie] = (0, import_react.useState)(!1), [z, B] = (0, import_react.useState)(null), [V, H] = (0, import_react.useState)(null), [U, W] = (0, import_react.useState)(null), [G, K] = (0, import_react.useState)(null), [q, J] = (0, import_react.useState)({
		scale: 1,
		offsetX: 0,
		offsetY: 0
	}), Y = (0, import_react.useRef)(q);
	(0, import_react.useEffect)(() => {
		Y.current = q;
	}, [q]), (0, import_react.useEffect)(() => {
		L((e) => {
			let t = {};
			for (let n of k) t[n.id] = e[n.id] ?? null;
			return t;
		});
	}, [k]), (0, import_react.useEffect)(() => {
		let e = /* @__PURE__ */ new Set(["edge"]);
		for (let t of k) for (let n of t.tools) n.kind === "node" && n.nodeType && e.add(n.nodeType);
		I((t) => e.has(t) ? t : D);
	}, [D, k]);
	let ae = (0, import_react.useMemo)(() => `translate(${q.offsetX}, ${q.offsetY}) scale(${q.scale})`, [q]), X = (0, import_react.useCallback)((e, t, n) => {
		let { scale: r, offsetX: i, offsetY: a } = Y.current;
		return {
			x: (e - n.left - i) / r,
			y: (t - n.top - a) / r
		};
	}, []), Z = (0, import_react.useCallback)((e, t) => {
		let n = A.current?.getBoundingClientRect();
		if (!n) return;
		let r = m$3[e], i = X(n.left + n.width / 2, n.top + n.height / 2, n);
		M((n) => {
			let a = {
				id: y$3(),
				type: e,
				label: `${t ?? p$4[e]} ${n.length + 1}`,
				width: r.width,
				height: r.height,
				x: i.x - r.width / 2,
				y: i.y - r.height / 2,
				createdAt: Date.now()
			}, o = [...n, a];
			return S?.(a), B(a.id), o;
		});
	}, [S, X]), Q = (0, import_react.useCallback)((e, t) => {
		e !== t && P((n) => {
			if (O ? n.some((n) => n.fromId === e && n.toId === t) : n.some((n) => n.fromId === e && n.toId === t || n.fromId === t && n.toId === e)) return n;
			let r = `Edge ${n.length + 1}`;
			if (O) {
				let i = x$2(j, n, e, t);
				if (!i.allowed || !i.label) return n;
				r = i.label;
			}
			return [...n, {
				id: y$3(),
				fromId: e,
				toId: t,
				label: r,
				createdAt: Date.now()
			}];
		});
	}, [O, j]), oe = (0, import_react.useCallback)((e, t) => {
		if (L((n) => ({
			...n,
			[t]: e.id
		})), e.kind === "edge") {
			if (!z) return;
			I("edge"), H(z);
			return;
		}
		e.nodeType && (I(e.nodeType), H(null));
	}, [z]), se = (0, import_react.useCallback)((e, t) => {
		e.kind !== "edge" && e.nodeType && (L((n) => ({
			...n,
			[t]: e.id
		})), I(e.nodeType), H(null), Z(e.nodeType, e.label));
	}, [Z]), ce = (0, import_react.useCallback)(() => {
		ie((e) => !e);
	}, []), $ = (0, import_react.useCallback)((e, t) => {
		if (e.preventDefault(), e.stopPropagation(), B(t), F === "edge") {
			V && V !== t && (Q(V, t), H(null), I(D));
			return;
		}
		let n = A.current?.getBoundingClientRect(), r = j.find((e) => e.id === t);
		if (!n || !r) return;
		let { x: i, y: a } = X(e.clientX, e.clientY, n);
		W({
			id: t,
			offsetX: i - r.x,
			offsetY: a - r.y,
			pointerId: e.pointerId
		});
	}, [
		F,
		Q,
		D,
		V,
		j,
		X
	]), le = (0, import_react.useCallback)((e) => {
		if (e.button !== 0) return;
		B(null), F === "edge" && (H(null), I(D));
		let t = e.pointerId;
		e.currentTarget.setPointerCapture(t), K({
			pointerId: t,
			startX: e.clientX,
			startY: e.clientY,
			startOffsetX: q.offsetX,
			startOffsetY: q.offsetY
		});
	}, [
		F,
		D,
		q
	]), ue = (0, import_react.useCallback)((e) => {
		e.preventDefault();
		let t = A.current?.getBoundingClientRect();
		if (!t) return;
		let n = e.clientX - t.left, r = e.clientY - t.top, i = -e.deltaY * .0015;
		J((e) => {
			let t = ee$1(e.scale + i, g$3, _$3);
			if (t === e.scale) return e;
			let a = (n - e.offsetX) / e.scale, o = (r - e.offsetY) / e.scale;
			return {
				scale: t,
				offsetX: n - a * t,
				offsetY: r - o * t
			};
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!U) return;
		let e = (e) => {
			if (e.pointerId !== U.pointerId) return;
			let t = A.current?.getBoundingClientRect();
			t && M((n) => n.map((n) => {
				if (n.id !== U.id) return n;
				let { x: r, y: i } = X(e.clientX, e.clientY, t), a = {
					...n,
					x: r - U.offsetX,
					y: i - U.offsetY
				};
				return C?.(a), a;
			}));
		}, t = (e) => {
			e.pointerId === U.pointerId && W(null);
		};
		return document.addEventListener("pointermove", e), document.addEventListener("pointerup", t), () => {
			document.removeEventListener("pointermove", e), document.removeEventListener("pointerup", t);
		};
	}, [
		U,
		C,
		X
	]), (0, import_react.useEffect)(() => {
		if (!G) return;
		let e = (e) => {
			if (e.pointerId !== G.pointerId) return;
			let t = e.clientX - G.startX, n = e.clientY - G.startY;
			J((e) => ({
				...e,
				offsetX: G.startOffsetX + t,
				offsetY: G.startOffsetY + n
			}));
		}, t = (e) => {
			e.pointerId === G.pointerId && (A.current?.releasePointerCapture(G.pointerId), K(null));
		};
		return document.addEventListener("pointermove", e), document.addEventListener("pointerup", t), () => {
			document.removeEventListener("pointermove", e), document.removeEventListener("pointerup", t);
		};
	}, [G]);
	let de = [
		"nabs-ui-graph",
		R ? "nabs-ui-graph--toolbox-collapsed" : "",
		e
	].filter(Boolean).join(" "), fe = z !== null, pe = F === "edge" && V ? "Select another node" : "Select node first";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: w,
		className: de,
		...ne,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-graph__canvas",
			ref: A,
			onPointerDown: le,
			onWheel: ue,
			role: "presentation",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				className: "nabs-ui-graph__canvasSvg",
				role: "presentation",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					className: "nabs-ui-graph__viewport",
					transform: ae,
					children: [N.map((e) => {
						let t = j.find((t) => t.id === e.fromId), n = j.find((t) => t.id === e.toId);
						if (!t || !n) return null;
						let r = (t.x + t.width / 2 + (n.x + n.width / 2)) / 2, i = (t.y + t.height / 2 + (n.y + n.height / 2)) / 2;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							className: "nabs-ui-graph__edge",
							x1: t.x + t.width / 2,
							y1: t.y + t.height / 2,
							x2: n.x + n.width / 2,
							y2: n.y + n.height / 2
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							className: "nabs-ui-graph__edgeLabel",
							x: r,
							y: i - 6,
							children: e.label
						})] }, e.id);
					}), j.map((e) => {
						let t = te$1(e.label, e.width), n = e.x + e.width / 2, r = e.y + e.height / 2 - (t.length - 1) * 12 / 2, i = {
							className: [
								"nabs-ui-graph__shape",
								e.type === "circle" && "nabs-ui-graph__shape--circle",
								e.type === "rectangle" && "nabs-ui-graph__shape--rectangle",
								e.type === "hexagon" && "nabs-ui-graph__shape--hexagon",
								e.type === "initiative" && "nabs-ui-graph__shape--initiative",
								e.type === "scenario" && "nabs-ui-graph__shape--scenario",
								e.type === "lifecycle" && "nabs-ui-graph__shape--lifecycle",
								e.type === "context" && "nabs-ui-graph__shape--context",
								z === e.id && "nabs-ui-graph__shape--selected"
							].filter(Boolean).join(" "),
							onPointerDown: (t) => $(t, e.id),
							role: "presentation",
							"aria-hidden": !0
						};
						if (e.type === "circle") {
							let a = e.width / 2, c = e.x + a, l = e.y + a;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								...i,
								cx: c,
								cy: l,
								r: a
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								className: "nabs-ui-graph__nodeLabel",
								x: n,
								y: r,
								children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
									x: n,
									dy: r === 0 ? 0 : 12,
									children: t
								}, `${e.id}-line-${r}`))
							})] }, e.id);
						}
						if (e.type === "scenario") {
							let a = Math.min(26, Math.round(e.width * .16)), c = [
								`${e.x + a},${e.y}`,
								`${e.x + e.width},${e.y}`,
								`${e.x + e.width - a},${e.y + e.height}`,
								`${e.x},${e.y + e.height}`
							].join(" ");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								...i,
								points: c
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								className: "nabs-ui-graph__nodeLabel",
								x: n,
								y: r,
								children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
									x: n,
									dy: r === 0 ? 0 : 12,
									children: t
								}, `${e.id}-line-${r}`))
							})] }, e.id);
						}
						if (e.type === "context") {
							let a = Math.min(24, Math.round(e.width * .14)), c = e.y + e.height - 9, l = [
								`M ${e.x} ${e.y}`,
								`H ${e.x + e.width - a}`,
								`L ${e.x + e.width} ${e.y + a}`,
								`V ${c}`,
								`Q ${e.x + e.width * .76} ${e.y + e.height + 9} ${e.x + e.width * .5} ${c}`,
								`Q ${e.x + e.width * .24} ${e.y + e.height - 18} ${e.x} ${c}`,
								"Z"
							].join(" ");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								...i,
								d: l
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								className: "nabs-ui-graph__nodeLabel",
								x: n,
								y: r,
								children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
									x: n,
									dy: r === 0 ? 0 : 12,
									children: t
								}, `${e.id}-line-${r}`))
							})] }, e.id);
						}
						if (e.type === "hexagon") {
							let a = [
								`${e.x + e.width * .25},${e.y}`,
								`${e.x + e.width * .75},${e.y}`,
								`${e.x + e.width},${e.y + e.height * .5}`,
								`${e.x + e.width * .75},${e.y + e.height}`,
								`${e.x + e.width * .25},${e.y + e.height}`,
								`${e.x},${e.y + e.height * .5}`
							].join(" ");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								...i,
								points: a
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								className: "nabs-ui-graph__nodeLabel",
								x: n,
								y: r,
								children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
									x: n,
									dy: r === 0 ? 0 : 12,
									children: t
								}, `${e.id}-line-${r}`))
							})] }, e.id);
						}
						let a = e.type === "rectangle" || e.type === "initiative" ? 14 : 4;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							...i,
							x: e.x,
							y: e.y,
							width: e.width,
							height: e.height,
							rx: a
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							className: "nabs-ui-graph__nodeLabel",
							x: n,
							y: r,
							children: t.map((t, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tspan", {
								x: n,
								dy: r === 0 ? 0 : 12,
								children: t
							}, `${e.id}-line-${r}`))
						})] }, e.id);
					})]
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(b, {
			toolboxLabel: l,
			toolsets: k,
			isCollapsed: R,
			isEdgeToolEnabled: fe,
			edgeHint: pe,
			activeToolIdsBySet: re,
			onToggleCollapse: ce,
			onToolClick: oe,
			onToolDoubleClick: se
		})]
	});
});
//#endregion
//#region node_modules/@net-advantage/nabs-ui-grid/dist/nabs-ui-grid.js
var l$5 = {
	primary: "nabs-ui-button--primary",
	secondary: "nabs-ui-button--secondary",
	ghost: "nabs-ui-button--ghost"
};
var u$4 = (0, import_react.forwardRef)(function({ children: e, className: t = "", variant: n = "primary", type: r = "button", ...i }, a) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref: a,
		className: [
			"nabs-ui-button",
			l$5[n] ?? l$5.primary,
			t
		].filter(Boolean).join(" "),
		type: r,
		...i,
		children: e
	});
});
u$4.displayName = "Button";
var d$3 = "a[href], area[href], button:not([disabled]), input:not([disabled]):not([type=\"hidden\"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex=\"-1\"])";
function f$4(e) {
	return Array.from(e.querySelectorAll(d$3)).filter((e) => !e.hasAttribute("disabled") && e.getAttribute("aria-hidden") !== "true");
}
var p$3 = (0, import_react.forwardRef)(function({ title: e, description: r, header: a, footer: o, showHeader: l = !0, showFooter: u = !0, onRequestClose: d, closeOnBackdropClick: p = !0, closeOnEscape: ee = !0, initialFocusSelector: m, dialogRole: h = "dialog", className: g = "", backdropClassName: _ = "", headerClassName: v = "", descriptionClassName: te = "", contentClassName: y = "", footerClassName: b = "", onKeyDown: x, tabIndex: ne, children: re, ...ie }, ae) {
	let S = (0, import_react.useRef)(null), C = (0, import_react.useRef)(null), oe = `nabs-ui-dialog-title-${(0, import_react.useId)().replace(/:/g, "")}`, se = `nabs-ui-dialog-description-${(0, import_react.useId)().replace(/:/g, "")}`, w = ie["aria-labelledby"], ce = ie["aria-describedby"], T = !a && !!e, E = !!r, le = l && (!!a || T), ue = u && o != null, de = w ?? (T ? oe : void 0), D = ce ?? (E ? se : void 0), fe = ["nabs-ui-dialog__backdrop", _].filter(Boolean).join(" "), pe = ["nabs-ui-dialog", g].filter(Boolean).join(" "), me = ["nabs-ui-dialog__header", v].filter(Boolean).join(" "), he = ["nabs-ui-dialog__description", te].filter(Boolean).join(" "), ge = ["nabs-ui-dialog__content", y].filter(Boolean).join(" "), _e = ["nabs-ui-dialog__footer", b].filter(Boolean).join(" ");
	return (0, import_react.useEffect)(() => {
		let e = S.current;
		if (!e) return;
		if (C.current = document.activeElement instanceof HTMLElement ? document.activeElement : null, m) try {
			let t = e.querySelector(m);
			if (t) return t.focus(), () => {
				C.current?.focus(), C.current = null;
			};
		} catch {}
		let t = f$4(e);
		return t.length > 0 ? t[0].focus() : e.focus(), () => {
			C.current?.focus(), C.current = null;
		};
	}, [m]), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: fe,
		role: "presentation",
		onClick: (e) => {
			!p || e.target !== e.currentTarget || d?.();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			ref: (e) => {
				if (S.current = e, typeof ae == "function") {
					ae(e);
					return;
				}
				ae && (ae.current = e);
			},
			className: pe,
			role: h,
			"aria-modal": "true",
			"aria-labelledby": de,
			"aria-describedby": D,
			tabIndex: ne ?? -1,
			onKeyDown: (e) => {
				if (x?.(e), e.defaultPrevented) return;
				if (e.key === "Escape" && ee) {
					e.preventDefault(), d?.();
					return;
				}
				if (e.key !== "Tab" || !S.current) return;
				let t = f$4(S.current);
				if (t.length === 0) {
					e.preventDefault(), S.current.focus();
					return;
				}
				let n = document.activeElement, r = t[0], i = t[t.length - 1];
				if (e.shiftKey) {
					(!n || n === r || !S.current.contains(n)) && (e.preventDefault(), i.focus());
					return;
				}
				(!n || n === i || !S.current.contains(n)) && (e.preventDefault(), r.focus());
			},
			...ie,
			children: [
				le ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: me,
					children: a ?? (T ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "nabs-ui-dialog__title",
						id: oe,
						children: e
					}) : null)
				}) : null,
				E ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: se,
					className: he,
					children: r
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: ge,
					children: re
				}),
				ue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: _e,
					children: o
				}) : null
			]
		})
	});
});
p$3.displayName = "Dialog";
var ee = async (e) => {
	let t = await fetch(e);
	if (!t.ok) throw Error(`Failed request for ${e}: ${t.status}`);
	return t.json();
};
function m$2(e) {
	if (!e || !Array.isArray(e.columns)) return {
		idField: "id",
		pageSize: 10,
		pageSizeOptions: [
			10,
			20,
			50
		],
		selectionMode: "multiple",
		columns: []
	};
	let t = e.columns.map((e) => ({
		type: "string",
		sortable: !0,
		filterable: !0,
		groupable: !1,
		editable: !1,
		aggregate: "none",
		format: "plain",
		...e
	}));
	return {
		idField: e.idField ?? "id",
		pageSize: e.pageSize ?? 10,
		pageSizeOptions: e.pageSizeOptions?.length ? e.pageSizeOptions : [
			10,
			20,
			50
		],
		selectionMode: e.selectionMode ?? "multiple",
		defaultGroupBy: e.defaultGroupBy,
		defaultSort: e.defaultSort,
		footer: {
			showColumnAggregates: e.footer?.showColumnAggregates ?? !0,
			rowAggregates: e.footer?.rowAggregates?.length ? e.footer.rowAggregates : [
				"filteredRows",
				"pagedRows",
				"selectedRows",
				"groupCount"
			]
		},
		columns: t
	};
}
function h$3(e, t) {
	return t === "date" ? "date" : t === "date-time" ? "datetime" : e === "number" || e === "integer" ? "number" : e === "boolean" ? "boolean" : "string";
}
function g$2(e) {
	return e === "date" ? "date" : e === "date-time" ? "datetime" : e === "currency" ? "currency" : e === "percent" ? "percent" : "plain";
}
function _$2(e) {
	if (e?.length) return e.map((e) => ({
		label: e === null ? "(empty)" : String(e),
		value: e
	}));
}
function v$2(e) {
	if (!e?.properties) return m$2(void 0);
	let t = new Set(e.required ?? []), n = e["x-grid"], r = Object.entries(e.properties).map(([e, n]) => {
		let r = n["x-grid"], i = h$3(n.type, n.format), a = g$2(n.format), o = r?.editor ?? (i === "boolean" ? "checkbox" : i === "number" ? "number" : i === "date" ? "date" : void 0);
		return {
			key: r?.key ?? e,
			label: n.title ?? e,
			type: i,
			sortable: r?.sortable ?? !0,
			filterable: r?.filterable ?? !0,
			groupable: r?.groupable ?? !1,
			editable: r?.editable ?? t.has(e),
			editor: o,
			aggregate: r?.aggregate ?? "none",
			width: r?.width,
			minWidth: r?.minWidth,
			options: r?.options ?? _$2(n.enum),
			format: r?.format ?? a
		};
	});
	return m$2({
		idField: n?.idField,
		pageSize: n?.pageSize,
		pageSizeOptions: n?.pageSizeOptions,
		selectionMode: n?.selectionMode,
		defaultGroupBy: n?.defaultGroupBy,
		defaultSort: n?.defaultSort,
		footer: n?.footer,
		columns: r
	});
}
function te(e) {
	if (e) {
		if (typeof e == "string") {
			let t = JSON.parse(e);
			if (!t || typeof t != "object") throw Error("Invalid jsonIsland: expected a JSON object.");
			return t;
		}
		return e;
	}
}
async function y$2(e, t) {
	if (e !== void 0) return typeof e == "function" ? e() : typeof e == "string" ? await (t ?? ee)(e) : e;
}
function b$3(...e) {
	return e.filter(Boolean).join(" ");
}
function x$1(e, t, n) {
	let r = e[t];
	return r == null ? `row-${n}` : String(r);
}
function ne(e, t, n, r) {
	let i = n.trim().toLowerCase();
	return e.filter((e) => i.length === 0 || t.some((t) => w$1(e[t.key]).toLowerCase().includes(i)) ? t.every((t) => {
		let n = (r[t.key] ?? "").trim().toLowerCase();
		if (!n) return !0;
		let i = e[t.key];
		if (t.type === "boolean") {
			if (n === "true") return i === !0;
			if (n === "false") return i === !1;
		}
		return w$1(i).toLowerCase().includes(n);
	}) : !1);
}
function re(e, t, n) {
	if (!t) return e;
	let r = n.find((e) => e.key === t.columnKey);
	if (!r || !r.sortable) return e;
	let i = t.direction === "asc" ? 1 : -1;
	return [...e].sort((e, n) => {
		let a = e[t.columnKey], o = n[t.columnKey];
		return se(a, o, r.type) * i;
	});
}
function ie(e, t, n, r) {
	if (!n) return e.map((e, t) => ({
		kind: "data",
		key: `data-${t}`,
		row: e,
		rowIndex: t
	}));
	let i = t.find((e) => e.key === n);
	if (!i || !i.groupable) return e.map((e, t) => ({
		kind: "data",
		key: `data-${t}`,
		row: e,
		rowIndex: t
	}));
	let a = /* @__PURE__ */ new Map();
	e.forEach((e) => {
		let t = w$1(e[n]) || "(empty)", r = a.get(t);
		if (r) {
			r.push(e);
			return;
		}
		a.set(t, [e]);
	});
	let o = [];
	return Array.from(a.entries()).forEach(([e, t]) => {
		let n = `group-${e}`;
		o.push({
			kind: "group",
			key: n,
			groupValue: e,
			groupSize: t.length,
			groupRows: t
		}), r.has(e) && t.forEach((t, r) => {
			o.push({
				kind: "data",
				key: `${n}-row-${r}`,
				row: t,
				rowIndex: r,
				groupValue: e
			});
		});
	}), o;
}
function ae(e, t, n) {
	if (t <= 0) return e;
	let r = Math.max(0, n) * t;
	return e.slice(r, r + t);
}
function S$2(e, t) {
	if (e == null) return "";
	if (t.format === "currency" && typeof e == "number") return new Intl.NumberFormat(void 0, {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 2
	}).format(e);
	if (t.format === "percent" && typeof e == "number") return new Intl.NumberFormat(void 0, {
		style: "percent",
		maximumFractionDigits: 2
	}).format(e);
	if ((t.format === "date" || t.type === "date") && (typeof e == "string" || e instanceof Date)) {
		let t = new Date(e);
		if (!Number.isNaN(t.getTime())) return new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }).format(t);
	}
	if ((t.format === "datetime" || t.type === "datetime") && (typeof e == "string" || e instanceof Date)) {
		let t = new Date(e);
		if (!Number.isNaN(t.getTime())) return new Intl.DateTimeFormat(void 0, {
			dateStyle: "medium",
			timeStyle: "short"
		}).format(t);
	}
	return w$1(e);
}
function C$1(e, t) {
	let n = t.aggregate ?? "none";
	if (n === "none") return {
		type: "none",
		value: null
	};
	let r = e.map((e) => e[t.key]).filter((e) => typeof e == "number" && Number.isFinite(e));
	return n === "count" ? {
		type: "count",
		value: e.length
	} : r.length === 0 ? {
		type: n,
		value: null
	} : n === "sum" ? {
		type: "sum",
		value: r.reduce((e, t) => e + t, 0)
	} : n === "avg" ? {
		type: "avg",
		value: r.reduce((e, t) => e + t, 0) / r.length
	} : n === "min" ? {
		type: "min",
		value: Math.min(...r)
	} : n === "max" ? {
		type: "max",
		value: Math.max(...r)
	} : {
		type: n,
		value: null
	};
}
function oe(e) {
	return e.type === "none" ? "" : e.value === null || e.value === void 0 ? "-" : e.type === "count" ? `${Math.round(e.value)}` : new Intl.NumberFormat(void 0, {
		minimumFractionDigits: 0,
		maximumFractionDigits: 2
	}).format(e.value);
}
function se(e, t, n) {
	if (e === t) return 0;
	if (e == null) return -1;
	if (t == null) return 1;
	if (n === "number") {
		let n = Number(e), r = Number(t);
		if (Number.isFinite(n) && Number.isFinite(r)) return n - r;
	}
	if (n === "date" || n === "datetime") {
		let n = new Date(String(e)).getTime(), r = new Date(String(t)).getTime();
		if (!Number.isNaN(n) && !Number.isNaN(r)) return n - r;
	}
	return n === "boolean" ? !!e - +!!t : w$1(e).localeCompare(w$1(t));
}
function w$1(e) {
	if (e == null) return "";
	if (typeof e == "string") return e;
	if (typeof e == "number" || typeof e == "boolean") return String(e);
	if (e instanceof Date) return e.toISOString();
	if (Array.isArray(e)) return e.map((e) => w$1(e)).join(", ");
	if (typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return "[object]";
	}
	return String(e);
}
function ce(e, t) {
	return t.sortable ? !e || e.columnKey !== t.key ? {
		columnKey: t.key,
		direction: "asc"
	} : e.direction === "asc" ? {
		columnKey: t.key,
		direction: "desc"
	} : null : e;
}
function T$1(e, t) {
	if (e == null) return "";
	if (t === "date" || t === "datetime") {
		let n = new Date(String(e));
		return Number.isNaN(n.getTime()) ? "" : t === "date" ? n.toISOString().slice(0, 10) : n.toISOString().slice(0, 16);
	}
	return w$1(e);
}
function E$1(e, t) {
	if (t.editor === "checkbox" || t.type === "boolean") return e === "true";
	if (t.editor === "number" || t.type === "number") {
		let t = Number(e);
		return Number.isFinite(t) ? t : null;
	}
	return t.type === "date" || t.type === "datetime" ? e || null : e;
}
function le(e) {
	let t = e.trim().toLowerCase();
	return t === "true" || t === "false" ? t : "";
}
function ue(e) {
	return e === "none" ? "" : e.toUpperCase();
}
function de({ columns: e, draft: n, rowId: r, onCancel: i, onSave: l }) {
	let [d, f] = (0, import_react.useState)(n);
	return (0, import_react.useEffect)(() => {
		f(n);
	}, [n]), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(p$3, {
		title: `Edit row ${r}`,
		"aria-label": `Edit row ${r}`,
		onRequestClose: i,
		className: "nabs-ui-grid__editDialog",
		contentClassName: "nabs-ui-grid__editDialogContent",
		footerClassName: "nabs-ui-grid__editDialogFooter",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$4, {
			variant: "secondary",
			onClick: i,
			children: "Cancel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$4, {
			onClick: () => l(d),
			children: "Save"
		})] }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-grid__dialogBody",
			children: e.filter((e) => e.editable).map((e) => {
				let t = T$1(d[e.key], e.type);
				return e.editor === "checkbox" || e.type === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nabs-ui-grid__field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "nabs-ui-grid__input",
						value: t === "true" ? "true" : "false",
						onChange: (t) => {
							let n = t.target.value === "true";
							f((t) => ({
								...t,
								[e.key]: n
							}));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "true",
							children: "True"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "false",
							children: "False"
						})]
					})]
				}, e.key) : e.editor === "select" && e.options?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nabs-ui-grid__field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "nabs-ui-grid__input",
						value: t,
						onChange: (t) => {
							let n = E$1(t.target.value, e);
							f((t) => ({
								...t,
								[e.key]: n
							}));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "(empty)"
						}), e.options.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: String(e.value),
							children: e.label
						}, String(e.value)))]
					})]
				}, e.key) : e.editor === "textarea" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nabs-ui-grid__field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "nabs-ui-grid__input nabs-ui-grid__input--textarea",
						value: t,
						onChange: (t) => {
							let n = E$1(t.target.value, e);
							f((t) => ({
								...t,
								[e.key]: n
							}));
						}
					})]
				}, e.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nabs-ui-grid__field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "nabs-ui-grid__input",
						type: e.editor === "number" || e.type === "number" ? "number" : e.type === "date" ? "date" : "text",
						value: t,
						onChange: (t) => {
							let n = E$1(t.target.value, e);
							f((t) => ({
								...t,
								[e.key]: n
							}));
						}
					})]
				}, e.key);
			})
		})
	});
}
var D = (0, import_react.forwardRef)(function({ mode: e, schema: n, jsonSchema: l, jsonIsland: u, data: d, schemaSource: f, jsonSchemaSource: p, jsonIslandSource: ee, dataSource: h, serverDataSource: g, fetcher: _, height: se = 440, rowHeight: w = 40, overscan: D = 6, editMode: fe = "both", searchable: pe = !0, filterable: me = !0, groupable: he = !0, pageable: ge = !0, selectable: _e = !0, className: ve = "", onDataChange: ye, onSelectionChange: be, onSchemaLoaded: xe, onDataLoaded: Se, onError: Ce, valueFormatters: we, ...Te }, Ee) {
	let [O, k] = (0, import_react.useState)(() => n ? m$2(n) : l ? v$2(l) : m$2(void 0)), [De, Oe] = (0, import_react.useState)(e ?? "client"), [A, j] = (0, import_react.useState)(d ?? []), [ke, Ae] = (0, import_react.useState)(void 0), [je, Me] = (0, import_react.useState)(void 0), [Ne, Pe] = (0, import_react.useState)(void 0), [Fe, Ie] = (0, import_react.useState)(!1), [Le, Re] = (0, import_react.useState)(""), [M, ze] = (0, import_react.useState)(""), [N, Be] = (0, import_react.useState)({}), [P, F] = (0, import_react.useState)(null), [I, L] = (0, import_react.useState)(null), [R, Ve] = (0, import_react.useState)(/* @__PURE__ */ new Set()), [z, B] = (0, import_react.useState)(0), [V, H] = (0, import_react.useState)(O.pageSize ?? 10), [He, Ue] = (0, import_react.useState)(/* @__PURE__ */ new Set()), [We, Ge] = (0, import_react.useState)(null), [Ke, U] = (0, import_react.useState)(null), [qe, Je] = (0, import_react.useState)(null), [Ye, Xe] = (0, import_react.useState)(0), [Ze, Qe] = (0, import_react.useState)(0), $e = (0, import_react.useRef)(be), et = (0, import_react.useRef)(g), W = ke ?? je;
	(0, import_react.useEffect)(() => {
		try {
			let t = te(u);
			Ae(t), !d && t?.data && j(t.data), Oe(e ?? t?.mode ?? "client");
		} catch (t) {
			let n = t instanceof Error ? t : /* @__PURE__ */ Error("Invalid jsonIsland value.");
			Re(n.message), Ce?.(n), Ae(void 0), Oe(e ?? "client");
		}
	}, [
		d,
		u,
		e
	]), (0, import_react.useEffect)(() => {
		if (n) {
			k(m$2(n));
			return;
		}
		if (l) {
			k(v$2(l));
			return;
		}
		if (W?.schema) {
			k(m$2(W.schema));
			return;
		}
		if (W?.jsonSchema) {
			k(v$2(W.jsonSchema));
			return;
		}
		k(m$2(void 0));
	}, [
		W,
		l,
		n
	]), (0, import_react.useEffect)(() => {
		d && (j(d), Pe(void 0));
	}, [d]), (0, import_react.useEffect)(() => {
		let e = n ? m$2(n) : l ? v$2(l) : W?.schema ? m$2(W.schema) : v$2(W?.jsonSchema);
		H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && (L(e.defaultGroupBy), Ve((t) => {
			let n = new Set(t);
			return n.add(e.defaultGroupBy), n;
		}));
	}, [
		W,
		l,
		n
	]), (0, import_react.useEffect)(() => {
		let t = !1;
		return (async () => {
			if (!(!f && !p && !ee && !h)) try {
				Ie(!0), Re("");
				let [n, r, i, a] = await Promise.all([
					y$2(f, _),
					y$2(p, _),
					y$2(ee, _),
					y$2(h, _)
				]), o = te(i);
				if (Me(o), t) return;
				if (n) {
					let e = m$2(n);
					k(e), H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && L(e.defaultGroupBy), xe?.(e);
				} else if (r) {
					let e = v$2(r);
					k(e), H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && L(e.defaultGroupBy), xe?.(e);
				} else if (o?.schema) {
					let e = m$2(o.schema);
					k(e), H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && L(e.defaultGroupBy), xe?.(e);
				} else if (o?.jsonSchema) {
					let e = v$2(o.jsonSchema);
					k(e), H(e.pageSize ?? 10), e.defaultSort && F(e.defaultSort), e.defaultGroupBy && L(e.defaultGroupBy), xe?.(e);
				}
				Array.isArray(a) ? (j(a), Pe(void 0), Se?.(a)) : o?.data && !d && (j(o.data), Pe(void 0), Se?.(o.data)), !e && o?.mode && Oe(o.mode);
			} catch (e) {
				if (t) return;
				let n = e instanceof Error ? e : /* @__PURE__ */ Error("Failed to load grid sources.");
				Re(n.message), Ce?.(n);
			} finally {
				t || Ie(!1);
			}
		})(), () => {
			t = !0;
		};
	}, [
		d,
		h,
		_,
		ee,
		p,
		e,
		f
	]), (0, import_react.useEffect)(() => {
		$e.current = be;
	}, [be]), (0, import_react.useEffect)(() => {
		et.current = g;
	}, [g]), (0, import_react.useEffect)(() => {
		if (De !== "server" || !g) return;
		let e = !1, t = {
			pageIndex: z,
			pageSize: V,
			searchTerm: M,
			sort: P,
			groupBy: I,
			filters: N
		};
		return (async () => {
			try {
				let n = et.current;
				if (!n) return;
				Ie(!0), Re("");
				let r = await n(t, O);
				if (e) return;
				if (Array.isArray(r)) {
					j(r), Pe(r.length), Se?.(r);
					return;
				}
				j(r.rows), Pe(r.totalCount ?? r.rows.length), Se?.(r.rows);
			} catch (t) {
				if (e) return;
				let n = t instanceof Error ? t : /* @__PURE__ */ Error("Failed to load server data.");
				Re(n.message), Ce?.(n);
			} finally {
				e || Ie(!1);
			}
		})(), () => {
			e = !0;
		};
	}, [
		N,
		I,
		z,
		V,
		De,
		O,
		M,
		P
	]);
	let G = O.columns, K = O.idField ?? "id", q = _e ? O.selectionMode ?? "multiple" : "none", tt = pe, nt = me, rt = he, it = ge, at = fe === "inline" || fe === "both", ot = fe === "dialog" || fe === "both", J = De === "server", Y = (0, import_react.useMemo)(() => J ? A : ne(A, G, tt ? M : "", nt ? N : {}), [
		nt,
		tt,
		N,
		G,
		J,
		A,
		M
	]), X = (0, import_react.useMemo)(() => J ? Y : re(Y, P, G), [
		G,
		Y,
		J,
		P
	]), st = J ? Ne ?? X.length : X.length, Z = Math.max(1, Math.ceil(st / Math.max(1, V))), Q = Math.min(z, Z - 1);
	(0, import_react.useEffect)(() => {
		Q !== z && B(Q);
	}, [Q, z]);
	let ct = (0, import_react.useMemo)(() => J ? X : it ? ae(X, V, Q) : X, [
		it,
		Q,
		J,
		V,
		X
	]), lt = (0, import_react.useMemo)(() => {
		let e = /* @__PURE__ */ new Set();
		return I && ct.forEach((t) => {
			let n = t[I];
			e.add(n == null || n === "" ? "(empty)" : String(n));
		}), e;
	}, [I, ct]);
	(0, import_react.useEffect)(() => {
		I && R.size === 0 && lt.size > 0 && Ve(lt);
	}, [
		lt,
		R.size,
		I
	]);
	let $ = (0, import_react.useMemo)(() => ie(ct, G, rt ? I : null, R), [
		rt,
		G,
		R,
		I,
		ct
	]), ut = $.filter((e) => e.kind === "data").length, dt = Math.max(1, ut + $.filter((e) => e.kind === "group").length) * w, ft = Math.ceil(se / w) + D * 2, pt = Math.max(0, Math.floor(Ye / w) - D), mt = Math.min($.length, pt + ft), ht = $.slice(pt, mt), gt = pt * w, _t = Math.max(0, dt - gt - ht.length * w), vt = (0, import_react.useMemo)(() => {
		let e = /* @__PURE__ */ new Map();
		return A.forEach((t, n) => {
			e.set(x$1(t, K, n), t);
		}), Array.from(He.values()).map((t) => e.get(t)).filter((e) => !!e);
	}, [
		K,
		A,
		He
	]);
	(0, import_react.useEffect)(() => {
		$e.current?.(vt);
	}, [vt]);
	let yt = (0, import_react.useMemo)(() => {
		let e = /* @__PURE__ */ new Map();
		return G.forEach((t) => {
			let n = C$1(Y, t);
			n.type !== "none" && e.set(t.key, `${ue(n.type)} ${oe(n)}`);
		}), e;
	}, [G, Y]), bt = (0, import_react.useMemo)(() => $.filter((e) => e.kind === "data" && !!e.row).map((e) => x$1(e.row, K, e.rowIndex ?? 0)), [$, K]), xt = q !== "none" && bt.length > 0 && bt.every((e) => He.has(e));
	function St(e) {
		j(e), ye?.(e);
	}
	function Ct(e, t) {
		Be((n) => ({
			...n,
			[e]: t
		})), B(0);
	}
	function wt(e) {
		F((t) => ce(t, e)), B(0);
	}
	function Tt(e, t, n) {
		let r = we?.[n.key], i = e[n.key];
		return r ? r({
			row: e,
			rowIndex: t,
			column: n,
			value: i
		}) : S$2(i, n);
	}
	function Et(e, t) {
		let n = x$1(e, K, t);
		Ge(n), U({ ...e });
	}
	function Dt(e) {
		Ke && (St(A.map((t, n) => x$1(t, K, n) === e ? { ...Ke } : t)), Ge(null), U(null));
	}
	function Ot() {
		Ge(null), U(null);
	}
	function kt(e, t) {
		let n = x$1(e, K, t);
		Je({
			rowId: n,
			draft: { ...e }
		});
	}
	function At(e, t) {
		St(A.map((n, r) => x$1(n, K, r) === e ? { ...t } : n)), Je(null);
	}
	function jt(e) {
		Ve((t) => {
			let n = new Set(t);
			return n.has(e) ? n.delete(e) : n.add(e), n;
		});
	}
	function Mt(e, t, n) {
		if (q === "none") return;
		let r = x$1(e, K, t);
		Ue((e) => {
			if (q === "single") return n ? /* @__PURE__ */ new Set([r]) : /* @__PURE__ */ new Set();
			let t = new Set(e);
			return n ? t.add(r) : t.delete(r), t;
		});
	}
	function Nt(e) {
		if (q !== "none") {
			if (q === "single") {
				let t = $.find((e) => e.kind === "data" && e.row);
				if (!t || !t.row) {
					Ue(/* @__PURE__ */ new Set());
					return;
				}
				Ue(e ? /* @__PURE__ */ new Set([x$1(t.row, K, t.rowIndex ?? 0)]) : /* @__PURE__ */ new Set());
				return;
			}
			Ue((t) => {
				let n = new Set(t);
				return bt.forEach((t) => {
					e ? n.add(t) : n.delete(t);
				}), n;
			});
		}
	}
	let Pt = b$3("nabs-ui-grid", ve), Ft = G.length + (q === "none" ? 0 : 1) + 1, It = G.filter((e) => e.groupable), Lt = O.footer?.showColumnAggregates !== !1, Rt = J ? st : Y.length, zt = (O.footer?.rowAggregates ?? []).map((e) => e === "filteredRows" ? `Filtered rows ${Rt}` : e === "pagedRows" ? `Page rows ${ct.length}` : e === "selectedRows" ? `Selected rows ${vt.length}` : e === "groupCount" ? `Groups ${I ? $.filter((e) => e.kind === "group").length : 0}` : "").filter(Boolean), Bt = Ze === 0 ? void 0 : { transform: `translateX(${-Ze}px)` };
	function Vt() {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("colgroup", { children: [
			q === "none" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "nabs-ui-grid__col nabs-ui-grid__col--selection" }),
			G.map((e) => {
				let t = e.width, n = e.minWidth;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", {
					className: "nabs-ui-grid__col",
					style: {
						width: t === void 0 ? void 0 : typeof t == "number" ? `${t}px` : t,
						minWidth: n === void 0 ? void 0 : `${n}px`
					}
				}, e.key);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "nabs-ui-grid__col nabs-ui-grid__col--actions" })
		] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: Ee,
		className: Pt,
		...Te,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-grid__toolbar",
				children: [
					tt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "nabs-ui-grid__input nabs-ui-grid__search",
						type: "search",
						value: M,
						placeholder: "Find rows...",
						onChange: (e) => {
							ze(e.target.value), B(0);
						}
					}) : null,
					rt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "nabs-ui-grid__groupControl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Group by" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "nabs-ui-grid__input",
							value: I ?? "",
							onChange: (e) => {
								let t = e.target.value || null;
								L(t), Ve(/* @__PURE__ */ new Set());
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "None"
							}), It.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: e.key,
								children: e.label
							}, e.key))]
						})]
					}) : null,
					it ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "nabs-ui-grid__groupControl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Page size" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "nabs-ui-grid__input",
							value: String(V),
							onChange: (e) => {
								let t = Number(e.target.value);
								H(Number.isFinite(t) && t > 0 ? t : 10), B(0);
							},
							children: (O.pageSizeOptions ?? [
								10,
								20,
								50
							]).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: String(e),
								children: e
							}, e))
						})]
					}) : null
				]
			}),
			Le ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-grid__status",
				children: Le
			}) : null,
			Fe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-grid__status",
				children: "Loading data..."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-grid__surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "nabs-ui-grid__headerViewport",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "nabs-ui-grid__table",
							style: Bt,
							children: [Vt(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "nabs-ui-grid__head",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									q === "none" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--head nabs-ui-grid__cell--selection",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: xt,
											onChange: (e) => Nt(e.target.checked),
											"aria-label": "Select visible rows"
										})
									}),
									G.map((e) => {
										let t = P?.columnKey === e.key ? ` (${P.direction})` : "", n = !!N[e.key];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "nabs-ui-grid__cell nabs-ui-grid__cell--head",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "nabs-ui-grid__headCell",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													className: "nabs-ui-grid__sortButton",
													type: "button",
													onClick: () => wt(e),
													disabled: !e.sortable,
													"aria-label": `${e.label}${t}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.label }), e.sortable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: P?.columnKey === e.key ? P.direction : "-" }) : null]
												}), nt && e.filterable ? e.type === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													className: b$3("nabs-ui-grid__input", n ? "nabs-ui-grid__input--active" : ""),
													value: le(N[e.key] ?? ""),
													onChange: (t) => Ct(e.key, t.target.value),
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "",
															children: "All"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "true",
															children: "True"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "false",
															children: "False"
														})
													]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													className: b$3("nabs-ui-grid__input", n ? "nabs-ui-grid__input--active" : ""),
													type: "text",
													value: N[e.key] ?? "",
													placeholder: "Filter",
													onChange: (t) => Ct(e.key, t.target.value)
												}) : null]
											})
										}, e.key);
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--head nabs-ui-grid__cell--actions",
										children: "Actions"
									})
								] })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "nabs-ui-grid__viewport",
						style: { height: `${se}px` },
						onScroll: (e) => {
							let t = e.target;
							Xe(t.scrollTop), Qe(t.scrollLeft);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "nabs-ui-grid__table",
							children: [Vt(), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
								gt > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "nabs-ui-grid__spacer",
									style: { height: `${gt}px` },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { colSpan: Ft })
								}) : null,
								ht.map((e, t) => {
									if (e.kind === "group") {
										let t = e.groupValue ?? "(empty)", n = R.has(t);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
											className: "nabs-ui-grid__groupRow",
											style: { height: `${w}px` },
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: Ft,
												className: "nabs-ui-grid__groupCell",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													className: "nabs-ui-grid__groupToggle",
													type: "button",
													onClick: () => jt(t),
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: n ? "Hide" : "Show" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [e.groupSize ?? 0, " rows"] })
													]
												})
											})
										}, e.key);
									}
									if (!e.row) return null;
									let n = e.row, r = e.rowIndex ?? t, i = x$1(n, K, r), a = He.has(i), l = We === i;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: b$3("nabs-ui-grid__dataRow", a ? "nabs-ui-grid__dataRow--selected" : ""),
										style: { height: `${w}px` },
										children: [
											q === "none" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "nabs-ui-grid__cell nabs-ui-grid__cell--selection",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "checkbox",
													checked: a,
													onChange: (e) => Mt(n, r, e.target.checked),
													"aria-label": `Select row ${i}`
												})
											}),
											G.map((e) => {
												let t = T$1((l ? Ke : n)?.[e.key], e.type);
												return l && e.editable ? e.editor === "checkbox" || e.type === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
														className: "nabs-ui-grid__input",
														value: t === "true" ? "true" : "false",
														onChange: (t) => {
															let n = t.target.value === "true";
															U((t) => ({
																...t ?? {},
																[e.key]: n
															}));
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "true",
															children: "True"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "false",
															children: "False"
														})]
													})
												}, e.key) : e.editor === "select" && e.options?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
														className: "nabs-ui-grid__input",
														value: t,
														onChange: (t) => {
															let n = E$1(t.target.value, e);
															U((t) => ({
																...t ?? {},
																[e.key]: n
															}));
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "",
															children: "(empty)"
														}), e.options.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: String(e.value),
															children: e.label
														}, String(e.value)))]
													})
												}, e.key) : e.editor === "textarea" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
														className: "nabs-ui-grid__input nabs-ui-grid__input--textarea",
														value: t,
														onChange: (t) => {
															let n = E$1(t.target.value, e);
															U((t) => ({
																...t ?? {},
																[e.key]: n
															}));
														}
													})
												}, e.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														className: "nabs-ui-grid__input",
														type: e.editor === "number" || e.type === "number" ? "number" : e.type === "date" ? "date" : "text",
														value: t,
														onChange: (t) => {
															let n = E$1(t.target.value, e);
															U((t) => ({
																...t ?? {},
																[e.key]: n
															}));
														}
													})
												}, e.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "nabs-ui-grid__cell",
													title: S$2(n[e.key], e),
													children: Tt(n, r, e)
												}, e.key);
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "nabs-ui-grid__cell nabs-ui-grid__cell--actions",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "nabs-ui-grid__actionStack",
													children: [at ? l ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "nabs-ui-grid__button nabs-ui-grid__button--primary",
														type: "button",
														onClick: () => Dt(i),
														children: "Save"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "nabs-ui-grid__button",
														type: "button",
														onClick: Ot,
														children: "Cancel"
													})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "nabs-ui-grid__button",
														type: "button",
														onClick: () => Et(n, r),
														children: "Inline"
													}) : null, ot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "nabs-ui-grid__button",
														type: "button",
														onClick: () => kt(n, r),
														children: "Dialog"
													}) : null]
												})
											})
										]
									}, e.key);
								}),
								_t > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "nabs-ui-grid__spacer",
									style: { height: `${_t}px` },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { colSpan: Ft })
								}) : null
							] })]
						})
					}),
					Lt || zt.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "nabs-ui-grid__footer",
						children: [Lt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "nabs-ui-grid__footerSection nabs-ui-grid__footerSection--columns",
							"aria-label": "Column aggregates",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "nabs-ui-grid__footerSectionHeader",
								children: "Column aggregates"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "nabs-ui-grid__table",
								style: Bt,
								children: [Vt(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									q === "none" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--foot",
										children: vt.length
									}),
									G.map((e, t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--foot",
										children: [
											t === 0 ? `Rows ${Rt}` : "",
											t === 0 && yt.has(e.key) ? " | " : "",
											yt.get(e.key) ?? ""
										]
									}, e.key)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "nabs-ui-grid__cell nabs-ui-grid__cell--foot",
										children: ["Selected ", vt.length]
									})
								] }) })]
							})]
						}) : null, zt.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "nabs-ui-grid__footerSection nabs-ui-grid__footerSection--rows",
							"aria-label": "Row aggregates",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "nabs-ui-grid__footerSectionHeader",
								children: "Row aggregates"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "nabs-ui-grid__cell nabs-ui-grid__cell--foot",
								children: zt.join(" | ")
							})]
						}) : null]
					}) : null
				]
			}),
			it ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-grid__pager",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nabs-ui-grid__button",
						type: "button",
						onClick: () => B(0),
						disabled: Q === 0,
						children: "First"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nabs-ui-grid__button",
						type: "button",
						onClick: () => B((e) => Math.max(0, e - 1)),
						disabled: Q === 0,
						children: "Prev"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Page ",
						Q + 1,
						" / ",
						Z
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nabs-ui-grid__button",
						type: "button",
						onClick: () => B((e) => Math.min(Z - 1, e + 1)),
						disabled: Q >= Z - 1,
						children: "Next"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nabs-ui-grid__button",
						type: "button",
						onClick: () => B(Z - 1),
						disabled: Q >= Z - 1,
						children: "Last"
					})
				]
			}) : null,
			qe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(de, {
				columns: G,
				draft: qe.draft,
				rowId: qe.rowId,
				onCancel: () => Je(null),
				onSave: (e) => At(qe.rowId, e)
			}) : null
		]
	});
});
D.displayName = "Grid";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-markdown/dist/nabs-ui-markdown.js
var c$4 = {
	left: "nabs-ui-toolbar__content--label-left",
	right: "nabs-ui-toolbar__content--label-right",
	top: "nabs-ui-toolbar__content--label-top",
	bottom: "nabs-ui-toolbar__content--label-bottom"
};
function l$4(e) {
	return e || "right";
}
var u$3 = (0, import_react.forwardRef)(function({ items: e, activeItemId: t, className: n = "", buttonClassName: r = "", iconClassName: i = "", labelClassName: a = "", onItemSelect: u, ...d }, f) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: f,
		className: ["nabs-ui-toolbar", n].filter(Boolean).join(" "),
		role: "toolbar",
		...d,
		children: e.map((e) => {
			let n = e.icon, d = !!e.label, f = e.id === t || e.pressed === !0, p = ["nabs-ui-toolbar__content", c$4[l$4(e.labelPosition)]].filter(Boolean).join(" "), m = [
				"nabs-ui-toolbar__button",
				f ? "nabs-ui-toolbar__button--active" : "",
				d ? "" : "nabs-ui-toolbar__button--icon-only",
				r
			].filter(Boolean).join(" "), h = ["nabs-ui-toolbar__icon", i].filter(Boolean).join(" "), g = ["nabs-ui-toolbar__label", a].filter(Boolean).join(" "), _ = typeof e.label == "string" ? e.label : e.title;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: m,
				disabled: e.disabled,
				title: e.title,
				"aria-label": _,
				"aria-pressed": typeof e.pressed == "boolean" ? e.pressed : void 0,
				onClick: (t) => {
					u?.({
						itemId: e.id,
						item: e,
						event: t
					});
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: p,
					children: [n ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(n, {
						className: h,
						"aria-hidden": "true",
						focusable: "false"
					}) : null, e.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: g,
						children: e.label
					}) : null]
				})
			}, e.id);
		})
	});
});
u$3.displayName = "Toolbar";
function d$2({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M8.625 9.75a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375m-13.5 3.01c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.184-4.183a1.14 1.14 0 0 1 .778-.332 48.294 48.294 0 0 0 5.83-.498c1.585-.233 2.708-1.626 2.708-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z"
	}));
}
var f$3 = /*#__PURE__*/ import_react.forwardRef(d$2);
function p$2({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M17.25 6.75 22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3-4.5 16.5"
	}));
}
var m$1 = /*#__PURE__*/ import_react.forwardRef(p$2);
function h$2({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z"
	}));
}
var g$1 = /*#__PURE__*/ import_react.forwardRef(h$2);
function _$1({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"
	}), /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
	}));
}
var v$1 = /*#__PURE__*/ import_react.forwardRef(_$1);
function y$1({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M5.25 8.25h15m-16.5 7.5h15m-1.8-13.5-3.9 19.5m-2.1-19.5-3.9 19.5"
	}));
}
var b$2 = /*#__PURE__*/ import_react.forwardRef(y$1);
function x({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244"
	}));
}
var S$1 = /*#__PURE__*/ import_react.forwardRef(x);
function C({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0ZM3.75 12h.007v.008H3.75V12Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm-.375 5.25h.007v.008H3.75v-.008Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z"
	}));
}
var w = /*#__PURE__*/ import_react.forwardRef(C);
function T({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10"
	}));
}
var E = /*#__PURE__*/ import_react.forwardRef(T);
function D$1({ title: t, titleId: n, ...r }, i) {
	return /*#__PURE__*/ import_react.createElement("svg", Object.assign({
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 24 24",
		strokeWidth: 1.5,
		stroke: "currentColor",
		"aria-hidden": "true",
		"data-slot": "icon",
		ref: i,
		"aria-labelledby": n
	}, r), t ? /*#__PURE__*/ import_react.createElement("title", { id: n }, t) : null, /*#__PURE__*/ import_react.createElement("path", {
		strokeLinecap: "round",
		strokeLinejoin: "round",
		d: "M3.75 12h16.5m-16.5 3.75h16.5M3.75 19.5h16.5M5.625 4.5h12.75a1.875 1.875 0 0 1 0 3.75H5.625a1.875 1.875 0 0 1 0-3.75Z"
	}));
}
var O = /*#__PURE__*/ import_react.forwardRef(D$1);
function k(e) {
	return e.split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;").split("\"").join("&quot;").split("'").join("&#39;");
}
function A(e) {
	let t = e.trim();
	return /^(https?:|mailto:|\/|#)/i.test(t) ? k(t) : "#";
}
function j(e) {
	let t = k(e);
	return t = t.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (e, t, n) => `<a href="${A(n)}" target="_blank" rel="noreferrer noopener">${t}</a>`), t = t.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>"), t = t.replace(/__([^_]+)__/g, "<strong>$1</strong>"), t = t.replace(/\*([^*]+)\*/g, "<em>$1</em>"), t = t.replace(/_([^_]+)_/g, "<em>$1</em>"), t = t.replace(/~~([^~]+)~~/g, "<del>$1</del>"), t = t.replace(/`([^`]+)`/g, "<code>$1</code>"), t;
}
function M(e) {
	let t = e.split("\r\n").join("\n").split("\n"), n = [], r = 0;
	for (; r < t.length;) {
		let e = t[r];
		if (!e.trim()) {
			r += 1;
			continue;
		}
		if (e.startsWith("```")) {
			let e = [];
			for (r += 1; r < t.length && !t[r].startsWith("```");) e.push(t[r]), r += 1;
			r < t.length && (r += 1), n.push(`<pre><code>${k(e.join("\n"))}</code></pre>`);
			continue;
		}
		let i = e.match(/^(#{1,6})\s+(.*)$/);
		if (i) {
			let e = i[1].length;
			n.push(`<h${e}>${j(i[2])}</h${e}>`), r += 1;
			continue;
		}
		if (e.startsWith(">")) {
			let e = [];
			for (; r < t.length && t[r].startsWith(">");) e.push(t[r].replace(/^> ?/, "")), r += 1;
			n.push(`<blockquote>${e.map(j).join("<br />")}</blockquote>`);
			continue;
		}
		if (e.match(/^[-*+]\s+(.*)$/)) {
			let e = [];
			for (; r < t.length;) {
				let n = t[r].match(/^[-*+]\s+(.*)$/);
				if (!n) break;
				e.push(`<li>${j(n[1])}</li>`), r += 1;
			}
			n.push(`<ul>${e.join("")}</ul>`);
			continue;
		}
		if (e.match(/^\d+\.\s+(.*)$/)) {
			let e = [];
			for (; r < t.length;) {
				let n = t[r].match(/^\d+\.\s+(.*)$/);
				if (!n) break;
				e.push(`<li>${j(n[1])}</li>`), r += 1;
			}
			n.push(`<ol>${e.join("")}</ol>`);
			continue;
		}
		let a = [];
		for (; r < t.length && t[r].trim();) {
			let e = t[r], n = e.startsWith("```") || /^(#{1,6})\s+/.test(e) || e.startsWith(">") || /^[-*+]\s+/.test(e) || /^\d+\.\s+/.test(e);
			if (a.length > 0 && n) break;
			a.push(e), r += 1;
		}
		n.push(`<p>${j(a.join(" "))}</p>`);
	}
	return n.join("");
}
function N(e, t, n) {
	let r = e.lastIndexOf("\n", Math.max(0, t - 1)) + 1, i = e.indexOf("\n", n), a = i === -1 ? e.length : i;
	return {
		before: e.slice(0, r),
		selected: e.slice(r, a),
		after: e.slice(a),
		lineStart: r,
		lineEnd: a
	};
}
function P(e, t, n) {
	let r = e.value, i = e.selectionStart ?? 0, a = e.selectionEnd ?? i, o = i !== a, { before: s, selected: c, after: l, lineStart: u } = N(r, i, a);
	if (!o) {
		let e = `${t}${n}`;
		return {
			nextValue: `${r.slice(0, i)}${e}${r.slice(a)}`,
			nextStart: i + t.length,
			nextEnd: i + e.length
		};
	}
	let d = c.split("\n").map((e) => e.trim() ? `${t}${e}` : t.trimEnd()).join("\n");
	return {
		nextValue: `${s}${d}${l}`,
		nextStart: u,
		nextEnd: u + d.length
	};
}
function F(e, t, n, r) {
	let i = e.value, a = e.selectionStart ?? 0, o = e.selectionEnd ?? a, s = a === o ? r : i.slice(a, o), c = `${t}${s}${n}`;
	return {
		nextValue: `${i.slice(0, a)}${c}${i.slice(o)}`,
		nextStart: a + t.length,
		nextEnd: a + t.length + s.length
	};
}
function I(e) {
	let t = e.value, n = e.selectionStart ?? 0, r = e.selectionEnd ?? n, i = n === r ? "link text" : t.slice(n, r), a = `[${i}](https://example.com)`;
	return {
		nextValue: `${t.slice(0, n)}${a}${t.slice(r)}`,
		nextStart: n + i.length + 3,
		nextEnd: n + i.length + 3 + 19
	};
}
function L({ label: e = "Markdown", helperText: t = "Use the toolbar to format markdown and toggle between edit and preview modes.", placeholder: c = "Write markdown here...", value: l = "", disabled: d = !1, className: p = "", editorClassName: h = "", toolbarClassName: _ = "", previewClassName: y = "", htmlClassName: x = "", id: C, rows: T = 12, onChange: D, onToolbarAction: k, ...A }) {
	let j = (0, import_react.useId)(), N = C ?? `nabs-ui-markdown-${j.replace(/:/g, "")}`, L = (0, import_react.useRef)(null), [R, z] = (0, import_react.useState)(l), [B, V] = (0, import_react.useState)("edit");
	(0, import_react.useEffect)(() => {
		z(l);
	}, [l]);
	let H = M(R), U = [
		"nabs-ui-markdown",
		"nabs-ui-markdown--single-panel",
		d ? "nabs-ui-markdown--disabled" : "",
		p
	].filter(Boolean).join(" "), W = ["nabs-ui-markdown__toolbar", _].filter(Boolean).join(" "), G = ["nabs-ui-markdown__editor", h].filter(Boolean).join(" "), K = ["nabs-ui-markdown__preview", y].filter(Boolean).join(" "), q = ["nabs-ui-markdown__html", x].filter(Boolean).join(" "), J = [
		{
			id: "mode-toggle",
			icon: v$1,
			title: B === "edit" ? "Preview" : "Edit"
		},
		{
			id: "heading",
			icon: b$2,
			title: "Heading"
		},
		{
			id: "bold",
			icon: g$1,
			title: "Bold"
		},
		{
			id: "italic",
			icon: E,
			title: "Italic"
		},
		{
			id: "quote",
			icon: f$3,
			title: "Quote"
		},
		{
			id: "bullet-list",
			icon: w,
			title: "Bullet list"
		},
		{
			id: "numbered-list",
			icon: O,
			title: "Numbered list"
		},
		{
			id: "code",
			icon: m$1,
			title: "Code"
		},
		{
			id: "link",
			icon: S$1,
			title: "Link"
		}
	], Y = (e, t) => {
		if (d) return;
		let n = L.current;
		if (!n) return;
		let r = t(n);
		r && (n.value = r.nextValue, n.setSelectionRange(r.nextStart, r.nextEnd), z(r.nextValue), D?.(r.nextValue), k?.(e));
	}, X = (e) => {
		let t = e.currentTarget.value;
		z(t), D?.(t);
	}, Z = (e) => {
		if (e === "mode-toggle") {
			let e = B === "edit" ? "preview" : "edit";
			V(e), k?.(`mode-${e}`);
			return;
		}
		switch (e) {
			case "heading":
				Y("heading", (e) => P(e, "# ", "Heading"));
				break;
			case "bold":
				Y("bold", (e) => F(e, "**", "**", "bold text"));
				break;
			case "italic":
				Y("italic", (e) => F(e, "*", "*", "italic text"));
				break;
			case "quote":
				Y("quote", (e) => P(e, "> ", "Quote"));
				break;
			case "bullet-list":
				Y("bullet-list", (e) => P(e, "- ", "List item"));
				break;
			case "numbered-list":
				Y("numbered-list", (e) => P(e, "1. ", "List item"));
				break;
			case "code":
				Y("code", (e) => F(e, "`", "`", "code"));
				break;
			case "link": Y("link", I);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: U,
		...A,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-markdown__editorPanel",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "nabs-ui-markdown__label",
					htmlFor: N,
					children: e
				}),
				t ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nabs-ui-markdown__helper",
					children: t
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(u$3, {
					className: W,
					"aria-label": "Markdown formatting toolbar",
					items: J.map((e) => {
						let t = e.id === "mode-toggle";
						return {
							...e,
							label: t ? B === "edit" ? "Preview" : "Edit" : void 0,
							disabled: d || !t && B === "preview",
							pressed: t ? B === "preview" : void 0
						};
					}),
					onMouseDown: (e) => {
						e.target?.closest("button") && e.preventDefault();
					},
					onItemSelect: ({ itemId: e }) => Z(e)
				}),
				B === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					id: N,
					ref: L,
					className: G,
					rows: T,
					placeholder: c,
					value: R,
					disabled: d,
					onChange: X
				}) : null
			]
		}), B === "preview" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-markdown__previewPanel",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-markdown__previewLabel",
				children: "Rendered preview"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: K,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: q,
					dangerouslySetInnerHTML: { __html: H || "<p>Preview appears here.</p>" }
				})
			})]
		}) : null]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-navigation/dist/nabs-ui-navigation.js
var t$9 = {
	vertical: "nabs-ui-navigation--vertical",
	horizontal: "nabs-ui-navigation--horizontal"
};
function n$10(e) {
	return [
		"nabs-ui-navigation__itemContent",
		e === "center" ? "nabs-ui-navigation__itemContent--center" : "",
		e === "right" ? "nabs-ui-navigation__itemContent--right" : ""
	].filter(Boolean).join(" ");
}
function r$12({ item: t, activeItemId: r, textAlignment: i, itemClassName: a, onItemSelect: o }) {
	let s = [
		"nabs-ui-navigation__item",
		t.id === r ? "nabs-ui-navigation__item--active" : "",
		t.disabled ? "nabs-ui-navigation__item--disabled" : "",
		a
	].filter(Boolean).join(" "), c = (e) => {
		if (t.disabled) {
			e.preventDefault();
			return;
		}
		o?.(t.id, t, e);
	};
	return "href" in t ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: s,
		href: t.href,
		"aria-current": t.id === r ? "page" : void 0,
		onClick: c,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: n$10(i),
			children: t.label
		})
	}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: s,
		disabled: t.disabled,
		"aria-current": t.id === r ? "page" : void 0,
		onClick: c,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: n$10(i),
			children: t.label
		})
	}) });
}
function i$1({ items: n = [], direction: i = "vertical", textAlignment: a = "left", activeItemId: o, className: s = "", itemClassName: c = "", onItemSelect: l, ...u }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: [
			"nabs-ui-navigation",
			t$9[i] ?? t$9.vertical,
			s
		].filter(Boolean).join(" "),
		...u,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "nabs-ui-navigation__list",
			children: n.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(r$12, {
				item: t,
				activeItemId: o,
				textAlignment: a,
				itemClassName: c,
				onItemSelect: l
			}, t.id))
		})
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-panel/dist/nabs-ui-panel.js
var r$2 = (0, import_react.forwardRef)(({ header: e = "Panel", footer: r, showHeader: i = !0, showFooter: a = !1, children: o, className: s = "", headerClassName: c = "", contentClassName: l = "", footerClassName: u = "", ...d }, f) => {
	let p = ["nabs-ui-panel", s].filter(Boolean).join(" "), m = ["nabs-ui-panel__header", c].filter(Boolean).join(" "), h = ["nabs-ui-panel__content", l].filter(Boolean).join(" "), g = ["nabs-ui-panel__footer", u].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref: f,
		className: p,
		...d,
		children: [
			i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: m,
				children: e
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: h,
				children: o
			}),
			a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: g,
				children: r
			}) : null
		]
	});
});
r$2.displayName = "Panel";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-radiobutton/dist/nabs-ui-radiobutton.js
var r$11 = {
	right: "nabs-ui-radiobutton--label-right",
	left: "nabs-ui-radiobutton--label-left",
	top: "nabs-ui-radiobutton--label-top",
	bottom: "nabs-ui-radiobutton--label-bottom"
};
function i$2({ label: i = "Radio button", labelPosition: a = "right", className: o = "", inputClassName: s = "", labelClassName: c = "", id: l, ...u }) {
	let d = u.disabled === !0, f = (0, import_react.useId)(), p = l ?? `nabs-ui-radiobutton-${f.replace(/:/g, "")}`, m = [
		"nabs-ui-radiobutton",
		d ? "nabs-ui-radiobutton--disabled" : "",
		r$11[a] ?? r$11.right,
		o
	].filter(Boolean).join(" "), h = ["nabs-ui-radiobutton__input", s].filter(Boolean).join(" "), g = ["nabs-ui-radiobutton__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: m,
		htmlFor: p,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: p,
			className: h,
			type: "radio",
			...u
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: g,
			children: i
		})]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-signature/dist/nabs-ui-signature.js
function o$1(e, t) {
	let n = t.getBoundingClientRect();
	return {
		x: e.clientX - n.left,
		y: e.clientY - n.top
	};
}
function s$2(e, t) {
	if (t.length !== 0) {
		e.beginPath(), e.moveTo(t[0].x, t[0].y);
		for (let n = 1; n < t.length; n += 1) e.lineTo(t[n].x, t[n].y);
		e.stroke();
	}
}
function c$3(e, t, n) {
	e.fillStyle = n, e.fillRect(0, 0, t.width, t.height);
}
function l$1({ label: l = "Signature", helperText: u = "Use your mouse to draw your signature.", value: d = "", disabled: f = !1, className: p = "", labelClassName: m = "", helperTextClassName: h = "", padClassName: g = "", canvasClassName: _ = "", id: v, width: y = 720, height: b = 240, backgroundColor: x = "#ffffff", penColor: S = "#0f172a", penWidth: C = 2.5, onChange: w, onBeginStroke: T, onEndStroke: E, onClear: D }) {
	let O = (0, import_react.useId)(), k = v ?? `nabs-ui-signature-${O.replace(/:/g, "")}`, A = (0, import_react.useRef)(null), j = (0, import_react.useRef)(null), M = (0, import_react.useRef)(!1), N = (0, import_react.useRef)([]), [P, F] = (0, import_react.useState)(!d), I = [
		"nabs-ui-signature",
		f ? "nabs-ui-signature--disabled" : "",
		p
	].filter(Boolean).join(" "), L = ["nabs-ui-signature__label", m].filter(Boolean).join(" "), R = ["nabs-ui-signature__helper", h].filter(Boolean).join(" "), z = ["nabs-ui-signature__pad", g].filter(Boolean).join(" "), B = ["nabs-ui-signature__canvas", _].filter(Boolean).join(" ");
	(0, import_react.useEffect)(() => {
		let e = A.current;
		if (!e) return;
		let t = e.getContext("2d");
		if (!t) return;
		let n = window.devicePixelRatio || 1, r = Math.round(y), i = Math.round(b);
		if (e.width = Math.round(r * n), e.height = Math.round(i * n), e.style.width = `${r}px`, e.style.height = `${i}px`, j.current = t, t.lineCap = "round", t.lineJoin = "round", t.lineWidth = C * n, t.strokeStyle = S, t.scale(n, n), c$3(t, e, x), d) {
			let e = new Image();
			e.onload = () => {
				t.clearRect(0, 0, r, i), t.fillStyle = x, t.fillRect(0, 0, r, i), t.drawImage(e, 0, 0, r, i), F(!1);
			}, e.src = d;
		}
		return () => {
			j.current = null;
		};
	}, [
		x,
		S,
		C,
		d,
		y,
		b
	]);
	let V = (e) => {
		w?.(e.toDataURL("image/png"));
	}, H = (e) => {
		if (f || M.current) return;
		let t = A.current, n = j.current;
		!t || !n || ("pointerId" in e && typeof e.pointerId == "number" && t.setPointerCapture && t.setPointerCapture(e.pointerId), M.current = !0, N.current = [o$1(e, t)], n.beginPath(), n.moveTo(N.current[0].x, N.current[0].y), T?.());
	}, U = (e) => {
		if (f || !M.current) return;
		let t = A.current, n = j.current;
		if (!t || !n) return;
		let r = o$1(e, t);
		N.current.push(r), n.lineTo(r.x, r.y), n.stroke(), F(!1);
	}, W = (e) => {
		let t = A.current, n = j.current;
		if (!(!t || !n || !M.current)) {
			if (e && "pointerId" in e && typeof e.pointerId == "number" && t.releasePointerCapture) try {
				t.releasePointerCapture(e.pointerId);
			} catch {}
			M.current = !1, s$2(n, N.current), N.current = [], V(t), E?.();
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: I,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: L,
				id: `${k}-label`,
				children: l
			}),
			u ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: R,
				children: u
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: z,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					id: k,
					ref: A,
					className: B,
					role: "img",
					"aria-labelledby": `${k}-label`,
					"aria-label": l,
					onPointerDown: H,
					onPointerMove: U,
					onPointerUp: W,
					onPointerCancel: W,
					onPointerLeave: W,
					onMouseDown: H,
					onMouseMove: U,
					onMouseUp: W,
					onMouseLeave: W
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nabs-ui-signature__placeholder",
					"aria-hidden": "true",
					children: P ? "Draw here" : null
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-signature__actions",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "nabs-ui-signature__clearButton",
					onClick: () => {
						let e = A.current, t = j.current;
						!e || !t || (t.clearRect(0, 0, e.width, e.height), c$3(t, e, x), F(!0), w?.(""), D?.());
					},
					disabled: f || P,
					children: "Clear"
				})
			})
		]
	});
}
//#endregion
//#region node_modules/@net-advantage/nabs-ui-slider/dist/nabs-ui-slider.js
var i$4 = (0, import_react.forwardRef)(({ label: e = "Slider", value: i = 0, min: a = 0, max: o = 100, step: s = 1, disabled: c = !1, className: l = "", inputClassName: u = "", labelClassName: d = "", valueClassName: f = "", id: p, onChange: m, ...h }, g) => {
	let _ = (0, import_react.useId)(), v = p ?? `nabs-ui-slider-${_.replace(/:/g, "")}`, y = [
		"nabs-ui-slider",
		c ? "nabs-ui-slider--disabled" : "",
		l
	].filter(Boolean).join(" "), b = ["nabs-ui-slider__input", u].filter(Boolean).join(" "), x = ["nabs-ui-slider__label", d].filter(Boolean).join(" "), S = ["nabs-ui-slider__value", f].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: y,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-slider__header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: x,
					htmlFor: v,
					children: e
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("output", {
					className: S,
					htmlFor: v,
					children: i
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: g,
				id: v,
				className: b,
				type: "range",
				value: i,
				min: a,
				max: o,
				step: s,
				disabled: c,
				onChange: m,
				...h
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nabs-ui-slider__scale",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: o })]
			})
		]
	});
});
i$4.displayName = "Slider";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-stepper/dist/nabs-ui-stepper.js
function c$2(e) {
	return e === "top" || e === "bottom" ? "horizontal" : "vertical";
}
function l$3(e, t) {
	return [
		"nabs-ui-stepper",
		`nabs-ui-stepper--${e}`,
		t
	].filter(Boolean).join(" ");
}
function u$2(e) {
	return ["nabs-ui-stepper__steps", `nabs-ui-stepper__steps--${e}`].filter(Boolean).join(" ");
}
function d$1(e) {
	return ["nabs-ui-stepper__content", `nabs-ui-stepper__content--${e}`].filter(Boolean).join(" ");
}
function f$2(t) {
	return import_react.Children.toArray(t).flatMap((e) => {
		if (!(0, import_react.isValidElement)(e)) return [];
		let t = Number(e.props.index);
		return Number.isFinite(t) ? [{
			index: t,
			label: e.props.label ?? e.props.children ?? `Step ${t}`,
			icon: e.props.icon,
			disabled: !!e.props.disabled
		}] : [];
	}).sort((e, t) => e.index - t.index);
}
function p$1(t) {
	return import_react.Children.toArray(t).flatMap((e) => {
		if (!(0, import_react.isValidElement)(e)) return [];
		let t = Number(e.props.index);
		return Number.isFinite(t) ? [{
			index: t,
			content: e.props.children
		}] : [];
	}).sort((e, t) => e.index - t.index);
}
function m({ children: e }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: e });
}
function h$1(e) {
	return null;
}
function g({ children: e }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: e });
}
function _(e) {
	return null;
}
var v = m;
var y = g;
var b$1 = (0, import_react.forwardRef)(({ children: t, className: a = "", stepsPosition: m = "top", stepsAlignment: h = "left", stepLabelAlignment: g = "right", showCenterLine: _ = !0, activeIndex: b, defaultActiveIndex: x, onStepChange: S, ...C }, w) => {
	let [T, E] = (0, import_react.useState)(x), { parsedSteps: D, parsedContentSteps: O } = (0, import_react.useMemo)(() => {
		let r = import_react.Children.toArray(t), i = r.find((e) => (0, import_react.isValidElement)(e) && e.type === v), a = r.find((e) => (0, import_react.isValidElement)(e) && e.type === y);
		return {
			parsedSteps: f$2(i?.props.children),
			parsedContentSteps: p$1(a?.props.children)
		};
	}, [t]), k = D[0]?.index ?? O[0]?.index ?? 0, A = b ?? T ?? k, j = O.find((e) => e.index === A), M = c$2(m), N = [
		l$3(m, a),
		`nabs-ui-stepper--label-${g}`,
		`nabs-ui-stepper--align-${h}`,
		_ ? "nabs-ui-stepper--with-center-line" : "nabs-ui-stepper--without-center-line"
	].filter(Boolean).join(" "), P = u$2(m), F = d$1(m);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref: w,
		className: N,
		...C,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: P,
			role: "tablist",
			"aria-orientation": M,
			children: D.map((e) => {
				let t = e.index === A;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "tab",
					"aria-selected": t,
					"aria-disabled": e.disabled,
					tabIndex: e.disabled ? -1 : 0,
					className: [
						"nabs-ui-stepper__step",
						t ? "nabs-ui-stepper__step--active" : "",
						e.disabled ? "nabs-ui-stepper__step--disabled" : ""
					].filter(Boolean).join(" "),
					onClick: (t) => {
						e.disabled || (b === void 0 && E(e.index), S?.(e.index, t));
					},
					children: [e.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-stepper__stepIndicators",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nabs-ui-stepper__stepIcon",
							children: e.icon
						})
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nabs-ui-stepper__stepLabel",
						children: e.label
					})]
				}, e.index);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: F,
			role: "tabpanel",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nabs-ui-stepper__contentInner",
				children: j?.content ?? null
			})
		})]
	});
});
b$1.displayName = "Stepper", m.displayName = "Stepper.Steps", h$1.displayName = "Stepper.Step", g.displayName = "Stepper.ContentSteps", _.displayName = "Stepper.ContentStep", b$1.Steps = m, b$1.Step = h$1, b$1.ContentSteps = g, b$1.ContentStep = _;
//#endregion
//#region node_modules/@net-advantage/nabs-ui-tab/dist/nabs-ui-tab.js
var r$3 = (0, import_react.forwardRef)(({ label: e = "Tab", children: r, showHeader: i = !0, className: a = "", headerClassName: o = "", contentClassName: s = "", labelClassName: c = "", id: l, ...u }, d) => {
	let f = ["nabs-ui-tab", a].filter(Boolean).join(" "), p = ["nabs-ui-tab__header", o].filter(Boolean).join(" "), m = ["nabs-ui-tab__content", s].filter(Boolean).join(" "), h = ["nabs-ui-tab__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref: d,
		id: l,
		className: f,
		...u,
		children: [i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: p,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: h,
				children: e
			})
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: m,
			children: r
		})]
	});
});
r$3.displayName = "Tab";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-textarea/dist/nabs-ui-textarea.js
var i$5 = (0, import_react.forwardRef)(({ label: e, className: i = "", inputClassName: a = "", labelClassName: o = "", id: s, rows: c = 4, resize: l = "vertical", ...u }, d) => {
	let f = (0, import_react.useId)(), p = s ?? `nabs-ui-textarea-${f.replace(/:/g, "")}`, m = ["nabs-ui-textarea", i].filter(Boolean).join(" "), h = ["nabs-ui-textarea__input", a].filter(Boolean).join(" "), g = ["nabs-ui-textarea__label", o].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: m,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: g,
			htmlFor: p,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			ref: d,
			id: p,
			className: h,
			rows: c,
			"data-resize": l,
			...u
		})]
	});
});
i$5.displayName = "Textarea";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-textbox/dist/nabs-ui-textbox.js
var i$7 = {
	none: "",
	top: "nabs-ui-textbox--label-top",
	left: "nabs-ui-textbox--label-left"
};
var a$4 = (0, import_react.forwardRef)(({ label: e, labelPosition: a = "top", className: o = "", inputClassName: s = "", labelClassName: c = "", id: l, type: u = "text", ...d }, f) => {
	let p = (0, import_react.useId)(), m = l ?? `nabs-ui-textbox-${p.replace(/:/g, "")}`, h = [
		"nabs-ui-textbox",
		e ? i$7[a] ?? i$7.top : "",
		o
	].filter(Boolean).join(" "), g = ["nabs-ui-textbox__input", s].filter(Boolean).join(" "), _ = ["nabs-ui-textbox__label", c].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: h,
		children: [e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: _,
			htmlFor: m,
			children: e
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: f,
			id: m,
			className: g,
			type: u,
			...d
		})]
	});
});
a$4.displayName = "Textbox";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-toolbar/dist/nabs-ui-toolbar.js
var r$5 = {
	left: "nabs-ui-toolbar__content--label-left",
	right: "nabs-ui-toolbar__content--label-right",
	top: "nabs-ui-toolbar__content--label-top",
	bottom: "nabs-ui-toolbar__content--label-bottom"
};
function i$6(e) {
	return e || "right";
}
var a$5 = (0, import_react.forwardRef)(function({ items: e, activeItemId: a, className: o = "", buttonClassName: s = "", iconClassName: c = "", labelClassName: l = "", onItemSelect: u, ...d }, f) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: f,
		className: ["nabs-ui-toolbar", o].filter(Boolean).join(" "),
		role: "toolbar",
		...d,
		children: e.map((e) => {
			let o = e.icon, d = !!e.label, f = e.id === a || e.pressed === !0, p = ["nabs-ui-toolbar__content", r$5[i$6(e.labelPosition)]].filter(Boolean).join(" "), m = [
				"nabs-ui-toolbar__button",
				f ? "nabs-ui-toolbar__button--active" : "",
				d ? "" : "nabs-ui-toolbar__button--icon-only",
				s
			].filter(Boolean).join(" "), h = ["nabs-ui-toolbar__icon", c].filter(Boolean).join(" "), g = ["nabs-ui-toolbar__label", l].filter(Boolean).join(" "), _ = typeof e.label == "string" ? e.label : e.title;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: m,
				disabled: e.disabled,
				title: e.title,
				"aria-label": _,
				"aria-pressed": typeof e.pressed == "boolean" ? e.pressed : void 0,
				onClick: (t) => {
					u?.({
						itemId: e.id,
						item: e,
						event: t
					});
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: p,
					children: [o ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(o, {
						className: h,
						"aria-hidden": "true",
						focusable: "false"
					}) : null, e.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: g,
						children: e.label
					}) : null]
				})
			}, e.id);
		})
	});
});
a$5.displayName = "Toolbar";
//#endregion
//#region node_modules/@net-advantage/nabs-ui-shell/dist/nabs-ui-shell.js
var i$3 = (0, import_react.forwardRef)(({ header: e, navigation: r, footer: i, children: a, className: o = "", headerClassName: s = "", navigationClassName: c = "", contentClassName: l = "", footerClassName: u = "", ...d }, f) => {
	let p = ["nabs-ui-shell", o].filter(Boolean).join(" "), m = ["nabs-ui-shell__header", s].filter(Boolean).join(" "), h = ["nabs-ui-shell__navigation", c].filter(Boolean).join(" "), g = ["nabs-ui-shell__content", l].filter(Boolean).join(" "), _ = ["nabs-ui-shell__footer", u].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: f,
		className: p,
		...d,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(r$1, {
			className: "nabs-ui-shell__layout",
			header: e,
			footer: i,
			leftSidePanel: r,
			headerClassName: m,
			footerClassName: _,
			leftSidePanelClassName: h,
			contentClassName: g,
			children: a
		})
	});
});
i$3.displayName = "Shell";
var a = (0, import_react.forwardRef)(function({ logo: e, title: t, byline: i, className: a = "", ...o }, s) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: s,
		className: ["nabs-ui-branding", a].filter(Boolean).join(" "),
		...o,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nabs-ui-branding__logo",
			"aria-hidden": "true",
			children: e
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nabs-ui-branding__text",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
				className: "nabs-ui-branding__title",
				children: t
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nabs-ui-branding__byline",
				children: i
			})]
		})]
	});
});
a.displayName = "Branding";
//#endregion
export { u as Accordion, h as Avatar, a as Branding, r as Button, a$1 as Cards, a$2 as Checkbox, i as Code, p as Combobox, a$3 as DatePicker, c as Dialog, s as DropdownList, f as DropdownMenu, b as DynamicForm, l as FileUpload, S as Graph, D as Grid, r$1 as Layout, L as Markdown, i$1 as Navigation, r$2 as Panel, i$2 as RadioButton, i$3 as Shell, l$1 as Signature, c$1 as SimpleGraphToolset, i$4 as Slider, b$1 as Stepper, r$3 as Tab, i$5 as Textarea, a$4 as Textbox, a$5 as Toolbar, d as agenticWorkflowToolset, f$1 as agenticWorkflowToolsets, l$2 as simpleGraphToolset, u$1 as simpleGraphToolsets };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQG5ldC1hZHZhbnRhZ2VfbmFicy11aS1zaGVsbC5qcyIsIm5hbWVzIjpbIm4iLCJyIiwicyIsImMiLCJsIiwiZSIsIm4iLCJpIiwiciIsInUiLCJkIiwiZiIsInAiLCJhIiwiaSIsIm4iLCJyIiwicyIsIm8iLCJtIiwiZSIsIm4iLCJlIiwiciIsImkiLCJhIiwiZSIsImkiLCJhIiwiZSIsInQiLCJyIiwiZSIsImMiLCJsIiwidSIsImQiLCJmIiwiZSIsIm4iLCJpIiwiYSIsInIiLCJ0IiwiaSIsImEiLCJlIiwidCIsIm8iLCJzIiwiZSIsInIiLCJuIiwidCIsImkiLCJhIiwibyIsImUiLCJ0IiwibCIsInUiLCJkIiwiaSIsInIiLCJ0IiwibiIsIm8iLCJhIiwibyIsInMiLCJlIiwibiIsImMiLCJsIiwidSIsImQiLCJmIiwicCIsIm0iLCJoIiwiZyIsIl8iLCJ2IiwieSIsInIiLCJhIiwibyIsInMiLCJjIiwiZSIsInQiLCJuIiwiYyIsImwiLCJ1IiwiZiIsInAiLCJtIiwiaCIsImciLCJfIiwidiIsInkiLCJlZSIsImIiLCJ4IiwidGUiLCJlIiwiciIsImkiLCJhIiwibiIsInQiLCJsIiwidSIsImUiLCJkIiwiZiIsInAiLCJpIiwibiIsInQiLCJtIiwiaCIsImciLCJfIiwidiIsInkiLCJiIiwieCIsInciLCJTIiwiQyIsIlQiLCJFIiwiYSIsIm8iLCJyIiwiYyIsImwiLCJ1IiwidCIsImQiLCJmIiwicCIsIm0iLCJoIiwiZyIsIl8iLCJ2IiwieSIsImIiLCJTIiwiRCIsInIiLCJpIiwiYSIsInQiLCJuIiwiciIsImkiLCJyIiwiZSIsInIiLCJpIiwiZSIsIm8iLCJzIiwiYyIsImwiLCJ0IiwibiIsInIiLCJpIiwiZSIsInQiLCJjIiwibCIsInUiLCJkIiwiZiIsImUiLCJuIiwicCIsImEiLCJoIiwiYiIsInQiLCJpIiwiciIsInIiLCJlIiwiaSIsImUiLCJ0IiwiaSIsImEiLCJlIiwidCIsInIiLCJpIiwiYSIsImUiLCJpIiwiZSIsInQiXSwic291cmNlcyI6WyIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWxheW91dC9kaXN0L25hYnMtdWktbGF5b3V0LmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1hY2NvcmRpb24vZGlzdC9uYWJzLXVpLWFjY29yZGlvbi5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktYXZhdGFyL2Rpc3QvbmFicy11aS1hdmF0YXIuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWJ1dHRvbnMvZGlzdC9uYWJzLXVpLWJ1dHRvbnMuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWNhcmRzL2Rpc3QvbmFicy11aS1jYXJkcy5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktY2hlY2tib3gvZGlzdC9uYWJzLXVpLWNoZWNrYm94LmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1jb2RlL2Rpc3QvbmFicy11aS1jb2RlLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1jb21ib2JveC9kaXN0L25hYnMtdWktY29tYm9ib3guanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWRhdGVwaWNrZXIvZGlzdC9uYWJzLXVpLWRhdGVwaWNrZXIuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWRpYWxvZy9kaXN0L25hYnMtdWktZGlhbG9nLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1kcm9wZG93bmxpc3QvZGlzdC9uYWJzLXVpLWRyb3Bkb3dubGlzdC5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktZHJvcGRvd25tZW51L2Rpc3QvbmFicy11aS1kcm9wZG93bm1lbnUuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLWR5bmFtaWNmb3JtL2Rpc3QvbmFicy11aS1keW5hbWljZm9ybS5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktZmlsZXVwbG9hZC9kaXN0L25hYnMtdWktZmlsZXVwbG9hZC5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktZ3JhcGgvZGlzdC9uYWJzLXVpLWdyYXBoLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1ncmlkL2Rpc3QvbmFicy11aS1ncmlkLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1tYXJrZG93bi9kaXN0L25hYnMtdWktbWFya2Rvd24uanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLW5hdmlnYXRpb24vZGlzdC9uYWJzLXVpLW5hdmlnYXRpb24uanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLXBhbmVsL2Rpc3QvbmFicy11aS1wYW5lbC5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktcmFkaW9idXR0b24vZGlzdC9uYWJzLXVpLXJhZGlvYnV0dG9uLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1zaWduYXR1cmUvZGlzdC9uYWJzLXVpLXNpZ25hdHVyZS5qcyIsIi4uLy4uL0BuZXQtYWR2YW50YWdlL25hYnMtdWktc2xpZGVyL2Rpc3QvbmFicy11aS1zbGlkZXIuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLXN0ZXBwZXIvZGlzdC9uYWJzLXVpLXN0ZXBwZXIuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLXRhYi9kaXN0L25hYnMtdWktdGFiLmpzIiwiLi4vLi4vQG5ldC1hZHZhbnRhZ2UvbmFicy11aS10ZXh0YXJlYS9kaXN0L25hYnMtdWktdGV4dGFyZWEuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLXRleHRib3gvZGlzdC9uYWJzLXVpLXRleHRib3guanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLXRvb2xiYXIvZGlzdC9uYWJzLXVpLXRvb2xiYXIuanMiLCIuLi8uLi9AbmV0LWFkdmFudGFnZS9uYWJzLXVpLXNoZWxsL2Rpc3QvbmFicy11aS1zaGVsbC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBqc3ggYXMgZSwganN4cyBhcyB0IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL0xheW91dC50c3hcbmZ1bmN0aW9uIG4oeyBhczogdCA9IFwiZGl2XCIsIGNsYXNzTmFtZTogbiA9IFwiXCIsIGNoaWxkcmVuOiByLCAuLi5pIH0pIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBlKHQsIHtcblx0XHRjbGFzc05hbWU6IG4sXG5cdFx0Li4uaSxcblx0XHRjaGlsZHJlbjogclxuXHR9KTtcbn1cbmZ1bmN0aW9uIHIoeyBoZWFkZXI6IHIsIGZvb3RlcjogaSwgbGVmdFNpZGVQYW5lbDogYSwgcmlnaHRTaWRlUGFuZWw6IG8sIGNoaWxkcmVuOiBzLCBjbGFzc05hbWU6IGMgPSBcIlwiLCBoZWFkZXJDbGFzc05hbWU6IGwgPSBcIlwiLCBmb290ZXJDbGFzc05hbWU6IHUgPSBcIlwiLCBsZWZ0U2lkZVBhbmVsQ2xhc3NOYW1lOiBkID0gXCJcIiwgcmlnaHRTaWRlUGFuZWxDbGFzc05hbWU6IGYgPSBcIlwiLCBjb250ZW50Q2xhc3NOYW1lOiBwID0gXCJcIiwgLi4ubSB9KSB7XG5cdGxldCBoID0gciAhPSBudWxsICYmIHIgIT09ICExLCBnID0gaSAhPSBudWxsICYmIGkgIT09ICExLCBfID0gYSAhPSBudWxsICYmIGEgIT09ICExLCB2ID0gbyAhPSBudWxsICYmIG8gIT09ICExLCB5ID0gW1xuXHRcdFwibmFicy11aS1sYXlvdXRfX2JvZHlcIixcblx0XHRfICYmIHYgPyBcIm5hYnMtdWktbGF5b3V0X19ib2R5LS13aXRoLWJvdGgtcGFuZWxzXCIgOiBcIlwiLFxuXHRcdF8gJiYgIXYgPyBcIm5hYnMtdWktbGF5b3V0X19ib2R5LS13aXRoLWxlZnQtcGFuZWxcIiA6IFwiXCIsXG5cdFx0IV8gJiYgdiA/IFwibmFicy11aS1sYXlvdXRfX2JvZHktLXdpdGgtcmlnaHQtcGFuZWxcIiA6IFwiXCJcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gdChcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBbXCJuYWJzLXVpLWxheW91dFwiLCBjXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0Li4ubSxcblx0XHRjaGlsZHJlbjogW1xuXHRcdFx0aCA/IC8qIEBfX1BVUkVfXyAqLyBlKG4sIHtcblx0XHRcdFx0YXM6IFwiaGVhZGVyXCIsXG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWxheW91dF9faGVhZGVyV3JhcHBlclwiLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGUoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogW1wibmFicy11aS1sYXlvdXRfX2hlYWRlclwiLCBsXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IHJcblx0XHRcdFx0fSlcblx0XHRcdH0pIDogbnVsbCxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyB0KFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiB5LFxuXHRcdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHRcdF8gPyAvKiBAX19QVVJFX18gKi8gZShuLCB7XG5cdFx0XHRcdFx0XHRhczogXCJhc2lkZVwiLFxuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBbXG5cdFx0XHRcdFx0XHRcdFwibmFicy11aS1sYXlvdXRfX3BhbmVsXCIsXG5cdFx0XHRcdFx0XHRcdFwibmFicy11aS1sYXlvdXRfX3BhbmVsLS1sZWZ0XCIsXG5cdFx0XHRcdFx0XHRcdGRcblx0XHRcdFx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGFcblx0XHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIGUobiwge1xuXHRcdFx0XHRcdFx0YXM6IFwic2VjdGlvblwiLFxuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBbXCJuYWJzLXVpLWxheW91dF9fY29udGVudFwiLCBwXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogc1xuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdHYgPyAvKiBAX19QVVJFX18gKi8gZShuLCB7XG5cdFx0XHRcdFx0XHRhczogXCJhc2lkZVwiLFxuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBbXG5cdFx0XHRcdFx0XHRcdFwibmFicy11aS1sYXlvdXRfX3BhbmVsXCIsXG5cdFx0XHRcdFx0XHRcdFwibmFicy11aS1sYXlvdXRfX3BhbmVsLS1yaWdodFwiLFxuXHRcdFx0XHRcdFx0XHRmXG5cdFx0XHRcdFx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBvXG5cdFx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRcdF1cblx0XHRcdH0pLFxuXHRcdFx0ZyA/IC8qIEBfX1BVUkVfXyAqLyBlKG4sIHtcblx0XHRcdFx0YXM6IFwiZm9vdGVyXCIsXG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWxheW91dF9fZm9vdGVyV3JhcHBlclwiLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGUoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogW1wibmFicy11aS1sYXlvdXRfX2Zvb3RlclwiLCB1XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGlcblx0XHRcdFx0fSlcblx0XHRcdH0pIDogbnVsbFxuXHRcdF1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHIgYXMgTGF5b3V0IH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUVmZmVjdCBhcyB0LCB1c2VJZCBhcyBuLCB1c2VNZW1vIGFzIHIsIHVzZVN0YXRlIGFzIGkgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBhLCBqc3hzIGFzIG8gfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvYWNjb3JkaW9uLnV0aWxzLnRzXG5mdW5jdGlvbiBzKGUsIHQsIG4pIHtcblx0bGV0IHIgPSBlID8/IFtdLCBpID0gbmV3IFNldCh0Lm1hcCgoZSkgPT4gZS5pZCkpLCBhID0gci5maWx0ZXIoKGUsIHQsIG4pID0+IGkuaGFzKGUpICYmIG4uaW5kZXhPZihlKSA9PT0gdCk7XG5cdHJldHVybiBuID09PSBcInNpbmdsZVwiID8gYS5zbGljZSgwLCAxKSA6IGE7XG59XG5mdW5jdGlvbiBjKGUsIHQsIG4pIHtcblx0bGV0IHIgPSBlLmluY2x1ZGVzKHQpO1xuXHRyZXR1cm4gbiA9PT0gXCJzaW5nbGVcIiA/IHIgPyBbXSA6IFt0XSA6IHIgPyBlLmZpbHRlcigoZSkgPT4gZSAhPT0gdCkgOiBbLi4uZSwgdF07XG59XG5mdW5jdGlvbiBsKGUpIHtcblx0cmV0dXJuIFtcIm5hYnMtdWktYWNjb3JkaW9uXCIsIGVdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9BY2NvcmRpb24udHN4XG52YXIgdSA9IGUoZnVuY3Rpb24oeyBpdGVtczogZSwgbW9kZTogdSA9IFwibXVsdGlwbGVcIiwgZXhwYW5kZWRJdGVtSWRzOiBkLCBkZWZhdWx0RXhwYW5kZWRJdGVtSWRzOiBmLCBvbkV4cGFuZGVkSXRlbUlkc0NoYW5nZTogcCwgY2xhc3NOYW1lOiBtID0gXCJcIiwgaXRlbUNsYXNzTmFtZTogaCA9IFwiXCIsIHRyaWdnZXJDbGFzc05hbWU6IGcgPSBcIlwiLCBwYW5lbENsYXNzTmFtZTogXyA9IFwiXCIsIGlkOiB2LCAuLi55IH0sIGIpIHtcblx0bGV0IHggPSBuKCksIFMgPSB2ID8/IGBuYWJzLXVpLWFjY29yZGlvbi0ke3gucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBbQywgd10gPSBpKHIoKCkgPT4gcyhmLCBlLCB1KSwgW1xuXHRcdGYsXG5cdFx0ZSxcblx0XHR1XG5cdF0pKTtcblx0dCgoKSA9PiB7XG5cdFx0dygodCkgPT4gcyh0LCBlLCB1KSk7XG5cdH0sIFtlLCB1XSk7XG5cdGxldCBUID0gcigoKSA9PiBzKGQgPT09IHZvaWQgMCA/IEMgOiBkLCBlLCB1KSwgW1xuXHRcdGQsXG5cdFx0Qyxcblx0XHRlLFxuXHRcdHVcblx0XSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gYShcInNlY3Rpb25cIiwge1xuXHRcdHJlZjogYixcblx0XHRpZDogUyxcblx0XHRjbGFzc05hbWU6IGwobSksXG5cdFx0Li4ueSxcblx0XHRjaGlsZHJlbjogZS5tYXAoKGUpID0+IHtcblx0XHRcdGxldCB0ID0gVC5pbmNsdWRlcyhlLmlkKSwgbiA9IGAke1N9LXBhbmVsLSR7ZS5pZH1gLCByID0gYCR7U30tdHJpZ2dlci0ke2UuaWR9YCwgaSA9IFtcblx0XHRcdFx0XCJuYWJzLXVpLWFjY29yZGlvbl9faXRlbVwiLFxuXHRcdFx0XHR0ID8gXCJuYWJzLXVpLWFjY29yZGlvbl9faXRlbS0tZXhwYW5kZWRcIiA6IFwiXCIsXG5cdFx0XHRcdGhcblx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBzID0gW1wibmFicy11aS1hY2NvcmRpb25fX3RyaWdnZXJcIiwgZ10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBsID0gW1wibmFicy11aS1hY2NvcmRpb25fX3BhbmVsXCIsIF9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZiA9ICh0KSA9PiB7XG5cdFx0XHRcdGxldCBuID0gYyhULCBlLmlkLCB1KTtcblx0XHRcdFx0ZCA9PT0gdm9pZCAwICYmIHcobiksIHA/Lih7XG5cdFx0XHRcdFx0aXRlbUlkOiBlLmlkLFxuXHRcdFx0XHRcdGV4cGFuZGVkSXRlbUlkczogbixcblx0XHRcdFx0XHRldmVudDogdFxuXHRcdFx0XHR9KTtcblx0XHRcdH07XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG8oXCJhcnRpY2xlXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBpLFxuXHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBhKFwiaDNcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJtLTBcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogdCA/IC8qIEBfX1BVUkVfXyAqLyBvKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdGlkOiByLFxuXHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogcyxcblx0XHRcdFx0XHRcdFwiYXJpYS1leHBhbmRlZFwiOiBcInRydWVcIixcblx0XHRcdFx0XHRcdFwiYXJpYS1jb250cm9sc1wiOiBuLFxuXHRcdFx0XHRcdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XHRcdFx0XHRvbkNsaWNrOiBmLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gYShcInNwYW5cIiwgeyBjaGlsZHJlbjogZS5oZWFkZXIgfSksIC8qIEBfX1BVUkVfXyAqLyBhKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWFjY29yZGlvbl9fdHJpZ2dlckljb25cIixcblx0XHRcdFx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiK1wiXG5cdFx0XHRcdFx0XHR9KV1cblx0XHRcdFx0XHR9KSA6IC8qIEBfX1BVUkVfXyAqLyBvKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdGlkOiByLFxuXHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogcyxcblx0XHRcdFx0XHRcdFwiYXJpYS1leHBhbmRlZFwiOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XHRcImFyaWEtY29udHJvbHNcIjogbixcblx0XHRcdFx0XHRcdGRpc2FibGVkOiBlLmRpc2FibGVkLFxuXHRcdFx0XHRcdFx0b25DbGljazogZixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGEoXCJzcGFuXCIsIHsgY2hpbGRyZW46IGUuaGVhZGVyIH0pLCAvKiBAX19QVVJFX18gKi8gYShcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1hY2NvcmRpb25fX3RyaWdnZXJJY29uXCIsXG5cdFx0XHRcdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIitcIlxuXHRcdFx0XHRcdFx0fSldXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBhKFwic2VjdGlvblwiLCB7XG5cdFx0XHRcdFx0aWQ6IG4sXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBsLFxuXHRcdFx0XHRcdHJvbGU6IFwicmVnaW9uXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogcixcblx0XHRcdFx0XHRoaWRkZW46ICF0LFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBlLmNvbnRlbnRcblx0XHRcdFx0fSldXG5cdFx0XHR9LCBlLmlkKTtcblx0XHR9KVxuXHR9KTtcbn0pO1xudS5kaXNwbGF5TmFtZSA9IFwiQWNjb3JkaW9uXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHUgYXMgQWNjb3JkaW9uIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUVmZmVjdCBhcyB0LCB1c2VJZCBhcyBuLCB1c2VMYXlvdXRFZmZlY3QgYXMgciwgdXNlUmVmIGFzIGksIHVzZVN0YXRlIGFzIGEgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCBhcyBvIH0gZnJvbSBcInJlYWN0LWRvbVwiO1xuaW1wb3J0IHsgRnJhZ21lbnQgYXMgcywganN4IGFzIGMsIGpzeHMgYXMgbCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIC4uL25hYnMtdWktZHJvcGRvd25tZW51L3NyYy9kcm9wZG93bm1lbnUudXRpbHMudHNcbmZ1bmN0aW9uIHUoZSkge1xuXHRyZXR1cm4gISEoZSAmJiBcInR5cGVcIiBpbiBlICYmIGUudHlwZSA9PT0gXCJkaXZpZGVyXCIpO1xufVxuZnVuY3Rpb24gZChlKSB7XG5cdHJldHVybiBlLmxhYmVsID8/IGUuY2hpbGRyZW4gPz8gXCJNZW51IGl0ZW1cIjtcbn1cbmZ1bmN0aW9uIGYoZSwgdCkge1xuXHRyZXR1cm4gZS52YWx1ZSA/PyBlLmxhYmVsID8/IGBpdGVtLSR7dH1gO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vbmFicy11aS1kcm9wZG93bm1lbnUvc3JjL0Ryb3Bkb3duTWVudS50c3hcbmZ1bmN0aW9uIHAoeyBsYWJlbDogZSA9IFwiTWVudVwiLCB0cmlnZ2VyQ29udGVudDogcCwgdHJpZ2dlckFyaWFMYWJlbDogbSwgbWVudUFsaWduOiBoID0gXCJzdGFydFwiLCBpdGVtczogZyA9IFtdLCBjbGFzc05hbWU6IF8gPSBcIlwiLCB0cmlnZ2VyQ2xhc3NOYW1lOiB2ID0gXCJcIiwgbWVudUNsYXNzTmFtZTogeSA9IFwiXCIsIGl0ZW1DbGFzc05hbWU6IGIgPSBcIlwiLCBkaXZpZGVyQ2xhc3NOYW1lOiB4ID0gXCJcIiwgaWQ6IFMsIG9uSXRlbVNlbGVjdDogQywgLi4udyB9KSB7XG5cdGxldCBbVCwgRV0gPSBhKCExKSwgRCA9IGkobnVsbCksIE8gPSBpKG51bGwpLCBrID0gaShudWxsKSwgQSA9IG4oKSwgaiA9IFMgPz8gYG5hYnMtdWktZHJvcGRvd25tZW51LSR7QS5yZXBsYWNlKC86L2csIFwiXCIpfWAsIE0gPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudVwiLCBfXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIE4gPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9fdHJpZ2dlclwiLCB2XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFAgPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9fbWVudVwiLCB5XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEYgPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbVwiLCBiXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEkgPSBbXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9fZGl2aWRlclwiLCB4XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHQoKCkgPT4ge1xuXHRcdGxldCBlID0gKGUpID0+IHtcblx0XHRcdGUudGFyZ2V0IGluc3RhbmNlb2YgTm9kZSAmJiBELmN1cnJlbnQgJiYgIUQuY3VycmVudC5jb250YWlucyhlLnRhcmdldCkgJiYgay5jdXJyZW50ICYmICFrLmN1cnJlbnQuY29udGFpbnMoZS50YXJnZXQpICYmIEUoITEpO1xuXHRcdH0sIHQgPSAoZSkgPT4ge1xuXHRcdFx0ZS5rZXkgPT09IFwiRXNjYXBlXCIgJiYgRSghMSk7XG5cdFx0fTtcblx0XHRyZXR1cm4gZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIGUpLCBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCB0KSwgKCkgPT4ge1xuXHRcdFx0ZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIGUpLCBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCB0KTtcblx0XHR9O1xuXHR9LCBbXSksIHIoKCkgPT4ge1xuXHRcdGlmICghVCB8fCAhTy5jdXJyZW50KSByZXR1cm47XG5cdFx0bGV0IGUgPSAoKSA9PiB7XG5cdFx0XHRsZXQgZSA9IE8uY3VycmVudD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksIHQgPSBrLmN1cnJlbnQ/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLCBuID0gay5jdXJyZW50O1xuXHRcdFx0aWYgKCFlIHx8ICF0IHx8ICFuKSByZXR1cm47XG5cdFx0XHRsZXQgciA9IE1hdGgubWF4KGUud2lkdGgsIHQud2lkdGgpLCBpID0gd2luZG93LmlubmVyV2lkdGggLSByIC0gOCwgYSA9IGggPT09IFwiZW5kXCIgPyBlLnJpZ2h0IC0gciA6IGUubGVmdCwgbyA9IE1hdGgubWF4KDgsIE1hdGgubWluKGEsIGkpKSwgcyA9IE1hdGgubWF4KDgsIGUuYm90dG9tICsgMTApO1xuXHRcdFx0bi5zdHlsZS5wb3NpdGlvbiA9IFwiZml4ZWRcIiwgbi5zdHlsZS50b3AgPSBgJHtzfXB4YCwgbi5zdHlsZS5sZWZ0ID0gYCR7b31weGAsIG4uc3R5bGUucmlnaHQgPSBcImF1dG9cIiwgbi5zdHlsZS5taW5XaWR0aCA9IGAke3J9cHhgLCBuLnN0eWxlLnZpc2liaWxpdHkgPSBcInZpc2libGVcIjtcblx0XHR9O1xuXHRcdHJldHVybiBrLmN1cnJlbnQgJiYgKGsuY3VycmVudC5zdHlsZS52aXNpYmlsaXR5ID0gXCJoaWRkZW5cIiksIGUoKSwgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgZSksIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIGUsICEwKSwgKCkgPT4ge1xuXHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgZSksIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIGUsICEwKTtcblx0XHR9O1xuXHR9LCBbaCwgVF0pO1xuXHRsZXQgTCA9IChlLCB0KSA9PiB7XG5cdFx0aWYgKEUoITEpLCBlLmRpc2FibGVkKSB7XG5cdFx0XHR0LnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdEM/LihlLCB0KSwgZS5vblNlbGVjdD8uKGUsIHQpO1xuXHR9O1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGwoXCJkaXZcIiwge1xuXHRcdHJlZjogRCxcblx0XHRjbGFzc05hbWU6IE0sXG5cdFx0Li4udyxcblx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBjKFwiYnV0dG9uXCIsIHtcblx0XHRcdHJlZjogTyxcblx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRjbGFzc05hbWU6IE4sXG5cdFx0XHRcImFyaWEtaGFzcG9wdXBcIjogXCJtZW51XCIsXG5cdFx0XHRcImFyaWEtY29udHJvbHNcIjogaixcblx0XHRcdFwiYXJpYS1sYWJlbFwiOiBtID8/IGUsXG5cdFx0XHRvbkNsaWNrOiAoKSA9PiBFKChlKSA9PiAhZSksXG5cdFx0XHRjaGlsZHJlbjogcCA/PyAvKiBAX19QVVJFX18gKi8gbChzLCB7IGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X190cmlnZ2VyTGFiZWxcIixcblx0XHRcdFx0Y2hpbGRyZW46IGVcblx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gYyhcInNwYW5cIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kcm9wZG93bm1lbnVfX3RyaWdnZXJDaGV2cm9uXCIsXG5cdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBcIuKWvlwiXG5cdFx0XHR9KV0gfSlcblx0XHR9KSwgVCAmJiB0eXBlb2YgZG9jdW1lbnQgPCBcInVcIiA/IG8oLyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdFx0cmVmOiBrLFxuXHRcdFx0aWQ6IGosXG5cdFx0XHRjbGFzc05hbWU6IFAsXG5cdFx0XHRcImFyaWEtbGFiZWxcIjogZSxcblx0XHRcdGNoaWxkcmVuOiBnLm1hcCgoZSwgdCkgPT4ge1xuXHRcdFx0XHRpZiAodShlKSkgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBjKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IEksXG5cdFx0XHRcdFx0cm9sZTogXCJzZXBhcmF0b3JcIixcblx0XHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiXG5cdFx0XHRcdH0sIGBkaXZpZGVyLSR7dH1gKTtcblx0XHRcdFx0bGV0IG4gPSBkKGUpLCByID0gW1xuXHRcdFx0XHRcdEYsXG5cdFx0XHRcdFx0ZS5kaXNhYmxlZCA/IFwibmFicy11aS1kcm9wZG93bm1lbnVfX2l0ZW0tLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdFx0XHRcdGUuZGFuZ2VyID8gXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbS0tZGFuZ2VyXCIgOiBcIlwiXG5cdFx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBpID0ge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogcixcblx0XHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogZS5kaXNhYmxlZCB8fCB2b2lkIDBcblx0XHRcdFx0fTtcblx0XHRcdFx0cmV0dXJuIGUuaHJlZiA/IC8qIEBfX1BVUkVfXyAqLyBsKFwiYVwiLCB7XG5cdFx0XHRcdFx0Li4uaSxcblx0XHRcdFx0XHRocmVmOiBlLmRpc2FibGVkID8gdm9pZCAwIDogZS5ocmVmLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICh0KSA9PiBMKGUsIHQpLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbUxhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogblxuXHRcdFx0XHRcdH0pLCBlLmRlc2NyaXB0aW9uID8gLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbURlc2NyaXB0aW9uXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5kZXNjcmlwdGlvblxuXHRcdFx0XHRcdH0pIDogbnVsbF1cblx0XHRcdFx0fSwgZihlLCB0KSkgOiAvKiBAX19QVVJFX18gKi8gbChcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRjbGFzc05hbWU6IHIsXG5cdFx0XHRcdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XHRcdFx0b25DbGljazogKHQpID0+IEwoZSwgdCksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gYyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtTGFiZWxcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBuXG5cdFx0XHRcdFx0fSksIGUuZGVzY3JpcHRpb24gPyAvKiBAX19QVVJFX18gKi8gYyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtRGVzY3JpcHRpb25cIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmRlc2NyaXB0aW9uXG5cdFx0XHRcdFx0fSkgOiBudWxsXVxuXHRcdFx0XHR9LCBmKGUsIHQpKTtcblx0XHRcdH0pXG5cdFx0fSksIGRvY3VtZW50LmJvZHkpIDogbnVsbF1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYXZhdGFyLnV0aWxzLnRzXG5mdW5jdGlvbiBtKGUpIHtcblx0bGV0IHQgPSBlLnRyaW0oKS5zcGxpdCgvXFxzKy8pLmZpbHRlcihCb29sZWFuKTtcblx0cmV0dXJuIHQubGVuZ3RoID09PSAwID8gXCI/XCIgOiB0LnNsaWNlKDAsIDIpLm1hcCgoZSkgPT4gZVswXT8udG9VcHBlckNhc2UoKSA/PyBcIlwiKS5qb2luKFwiXCIpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL0F2YXRhci50c3hcbnZhciBoID0gZShmdW5jdGlvbih7IGF1dGhlbnRpY2F0ZWQ6IGUgPSAhMSwgbmFtZTogdCA9IFwiR3Vlc3QgdXNlclwiLCBhdmF0YXJVcmw6IG4gPSBcIlwiLCBsb2dpbkhyZWY6IHIsIHByb2ZpbGVIcmVmOiBpID0gXCIjXCIsIGxvZ291dEhyZWY6IGEgPSBcIiNcIiwgb25Mb2dpbkNsaWNrOiBvLCBvblByb2ZpbGVDbGljazogdSwgb25Mb2dvdXRDbGljazogZCwgY2xhc3NOYW1lOiBmID0gXCJcIiwgbWVudUxhYmVsOiBoLCAuLi5nIH0sIF8pIHtcblx0bGV0IHYgPSB0LnRyaW0oKSB8fCBcIkd1ZXN0IHVzZXJcIiwgeSA9IG0odiksIGIgPSBbXG5cdFx0XCJuYWJzLXVpLWF2YXRhclwiLFxuXHRcdGUgPyBcIm5hYnMtdWktYXZhdGFyLS1hdXRoZW50aWNhdGVkXCIgOiBcIm5hYnMtdWktYXZhdGFyLS11bmF1dGhlbnRpY2F0ZWRcIixcblx0XHRmXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCB4ID0gKGUpID0+IHtcblx0XHRvICYmIChlLnByZXZlbnREZWZhdWx0KCksIG8oZSkpO1xuXHR9LCBTID0gKGUpID0+IHtcblx0XHR1ICYmIChlLnByZXZlbnREZWZhdWx0KCksIHUoZSkpO1xuXHR9LCBDID0gKGUpID0+IHtcblx0XHRkICYmIChlLnByZXZlbnREZWZhdWx0KCksIGQoZSkpO1xuXHR9O1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdHJlZjogXyxcblx0XHRjbGFzc05hbWU6IGIsXG5cdFx0Li4uZyxcblx0XHRjaGlsZHJlbjogZSA/IC8qIEBfX1BVUkVfXyAqLyBjKHAsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWF2YXRhcl9fbWVudVJvb3RcIixcblx0XHRcdGxhYmVsOiBgJHt2fSBhY2NvdW50IG1lbnVgLFxuXHRcdFx0dHJpZ2dlckFyaWFMYWJlbDogaCA/PyBgJHt2fSBhY2NvdW50IG1lbnVgLFxuXHRcdFx0bWVudUFsaWduOiBcImVuZFwiLFxuXHRcdFx0dHJpZ2dlckNvbnRlbnQ6IC8qIEBfX1BVUkVfXyAqLyBsKHMsIHsgY2hpbGRyZW46IFtcblx0XHRcdFx0LyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1hdmF0YXJfX2F2YXRhclwiLFxuXHRcdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IG4gPyAvKiBAX19QVVJFX18gKi8gYyhcImltZ1wiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1hdmF0YXJfX2ltYWdlXCIsXG5cdFx0XHRcdFx0XHRzcmM6IG4sXG5cdFx0XHRcdFx0XHRhbHQ6IFwiXCJcblx0XHRcdFx0XHR9KSA6IHlcblx0XHRcdFx0fSksXG5cdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19uYW1lXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IHZcblx0XHRcdFx0fSksXG5cdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19jaGV2cm9uXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogXCLilr5cIlxuXHRcdFx0XHR9KVxuXHRcdFx0XSB9KSxcblx0XHRcdHRyaWdnZXJDbGFzc05hbWU6IFwibmFicy11aS1hdmF0YXJfX3RyaWdnZXJcIixcblx0XHRcdG1lbnVDbGFzc05hbWU6IFwibmFicy11aS1hdmF0YXJfX21lbnVcIixcblx0XHRcdGl0ZW1DbGFzc05hbWU6IFwibmFicy11aS1hdmF0YXJfX21lbnVJdGVtXCIsXG5cdFx0XHRpdGVtczogW3tcblx0XHRcdFx0bGFiZWw6IFwiUHJvZmlsZVwiLFxuXHRcdFx0XHRocmVmOiBpLFxuXHRcdFx0XHRvblNlbGVjdDogKGUsIHQpID0+IFModClcblx0XHRcdH0sIHtcblx0XHRcdFx0bGFiZWw6IFwiTG9nb3V0XCIsXG5cdFx0XHRcdGhyZWY6IGEsXG5cdFx0XHRcdGRhbmdlcjogITAsXG5cdFx0XHRcdG9uU2VsZWN0OiAoZSwgdCkgPT4gQyh0KVxuXHRcdFx0fV1cblx0XHR9KSA6IHIgPyAvKiBAX19QVVJFX18gKi8gbChcImFcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19sb2dpblwiLFxuXHRcdFx0aHJlZjogcixcblx0XHRcdG9uQ2xpY2s6IHgsXG5cdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWF2YXRhcl9fYXZhdGFyIG5hYnMtdWktYXZhdGFyX19hdmF0YXItLXBsYWNlaG9sZGVyXCIsXG5cdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiB5XG5cdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19sb2dpblRleHRcIixcblx0XHRcdFx0Y2hpbGRyZW46IFwiTG9naW5cIlxuXHRcdFx0fSldXG5cdFx0fSkgOiAvKiBAX19QVVJFX18gKi8gbChcImJ1dHRvblwiLCB7XG5cdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19sb2dpblwiLFxuXHRcdFx0b25DbGljazogeCxcblx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYXZhdGFyX19hdmF0YXIgbmFicy11aS1hdmF0YXJfX2F2YXRhci0tcGxhY2Vob2xkZXJcIixcblx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdFx0Y2hpbGRyZW46IHlcblx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gYyhcInNwYW5cIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1hdmF0YXJfX2xvZ2luVGV4dFwiLFxuXHRcdFx0XHRjaGlsZHJlbjogXCJMb2dpblwiXG5cdFx0XHR9KV1cblx0XHR9KVxuXHR9KTtcbn0pO1xuaC5kaXNwbGF5TmFtZSA9IFwiQXZhdGFyXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGggYXMgQXZhdGFyIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyB0IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2J1dHRvbi51dGlscy50c1xudmFyIG4gPSB7XG5cdHByaW1hcnk6IFwibmFicy11aS1idXR0b24tLXByaW1hcnlcIixcblx0c2Vjb25kYXJ5OiBcIm5hYnMtdWktYnV0dG9uLS1zZWNvbmRhcnlcIixcblx0Z2hvc3Q6IFwibmFicy11aS1idXR0b24tLWdob3N0XCJcbn0sIHIgPSBlKGZ1bmN0aW9uKHsgY2hpbGRyZW46IGUsIGNsYXNzTmFtZTogciA9IFwiXCIsIHZhcmlhbnQ6IGkgPSBcInByaW1hcnlcIiwgdHlwZTogYSA9IFwiYnV0dG9uXCIsIC4uLm8gfSwgcykge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHQoXCJidXR0b25cIiwge1xuXHRcdHJlZjogcyxcblx0XHRjbGFzc05hbWU6IFtcblx0XHRcdFwibmFicy11aS1idXR0b25cIixcblx0XHRcdG5baV0gPz8gbi5wcmltYXJ5LFxuXHRcdFx0clxuXHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdHR5cGU6IGEsXG5cdFx0Li4ubyxcblx0XHRjaGlsZHJlbjogZVxuXHR9KTtcbn0pO1xuci5kaXNwbGF5TmFtZSA9IFwiQnV0dG9uXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHIgYXMgQnV0dG9uIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyB0LCBqc3hzIGFzIG4gfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvY2FyZHMudXRpbHMudHNcbmZ1bmN0aW9uIHIoZSkge1xuXHRyZXR1cm4gZSA9PT0gdm9pZCAwID8gMSA6IE51bWJlci5pc0Zpbml0ZShlKSA/IE1hdGgubWluKDEyLCBNYXRoLm1heCgxLCBNYXRoLmZsb29yKGUpKSkgOiAxO1xufVxuZnVuY3Rpb24gaShlLCB0LCBuKSB7XG5cdHJldHVybiB0ID09PSBcIlpcIiA/IFsuLi5lXS5zb3J0KCh0LCByKSA9PiB7XG5cdFx0bGV0IGkgPSBlLmZpbmRJbmRleCgoZSkgPT4gZS5pZCA9PT0gdC5pZCksIGEgPSBlLmZpbmRJbmRleCgoZSkgPT4gZS5pZCA9PT0gci5pZCksIG8gPSBNYXRoLmZsb29yKGkgLyBuKSwgcyA9IE1hdGguZmxvb3IoYSAvIG4pO1xuXHRcdGlmIChvICE9PSBzKSByZXR1cm4gbyAtIHM7XG5cdFx0bGV0IGMgPSBpICUgbiwgbCA9IGEgJSBuO1xuXHRcdHJldHVybiAobyAlIDIgPT0gMCA/IGMgOiBuIC0gMSAtIGMpIC0gKHMgJSAyID09IDAgPyBsIDogbiAtIDEgLSBsKTtcblx0fSkgOiBlO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL0NhcmRzLnRzeFxudmFyIGEgPSBlKCh7IGl0ZW1zOiBlLCBsYXlvdXQ6IGEgPSBcIk5cIiwgY29sdW1uczogbywgY2xhc3NOYW1lOiBzID0gXCJcIiwgaXRlbUNsYXNzTmFtZTogYyA9IFwiXCIsIGhlYWRlckNsYXNzTmFtZTogbCA9IFwiXCIsIGNvbnRlbnRDbGFzc05hbWU6IHUgPSBcIlwiLCBhY3Rpb25zQ2xhc3NOYW1lOiBkID0gXCJcIiwgLi4uZiB9LCBwKSA9PiB7XG5cdGxldCBtID0gcihvKSwgaCA9IFtcIm5hYnMtdWktY2FyZHNcIiwgc10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBnID0gW1wibmFicy11aS1jYXJkc19fZ3JpZFwiLCBgbmFicy11aS1jYXJkc19fZ3JpZC0tY29sdW1ucy0ke219YF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBfID0gaShlLCBhLCBtKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyB0KFwic2VjdGlvblwiLCB7XG5cdFx0cmVmOiBwLFxuXHRcdGNsYXNzTmFtZTogaCxcblx0XHQuLi5mLFxuXHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gdChcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IGcsXG5cdFx0XHRjaGlsZHJlbjogXy5tYXAoKGUpID0+IHtcblx0XHRcdFx0bGV0IHIgPSBbXCJuYWJzLXVpLWNhcmRzX19jYXJkXCIsIGNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaSA9IGUuaGVhZGVyICE9IG51bGwgJiYgZS5oZWFkZXIgIT09ICExLCBhID0gZS5jb250ZW50ICE9IG51bGwgJiYgZS5jb250ZW50ICE9PSAhMSwgbyA9IGUuYWN0aW9ucyAhPSBudWxsICYmIGUuYWN0aW9ucyAhPT0gITE7XG5cdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gbihcImFydGljbGVcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogcixcblx0XHRcdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHRcdFx0aSA/IC8qIEBfX1BVUkVfXyAqLyB0KFwiaGVhZGVyXCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBbXCJuYWJzLXVpLWNhcmRzX19oZWFkZXJcIiwgbF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5oZWFkZXJcblx0XHRcdFx0XHRcdH0pIDogbnVsbCxcblx0XHRcdFx0XHRcdGEgPyAvKiBAX19QVVJFX18gKi8gdChcImRpdlwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogW1wibmFicy11aS1jYXJkc19fY29udGVudFwiLCB1XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmNvbnRlbnRcblx0XHRcdFx0XHRcdH0pIDogbnVsbCxcblx0XHRcdFx0XHRcdG8gPyAvKiBAX19QVVJFX18gKi8gdChcImRpdlwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogW1wibmFicy11aS1jYXJkc19fYWN0aW9uc1wiLCBkXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmFjdGlvbnNcblx0XHRcdFx0XHRcdH0pIDogbnVsbFxuXHRcdFx0XHRcdF1cblx0XHRcdFx0fSwgZS5pZCk7XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH0pO1xufSk7XG5hLmRpc3BsYXlOYW1lID0gXCJDYXJkc1wiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhIGFzIENhcmRzIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUlkIGFzIHQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBuLCBqc3hzIGFzIHIgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvY2hlY2tib3gudXRpbHMudHNcbnZhciBpID0ge1xuXHRyaWdodDogXCJuYWJzLXVpLWNoZWNrYm94LS1sYWJlbC1yaWdodFwiLFxuXHRsZWZ0OiBcIm5hYnMtdWktY2hlY2tib3gtLWxhYmVsLWxlZnRcIixcblx0dG9wOiBcIm5hYnMtdWktY2hlY2tib3gtLWxhYmVsLXRvcFwiLFxuXHRib3R0b206IFwibmFicy11aS1jaGVja2JveC0tbGFiZWwtYm90dG9tXCJcbn0sIGEgPSBlKGZ1bmN0aW9uKHsgbGFiZWw6IGUgPSBcIkNoZWNrYm94XCIsIGxhYmVsUG9zaXRpb246IGEgPSBcInJpZ2h0XCIsIGNsYXNzTmFtZTogbyA9IFwiXCIsIGlucHV0Q2xhc3NOYW1lOiBzID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IGMgPSBcIlwiLCBpZDogbCwgZGlzYWJsZWQ6IHUsIC4uLmQgfSwgZikge1xuXHRsZXQgcCA9IHQoKSwgbSA9IGwgPz8gYG5hYnMtdWktY2hlY2tib3gtJHtwLnJlcGxhY2UoLzovZywgXCJcIil9YCwgaCA9IFtcblx0XHRcIm5hYnMtdWktY2hlY2tib3hcIixcblx0XHR1ID8gXCJuYWJzLXVpLWNoZWNrYm94LS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRpW2FdID8/IGkucmlnaHQsXG5cdFx0b1xuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktY2hlY2tib3hfX2lucHV0XCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgXyA9IFtcIm5hYnMtdWktY2hlY2tib3hfX2xhYmVsXCIsIGNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyByKFwibGFiZWxcIiwge1xuXHRcdGNsYXNzTmFtZTogaCxcblx0XHRodG1sRm9yOiBtLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG4oXCJpbnB1dFwiLCB7XG5cdFx0XHRyZWY6IGYsXG5cdFx0XHRpZDogbSxcblx0XHRcdGNsYXNzTmFtZTogZyxcblx0XHRcdHR5cGU6IFwiY2hlY2tib3hcIixcblx0XHRcdGRpc2FibGVkOiB1LFxuXHRcdFx0Li4uZFxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gbihcInNwYW5cIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBfLFxuXHRcdFx0Y2hpbGRyZW46IGVcblx0XHR9KV1cblx0fSk7XG59KTtcbmEuZGlzcGxheU5hbWUgPSBcIkNoZWNrYm94XCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGEgYXMgQ2hlY2tib3ggfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIHQsIGpzeHMgYXMgbiB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9jb2RlLnV0aWxzLnRzXG52YXIgciA9IHtcblx0aHRtbDogXCJIVE1MXCIsXG5cdGNzczogXCJDU1NcIixcblx0anNvbjogXCJKU09OXCIsXG5cdGNzaGFycDogXCJDI1wiXG59LCBpID0gZSgoeyBjb2RlOiBlLCBsYW5ndWFnZTogaSA9IFwiaHRtbFwiLCBzaG93TGluZU51bWJlcnM6IGEgPSAhMSwgd3JhcDogbyA9ICExLCB0aXRsZTogcywgY2xhc3NOYW1lOiBjID0gXCJcIiwgcHJlQ2xhc3NOYW1lOiBsID0gXCJcIiwgY29kZUNsYXNzTmFtZTogdSA9IFwiXCIsIC4uLmQgfSwgZikgPT4ge1xuXHRsZXQgcCA9IFtcIm5hYnMtdWktY29kZVwiLCBjXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIG0gPSBbXG5cdFx0XCJuYWJzLXVpLWNvZGVfX3ByZVwiLFxuXHRcdG8gPyBcIm5hYnMtdWktY29kZV9fcHJlLS13cmFwXCIgOiBcIlwiLFxuXHRcdGEgPyBcIm5hYnMtdWktY29kZV9fcHJlLS1saW5lTnVtYmVyc1wiIDogXCJcIixcblx0XHRsXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBoID0gW1xuXHRcdFwibmFicy11aS1jb2RlX19zbmlwcGV0XCIsXG5cdFx0YG5hYnMtdWktY29kZV9fc25pcHBldC0tJHtpfWAsXG5cdFx0dVxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IGUucmVwbGFjZSgvXFxyXFxuL2csIFwiXFxuXCIpLCBfID0gZy5zcGxpdChcIlxcblwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBuKFwic2VjdGlvblwiLCB7XG5cdFx0cmVmOiBmLFxuXHRcdGNsYXNzTmFtZTogcCxcblx0XHQuLi5kLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG4oXCJoZWFkZXJcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29kZV9faGVhZGVyXCIsXG5cdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyB0KFwic3BhblwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvZGVfX2xhbmd1YWdlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiByW2ldXG5cdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIHQoXCJzcGFuXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29kZV9fdGl0bGVcIixcblx0XHRcdFx0Y2hpbGRyZW46IHMgPz8gXCJTbmlwcGV0XCJcblx0XHRcdH0pXVxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gdChcInByZVwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IG0sXG5cdFx0XHRjaGlsZHJlbjogYSA/IC8qIEBfX1BVUkVfXyAqLyB0KFwiY29kZVwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogaCxcblx0XHRcdFx0Y2hpbGRyZW46IF8ubWFwKChlLCByKSA9PiAvKiBAX19QVVJFX18gKi8gbihcInNwYW5cIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvZGVfX2xpbmVcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyB0KFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb2RlX19saW5lTnVtYmVyXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogciArIDFcblx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIHQoXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvZGVfX2xpbmVUZXh0XCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZSB8fCBcIiBcIlxuXHRcdFx0XHRcdH0pXVxuXHRcdFx0XHR9LCByKSlcblx0XHRcdH0pIDogLyogQF9fUFVSRV9fICovIHQoXCJjb2RlXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdFx0XHRjaGlsZHJlbjogZ1xuXHRcdFx0fSlcblx0XHR9KV1cblx0fSk7XG59KTtcbmkuZGlzcGxheU5hbWUgPSBcIkNvZGVcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaSBhcyBDb2RlIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUVmZmVjdCBhcyB0LCB1c2VJZCBhcyBuLCB1c2VNZW1vIGFzIHIsIHVzZVJlZiBhcyBpLCB1c2VTdGF0ZSBhcyBhIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgbywganN4cyBhcyBzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2NvbWJvYm94LnV0aWxzLnRzXG5mdW5jdGlvbiBjKGUpIHtcblx0cmV0dXJuIGUubGFiZWwgPz8gZS5jaGlsZHJlbiA/PyBlLnZhbHVlO1xufVxuZnVuY3Rpb24gbChlKSB7XG5cdGxldCB0ID0gYyhlKTtcblx0cmV0dXJuIHR5cGVvZiB0ID09IFwic3RyaW5nXCIgfHwgdHlwZW9mIHQgPT0gXCJudW1iZXJcIiA/IGAke3R9YCA6IGUudmFsdWU7XG59XG5mdW5jdGlvbiB1KGUsIHQpIHtcblx0cmV0dXJuIGUudmFsdWUgfHwgYGl0ZW0tJHt0fWA7XG59XG5mdW5jdGlvbiBkKGUsIHQpIHtcblx0cmV0dXJuIHQgPT0gbnVsbCA/IG51bGwgOiBlLmZpbmQoKGUpID0+IGUudmFsdWUgPT09IHQpID8/IG51bGw7XG59XG5mdW5jdGlvbiBmKGUpIHtcblx0cmV0dXJuIGUudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvQ29tYm9ib3gudHN4XG52YXIgcCA9IGUoZnVuY3Rpb24oeyBpdGVtczogZSA9IFtdLCB2YWx1ZTogcCwgZGVmYXVsdFZhbHVlOiBtLCBhbGxvd051bGw6IGggPSAhMSwgbnVsbExhYmVsOiBnID0gXCJOb25lXCIsIGNsYXNzTmFtZTogXyA9IFwiXCIsIGlkOiB2LCBkaXNhYmxlZDogeSwgcGxhY2Vob2xkZXI6IGIsIG9uVmFsdWVDaGFuZ2U6IHgsIG9uRm9jdXM6IFMsIG9uQmx1cjogQywgb25LZXlEb3duOiB3LCAuLi5UIH0sIEUpIHtcblx0bGV0IEQgPSBuKCksIE8gPSBpKG51bGwpLCBrID0gYG5hYnMtdWktY29tYm9ib3gtbGlzdC0ke0QucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBBID0gdiA/PyBgbmFicy11aS1jb21ib2JveC0ke0QucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBqID0gcCAhPT0gdm9pZCAwLCBbTSwgTl0gPSBhKG0gPz8gbnVsbCksIFAgPSBqID8gcCA6IE0sIEYgPSBkKGUsIFApLCBJID0gRiA/IGwoRikgOiBQID8/IFwiXCIsIFtMLCBSXSA9IGEoITEpLCBbeiwgQl0gPSBhKEkpLCBbViwgSF0gPSBhKDApLCBVID0gcigoKSA9PiB7XG5cdFx0bGV0IHQgPSBmKHopO1xuXHRcdHJldHVybiBlLmZpbHRlcigoZSkgPT4ge1xuXHRcdFx0bGV0IG4gPSBmKGwoZSkpO1xuXHRcdFx0cmV0dXJuIHQubGVuZ3RoID09PSAwIHx8IG4uaW5jbHVkZXModCk7XG5cdFx0fSk7XG5cdH0sIFtlLCB6XSksIFcgPSBoID8gW3tcblx0XHR2YWx1ZTogXCJcIixcblx0XHRsYWJlbDogZyxcblx0XHRkaXNhYmxlZDogITEsXG5cdFx0X19udWxsOiAhMFxuXHR9LCAuLi5VXSA6IFU7XG5cdHQoKCkgPT4ge1xuXHRcdEwgfHwgQihJKTtcblx0fSwgW0wsIEldKSwgdCgoKSA9PiB7XG5cdFx0ViA+PSBXLmxlbmd0aCAmJiBIKFcubGVuZ3RoID09PSAwID8gMCA6IFcubGVuZ3RoIC0gMSk7XG5cdH0sIFtWLCBXLmxlbmd0aF0pLCB0KCgpID0+IHtcblx0XHRsZXQgZSA9IChlKSA9PiB7XG5cdFx0XHRPLmN1cnJlbnQgJiYgZS50YXJnZXQgaW5zdGFuY2VvZiBOb2RlICYmICFPLmN1cnJlbnQuY29udGFpbnMoZS50YXJnZXQpICYmIFIoITEpO1xuXHRcdH07XG5cdFx0cmV0dXJuIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJwb2ludGVyZG93blwiLCBlKSwgKCkgPT4ge1xuXHRcdFx0ZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIGUpO1xuXHRcdH07XG5cdH0sIFtdKTtcblx0bGV0IEcgPSAoZSwgdCkgPT4ge1xuXHRcdGogfHwgTihlKSwgeD8uKGUsIHQpLCBSKCExKSwgQih0ID8gbCh0KSA6IFwiXCIpO1xuXHR9LCBLID0gKGUpID0+IHtcblx0XHRsZXQgdCA9IFdbZV07XG5cdFx0aWYgKHQpIHtcblx0XHRcdGlmIChcIl9fbnVsbFwiIGluIHQpIHtcblx0XHRcdFx0RyhudWxsLCBudWxsKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0dC5kaXNhYmxlZCB8fCBHKHQudmFsdWUsIHQpO1xuXHRcdH1cblx0fSwgcSA9IChlKSA9PiB7XG5cdFx0UighMCksIEIoSSksIEgoMCksIFM/LihlKTtcblx0fSwgSiA9IChlKSA9PiB7XG5cdFx0UighMSksIEIoSSksIEM/LihlKTtcblx0fSwgWSA9IChlKSA9PiB7XG5cdFx0UighMCksIEIoZS50YXJnZXQudmFsdWUpLCBIKDApO1xuXHR9LCBYID0gKGUpID0+IHtcblx0XHRpZiAoZS5rZXkgPT09IFwiQXJyb3dEb3duXCIpIHtcblx0XHRcdGUucHJldmVudERlZmF1bHQoKSwgUighMCksIEgoKGUpID0+IE1hdGgubWluKGUgKyAxLCBNYXRoLm1heChXLmxlbmd0aCAtIDEsIDApKSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChlLmtleSA9PT0gXCJBcnJvd1VwXCIpIHtcblx0XHRcdGUucHJldmVudERlZmF1bHQoKSwgUighMCksIEgoKGUpID0+IE1hdGgubWF4KGUgLSAxLCAwKSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XG5cdFx0XHRMICYmIChlLnByZXZlbnREZWZhdWx0KCksIEsoVikpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIpIHtcblx0XHRcdGUucHJldmVudERlZmF1bHQoKSwgUighMSksIEIoSSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHc/LihlKTtcblx0fSwgWiA9IEwgPyAvKiBAX19QVVJFX18gKi8gbyhcImlucHV0XCIsIHtcblx0XHRyZWY6IEUsXG5cdFx0aWQ6IEEsXG5cdFx0cm9sZTogXCJjb21ib2JveFwiLFxuXHRcdFwiYXJpYS1oYXNwb3B1cFwiOiBcImxpc3Rib3hcIixcblx0XHRcImFyaWEtYXV0b2NvbXBsZXRlXCI6IFwibGlzdFwiLFxuXHRcdFwiYXJpYS1leHBhbmRlZFwiOiBcInRydWVcIixcblx0XHRcImFyaWEtY29udHJvbHNcIjogayxcblx0XHRcImFyaWEtYWN0aXZlZGVzY2VuZGFudFwiOiBXW1ZdID8gYCR7a30tb3B0aW9uLSR7Vn1gIDogdm9pZCAwLFxuXHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19pbnB1dFwiLFxuXHRcdGRpc2FibGVkOiB5LFxuXHRcdHBsYWNlaG9sZGVyOiBiLFxuXHRcdHZhbHVlOiB6LFxuXHRcdG9uRm9jdXM6IHEsXG5cdFx0b25CbHVyOiBKLFxuXHRcdG9uQ2hhbmdlOiBZLFxuXHRcdG9uS2V5RG93bjogWCxcblx0XHQuLi5UXG5cdH0pIDogLyogQF9fUFVSRV9fICovIG8oXCJpbnB1dFwiLCB7XG5cdFx0cmVmOiBFLFxuXHRcdGlkOiBBLFxuXHRcdHJvbGU6IFwiY29tYm9ib3hcIixcblx0XHRcImFyaWEtaGFzcG9wdXBcIjogXCJsaXN0Ym94XCIsXG5cdFx0XCJhcmlhLWF1dG9jb21wbGV0ZVwiOiBcImxpc3RcIixcblx0XHRcImFyaWEtZXhwYW5kZWRcIjogXCJmYWxzZVwiLFxuXHRcdFwiYXJpYS1jb250cm9sc1wiOiBrLFxuXHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19pbnB1dFwiLFxuXHRcdGRpc2FibGVkOiB5LFxuXHRcdHBsYWNlaG9sZGVyOiBiLFxuXHRcdHZhbHVlOiB6LFxuXHRcdG9uRm9jdXM6IHEsXG5cdFx0b25CbHVyOiBKLFxuXHRcdG9uQ2hhbmdlOiBZLFxuXHRcdG9uS2V5RG93bjogWCxcblx0XHQuLi5UXG5cdH0pO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdHJlZjogTyxcblx0XHRjbGFzc05hbWU6IFtcblx0XHRcdFwibmFicy11aS1jb21ib2JveFwiLFxuXHRcdFx0TCA/IFwibmFicy11aS1jb21ib2JveC0tb3BlblwiIDogXCJcIixcblx0XHRcdHkgPyBcIm5hYnMtdWktY29tYm9ib3gtLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdFx0X1xuXHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdGNoaWxkcmVuOiBbWiwgTCA/IC8qIEBfX1BVUkVfXyAqLyBvKFwiZGl2XCIsIHtcblx0XHRcdGlkOiBrLFxuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29tYm9ib3hfX3BvcHVwXCIsXG5cdFx0XHRyb2xlOiBcImxpc3Rib3hcIixcblx0XHRcdFwiYXJpYS1sYWJlbFwiOiBcIkNvbWJvYm94IG9wdGlvbnNcIixcblx0XHRcdGNoaWxkcmVuOiBXLmxlbmd0aCA9PT0gMCA/IC8qIEBfX1BVUkVfXyAqLyBvKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29tYm9ib3hfX2VtcHR5XCIsXG5cdFx0XHRcdHJvbGU6IFwib3B0aW9uXCIsXG5cdFx0XHRcdFwiYXJpYS1kaXNhYmxlZFwiOiBcInRydWVcIixcblx0XHRcdFx0XCJhcmlhLXNlbGVjdGVkXCI6IFwiZmFsc2VcIixcblx0XHRcdFx0Y2hpbGRyZW46IFwiTm8gb3B0aW9ucyBmb3VuZFwiXG5cdFx0XHR9KSA6IFcubWFwKChlLCB0KSA9PiB7XG5cdFx0XHRcdGxldCBuID0gXCJfX251bGxcIiBpbiBlLCByID0gIW4gJiYgUCA9PT0gZS52YWx1ZSwgaSA9IFtcblx0XHRcdFx0XHRcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvblwiLFxuXHRcdFx0XHRcdHQgPT09IFYgPyBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbi0tYWN0aXZlXCIgOiBcIlwiLFxuXHRcdFx0XHRcdHIgPyBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbi0tc2VsZWN0ZWRcIiA6IFwiXCIsXG5cdFx0XHRcdFx0biA/IFwibmFicy11aS1jb21ib2JveF9fb3B0aW9uLS1udWxsXCIgOiBcIlwiLFxuXHRcdFx0XHRcdGUuZGlzYWJsZWQgPyBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbi0tZGlzYWJsZWRcIiA6IFwiXCJcblx0XHRcdFx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdFx0XHRcdHJldHVybiBuID8gUCA9PT0gbnVsbCA/IC8qIEBfX1BVUkVfXyAqLyBvKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRpZDogYCR7a30tb3B0aW9uLSR7dH1gLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogaSxcblx0XHRcdFx0XHRyb2xlOiBcIm9wdGlvblwiLFxuXHRcdFx0XHRcdFwiYXJpYS1zZWxlY3RlZFwiOiBcInRydWVcIixcblx0XHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogXCJmYWxzZVwiLFxuXHRcdFx0XHRcdHRhYkluZGV4OiAtMSxcblx0XHRcdFx0XHRvbk1vdXNlRG93bjogKGUpID0+IGUucHJldmVudERlZmF1bHQoKSxcblx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBLKHQpLFxuXHRcdFx0XHRcdG9uTW91c2VFbnRlcjogKCkgPT4gSCh0KSxcblx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25MYWJlbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGdcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9LCBcIm51bGxcIikgOiAvKiBAX19QVVJFX18gKi8gbyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0aWQ6IGAke2t9LW9wdGlvbi0ke3R9YCxcblx0XHRcdFx0XHRjbGFzc05hbWU6IGksXG5cdFx0XHRcdFx0cm9sZTogXCJvcHRpb25cIixcblx0XHRcdFx0XHRcImFyaWEtc2VsZWN0ZWRcIjogXCJmYWxzZVwiLFxuXHRcdFx0XHRcdFwiYXJpYS1kaXNhYmxlZFwiOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0dGFiSW5kZXg6IC0xLFxuXHRcdFx0XHRcdG9uTW91c2VEb3duOiAoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IEsodCksXG5cdFx0XHRcdFx0b25Nb3VzZUVudGVyOiAoKSA9PiBIKHQpLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbkxhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZ1xuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdH0sIFwibnVsbFwiKSA6IGUuZGlzYWJsZWQgPyByID8gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGlkOiBgJHtrfS1vcHRpb24tJHt0fWAsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBpLFxuXHRcdFx0XHRcdHJvbGU6IFwib3B0aW9uXCIsXG5cdFx0XHRcdFx0XCJhcmlhLXNlbGVjdGVkXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdFwiYXJpYS1kaXNhYmxlZFwiOiBcInRydWVcIixcblx0XHRcdFx0XHR0YWJJbmRleDogLTEsXG5cdFx0XHRcdFx0b25Nb3VzZURvd246IChlKSA9PiBlLnByZXZlbnREZWZhdWx0KCksXG5cdFx0XHRcdFx0b25DbGljazogKCkgPT4gSyh0KSxcblx0XHRcdFx0XHRvbk1vdXNlRW50ZXI6ICgpID0+IEgodCksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbkxhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogYyhlKVxuXHRcdFx0XHRcdH0pLCBlLmRlc2NyaXB0aW9uID8gLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25EZXNjcmlwdGlvblwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUuZGVzY3JpcHRpb25cblx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdH0sIHUoZSwgdCkpIDogLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGlkOiBgJHtrfS1vcHRpb24tJHt0fWAsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBpLFxuXHRcdFx0XHRcdHJvbGU6IFwib3B0aW9uXCIsXG5cdFx0XHRcdFx0XCJhcmlhLXNlbGVjdGVkXCI6IFwiZmFsc2VcIixcblx0XHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0dGFiSW5kZXg6IC0xLFxuXHRcdFx0XHRcdG9uTW91c2VEb3duOiAoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IEsodCksXG5cdFx0XHRcdFx0b25Nb3VzZUVudGVyOiAoKSA9PiBIKHQpLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25MYWJlbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGMoZSlcblx0XHRcdFx0XHR9KSwgZS5kZXNjcmlwdGlvbiA/IC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb21ib2JveF9fb3B0aW9uRGVzY3JpcHRpb25cIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmRlc2NyaXB0aW9uXG5cdFx0XHRcdFx0fSkgOiBudWxsXVxuXHRcdFx0XHR9LCB1KGUsIHQpKSA6IHIgPyAvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0aWQ6IGAke2t9LW9wdGlvbi0ke3R9YCxcblx0XHRcdFx0XHRjbGFzc05hbWU6IGksXG5cdFx0XHRcdFx0cm9sZTogXCJvcHRpb25cIixcblx0XHRcdFx0XHRcImFyaWEtc2VsZWN0ZWRcIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWRpc2FibGVkXCI6IFwiZmFsc2VcIixcblx0XHRcdFx0XHR0YWJJbmRleDogLTEsXG5cdFx0XHRcdFx0b25Nb3VzZURvd246IChlKSA9PiBlLnByZXZlbnREZWZhdWx0KCksXG5cdFx0XHRcdFx0b25DbGljazogKCkgPT4gSyh0KSxcblx0XHRcdFx0XHRvbk1vdXNlRW50ZXI6ICgpID0+IEgodCksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbkxhYmVsXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogYyhlKVxuXHRcdFx0XHRcdH0pLCBlLmRlc2NyaXB0aW9uID8gLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWNvbWJvYm94X19vcHRpb25EZXNjcmlwdGlvblwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUuZGVzY3JpcHRpb25cblx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdH0sIHUoZSwgdCkpIDogLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGlkOiBgJHtrfS1vcHRpb24tJHt0fWAsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBpLFxuXHRcdFx0XHRcdHJvbGU6IFwib3B0aW9uXCIsXG5cdFx0XHRcdFx0XCJhcmlhLXNlbGVjdGVkXCI6IFwiZmFsc2VcIixcblx0XHRcdFx0XHRcImFyaWEtZGlzYWJsZWRcIjogXCJmYWxzZVwiLFxuXHRcdFx0XHRcdHRhYkluZGV4OiAtMSxcblx0XHRcdFx0XHRvbk1vdXNlRG93bjogKGUpID0+IGUucHJldmVudERlZmF1bHQoKSxcblx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBLKHQpLFxuXHRcdFx0XHRcdG9uTW91c2VFbnRlcjogKCkgPT4gSCh0KSxcblx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1jb21ib2JveF9fb3B0aW9uTGFiZWxcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBjKGUpXG5cdFx0XHRcdFx0fSksIGUuZGVzY3JpcHRpb24gPyAvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktY29tYm9ib3hfX29wdGlvbkRlc2NyaXB0aW9uXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5kZXNjcmlwdGlvblxuXHRcdFx0XHRcdH0pIDogbnVsbF1cblx0XHRcdFx0fSwgdShlLCB0KSk7XG5cdFx0XHR9KVxuXHRcdH0pIDogbnVsbF1cblx0fSk7XG59KTtcbnAuZGlzcGxheU5hbWUgPSBcIkNvbWJvYm94XCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHAgYXMgQ29tYm9ib3ggfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSwgdXNlSWQgYXMgdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIG4sIGpzeHMgYXMgciB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9kYXRlcGlja2VyLnV0aWxzLnRzXG52YXIgaSA9IHtcblx0bm9uZTogXCJuYWJzLXVpLWRhdGVwaWNrZXItLWxhYmVsLW5vbmVcIixcblx0dG9wOiBcIm5hYnMtdWktZGF0ZXBpY2tlci0tbGFiZWwtdG9wXCIsXG5cdGxlZnQ6IFwibmFicy11aS1kYXRlcGlja2VyLS1sYWJlbC1sZWZ0XCJcbn0sIGEgPSBlKCh7IGxhYmVsOiBlLCBsYWJlbFBvc2l0aW9uOiBhID0gXCJ0b3BcIiwgY2xhc3NOYW1lOiBvID0gXCJcIiwgaW5wdXRDbGFzc05hbWU6IHMgPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogYyA9IFwiXCIsIGFsbG93TnVsbDogbCA9ICExLCBpZDogdSwgdmFsdWU6IGQsIG9uQ2hhbmdlOiBmLCBvblZhbHVlQ2hhbmdlOiBwLCAuLi5tIH0sIGgpID0+IHtcblx0bGV0IGcgPSB0KCksIF8gPSB1ID8/IGBuYWJzLXVpLWRhdGVwaWNrZXItJHtnLnJlcGxhY2UoLzovZywgXCJcIil9YCwgdiA9IFtcblx0XHRcIm5hYnMtdWktZGF0ZXBpY2tlclwiLFxuXHRcdGUgPyBpW2FdID8/IGkudG9wIDogXCJcIixcblx0XHRvXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCB5ID0gW1wibmFicy11aS1kYXRlcGlja2VyX19pbnB1dFwiLCBzXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGIgPSBbXCJuYWJzLXVpLWRhdGVwaWNrZXJfX2xhYmVsXCIsIGNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyByKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IHYsXG5cdFx0Y2hpbGRyZW46IFtlID8gLyogQF9fUFVSRV9fICovIG4oXCJsYWJlbFwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IGIsXG5cdFx0XHRodG1sRm9yOiBfLFxuXHRcdFx0Y2hpbGRyZW46IGVcblx0XHR9KSA6IG51bGwsIC8qIEBfX1BVUkVfXyAqLyBuKFwiaW5wdXRcIiwge1xuXHRcdFx0cmVmOiBoLFxuXHRcdFx0aWQ6IF8sXG5cdFx0XHRjbGFzc05hbWU6IHksXG5cdFx0XHR0eXBlOiBcImRhdGVcIixcblx0XHRcdHZhbHVlOiBkID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkID8/IFwiXCIsXG5cdFx0XHRvbkNoYW5nZTogKGUpID0+IHtcblx0XHRcdFx0Zj8uKGUpLCBwPy4obCAmJiBlLnRhcmdldC52YWx1ZSA9PT0gXCJcIiA/IG51bGwgOiBlLnRhcmdldC52YWx1ZSwgZSk7XG5cdFx0XHR9LFxuXHRcdFx0Li4ubVxuXHRcdH0pXVxuXHR9KTtcbn0pO1xuYS5kaXNwbGF5TmFtZSA9IFwiRGF0ZVBpY2tlclwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhIGFzIERhdGVQaWNrZXIgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSwgdXNlRWZmZWN0IGFzIHQsIHVzZUlkIGFzIG4sIHVzZVJlZiBhcyByIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgaSwganN4cyBhcyBhIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL0RpYWxvZy50c3hcbnZhciBvID0gXCJhW2hyZWZdLCBhcmVhW2hyZWZdLCBidXR0b246bm90KFtkaXNhYmxlZF0pLCBpbnB1dDpub3QoW2Rpc2FibGVkXSk6bm90KFt0eXBlPVxcXCJoaWRkZW5cXFwiXSksIHNlbGVjdDpub3QoW2Rpc2FibGVkXSksIHRleHRhcmVhOm5vdChbZGlzYWJsZWRdKSwgW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVxcXCItMVxcXCJdKVwiO1xuZnVuY3Rpb24gcyhlKSB7XG5cdHJldHVybiBBcnJheS5mcm9tKGUucXVlcnlTZWxlY3RvckFsbChvKSkuZmlsdGVyKChlKSA9PiAhZS5oYXNBdHRyaWJ1dGUoXCJkaXNhYmxlZFwiKSAmJiBlLmdldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIpICE9PSBcInRydWVcIik7XG59XG52YXIgYyA9IGUoZnVuY3Rpb24oeyB0aXRsZTogZSwgZGVzY3JpcHRpb246IG8sIGhlYWRlcjogYywgZm9vdGVyOiBsLCBzaG93SGVhZGVyOiB1ID0gITAsIHNob3dGb290ZXI6IGQgPSAhMCwgb25SZXF1ZXN0Q2xvc2U6IGYsIGNsb3NlT25CYWNrZHJvcENsaWNrOiBwID0gITAsIGNsb3NlT25Fc2NhcGU6IG0gPSAhMCwgaW5pdGlhbEZvY3VzU2VsZWN0b3I6IGgsIGRpYWxvZ1JvbGU6IGcgPSBcImRpYWxvZ1wiLCBjbGFzc05hbWU6IF8gPSBcIlwiLCBiYWNrZHJvcENsYXNzTmFtZTogdiA9IFwiXCIsIGhlYWRlckNsYXNzTmFtZTogeSA9IFwiXCIsIGRlc2NyaXB0aW9uQ2xhc3NOYW1lOiBiID0gXCJcIiwgY29udGVudENsYXNzTmFtZTogeCA9IFwiXCIsIGZvb3RlckNsYXNzTmFtZTogUyA9IFwiXCIsIG9uS2V5RG93bjogQywgdGFiSW5kZXg6IHcsIGNoaWxkcmVuOiBULCAuLi5FIH0sIEQpIHtcblx0bGV0IE8gPSByKG51bGwpLCBrID0gcihudWxsKSwgQSA9IGBuYWJzLXVpLWRpYWxvZy10aXRsZS0ke24oKS5yZXBsYWNlKC86L2csIFwiXCIpfWAsIGogPSBgbmFicy11aS1kaWFsb2ctZGVzY3JpcHRpb24tJHtuKCkucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBNID0gRVtcImFyaWEtbGFiZWxsZWRieVwiXSwgTiA9IEVbXCJhcmlhLWRlc2NyaWJlZGJ5XCJdLCBQID0gIWMgJiYgISFlLCBGID0gISFvLCBJID0gdSAmJiAoISFjIHx8IFApLCBMID0gZCAmJiBsICE9IG51bGwsIFIgPSBNID8/IChQID8gQSA6IHZvaWQgMCksIHogPSBOID8/IChGID8gaiA6IHZvaWQgMCksIEIgPSBbXCJuYWJzLXVpLWRpYWxvZ19fYmFja2Ryb3BcIiwgdl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBWID0gW1wibmFicy11aS1kaWFsb2dcIiwgX10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBIID0gW1wibmFicy11aS1kaWFsb2dfX2hlYWRlclwiLCB5XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIFUgPSBbXCJuYWJzLXVpLWRpYWxvZ19fZGVzY3JpcHRpb25cIiwgYl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBXID0gW1wibmFicy11aS1kaWFsb2dfX2NvbnRlbnRcIiwgeF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBHID0gW1wibmFicy11aS1kaWFsb2dfX2Zvb3RlclwiLCBTXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiB0KCgpID0+IHtcblx0XHRsZXQgZSA9IE8uY3VycmVudDtcblx0XHRpZiAoIWUpIHJldHVybjtcblx0XHRpZiAoay5jdXJyZW50ID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50ID8gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA6IG51bGwsIGgpIHRyeSB7XG5cdFx0XHRsZXQgdCA9IGUucXVlcnlTZWxlY3RvcihoKTtcblx0XHRcdGlmICh0KSByZXR1cm4gdC5mb2N1cygpLCAoKSA9PiB7XG5cdFx0XHRcdGsuY3VycmVudD8uZm9jdXMoKSwgay5jdXJyZW50ID0gbnVsbDtcblx0XHRcdH07XG5cdFx0fSBjYXRjaCB7fVxuXHRcdGxldCB0ID0gcyhlKTtcblx0XHRyZXR1cm4gdC5sZW5ndGggPiAwID8gdFswXS5mb2N1cygpIDogZS5mb2N1cygpLCAoKSA9PiB7XG5cdFx0XHRrLmN1cnJlbnQ/LmZvY3VzKCksIGsuY3VycmVudCA9IG51bGw7XG5cdFx0fTtcblx0fSwgW2hdKSwgLyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdGNsYXNzTmFtZTogQixcblx0XHRyb2xlOiBcInByZXNlbnRhdGlvblwiLFxuXHRcdG9uQ2xpY2s6IChlKSA9PiB7XG5cdFx0XHQhcCB8fCBlLnRhcmdldCAhPT0gZS5jdXJyZW50VGFyZ2V0IHx8IGY/LigpO1xuXHRcdH0sXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBhKFwic2VjdGlvblwiLCB7XG5cdFx0XHRyZWY6IChlKSA9PiB7XG5cdFx0XHRcdGlmIChPLmN1cnJlbnQgPSBlLCB0eXBlb2YgRCA9PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdFx0XHREKGUpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHREICYmIChELmN1cnJlbnQgPSBlKTtcblx0XHRcdH0sXG5cdFx0XHRjbGFzc05hbWU6IFYsXG5cdFx0XHRyb2xlOiBnLFxuXHRcdFx0XCJhcmlhLW1vZGFsXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogUixcblx0XHRcdFwiYXJpYS1kZXNjcmliZWRieVwiOiB6LFxuXHRcdFx0dGFiSW5kZXg6IHcgPz8gLTEsXG5cdFx0XHRvbktleURvd246IChlKSA9PiB7XG5cdFx0XHRcdGlmIChDPy4oZSksIGUuZGVmYXVsdFByZXZlbnRlZCkgcmV0dXJuO1xuXHRcdFx0XHRpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIgJiYgbSkge1xuXHRcdFx0XHRcdGUucHJldmVudERlZmF1bHQoKSwgZj8uKCk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChlLmtleSAhPT0gXCJUYWJcIiB8fCAhTy5jdXJyZW50KSByZXR1cm47XG5cdFx0XHRcdGxldCB0ID0gcyhPLmN1cnJlbnQpO1xuXHRcdFx0XHRpZiAodC5sZW5ndGggPT09IDApIHtcblx0XHRcdFx0XHRlLnByZXZlbnREZWZhdWx0KCksIE8uY3VycmVudC5mb2N1cygpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHRsZXQgbiA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQsIHIgPSB0WzBdLCBpID0gdFt0Lmxlbmd0aCAtIDFdO1xuXHRcdFx0XHRpZiAoZS5zaGlmdEtleSkge1xuXHRcdFx0XHRcdCghbiB8fCBuID09PSByIHx8ICFPLmN1cnJlbnQuY29udGFpbnMobikpICYmIChlLnByZXZlbnREZWZhdWx0KCksIGkuZm9jdXMoKSk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdCghbiB8fCBuID09PSBpIHx8ICFPLmN1cnJlbnQuY29udGFpbnMobikpICYmIChlLnByZXZlbnREZWZhdWx0KCksIHIuZm9jdXMoKSk7XG5cdFx0XHR9LFxuXHRcdFx0Li4uRSxcblx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdEkgPyAvKiBAX19QVVJFX18gKi8gaShcImhlYWRlclwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBILFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBjID8/IChQID8gLyogQF9fUFVSRV9fICovIGkoXCJoM1wiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kaWFsb2dfX3RpdGxlXCIsXG5cdFx0XHRcdFx0XHRpZDogQSxcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0XHRcdFx0fSkgOiBudWxsKVxuXHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdEYgPyAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdFx0aWQ6IGosXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBVLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBvXG5cdFx0XHRcdH0pIDogbnVsbCxcblx0XHRcdFx0LyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogVyxcblx0XHRcdFx0XHRjaGlsZHJlbjogVFxuXHRcdFx0XHR9KSxcblx0XHRcdFx0TCA/IC8qIEBfX1BVUkVfXyAqLyBpKFwiZm9vdGVyXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IEcsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGxcblx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRdXG5cdFx0fSlcblx0fSk7XG59KTtcbmMuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1wiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjIGFzIERpYWxvZyB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlLCB1c2VJZCBhcyB0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgbiwganN4cyBhcyByIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2Ryb3Bkb3dubGlzdC51dGlscy50c1xuZnVuY3Rpb24gaShlKSB7XG5cdHJldHVybiBlLmxhYmVsID8/IGUuY2hpbGRyZW4gPz8gZS52YWx1ZTtcbn1cbmZ1bmN0aW9uIGEoZSwgdCkge1xuXHRyZXR1cm4gZS52YWx1ZSB8fCBgaXRlbS0ke3R9YDtcbn1cbmZ1bmN0aW9uIG8oZSwgdCwgbikge1xuXHRyZXR1cm4gZSB8fCB0ID09PSBudWxsIHx8IG4gPT09IG51bGw7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvRHJvcGRvd25MaXN0LnRzeFxudmFyIHMgPSBlKGZ1bmN0aW9uKHsgaXRlbXM6IGUgPSBbXSwgdmFsdWU6IHMsIGRlZmF1bHRWYWx1ZTogYywgYWxsb3dOdWxsOiBsID0gITEsIG51bGxMYWJlbDogdSA9IFwiTm9uZVwiLCBjbGFzc05hbWU6IGQgPSBcIlwiLCBvbkNoYW5nZTogZiwgb25WYWx1ZUNoYW5nZTogcCwgaWQ6IG0sIGRpc2FibGVkOiBoLCAuLi5nIH0sIF8pIHtcblx0bGV0IHYgPSB0KCksIHkgPSBtID8/IGBuYWJzLXVpLWRyb3Bkb3dubGlzdC0ke3YucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBiID0gW1xuXHRcdFwibmFicy11aS1kcm9wZG93bmxpc3RcIixcblx0XHRoID8gXCJuYWJzLXVpLWRyb3Bkb3dubGlzdC0tZGlzYWJsZWRcIiA6IFwiXCIsXG5cdFx0ZFxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgeCA9IG8obCwgcywgYyk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcihcInNlbGVjdFwiLCB7XG5cdFx0cmVmOiBfLFxuXHRcdGlkOiB5LFxuXHRcdGNsYXNzTmFtZTogYixcblx0XHRkaXNhYmxlZDogaCxcblx0XHR2YWx1ZTogcyA/PyB2b2lkIDAsXG5cdFx0ZGVmYXVsdFZhbHVlOiBjID8/IHZvaWQgMCxcblx0XHRvbkNoYW5nZTogKGUpID0+IHtcblx0XHRcdGxldCB0ID0gZS50YXJnZXQudmFsdWUgPT09IFwiXCIgPyBudWxsIDogZS50YXJnZXQudmFsdWU7XG5cdFx0XHRwPy4odCwgZSksIGY/LihlKTtcblx0XHR9LFxuXHRcdC4uLmcsXG5cdFx0Y2hpbGRyZW46IFt4ID8gLyogQF9fUFVSRV9fICovIG4oXCJvcHRpb25cIiwge1xuXHRcdFx0dmFsdWU6IFwiXCIsXG5cdFx0XHRkaXNhYmxlZDogIWwsXG5cdFx0XHRjaGlsZHJlbjogdVxuXHRcdH0pIDogbnVsbCwgZS5tYXAoKGUsIHQpID0+IC8qIEBfX1BVUkVfXyAqLyBuKFwib3B0aW9uXCIsIHtcblx0XHRcdHZhbHVlOiBlLnZhbHVlLFxuXHRcdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XHRjaGlsZHJlbjogaShlKVxuXHRcdH0sIGEoZSwgdCkpKV1cblx0fSk7XG59KTtcbnMuZGlzcGxheU5hbWUgPSBcIkRyb3Bkb3duTGlzdFwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBzIGFzIERyb3Bkb3duTGlzdCB9O1xuIiwiaW1wb3J0IHsgdXNlRWZmZWN0IGFzIGUsIHVzZUlkIGFzIHQsIHVzZUxheW91dEVmZmVjdCBhcyBuLCB1c2VSZWYgYXMgciwgdXNlU3RhdGUgYXMgaSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY3JlYXRlUG9ydGFsIGFzIGEgfSBmcm9tIFwicmVhY3QtZG9tXCI7XG5pbXBvcnQgeyBGcmFnbWVudCBhcyBvLCBqc3ggYXMgcywganN4cyBhcyBjIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL2Ryb3Bkb3dubWVudS51dGlscy50c1xuZnVuY3Rpb24gbChlKSB7XG5cdHJldHVybiAhIShlICYmIFwidHlwZVwiIGluIGUgJiYgZS50eXBlID09PSBcImRpdmlkZXJcIik7XG59XG5mdW5jdGlvbiB1KGUpIHtcblx0cmV0dXJuIGUubGFiZWwgPz8gZS5jaGlsZHJlbiA/PyBcIk1lbnUgaXRlbVwiO1xufVxuZnVuY3Rpb24gZChlLCB0KSB7XG5cdHJldHVybiBlLnZhbHVlID8/IGUubGFiZWwgPz8gYGl0ZW0tJHt0fWA7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvRHJvcGRvd25NZW51LnRzeFxuZnVuY3Rpb24gZih7IGxhYmVsOiBmID0gXCJNZW51XCIsIHRyaWdnZXJDb250ZW50OiBwLCB0cmlnZ2VyQXJpYUxhYmVsOiBtLCBtZW51QWxpZ246IGggPSBcInN0YXJ0XCIsIGl0ZW1zOiBnID0gW10sIGNsYXNzTmFtZTogXyA9IFwiXCIsIHRyaWdnZXJDbGFzc05hbWU6IHYgPSBcIlwiLCBtZW51Q2xhc3NOYW1lOiB5ID0gXCJcIiwgaXRlbUNsYXNzTmFtZTogYiA9IFwiXCIsIGRpdmlkZXJDbGFzc05hbWU6IHggPSBcIlwiLCBpZDogUywgb25JdGVtU2VsZWN0OiBDLCAuLi53IH0pIHtcblx0bGV0IFtULCBFXSA9IGkoITEpLCBEID0gcihudWxsKSwgTyA9IHIobnVsbCksIGsgPSByKG51bGwpLCBBID0gdCgpLCBqID0gUyA/PyBgbmFicy11aS1kcm9wZG93bm1lbnUtJHtBLnJlcGxhY2UoLzovZywgXCJcIil9YCwgTSA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51XCIsIF9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgTiA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51X190cmlnZ2VyXCIsIHZdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgUCA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51X19tZW51XCIsIHldLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgRiA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtXCIsIGJdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgSSA9IFtcIm5hYnMtdWktZHJvcGRvd25tZW51X19kaXZpZGVyXCIsIHhdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0ZSgoKSA9PiB7XG5cdFx0bGV0IGUgPSAoZSkgPT4ge1xuXHRcdFx0ZS50YXJnZXQgaW5zdGFuY2VvZiBOb2RlICYmIEQuY3VycmVudCAmJiAhRC5jdXJyZW50LmNvbnRhaW5zKGUudGFyZ2V0KSAmJiBrLmN1cnJlbnQgJiYgIWsuY3VycmVudC5jb250YWlucyhlLnRhcmdldCkgJiYgRSghMSk7XG5cdFx0fSwgdCA9IChlKSA9PiB7XG5cdFx0XHRlLmtleSA9PT0gXCJFc2NhcGVcIiAmJiBFKCExKTtcblx0XHR9O1xuXHRcdHJldHVybiBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcmRvd25cIiwgZSksIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHQpLCAoKSA9PiB7XG5cdFx0XHRkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcmRvd25cIiwgZSksIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHQpO1xuXHRcdH07XG5cdH0sIFtdKSwgbigoKSA9PiB7XG5cdFx0aWYgKCFUIHx8ICFPLmN1cnJlbnQpIHJldHVybjtcblx0XHRsZXQgZSA9ICgpID0+IHtcblx0XHRcdGxldCBlID0gTy5jdXJyZW50Py5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSwgdCA9IGsuY3VycmVudD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksIG4gPSBrLmN1cnJlbnQ7XG5cdFx0XHRpZiAoIWUgfHwgIXQgfHwgIW4pIHJldHVybjtcblx0XHRcdGxldCByID0gTWF0aC5tYXgoZS53aWR0aCwgdC53aWR0aCksIGkgPSB3aW5kb3cuaW5uZXJXaWR0aCAtIHIgLSA4LCBhID0gaCA9PT0gXCJlbmRcIiA/IGUucmlnaHQgLSByIDogZS5sZWZ0LCBvID0gTWF0aC5tYXgoOCwgTWF0aC5taW4oYSwgaSkpLCBzID0gTWF0aC5tYXgoOCwgZS5ib3R0b20gKyAxMCk7XG5cdFx0XHRuLnN0eWxlLnBvc2l0aW9uID0gXCJmaXhlZFwiLCBuLnN0eWxlLnRvcCA9IGAke3N9cHhgLCBuLnN0eWxlLmxlZnQgPSBgJHtvfXB4YCwgbi5zdHlsZS5yaWdodCA9IFwiYXV0b1wiLCBuLnN0eWxlLm1pbldpZHRoID0gYCR7cn1weGAsIG4uc3R5bGUudmlzaWJpbGl0eSA9IFwidmlzaWJsZVwiO1xuXHRcdH07XG5cdFx0cmV0dXJuIGsuY3VycmVudCAmJiAoay5jdXJyZW50LnN0eWxlLnZpc2liaWxpdHkgPSBcImhpZGRlblwiKSwgZSgpLCB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCBlKSwgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgZSwgITApLCAoKSA9PiB7XG5cdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCBlKSwgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgZSwgITApO1xuXHRcdH07XG5cdH0sIFtoLCBUXSk7XG5cdGxldCBMID0gKGUsIHQpID0+IHtcblx0XHRpZiAoRSghMSksIGUuZGlzYWJsZWQpIHtcblx0XHRcdHQucHJldmVudERlZmF1bHQoKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Qz8uKGUsIHQpLCBlLm9uU2VsZWN0Py4oZSwgdCk7XG5cdH07XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gYyhcImRpdlwiLCB7XG5cdFx0cmVmOiBELFxuXHRcdGNsYXNzTmFtZTogTSxcblx0XHQuLi53LFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJidXR0b25cIiwge1xuXHRcdFx0cmVmOiBPLFxuXHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdGNsYXNzTmFtZTogTixcblx0XHRcdFwiYXJpYS1oYXNwb3B1cFwiOiBcIm1lbnVcIixcblx0XHRcdFwiYXJpYS1jb250cm9sc1wiOiBqLFxuXHRcdFx0XCJhcmlhLWxhYmVsXCI6IG0gPz8gZixcblx0XHRcdG9uQ2xpY2s6ICgpID0+IEUoKGUpID0+ICFlKSxcblx0XHRcdGNoaWxkcmVuOiBwID8/IC8qIEBfX1BVUkVfXyAqLyBjKG8sIHsgY2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kcm9wZG93bm1lbnVfX3RyaWdnZXJMYWJlbFwiLFxuXHRcdFx0XHRjaGlsZHJlbjogZlxuXHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9fdHJpZ2dlckNoZXZyb25cIixcblx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdFx0Y2hpbGRyZW46IFwi4pa+XCJcblx0XHRcdH0pXSB9KVxuXHRcdH0pLCBUICYmIHR5cGVvZiBkb2N1bWVudCA8IFwidVwiID8gYSgvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRyZWY6IGssXG5cdFx0XHRpZDogaixcblx0XHRcdGNsYXNzTmFtZTogUCxcblx0XHRcdFwiYXJpYS1sYWJlbFwiOiBmLFxuXHRcdFx0Y2hpbGRyZW46IGcubWFwKChlLCB0KSA9PiB7XG5cdFx0XHRcdGlmIChsKGUpKSByZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogSSxcblx0XHRcdFx0XHRyb2xlOiBcInNlcGFyYXRvclwiLFxuXHRcdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCJcblx0XHRcdFx0fSwgYGRpdmlkZXItJHt0fWApO1xuXHRcdFx0XHRsZXQgbiA9IHUoZSksIHIgPSBbXG5cdFx0XHRcdFx0Rixcblx0XHRcdFx0XHRlLmRpc2FibGVkID8gXCJuYWJzLXVpLWRyb3Bkb3dubWVudV9faXRlbS0tZGlzYWJsZWRcIiA6IFwiXCIsXG5cdFx0XHRcdFx0ZS5kYW5nZXIgPyBcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtLS1kYW5nZXJcIiA6IFwiXCJcblx0XHRcdFx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGkgPSB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiByLFxuXHRcdFx0XHRcdFwiYXJpYS1kaXNhYmxlZFwiOiBlLmRpc2FibGVkIHx8IHZvaWQgMFxuXHRcdFx0XHR9O1xuXHRcdFx0XHRyZXR1cm4gZS5ocmVmID8gLyogQF9fUFVSRV9fICovIGMoXCJhXCIsIHtcblx0XHRcdFx0XHQuLi5pLFxuXHRcdFx0XHRcdGhyZWY6IGUuZGlzYWJsZWQgPyB2b2lkIDAgOiBlLmhyZWYsXG5cdFx0XHRcdFx0b25DbGljazogKHQpID0+IEwoZSwgdCksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtTGFiZWxcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBuXG5cdFx0XHRcdFx0fSksIGUuZGVzY3JpcHRpb24gPyAvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHJvcGRvd25tZW51X19pdGVtRGVzY3JpcHRpb25cIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmRlc2NyaXB0aW9uXG5cdFx0XHRcdFx0fSkgOiBudWxsXVxuXHRcdFx0XHR9LCBkKGUsIHQpKSA6IC8qIEBfX1BVUkVfXyAqLyBjKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogcixcblx0XHRcdFx0XHRkaXNhYmxlZDogZS5kaXNhYmxlZCxcblx0XHRcdFx0XHRvbkNsaWNrOiAodCkgPT4gTChlLCB0KSxcblx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kcm9wZG93bm1lbnVfX2l0ZW1MYWJlbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IG5cblx0XHRcdFx0XHR9KSwgZS5kZXNjcmlwdGlvbiA/IC8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1kcm9wZG93bm1lbnVfX2l0ZW1EZXNjcmlwdGlvblwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUuZGVzY3JpcHRpb25cblx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdH0sIGQoZSwgdCkpO1xuXHRcdFx0fSlcblx0XHR9KSwgZG9jdW1lbnQuYm9keSkgOiBudWxsXVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZiBhcyBEcm9wZG93bk1lbnUgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSwgdXNlRWZmZWN0IGFzIHQsIHVzZUlkIGFzIG4sIHVzZVN0YXRlIGFzIHIgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBpLCBqc3hzIGFzIGEgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiAuLi9uYWJzLXVpLWNoZWNrYm94L3NyYy9jaGVja2JveC51dGlscy50c1xudmFyIG8gPSB7XG5cdHJpZ2h0OiBcIm5hYnMtdWktY2hlY2tib3gtLWxhYmVsLXJpZ2h0XCIsXG5cdGxlZnQ6IFwibmFicy11aS1jaGVja2JveC0tbGFiZWwtbGVmdFwiLFxuXHR0b3A6IFwibmFicy11aS1jaGVja2JveC0tbGFiZWwtdG9wXCIsXG5cdGJvdHRvbTogXCJuYWJzLXVpLWNoZWNrYm94LS1sYWJlbC1ib3R0b21cIlxufSwgcyA9IGUoZnVuY3Rpb24oeyBsYWJlbDogZSA9IFwiQ2hlY2tib3hcIiwgbGFiZWxQb3NpdGlvbjogdCA9IFwicmlnaHRcIiwgY2xhc3NOYW1lOiByID0gXCJcIiwgaW5wdXRDbGFzc05hbWU6IHMgPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogYyA9IFwiXCIsIGlkOiBsLCBkaXNhYmxlZDogdSwgLi4uZCB9LCBmKSB7XG5cdGxldCBwID0gbigpLCBtID0gbCA/PyBgbmFicy11aS1jaGVja2JveC0ke3AucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBoID0gW1xuXHRcdFwibmFicy11aS1jaGVja2JveFwiLFxuXHRcdHUgPyBcIm5hYnMtdWktY2hlY2tib3gtLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdG9bdF0gPz8gby5yaWdodCxcblx0XHRyXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBnID0gW1wibmFicy11aS1jaGVja2JveF9faW5wdXRcIiwgc10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBfID0gW1wibmFicy11aS1jaGVja2JveF9fbGFiZWxcIiwgY10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGEoXCJsYWJlbFwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdGh0bWxGb3I6IG0sXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gaShcImlucHV0XCIsIHtcblx0XHRcdHJlZjogZixcblx0XHRcdGlkOiBtLFxuXHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0dHlwZTogXCJjaGVja2JveFwiLFxuXHRcdFx0ZGlzYWJsZWQ6IHUsXG5cdFx0XHQuLi5kXG5cdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBpKFwic3BhblwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IF8sXG5cdFx0XHRjaGlsZHJlbjogZVxuXHRcdH0pXVxuXHR9KTtcbn0pO1xucy5kaXNwbGF5TmFtZSA9IFwiQ2hlY2tib3hcIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uL25hYnMtdWktcmFkaW9idXR0b24vc3JjL3JhZGlvYnV0dG9uLnV0aWxzLnRzXG52YXIgYyA9IHtcblx0cmlnaHQ6IFwibmFicy11aS1yYWRpb2J1dHRvbi0tbGFiZWwtcmlnaHRcIixcblx0bGVmdDogXCJuYWJzLXVpLXJhZGlvYnV0dG9uLS1sYWJlbC1sZWZ0XCIsXG5cdHRvcDogXCJuYWJzLXVpLXJhZGlvYnV0dG9uLS1sYWJlbC10b3BcIixcblx0Ym90dG9tOiBcIm5hYnMtdWktcmFkaW9idXR0b24tLWxhYmVsLWJvdHRvbVwiXG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vbmFicy11aS1yYWRpb2J1dHRvbi9zcmMvUmFkaW9CdXR0b24udHN4XG5mdW5jdGlvbiBsKHsgbGFiZWw6IGUgPSBcIlJhZGlvIGJ1dHRvblwiLCBsYWJlbFBvc2l0aW9uOiB0ID0gXCJyaWdodFwiLCBjbGFzc05hbWU6IHIgPSBcIlwiLCBpbnB1dENsYXNzTmFtZTogbyA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBzID0gXCJcIiwgaWQ6IGwsIC4uLnUgfSkge1xuXHRsZXQgZCA9IHUuZGlzYWJsZWQgPT09ICEwLCBmID0gbigpLCBwID0gbCA/PyBgbmFicy11aS1yYWRpb2J1dHRvbi0ke2YucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBtID0gW1xuXHRcdFwibmFicy11aS1yYWRpb2J1dHRvblwiLFxuXHRcdGQgPyBcIm5hYnMtdWktcmFkaW9idXR0b24tLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdGNbdF0gPz8gYy5yaWdodCxcblx0XHRyXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBoID0gW1wibmFicy11aS1yYWRpb2J1dHRvbl9faW5wdXRcIiwgb10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBnID0gW1wibmFicy11aS1yYWRpb2J1dHRvbl9fbGFiZWxcIiwgc10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGEoXCJsYWJlbFwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBtLFxuXHRcdGh0bWxGb3I6IHAsXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gaShcImlucHV0XCIsIHtcblx0XHRcdGlkOiBwLFxuXHRcdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdFx0dHlwZTogXCJyYWRpb1wiLFxuXHRcdFx0Li4udVxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gaShcInNwYW5cIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0Y2hpbGRyZW46IGVcblx0XHR9KV1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi9uYWJzLXVpLXRleHRhcmVhL3NyYy9UZXh0YXJlYS50c3hcbnZhciB1ID0gZSgoeyBsYWJlbDogZSwgY2xhc3NOYW1lOiB0ID0gXCJcIiwgaW5wdXRDbGFzc05hbWU6IHIgPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogbyA9IFwiXCIsIGlkOiBzLCByb3dzOiBjID0gNCwgcmVzaXplOiBsID0gXCJ2ZXJ0aWNhbFwiLCAuLi51IH0sIGQpID0+IHtcblx0bGV0IGYgPSBuKCksIHAgPSBzID8/IGBuYWJzLXVpLXRleHRhcmVhLSR7Zi5yZXBsYWNlKC86L2csIFwiXCIpfWAsIG0gPSBbXCJuYWJzLXVpLXRleHRhcmVhXCIsIHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaCA9IFtcIm5hYnMtdWktdGV4dGFyZWFfX2lucHV0XCIsIHJdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktdGV4dGFyZWFfX2xhYmVsXCIsIG9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBhKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IG0sXG5cdFx0Y2hpbGRyZW46IFtlID8gLyogQF9fUFVSRV9fICovIGkoXCJsYWJlbFwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IGcsXG5cdFx0XHRodG1sRm9yOiBwLFxuXHRcdFx0Y2hpbGRyZW46IGVcblx0XHR9KSA6IG51bGwsIC8qIEBfX1BVUkVfXyAqLyBpKFwidGV4dGFyZWFcIiwge1xuXHRcdFx0cmVmOiBkLFxuXHRcdFx0aWQ6IHAsXG5cdFx0XHRjbGFzc05hbWU6IGgsXG5cdFx0XHRyb3dzOiBjLFxuXHRcdFx0XCJkYXRhLXJlc2l6ZVwiOiBsLFxuXHRcdFx0Li4udVxuXHRcdH0pXVxuXHR9KTtcbn0pO1xudS5kaXNwbGF5TmFtZSA9IFwiVGV4dGFyZWFcIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uL25hYnMtdWktdGV4dGJveC9zcmMvdGV4dGJveC51dGlscy50c1xudmFyIGQgPSB7XG5cdG5vbmU6IFwiXCIsXG5cdHRvcDogXCJuYWJzLXVpLXRleHRib3gtLWxhYmVsLXRvcFwiLFxuXHRsZWZ0OiBcIm5hYnMtdWktdGV4dGJveC0tbGFiZWwtbGVmdFwiXG59LCBmID0gZSgoeyBsYWJlbDogZSwgbGFiZWxQb3NpdGlvbjogdCA9IFwidG9wXCIsIGNsYXNzTmFtZTogciA9IFwiXCIsIGlucHV0Q2xhc3NOYW1lOiBvID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IHMgPSBcIlwiLCBpZDogYywgdHlwZTogbCA9IFwidGV4dFwiLCAuLi51IH0sIGYpID0+IHtcblx0bGV0IHAgPSBuKCksIG0gPSBjID8/IGBuYWJzLXVpLXRleHRib3gtJHtwLnJlcGxhY2UoLzovZywgXCJcIil9YCwgaCA9IFtcblx0XHRcIm5hYnMtdWktdGV4dGJveFwiLFxuXHRcdGUgPyBkW3RdID8/IGQudG9wIDogXCJcIixcblx0XHRyXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBnID0gW1wibmFicy11aS10ZXh0Ym94X19pbnB1dFwiLCBvXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIF8gPSBbXCJuYWJzLXVpLXRleHRib3hfX2xhYmVsXCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBhKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IGgsXG5cdFx0Y2hpbGRyZW46IFtlID8gLyogQF9fUFVSRV9fICovIGkoXCJsYWJlbFwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IF8sXG5cdFx0XHRodG1sRm9yOiBtLFxuXHRcdFx0Y2hpbGRyZW46IGVcblx0XHR9KSA6IG51bGwsIC8qIEBfX1BVUkVfXyAqLyBpKFwiaW5wdXRcIiwge1xuXHRcdFx0cmVmOiBmLFxuXHRcdFx0aWQ6IG0sXG5cdFx0XHRjbGFzc05hbWU6IGcsXG5cdFx0XHR0eXBlOiBsLFxuXHRcdFx0Li4udVxuXHRcdH0pXVxuXHR9KTtcbn0pO1xuZi5kaXNwbGF5TmFtZSA9IFwiVGV4dGJveFwiO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2R5bmFtaWNmb3JtLnV0aWxzLnRzXG5mdW5jdGlvbiBwKGUpIHtcblx0cmV0dXJuIHR5cGVvZiBlID09IFwib2JqZWN0XCIgJiYgISFlICYmICFBcnJheS5pc0FycmF5KGUpO1xufVxuZnVuY3Rpb24gbShlKSB7XG5cdHJldHVybiAhZSB8fCBlLnR5cGUgIT09IFwib2JqZWN0XCIgfHwgIXAoZS5wcm9wZXJ0aWVzKSA/IHt9IDogT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKGUucHJvcGVydGllcykubWFwKChbZSwgdF0pID0+IFtlLCBoKHQpXSkpO1xufVxuZnVuY3Rpb24gaChlKSB7XG5cdGlmICghZSB8fCAhcChlKSkgcmV0dXJuIFwiXCI7XG5cdGlmIChlLmRlZmF1bHQgIT09IHZvaWQgMCkgcmV0dXJuIGUuZGVmYXVsdDtcblx0aWYgKEFycmF5LmlzQXJyYXkoZS5lbnVtKSAmJiBlLmVudW0ubGVuZ3RoID4gMCkgcmV0dXJuIGUuZW51bVswXTtcblx0c3dpdGNoIChlLnR5cGUpIHtcblx0XHRjYXNlIFwiYm9vbGVhblwiOiByZXR1cm4gITE7XG5cdFx0Y2FzZSBcImludGVnZXJcIjpcblx0XHRjYXNlIFwibnVtYmVyXCI6IHJldHVybiBcIlwiO1xuXHRcdGNhc2UgXCJvYmplY3RcIjogcmV0dXJuIG0oZSk7XG5cdFx0ZGVmYXVsdDogcmV0dXJuIFwiXCI7XG5cdH1cbn1cbmZ1bmN0aW9uIGcoZSwgdCkge1xuXHRpZiAoIWUgfHwgIXAoZSkpIHJldHVybiB0O1xuXHRpZiAoZS50eXBlID09PSBcIm9iamVjdFwiICYmIHAoZS5wcm9wZXJ0aWVzKSkge1xuXHRcdGxldCBuID0gcCh0KSA/IHQgOiB7fTtcblx0XHRyZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKGUucHJvcGVydGllcykubWFwKChbZSwgdF0pID0+IFtlLCBnKHQsIG5bZV0gPT09IHZvaWQgMCA/IGgodCkgOiBuW2VdKV0pKTtcblx0fVxuXHRpZiAoZS50eXBlID09PSBcImJvb2xlYW5cIikgcmV0dXJuIHQgPT09ICEwO1xuXHRpZiAoZS50eXBlID09PSBcImludGVnZXJcIikge1xuXHRcdGlmICh0ID09PSBcIlwiIHx8IHQgPT0gbnVsbCkgcmV0dXJuIFwiXCI7XG5cdFx0bGV0IGUgPSBOdW1iZXIucGFyc2VJbnQoU3RyaW5nKHQpLCAxMCk7XG5cdFx0cmV0dXJuIE51bWJlci5pc05hTihlKSA/IFwiXCIgOiBlO1xuXHR9XG5cdGlmIChlLnR5cGUgPT09IFwibnVtYmVyXCIpIHtcblx0XHRpZiAodCA9PT0gXCJcIiB8fCB0ID09IG51bGwpIHJldHVybiBcIlwiO1xuXHRcdGxldCBlID0gTnVtYmVyLnBhcnNlRmxvYXQoU3RyaW5nKHQpKTtcblx0XHRyZXR1cm4gTnVtYmVyLmlzTmFOKGUpID8gXCJcIiA6IGU7XG5cdH1cblx0cmV0dXJuIHQgPz8gXCJcIjtcbn1cbmZ1bmN0aW9uIF8oZSkge1xuXHRyZXR1cm4gIWUgfHwgIXAoZSkgPyBcInRleHRib3hcIiA6IEFycmF5LmlzQXJyYXkoZS5lbnVtKSAmJiBlLmVudW0ubGVuZ3RoID4gMCA/IFwicmFkaW9cIiA6IGUudHlwZSA9PT0gXCJzdHJpbmdcIiA/IGUubWF4TGVuZ3RoICE9PSB2b2lkIDAgJiYgZS5tYXhMZW5ndGggPiA1MCA/IFwidGV4dGFyZWFcIiA6IFwidGV4dGJveFwiIDogZS50eXBlID09PSBcImludGVnZXJcIiA/IFwiaW50XCIgOiBlLnR5cGUgPT09IFwibnVtYmVyXCIgPyBTdHJpbmcoZS5mb3JtYXQgPz8gXCJcIikudG9Mb3dlckNhc2UoKSA9PT0gXCJkZWNpbWFsXCIgPyBcImRlY2ltYWxcIiA6IFwiZG91YmxlXCIgOiBlLnR5cGUgPT09IFwiYm9vbGVhblwiID8gXCJib29sXCIgOiBcInRleHRib3hcIjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9EeW5hbWljRm9ybS50c3hcbnZhciB2ID0ge1xuXHR0eXBlOiBcIm9iamVjdFwiLFxuXHRwcm9wZXJ0aWVzOiB7fVxufTtcbmZ1bmN0aW9uIHkoeyBzY2hlbWE6IGUsIG5hbWU6IHQsIHZhbHVlOiBuLCBvbkNoYW5nZTogciB9KSB7XG5cdGxldCBvID0gZS50aXRsZSA/PyB0LCBjID0gZS5kZXNjcmlwdGlvbiwgZCA9IF8oZSksIHAgPSBuID8/IGgoZSk7XG5cdGlmIChkID09PSBcInJhZGlvXCIpIHtcblx0XHRsZXQgbiA9IEFycmF5LmlzQXJyYXkoZS5lbnVtKSA/IGUuZW51bSA6IFtdO1xuXHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gYShcImZpZWxkc2V0XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19maWVsZHNldFwiLFxuXHRcdFx0Y2hpbGRyZW46IFtcblx0XHRcdFx0LyogQF9fUFVSRV9fICovIGkoXCJsZWdlbmRcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19sZWdlbmRcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogb1xuXHRcdFx0XHR9KSxcblx0XHRcdFx0YyA/IC8qIEBfX1BVUkVfXyAqLyBpKFwicFwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHluYW1pY2Zvcm1fX2Rlc2NyaXB0aW9uXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGNcblx0XHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHluYW1pY2Zvcm1fX3JhZGlvR3JvdXBcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogbi5tYXAoKGUpID0+IC8qIEBfX1BVUkVfXyAqLyBpKGwsIHtcblx0XHRcdFx0XHRcdGxhYmVsOiBTdHJpbmcoZSksXG5cdFx0XHRcdFx0XHRuYW1lOiB0LFxuXHRcdFx0XHRcdFx0Y2hlY2tlZDogcCA9PT0gZSxcblx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAoKSA9PiByKGUpXG5cdFx0XHRcdFx0fSwgU3RyaW5nKGUpKSlcblx0XHRcdFx0fSlcblx0XHRcdF1cblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gZCA9PT0gXCJ0ZXh0YXJlYVwiID8gLyogQF9fUFVSRV9fICovIGkodSwge1xuXHRcdGxhYmVsOiBvLFxuXHRcdHJvd3M6IDUsXG5cdFx0dmFsdWU6IFN0cmluZyhwID8/IFwiXCIpLFxuXHRcdHBsYWNlaG9sZGVyOiBTdHJpbmcoZS5kZWZhdWx0ID8/IFwiXCIpLFxuXHRcdG9uQ2hhbmdlOiAoZSkgPT4gcihlLnRhcmdldC52YWx1ZSlcblx0fSkgOiBkID09PSBcImJvb2xcIiA/IC8qIEBfX1BVUkVfXyAqLyBpKHMsIHtcblx0XHRsYWJlbDogbyxcblx0XHRjaGVja2VkOiBwID09PSAhMCxcblx0XHRvbkNoYW5nZTogKGUpID0+IHIoZS50YXJnZXQuY2hlY2tlZClcblx0fSkgOiAvKiBAX19QVVJFX18gKi8gaShmLCB7XG5cdFx0bGFiZWw6IG8sXG5cdFx0dHlwZTogZCA9PT0gXCJpbnRcIiB8fCBkID09PSBcImRlY2ltYWxcIiB8fCBkID09PSBcImRvdWJsZVwiID8gXCJudW1iZXJcIiA6IFwidGV4dFwiLFxuXHRcdHN0ZXA6IGQgPT09IFwiaW50XCIgPyAxIDogZCA9PT0gXCJkZWNpbWFsXCIgfHwgZCA9PT0gXCJkb3VibGVcIiA/IFwiYW55XCIgOiB2b2lkIDAsXG5cdFx0dmFsdWU6IFN0cmluZyhwID8/IFwiXCIpLFxuXHRcdHBsYWNlaG9sZGVyOiBTdHJpbmcoZS5kZWZhdWx0ID8/IFwiXCIpLFxuXHRcdG9uQ2hhbmdlOiAoZSkgPT4ge1xuXHRcdFx0bGV0IHQgPSBlLnRhcmdldC52YWx1ZTtcblx0XHRcdGlmIChkID09PSBcImludFwiKSB7XG5cdFx0XHRcdHIodCA9PT0gXCJcIiA/IFwiXCIgOiBOdW1iZXIucGFyc2VJbnQodCwgMTApKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0aWYgKGQgPT09IFwiZGVjaW1hbFwiIHx8IGQgPT09IFwiZG91YmxlXCIpIHtcblx0XHRcdFx0cih0ID09PSBcIlwiID8gXCJcIiA6IE51bWJlci5wYXJzZUZsb2F0KHQpKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0cih0KTtcblx0XHR9XG5cdH0pO1xufVxudmFyIGIgPSBlKGZ1bmN0aW9uKHsgc2NoZW1hOiBlLCB2YWx1ZTogbywgb25DaGFuZ2U6IHMsIGNsYXNzTmFtZTogYyA9IFwiXCIsIGlkOiBsLCBkaXNhYmxlZDogdSA9ICExLCAuLi5kIH0sIGYpIHtcblx0bGV0IGggPSBuKCksIF8gPSBsID8/IGBuYWJzLXVpLWR5bmFtaWNmb3JtLSR7aC5yZXBsYWNlKC86L2csIFwiXCIpfWAsIGIgPSBlICYmIGUudHlwZSA9PT0gXCJvYmplY3RcIiA/IGUgOiB2LCBbeCwgU10gPSByKCgpID0+IGcoYiwgbyA/PyBtKGIpKSk7XG5cdHQoKCkgPT4ge1xuXHRcdFMoZyhiLCBvID8/IG0oYikpKTtcblx0fSwgW2IsIG9dKTtcblx0bGV0IEMgPSBwKHgpID8geCA6IHt9LCB3ID0gYi50aXRsZSA/PyBcIkR5bmFtaWMgZm9ybVwiLCBUID0gYi5kZXNjcmlwdGlvbiwgRSA9IFtcblx0XHRcIm5hYnMtdWktZHluYW1pY2Zvcm1cIixcblx0XHR1ID8gXCJuYWJzLXVpLWR5bmFtaWNmb3JtLS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRjXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBEID0gKGUpID0+IHtcblx0XHRTKGUpLCBzPy4oZSk7XG5cdH07XG5cdHJldHVybiB1ID8gLyogQF9fUFVSRV9fICovIGEoXCJkaXZcIiwge1xuXHRcdHJlZjogZixcblx0XHRpZDogXyxcblx0XHRjbGFzc05hbWU6IEUsXG5cdFx0XCJhcmlhLWRpc2FibGVkXCI6IFwidHJ1ZVwiLFxuXHRcdC4uLmQsXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gYShcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1keW5hbWljZm9ybV9faGVhZGVyXCIsXG5cdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHluYW1pY2Zvcm1fX3RpdGxlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiB3XG5cdFx0XHR9KSwgVCA/IC8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHluYW1pY2Zvcm1fX2Rlc2NyaXB0aW9uXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBUXG5cdFx0XHR9KSA6IG51bGxdXG5cdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19maWVsZHNcIixcblx0XHRcdGNoaWxkcmVuOiBPYmplY3QuZW50cmllcyhiLnByb3BlcnRpZXMgPz8ge30pLm1hcCgoW2UsIHRdKSA9PiAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19maWVsZFwiLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGkoeSwge1xuXHRcdFx0XHRcdHNjaGVtYTogdCxcblx0XHRcdFx0XHRuYW1lOiBlLFxuXHRcdFx0XHRcdHZhbHVlOiBDW2VdLFxuXHRcdFx0XHRcdG9uQ2hhbmdlOiAobikgPT4gRCh7XG5cdFx0XHRcdFx0XHQuLi5DLFxuXHRcdFx0XHRcdFx0W2VdOiBnKHQsIG4pXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSlcblx0XHRcdH0sIGUpKVxuXHRcdH0pXVxuXHR9KSA6IC8qIEBfX1BVUkVfXyAqLyBhKFwiZGl2XCIsIHtcblx0XHRyZWY6IGYsXG5cdFx0aWQ6IF8sXG5cdFx0Y2xhc3NOYW1lOiBFLFxuXHRcdC4uLmQsXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gYShcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1keW5hbWljZm9ybV9faGVhZGVyXCIsXG5cdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHluYW1pY2Zvcm1fX3RpdGxlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiB3XG5cdFx0XHR9KSwgVCA/IC8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZHluYW1pY2Zvcm1fX2Rlc2NyaXB0aW9uXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBUXG5cdFx0XHR9KSA6IG51bGxdXG5cdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19maWVsZHNcIixcblx0XHRcdGNoaWxkcmVuOiBPYmplY3QuZW50cmllcyhiLnByb3BlcnRpZXMgPz8ge30pLm1hcCgoW2UsIHRdKSA9PiAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWR5bmFtaWNmb3JtX19maWVsZFwiLFxuXHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGkoeSwge1xuXHRcdFx0XHRcdHNjaGVtYTogdCxcblx0XHRcdFx0XHRuYW1lOiBlLFxuXHRcdFx0XHRcdHZhbHVlOiBDW2VdLFxuXHRcdFx0XHRcdG9uQ2hhbmdlOiAobikgPT4gRCh7XG5cdFx0XHRcdFx0XHQuLi5DLFxuXHRcdFx0XHRcdFx0W2VdOiBnKHQsIG4pXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSlcblx0XHRcdH0sIGUpKVxuXHRcdH0pXVxuXHR9KTtcbn0pO1xuYi5kaXNwbGF5TmFtZSA9IFwiRHluYW1pY0Zvcm1cIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYiBhcyBEeW5hbWljRm9ybSB9O1xuIiwiaW1wb3J0IHsgdXNlSWQgYXMgZSwgdXNlUmVmIGFzIHQsIHVzZVN0YXRlIGFzIG4gfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyByLCBqc3hzIGFzIGkgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvZmlsZXVwbG9hZC51dGlscy50c1xuZnVuY3Rpb24gYShlKSB7XG5cdHJldHVybiBlID8gKEFycmF5LmlzQXJyYXkoZSkgPyBlIDogU3RyaW5nKGUpLnNwbGl0KFwiLFwiKSkubWFwKChlKSA9PiBlLnRyaW0oKS50b0xvd2VyQ2FzZSgpKS5maWx0ZXIoQm9vbGVhbikubWFwKChlKSA9PiBlLnN0YXJ0c1dpdGgoXCIuXCIpID8gZSA6IGAuJHtlfWApIDogW107XG59XG5mdW5jdGlvbiBvKGUsIHQpIHtcblx0bGV0IG4gPSBTdHJpbmcoZSkuc3BsaXQoXCIsXCIpLm1hcCgoZSkgPT4gZS50cmltKCkudG9Mb3dlckNhc2UoKSkuZmlsdGVyKEJvb2xlYW4pLCByID0gYSh0KTtcblx0cmV0dXJuIFsuLi5uZXcgU2V0KFsuLi5uLCAuLi5yXSldO1xufVxuZnVuY3Rpb24gcyhlLCB0KSB7XG5cdGxldCBuID0gZS5uYW1lLnRvTG93ZXJDYXNlKCksIHIgPSAoZS50eXBlID8/IFwiXCIpLnRvTG93ZXJDYXNlKCk7XG5cdHJldHVybiB0ID09PSBcIiovKlwiID8gITAgOiB0LmVuZHNXaXRoKFwiLypcIikgPyByLnN0YXJ0c1dpdGgodC5zbGljZSgwLCAtMSkpIDogdC5zdGFydHNXaXRoKFwiLlwiKSA/IG4uZW5kc1dpdGgodCkgOiByID09PSB0O1xufVxuZnVuY3Rpb24gYyhlLCB0KSB7XG5cdGlmICh0Lmxlbmd0aCA9PT0gMCkgcmV0dXJuIHtcblx0XHRhY2NlcHRlZEZpbGVzOiBlLFxuXHRcdHJlamVjdGVkRmlsZXM6IFtdXG5cdH07XG5cdGxldCBuID0gW10sIHIgPSBbXTtcblx0Zm9yIChsZXQgaSBvZiBlKSAodC5zb21lKChlKSA9PiBzKGksIGUpKSA/IG4gOiByKS5wdXNoKGkpO1xuXHRyZXR1cm4ge1xuXHRcdGFjY2VwdGVkRmlsZXM6IG4sXG5cdFx0cmVqZWN0ZWRGaWxlczogclxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL0ZpbGVVcGxvYWQudHN4XG5mdW5jdGlvbiBsKHsgbGFiZWw6IGEgPSBcIkRyb3AgZmlsZXMgaGVyZSBvciBjbGljayBCcm93c2UgZmlsZXNcIiwgZGVzY3JpcHRpb246IHMgPSBcIkRyYWcgYW5kIGRyb3AgZmlsZXMgaW50byB0aGUgZHJvcCB6b25lIG9yIGNob29zZSB0aGVtIG1hbnVhbGx5LlwiLCBhY2NlcHQ6IGwgPSBcIlwiLCBleHRlbnNpb25zOiB1ID0gW10sIG11bHRpcGxlOiBkID0gITAsIGRpc2FibGVkOiBmID0gITEsIGNsYXNzTmFtZTogcCA9IFwiXCIsIHN1cmZhY2VDbGFzc05hbWU6IG0gPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogaCA9IFwiXCIsIGRlc2NyaXB0aW9uQ2xhc3NOYW1lOiBnID0gXCJcIiwgYnV0dG9uQ2xhc3NOYW1lOiBfID0gXCJcIiwgaW5wdXRDbGFzc05hbWU6IHYgPSBcIlwiLCBpZDogeSwgb25GaWxlc1NlbGVjdGVkOiBiLCAuLi54IH0pIHtcblx0bGV0IFMgPSBlKCksIEMgPSB5ID8/IGBuYWJzLXVpLWZpbGV1cGxvYWQtJHtTLnJlcGxhY2UoLzovZywgXCJcIil9YCwgdyA9IHQobnVsbCksIFtULCBFXSA9IG4oITEpLCBEID0gbyhsLCB1KSwgTyA9IEQubGVuZ3RoID4gMCA/IEQuam9pbihcIixcIikgOiB2b2lkIDAsIGsgPSBbXG5cdFx0XCJuYWJzLXVpLWZpbGV1cGxvYWRcIixcblx0XHRmID8gXCJuYWJzLXVpLWZpbGV1cGxvYWQtLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdFQgPyBcIm5hYnMtdWktZmlsZXVwbG9hZC0tZHJhZy1vdmVyXCIgOiBcIlwiLFxuXHRcdHBcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEEgPSBbXCJuYWJzLXVpLWZpbGV1cGxvYWRfX3N1cmZhY2VcIiwgbV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBqID0gW1wibmFicy11aS1maWxldXBsb2FkX19sYWJlbFwiLCBoXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIE0gPSBbXCJuYWJzLXVpLWZpbGV1cGxvYWRfX2Rlc2NyaXB0aW9uXCIsIGddLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgTiA9IFtcIm5hYnMtdWktZmlsZXVwbG9hZF9fYnV0dG9uXCIsIF9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgUCA9IFtcIm5hYnMtdWktZmlsZXVwbG9hZF9faW5wdXRcIiwgdl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBGID0gKGUsIHQpID0+IHtcblx0XHRsZXQgeyBhY2NlcHRlZEZpbGVzOiBuLCByZWplY3RlZEZpbGVzOiByIH0gPSBjKEFycmF5LmZyb20oZSA/PyBbXSksIEQpO1xuXHRcdGI/Lih7XG5cdFx0XHRhY2NlcHRlZEZpbGVzOiBuLFxuXHRcdFx0cmVqZWN0ZWRGaWxlczogcixcblx0XHRcdHNvdXJjZTogdFxuXHRcdH0pO1xuXHR9LCBJID0gKCkgPT4ge1xuXHRcdGYgfHwgdy5jdXJyZW50Py5jbGljaygpO1xuXHR9LCBMID0gKGUpID0+IHtcblx0XHRGKGUudGFyZ2V0LmZpbGVzLCBcImlucHV0XCIpLCBlLnRhcmdldC52YWx1ZSA9IFwiXCI7XG5cdH0sIFIgPSAoZSkgPT4ge1xuXHRcdGUucHJldmVudERlZmF1bHQoKSwgZiB8fCBFKCEwKTtcblx0fSwgeiA9IChlKSA9PiB7XG5cdFx0ZS5wcmV2ZW50RGVmYXVsdCgpLCBlLmN1cnJlbnRUYXJnZXQgPT09IGUudGFyZ2V0ICYmIEUoITEpO1xuXHR9LCBCID0gKGUpID0+IHtcblx0XHRlLnByZXZlbnREZWZhdWx0KCksIEUoITEpLCAhZiAmJiBGKGUuZGF0YVRyYW5zZmVyLmZpbGVzLCBcImRyb3BcIik7XG5cdH0sIFYgPSAoZSkgPT4ge1xuXHRcdChlLmtleSA9PT0gXCJFbnRlclwiIHx8IGUua2V5ID09PSBcIiBcIikgJiYgKGUucHJldmVudERlZmF1bHQoKSwgSSgpKTtcblx0fTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyByKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IGssXG5cdFx0Li4ueCxcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBBLFxuXHRcdFx0cm9sZTogXCJidXR0b25cIixcblx0XHRcdHRhYkluZGV4OiBmID8gLTEgOiAwLFxuXHRcdFx0XCJhcmlhLWxhYmVsXCI6IGEsXG5cdFx0XHRcImRhdGEtZGlzYWJsZWRcIjogZiA/IFwidHJ1ZVwiIDogdm9pZCAwLFxuXHRcdFx0b25DbGljazogSSxcblx0XHRcdG9uS2V5RG93bjogVixcblx0XHRcdG9uRHJhZ092ZXI6IFIsXG5cdFx0XHRvbkRyYWdMZWF2ZTogeixcblx0XHRcdG9uRHJvcDogQixcblx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyByKFwiaW5wdXRcIiwge1xuXHRcdFx0XHRcdHJlZjogdyxcblx0XHRcdFx0XHRpZDogQyxcblx0XHRcdFx0XHRjbGFzc05hbWU6IFAsXG5cdFx0XHRcdFx0dHlwZTogXCJmaWxlXCIsXG5cdFx0XHRcdFx0YWNjZXB0OiBPLFxuXHRcdFx0XHRcdG11bHRpcGxlOiBkLFxuXHRcdFx0XHRcdGRpc2FibGVkOiBmLFxuXHRcdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBhLFxuXHRcdFx0XHRcdHRpdGxlOiBhLFxuXHRcdFx0XHRcdG9uQ2hhbmdlOiBMXG5cdFx0XHRcdH0pLFxuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZmlsZXVwbG9hZF9fY29udGVudFwiLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcihcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IGosXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBhXG5cdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdHMgPyAvKiBAX19QVVJFX18gKi8gcihcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IE0sXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBzXG5cdFx0XHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gaShcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1maWxldXBsb2FkX19tZXRhXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbRC5sZW5ndGggPiAwID8gYEFjY2VwdGVkOiAke0Quam9pbihcIiwgXCIpfWAgOiBcIkFjY2VwdGVkOiBhbGwgZmlsZXNcIiwgZCA/IFwiIOKAoiBtdWx0aXBsZSBmaWxlc1wiIDogXCIg4oCiIHNpbmdsZSBmaWxlXCJdXG5cdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdF1cblx0XHRcdFx0fSksXG5cdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyByKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogTixcblx0XHRcdFx0XHRkaXNhYmxlZDogZixcblx0XHRcdFx0XHRvbkNsaWNrOiAoZSkgPT4ge1xuXHRcdFx0XHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKSwgSSgpO1xuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFwiQnJvd3NlIGZpbGVzXCJcblx0XHRcdFx0fSlcblx0XHRcdF1cblx0XHR9KVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbCBhcyBGaWxlVXBsb2FkIH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUsIHVzZUNhbGxiYWNrIGFzIHQsIHVzZUVmZmVjdCBhcyBuLCB1c2VNZW1vIGFzIHIsIHVzZVJlZiBhcyBpLCB1c2VTdGF0ZSBhcyBhIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgbywganN4cyBhcyBzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL3Rvb2xzZXRzL1NpbXBsZUdyYXBoVG9vbHNldC9TaW1wbGVHcmFwaFRvb2xzZXQudHN4XG5mdW5jdGlvbiBjKHsgdG9vbGJveExhYmVsOiBlLCB0b29sc2V0czogdCwgaXNDb2xsYXBzZWQ6IG4sIGlzRWRnZVRvb2xFbmFibGVkOiByLCBlZGdlSGludDogaSwgYWN0aXZlVG9vbElkc0J5U2V0OiBhLCBvblRvZ2dsZUNvbGxhcHNlOiBjLCBvblRvb2xDbGljazogbCwgb25Ub29sRG91YmxlQ2xpY2s6IHUgfSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyYXBoX190b29sYm94XCIsXG5cdFx0cm9sZTogXCJ0b29sYmFyXCIsXG5cdFx0XCJhcmlhLWxhYmVsXCI6IGUsXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcImJ1dHRvblwiLCB7XG5cdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX3Rvb2xib3hUb2dnbGVcIixcblx0XHRcdG9uQ2xpY2s6IGMsXG5cdFx0XHRcImFyaWEtbGFiZWxcIjogbiA/IFwiRXhwYW5kIHRvb2xib3hcIiA6IFwiQ29sbGFwc2UgdG9vbGJveFwiLFxuXHRcdFx0dGl0bGU6IG4gPyBcIkV4cGFuZCB0b29sYm94XCIgOiBcIkNvbGxhcHNlIHRvb2xib3hcIixcblx0XHRcdGNoaWxkcmVuOiBuID8gXCI+XCIgOiBcIjxcIlxuXHRcdH0pLCAhbiAmJiB0Lm1hcCgoZSkgPT4gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX3Rvb2xzZXRcIixcblx0XHRcdFwiZGF0YS10b29sc2V0XCI6IGUuaWQsXG5cdFx0XHRjaGlsZHJlbjogW2UubGFiZWwgJiYgLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fdG9vbHNldFRpdGxlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBlLmxhYmVsXG5cdFx0XHR9KSwgZS50b29scy5tYXAoKHQpID0+IHtcblx0XHRcdFx0bGV0IG4gPSBhW2UuaWRdID09PSB0LmlkLCBjID0gdC5raW5kID09PSBcImVkZ2VcIiwgZCA9IGMgJiYgIXIsIGYgPSB0Lmljb25DbGFzc05hbWUgPz8gYG5hYnMtdWktZ3JhcGhfX3Rvb2xJY29uLS0ke3QuaWR9YDtcblx0XHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogW1xuXHRcdFx0XHRcdFx0XCJuYWJzLXVpLWdyYXBoX190b29sXCIsXG5cdFx0XHRcdFx0XHRuID8gXCJuYWJzLXVpLWdyYXBoX190b29sLS1hY3RpdmVcIiA6IFwiXCIsXG5cdFx0XHRcdFx0XHRkID8gXCJuYWJzLXVpLWdyYXBoX190b29sLS1kaXNhYmxlZFwiIDogXCJcIlxuXHRcdFx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdFx0XHRcdGRpc2FibGVkOiBkLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IGwodCwgZS5pZCksXG5cdFx0XHRcdFx0b25Eb3VibGVDbGljazogKCkgPT4gdSh0LCBlLmlkKSxcblx0XHRcdFx0XHRcImRhdGEtYWN0aXZlXCI6IG4gPyBcInRydWVcIiA6IFwiZmFsc2VcIixcblx0XHRcdFx0XHRcImRhdGEtdG9vbFwiOiB0LmlkLFxuXHRcdFx0XHRcdHRpdGxlOiBjID8gaSA6IHQubGFiZWwsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBbXCJuYWJzLXVpLWdyYXBoX190b29sSWNvblwiLCBmXS5qb2luKFwiIFwiKSxcblx0XHRcdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCJcblx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyYXBoX190b29sTGFiZWxcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiB0LmxhYmVsXG5cdFx0XHRcdFx0fSldXG5cdFx0XHRcdH0sIHQuaWQpO1xuXHRcdFx0fSldXG5cdFx0fSwgZS5pZCkpXVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy90b29sc2V0cy9TaW1wbGVHcmFwaFRvb2xzZXQvc2ltcGxlR3JhcGhUb29sc2V0LnRzXG52YXIgbCA9IHtcblx0aWQ6IFwic2ltcGxlLWdyYXBoLXRvb2xzZXRcIixcblx0bGFiZWw6IFwiU2ltcGxlIEdyYXBoIFRvb2xzZXRcIixcblx0dG9vbHM6IFtcblx0XHR7XG5cdFx0XHRpZDogXCJzcXVhcmVcIixcblx0XHRcdGxhYmVsOiBcIlNxdWFyZVwiLFxuXHRcdFx0a2luZDogXCJub2RlXCIsXG5cdFx0XHRub2RlVHlwZTogXCJzcXVhcmVcIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwiY2lyY2xlXCIsXG5cdFx0XHRsYWJlbDogXCJDaXJjbGVcIixcblx0XHRcdGtpbmQ6IFwibm9kZVwiLFxuXHRcdFx0bm9kZVR5cGU6IFwiY2lyY2xlXCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcInJlY3RhbmdsZVwiLFxuXHRcdFx0bGFiZWw6IFwiUmVjdGFuZ2xlXCIsXG5cdFx0XHRraW5kOiBcIm5vZGVcIixcblx0XHRcdG5vZGVUeXBlOiBcInJlY3RhbmdsZVwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJoZXhhZ29uXCIsXG5cdFx0XHRsYWJlbDogXCJIZXhhZ29uXCIsXG5cdFx0XHRraW5kOiBcIm5vZGVcIixcblx0XHRcdG5vZGVUeXBlOiBcImhleGFnb25cIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwiZWRnZVwiLFxuXHRcdFx0bGFiZWw6IFwiRWRnZVwiLFxuXHRcdFx0a2luZDogXCJlZGdlXCJcblx0XHR9XG5cdF1cbn0sIHUgPSBbbF0sIGQgPSB7XG5cdGlkOiBcImFnZW50aWMtd29ya2Zsb3ctdG9vbHNldFwiLFxuXHRsYWJlbDogXCJBZ2VudGljIFdvcmtmbG93XCIsXG5cdHRvb2xzOiBbXG5cdFx0e1xuXHRcdFx0aWQ6IFwiaW5pdGlhdGl2ZVwiLFxuXHRcdFx0bGFiZWw6IFwiSW5pdGlhdGl2ZVwiLFxuXHRcdFx0a2luZDogXCJub2RlXCIsXG5cdFx0XHRub2RlVHlwZTogXCJpbml0aWF0aXZlXCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcInNjZW5hcmlvXCIsXG5cdFx0XHRsYWJlbDogXCJTY2VuYXJpb1wiLFxuXHRcdFx0a2luZDogXCJub2RlXCIsXG5cdFx0XHRub2RlVHlwZTogXCJzY2VuYXJpb1wiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJsaWZlY3ljbGVcIixcblx0XHRcdGxhYmVsOiBcIkxpZmVjeWNsZVwiLFxuXHRcdFx0a2luZDogXCJub2RlXCIsXG5cdFx0XHRub2RlVHlwZTogXCJsaWZlY3ljbGVcIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwiY29udGV4dFwiLFxuXHRcdFx0bGFiZWw6IFwiQ29udGV4dFwiLFxuXHRcdFx0a2luZDogXCJub2RlXCIsXG5cdFx0XHRub2RlVHlwZTogXCJjb250ZXh0XCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcImNvbm5lY3RvclwiLFxuXHRcdFx0bGFiZWw6IFwiQ29ubmVjdG9yXCIsXG5cdFx0XHRraW5kOiBcImVkZ2VcIixcblx0XHRcdGljb25DbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fdG9vbEljb24tLWVkZ2VcIlxuXHRcdH1cblx0XVxufSwgZiA9IFtkXSwgcCA9IHtcblx0c3F1YXJlOiBcIlNxdWFyZVwiLFxuXHRjaXJjbGU6IFwiQ2lyY2xlXCIsXG5cdHJlY3RhbmdsZTogXCJSZWN0YW5nbGVcIixcblx0aGV4YWdvbjogXCJIZXhhZ29uXCIsXG5cdGluaXRpYXRpdmU6IFwiSW5pdGlhdGl2ZVwiLFxuXHRzY2VuYXJpbzogXCJTY2VuYXJpb1wiLFxuXHRsaWZlY3ljbGU6IFwiTGlmZWN5Y2xlXCIsXG5cdGNvbnRleHQ6IFwiQ29udGV4dFwiLFxuXHRlZGdlOiBcIkVkZ2VcIlxufSwgbSA9IHtcblx0c3F1YXJlOiB7XG5cdFx0d2lkdGg6IDEwMCxcblx0XHRoZWlnaHQ6IDEwMFxuXHR9LFxuXHRjaXJjbGU6IHtcblx0XHR3aWR0aDogMTAwLFxuXHRcdGhlaWdodDogMTAwXG5cdH0sXG5cdHJlY3RhbmdsZToge1xuXHRcdHdpZHRoOiAxNDAsXG5cdFx0aGVpZ2h0OiA5MFxuXHR9LFxuXHRoZXhhZ29uOiB7XG5cdFx0d2lkdGg6IDEyMCxcblx0XHRoZWlnaHQ6IDEwNFxuXHR9LFxuXHRpbml0aWF0aXZlOiB7XG5cdFx0d2lkdGg6IDE4MCxcblx0XHRoZWlnaHQ6IDExMFxuXHR9LFxuXHRzY2VuYXJpbzoge1xuXHRcdHdpZHRoOiAxOTAsXG5cdFx0aGVpZ2h0OiAxMDBcblx0fSxcblx0bGlmZWN5Y2xlOiB7XG5cdFx0d2lkdGg6IDEyNixcblx0XHRoZWlnaHQ6IDEyNlxuXHR9LFxuXHRjb250ZXh0OiB7XG5cdFx0d2lkdGg6IDE5MCxcblx0XHRoZWlnaHQ6IDEyNFxuXHR9XG59LCBoID0ge1xuXHRzaW1wbGU6IFwic3F1YXJlXCIsXG5cdFwiYWdlbnRpYy13b3JrZmxvd1wiOiBcImluaXRpYXRpdmVcIlxufSwgZyA9IC41LCBfID0gMi41LCB2ID0ge1xuXHRcImluaXRpYXRpdmUtPmluaXRpYXRpdmVcIjogXCJFeHRlbmRcIixcblx0XCJpbml0aWF0aXZlLT5zY2VuYXJpb1wiOiBcIlJlc3VsdEluXCIsXG5cdFwic2NlbmFyaW8tPmxpZmVjeWNsZVwiOiBcIlVzZVwiLFxuXHRcImNvbnRleHQtPmxpZmVjeWNsZVwiOiBcIlVzZWRCeVwiXG59LCB5ID0gKCkgPT4gdHlwZW9mIGNyeXB0byA8IFwidVwiICYmIFwicmFuZG9tVVVJRFwiIGluIGNyeXB0byA/IGNyeXB0by5yYW5kb21VVUlEKCkgOiBgJHtEYXRlLm5vdygpLnRvU3RyaW5nKDM2KX0tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDE2KS5zbGljZSgyKX1gLCBlZSA9IChlLCB0LCBuKSA9PiBNYXRoLm1pbihuLCBNYXRoLm1heCh0LCBlKSksIGIgPSAoZSwgdCkgPT4gdltgJHtlfS0+JHt0fWBdID8/IG51bGwsIHggPSAoZSwgdCwgbiwgcikgPT4ge1xuXHRsZXQgaSA9IGUuZmluZCgoZSkgPT4gZS5pZCA9PT0gbiksIGEgPSBlLmZpbmQoKGUpID0+IGUuaWQgPT09IHIpO1xuXHRpZiAoIWkgfHwgIWEpIHJldHVybiB7XG5cdFx0YWxsb3dlZDogITEsXG5cdFx0bGFiZWw6IG51bGxcblx0fTtcblx0bGV0IG8gPSBiKGkudHlwZSwgYS50eXBlKTtcblx0aWYgKCFvIHx8IGkudHlwZSA9PT0gXCJzY2VuYXJpb1wiICYmIGEudHlwZSA9PT0gXCJsaWZlY3ljbGVcIiAmJiB0LnNvbWUoKHQpID0+IHQuZnJvbUlkID09PSBuID8gZS5maW5kKChlKSA9PiBlLmlkID09PSB0LnRvSWQpPy50eXBlID09PSBcImxpZmVjeWNsZVwiIDogITEpKSByZXR1cm4ge1xuXHRcdGFsbG93ZWQ6ICExLFxuXHRcdGxhYmVsOiBudWxsXG5cdH07XG5cdGlmIChpLnR5cGUgPT09IFwiaW5pdGlhdGl2ZVwiICYmIGEudHlwZSA9PT0gXCJpbml0aWF0aXZlXCIpIHtcblx0XHRpZiAodC5zb21lKCh0KSA9PiB0LnRvSWQgPT09IHIgPyBlLmZpbmQoKGUpID0+IGUuaWQgPT09IHQuZnJvbUlkKT8udHlwZSA9PT0gXCJpbml0aWF0aXZlXCIgOiAhMSkpIHJldHVybiB7XG5cdFx0XHRhbGxvd2VkOiAhMSxcblx0XHRcdGxhYmVsOiBudWxsXG5cdFx0fTtcblx0XHRsZXQgaSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0Zm9yIChsZXQgbiBvZiB0KSB7XG5cdFx0XHRsZXQgdCA9IGUuZmluZCgoZSkgPT4gZS5pZCA9PT0gbi5mcm9tSWQpLCByID0gZS5maW5kKChlKSA9PiBlLmlkID09PSBuLnRvSWQpO1xuXHRcdFx0aWYgKHQ/LnR5cGUgIT09IFwiaW5pdGlhdGl2ZVwiIHx8IHI/LnR5cGUgIT09IFwiaW5pdGlhdGl2ZVwiKSBjb250aW51ZTtcblx0XHRcdGxldCBhID0gaS5nZXQobi5mcm9tSWQpID8/IFtdO1xuXHRcdFx0YS5wdXNoKG4udG9JZCksIGkuc2V0KG4uZnJvbUlkLCBhKTtcblx0XHR9XG5cdFx0aWYgKCgoZSwgdCkgPT4ge1xuXHRcdFx0bGV0IG4gPSBbZV0sIHIgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdFx0Zm9yICg7IG4ubGVuZ3RoID4gMDspIHtcblx0XHRcdFx0bGV0IGUgPSBuLnBvcCgpO1xuXHRcdFx0XHRpZiAoIWUgfHwgci5oYXMoZSkpIGNvbnRpbnVlO1xuXHRcdFx0XHRpZiAoZSA9PT0gdCkgcmV0dXJuICEwO1xuXHRcdFx0XHRyLmFkZChlKTtcblx0XHRcdFx0bGV0IGEgPSBpLmdldChlKSA/PyBbXTtcblx0XHRcdFx0Zm9yIChsZXQgZSBvZiBhKSBuLnB1c2goZSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gITE7XG5cdFx0fSkociwgbikpIHJldHVybiB7XG5cdFx0XHRhbGxvd2VkOiAhMSxcblx0XHRcdGxhYmVsOiBudWxsXG5cdFx0fTtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdGFsbG93ZWQ6ICEwLFxuXHRcdGxhYmVsOiBvXG5cdH07XG59LCB0ZSA9IChlLCB0LCBuID0gNCkgPT4ge1xuXHRsZXQgciA9IGUudHJpbSgpLnJlcGxhY2UoL1xccysvZywgXCIgXCIpO1xuXHRpZiAoIXIpIHJldHVybiBbXCJcIl07XG5cdGxldCBpID0gTWF0aC5tYXgoOSwgTWF0aC5mbG9vcigodCAtIDE2KSAvIDYuNCkpLCBhID0gci5zcGxpdChcIiBcIiksIG8gPSBbXSwgcyA9IFwiXCI7XG5cdGZvciAobGV0IGUgb2YgYSkge1xuXHRcdGxldCB0ID0gZTtcblx0XHRmb3IgKDsgdC5sZW5ndGggPiBpOykge1xuXHRcdFx0bGV0IGUgPSB0LnNsaWNlKDAsIGkgLSAxKSArIFwiLVwiO1xuXHRcdFx0aWYgKHQgPSB0LnNsaWNlKGkgLSAxKSwgcy5sZW5ndGggPiAwICYmIChvLnB1c2gocyksIHMgPSBcIlwiKSwgby5wdXNoKGUpLCBvLmxlbmd0aCA+PSBuKSB7XG5cdFx0XHRcdGxldCBlID0gby5zbGljZSgwLCBuKTtcblx0XHRcdFx0cmV0dXJuIGVbbiAtIDFdID0gYCR7ZVtuIC0gMV0uc2xpY2UoMCwgTWF0aC5tYXgoMSwgaSAtIDEpKX3igKZgLCBlO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRsZXQgciA9IHMubGVuZ3RoID4gMCA/IGAke3N9ICR7dH1gIDogdDtcblx0XHRpZiAoci5sZW5ndGggPD0gaSkge1xuXHRcdFx0cyA9IHI7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0aWYgKHMubGVuZ3RoID4gMCAmJiBvLnB1c2gocyksIHMgPSB0LCBvLmxlbmd0aCA+PSBuKSBicmVhaztcblx0fVxuXHRpZiAocy5sZW5ndGggPiAwICYmIG8ubGVuZ3RoIDwgbiAmJiBvLnB1c2gocyksIG8ubGVuZ3RoIDw9IG4pIHJldHVybiBvO1xuXHRsZXQgYyA9IG8uc2xpY2UoMCwgbik7XG5cdHJldHVybiBjW24gLSAxXSA9IGAke2NbbiAtIDFdLnNsaWNlKDAsIE1hdGgubWF4KDEsIGkgLSAxKSl94oCmYCwgYztcbn0sIFMgPSBlKGZ1bmN0aW9uKHsgY2xhc3NOYW1lOiBlLCB0b29sYm94TGFiZWw6IGwgPSBcIlRvb2xzXCIsIHRvb2xzZXQ6IGQgPSBcInNpbXBsZVwiLCB0b29sc2V0czogdiwgVG9vbGJveENvbXBvbmVudDogYiA9IGMsIG9uU2hhcGVBZGQ6IFMsIG9uU2hhcGVNb3ZlOiBDLCAuLi5uZSB9LCB3KSB7XG5cdGxldCBUID0gZCwgRSA9ICEhKHYgJiYgdi5sZW5ndGggPiAwKSwgRCA9IGhbVF0sIE8gPSAhRSAmJiBUID09PSBcImFnZW50aWMtd29ya2Zsb3dcIiwgayA9IHIoKCkgPT4gdiAmJiB2Lmxlbmd0aCA+IDAgPyB2IDogVCA9PT0gXCJhZ2VudGljLXdvcmtmbG93XCIgPyBmIDogdSwgW1QsIHZdKSwgQSA9IGkobnVsbCksIFtqLCBNXSA9IGEoW10pLCBbTiwgUF0gPSBhKFtdKSwgW0YsIEldID0gYShEKSwgW3JlLCBMXSA9IGEoe30pLCBbUiwgaWVdID0gYSghMSksIFt6LCBCXSA9IGEobnVsbCksIFtWLCBIXSA9IGEobnVsbCksIFtVLCBXXSA9IGEobnVsbCksIFtHLCBLXSA9IGEobnVsbCksIFtxLCBKXSA9IGEoe1xuXHRcdHNjYWxlOiAxLFxuXHRcdG9mZnNldFg6IDAsXG5cdFx0b2Zmc2V0WTogMFxuXHR9KSwgWSA9IGkocSk7XG5cdG4oKCkgPT4ge1xuXHRcdFkuY3VycmVudCA9IHE7XG5cdH0sIFtxXSksIG4oKCkgPT4ge1xuXHRcdEwoKGUpID0+IHtcblx0XHRcdGxldCB0ID0ge307XG5cdFx0XHRmb3IgKGxldCBuIG9mIGspIHRbbi5pZF0gPSBlW24uaWRdID8/IG51bGw7XG5cdFx0XHRyZXR1cm4gdDtcblx0XHR9KTtcblx0fSwgW2tdKSwgbigoKSA9PiB7XG5cdFx0bGV0IGUgPSBuZXcgU2V0KFtcImVkZ2VcIl0pO1xuXHRcdGZvciAobGV0IHQgb2YgaykgZm9yIChsZXQgbiBvZiB0LnRvb2xzKSBuLmtpbmQgPT09IFwibm9kZVwiICYmIG4ubm9kZVR5cGUgJiYgZS5hZGQobi5ub2RlVHlwZSk7XG5cdFx0SSgodCkgPT4gZS5oYXModCkgPyB0IDogRCk7XG5cdH0sIFtELCBrXSk7XG5cdGxldCBhZSA9IHIoKCkgPT4gYHRyYW5zbGF0ZSgke3Eub2Zmc2V0WH0sICR7cS5vZmZzZXRZfSkgc2NhbGUoJHtxLnNjYWxlfSlgLCBbcV0pLCBYID0gdCgoZSwgdCwgbikgPT4ge1xuXHRcdGxldCB7IHNjYWxlOiByLCBvZmZzZXRYOiBpLCBvZmZzZXRZOiBhIH0gPSBZLmN1cnJlbnQ7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHg6IChlIC0gbi5sZWZ0IC0gaSkgLyByLFxuXHRcdFx0eTogKHQgLSBuLnRvcCAtIGEpIC8gclxuXHRcdH07XG5cdH0sIFtdKSwgWiA9IHQoKGUsIHQpID0+IHtcblx0XHRsZXQgbiA9IEEuY3VycmVudD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cdFx0aWYgKCFuKSByZXR1cm47XG5cdFx0bGV0IHIgPSBtW2VdLCBpID0gWChuLmxlZnQgKyBuLndpZHRoIC8gMiwgbi50b3AgKyBuLmhlaWdodCAvIDIsIG4pO1xuXHRcdE0oKG4pID0+IHtcblx0XHRcdGxldCBhID0ge1xuXHRcdFx0XHRpZDogeSgpLFxuXHRcdFx0XHR0eXBlOiBlLFxuXHRcdFx0XHRsYWJlbDogYCR7dCA/PyBwW2VdfSAke24ubGVuZ3RoICsgMX1gLFxuXHRcdFx0XHR3aWR0aDogci53aWR0aCxcblx0XHRcdFx0aGVpZ2h0OiByLmhlaWdodCxcblx0XHRcdFx0eDogaS54IC0gci53aWR0aCAvIDIsXG5cdFx0XHRcdHk6IGkueSAtIHIuaGVpZ2h0IC8gMixcblx0XHRcdFx0Y3JlYXRlZEF0OiBEYXRlLm5vdygpXG5cdFx0XHR9LCBvID0gWy4uLm4sIGFdO1xuXHRcdFx0cmV0dXJuIFM/LihhKSwgQihhLmlkKSwgbztcblx0XHR9KTtcblx0fSwgW1MsIFhdKSwgUSA9IHQoKGUsIHQpID0+IHtcblx0XHRlICE9PSB0ICYmIFAoKG4pID0+IHtcblx0XHRcdGlmIChPID8gbi5zb21lKChuKSA9PiBuLmZyb21JZCA9PT0gZSAmJiBuLnRvSWQgPT09IHQpIDogbi5zb21lKChuKSA9PiBuLmZyb21JZCA9PT0gZSAmJiBuLnRvSWQgPT09IHQgfHwgbi5mcm9tSWQgPT09IHQgJiYgbi50b0lkID09PSBlKSkgcmV0dXJuIG47XG5cdFx0XHRsZXQgciA9IGBFZGdlICR7bi5sZW5ndGggKyAxfWA7XG5cdFx0XHRpZiAoTykge1xuXHRcdFx0XHRsZXQgaSA9IHgoaiwgbiwgZSwgdCk7XG5cdFx0XHRcdGlmICghaS5hbGxvd2VkIHx8ICFpLmxhYmVsKSByZXR1cm4gbjtcblx0XHRcdFx0ciA9IGkubGFiZWw7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gWy4uLm4sIHtcblx0XHRcdFx0aWQ6IHkoKSxcblx0XHRcdFx0ZnJvbUlkOiBlLFxuXHRcdFx0XHR0b0lkOiB0LFxuXHRcdFx0XHRsYWJlbDogcixcblx0XHRcdFx0Y3JlYXRlZEF0OiBEYXRlLm5vdygpXG5cdFx0XHR9XTtcblx0XHR9KTtcblx0fSwgW08sIGpdKSwgb2UgPSB0KChlLCB0KSA9PiB7XG5cdFx0aWYgKEwoKG4pID0+ICh7XG5cdFx0XHQuLi5uLFxuXHRcdFx0W3RdOiBlLmlkXG5cdFx0fSkpLCBlLmtpbmQgPT09IFwiZWRnZVwiKSB7XG5cdFx0XHRpZiAoIXopIHJldHVybjtcblx0XHRcdEkoXCJlZGdlXCIpLCBIKHopO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRlLm5vZGVUeXBlICYmIChJKGUubm9kZVR5cGUpLCBIKG51bGwpKTtcblx0fSwgW3pdKSwgc2UgPSB0KChlLCB0KSA9PiB7XG5cdFx0ZS5raW5kICE9PSBcImVkZ2VcIiAmJiBlLm5vZGVUeXBlICYmIChMKChuKSA9PiAoe1xuXHRcdFx0Li4ubixcblx0XHRcdFt0XTogZS5pZFxuXHRcdH0pKSwgSShlLm5vZGVUeXBlKSwgSChudWxsKSwgWihlLm5vZGVUeXBlLCBlLmxhYmVsKSk7XG5cdH0sIFtaXSksIGNlID0gdCgoKSA9PiB7XG5cdFx0aWUoKGUpID0+ICFlKTtcblx0fSwgW10pLCAkID0gdCgoZSwgdCkgPT4ge1xuXHRcdGlmIChlLnByZXZlbnREZWZhdWx0KCksIGUuc3RvcFByb3BhZ2F0aW9uKCksIEIodCksIEYgPT09IFwiZWRnZVwiKSB7XG5cdFx0XHRWICYmIFYgIT09IHQgJiYgKFEoViwgdCksIEgobnVsbCksIEkoRCkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRsZXQgbiA9IEEuY3VycmVudD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksIHIgPSBqLmZpbmQoKGUpID0+IGUuaWQgPT09IHQpO1xuXHRcdGlmICghbiB8fCAhcikgcmV0dXJuO1xuXHRcdGxldCB7IHg6IGksIHk6IGEgfSA9IFgoZS5jbGllbnRYLCBlLmNsaWVudFksIG4pO1xuXHRcdFcoe1xuXHRcdFx0aWQ6IHQsXG5cdFx0XHRvZmZzZXRYOiBpIC0gci54LFxuXHRcdFx0b2Zmc2V0WTogYSAtIHIueSxcblx0XHRcdHBvaW50ZXJJZDogZS5wb2ludGVySWRcblx0XHR9KTtcblx0fSwgW1xuXHRcdEYsXG5cdFx0USxcblx0XHRELFxuXHRcdFYsXG5cdFx0aixcblx0XHRYXG5cdF0pLCBsZSA9IHQoKGUpID0+IHtcblx0XHRpZiAoZS5idXR0b24gIT09IDApIHJldHVybjtcblx0XHRCKG51bGwpLCBGID09PSBcImVkZ2VcIiAmJiAoSChudWxsKSwgSShEKSk7XG5cdFx0bGV0IHQgPSBlLnBvaW50ZXJJZDtcblx0XHRlLmN1cnJlbnRUYXJnZXQuc2V0UG9pbnRlckNhcHR1cmUodCksIEsoe1xuXHRcdFx0cG9pbnRlcklkOiB0LFxuXHRcdFx0c3RhcnRYOiBlLmNsaWVudFgsXG5cdFx0XHRzdGFydFk6IGUuY2xpZW50WSxcblx0XHRcdHN0YXJ0T2Zmc2V0WDogcS5vZmZzZXRYLFxuXHRcdFx0c3RhcnRPZmZzZXRZOiBxLm9mZnNldFlcblx0XHR9KTtcblx0fSwgW1xuXHRcdEYsXG5cdFx0RCxcblx0XHRxXG5cdF0pLCB1ZSA9IHQoKGUpID0+IHtcblx0XHRlLnByZXZlbnREZWZhdWx0KCk7XG5cdFx0bGV0IHQgPSBBLmN1cnJlbnQ/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRcdGlmICghdCkgcmV0dXJuO1xuXHRcdGxldCBuID0gZS5jbGllbnRYIC0gdC5sZWZ0LCByID0gZS5jbGllbnRZIC0gdC50b3AsIGkgPSAtZS5kZWx0YVkgKiAuMDAxNTtcblx0XHRKKChlKSA9PiB7XG5cdFx0XHRsZXQgdCA9IGVlKGUuc2NhbGUgKyBpLCBnLCBfKTtcblx0XHRcdGlmICh0ID09PSBlLnNjYWxlKSByZXR1cm4gZTtcblx0XHRcdGxldCBhID0gKG4gLSBlLm9mZnNldFgpIC8gZS5zY2FsZSwgbyA9IChyIC0gZS5vZmZzZXRZKSAvIGUuc2NhbGU7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRzY2FsZTogdCxcblx0XHRcdFx0b2Zmc2V0WDogbiAtIGEgKiB0LFxuXHRcdFx0XHRvZmZzZXRZOiByIC0gbyAqIHRcblx0XHRcdH07XG5cdFx0fSk7XG5cdH0sIFtdKTtcblx0bigoKSA9PiB7XG5cdFx0aWYgKCFVKSByZXR1cm47XG5cdFx0bGV0IGUgPSAoZSkgPT4ge1xuXHRcdFx0aWYgKGUucG9pbnRlcklkICE9PSBVLnBvaW50ZXJJZCkgcmV0dXJuO1xuXHRcdFx0bGV0IHQgPSBBLmN1cnJlbnQ/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRcdFx0dCAmJiBNKChuKSA9PiBuLm1hcCgobikgPT4ge1xuXHRcdFx0XHRpZiAobi5pZCAhPT0gVS5pZCkgcmV0dXJuIG47XG5cdFx0XHRcdGxldCB7IHg6IHIsIHk6IGkgfSA9IFgoZS5jbGllbnRYLCBlLmNsaWVudFksIHQpLCBhID0ge1xuXHRcdFx0XHRcdC4uLm4sXG5cdFx0XHRcdFx0eDogciAtIFUub2Zmc2V0WCxcblx0XHRcdFx0XHR5OiBpIC0gVS5vZmZzZXRZXG5cdFx0XHRcdH07XG5cdFx0XHRcdHJldHVybiBDPy4oYSksIGE7XG5cdFx0XHR9KSk7XG5cdFx0fSwgdCA9IChlKSA9PiB7XG5cdFx0XHRlLnBvaW50ZXJJZCA9PT0gVS5wb2ludGVySWQgJiYgVyhudWxsKTtcblx0XHR9O1xuXHRcdHJldHVybiBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcm1vdmVcIiwgZSksIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJwb2ludGVydXBcIiwgdCksICgpID0+IHtcblx0XHRcdGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVybW92ZVwiLCBlKSwgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJ1cFwiLCB0KTtcblx0XHR9O1xuXHR9LCBbXG5cdFx0VSxcblx0XHRDLFxuXHRcdFhcblx0XSksIG4oKCkgPT4ge1xuXHRcdGlmICghRykgcmV0dXJuO1xuXHRcdGxldCBlID0gKGUpID0+IHtcblx0XHRcdGlmIChlLnBvaW50ZXJJZCAhPT0gRy5wb2ludGVySWQpIHJldHVybjtcblx0XHRcdGxldCB0ID0gZS5jbGllbnRYIC0gRy5zdGFydFgsIG4gPSBlLmNsaWVudFkgLSBHLnN0YXJ0WTtcblx0XHRcdEooKGUpID0+ICh7XG5cdFx0XHRcdC4uLmUsXG5cdFx0XHRcdG9mZnNldFg6IEcuc3RhcnRPZmZzZXRYICsgdCxcblx0XHRcdFx0b2Zmc2V0WTogRy5zdGFydE9mZnNldFkgKyBuXG5cdFx0XHR9KSk7XG5cdFx0fSwgdCA9IChlKSA9PiB7XG5cdFx0XHRlLnBvaW50ZXJJZCA9PT0gRy5wb2ludGVySWQgJiYgKEEuY3VycmVudD8ucmVsZWFzZVBvaW50ZXJDYXB0dXJlKEcucG9pbnRlcklkKSwgSyhudWxsKSk7XG5cdFx0fTtcblx0XHRyZXR1cm4gZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJtb3ZlXCIsIGUpLCBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcnVwXCIsIHQpLCAoKSA9PiB7XG5cdFx0XHRkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcm1vdmVcIiwgZSksIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVydXBcIiwgdCk7XG5cdFx0fTtcblx0fSwgW0ddKTtcblx0bGV0IGRlID0gW1xuXHRcdFwibmFicy11aS1ncmFwaFwiLFxuXHRcdFIgPyBcIm5hYnMtdWktZ3JhcGgtLXRvb2xib3gtY29sbGFwc2VkXCIgOiBcIlwiLFxuXHRcdGVcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGZlID0geiAhPT0gbnVsbCwgcGUgPSBGID09PSBcImVkZ2VcIiAmJiBWID8gXCJTZWxlY3QgYW5vdGhlciBub2RlXCIgOiBcIlNlbGVjdCBub2RlIGZpcnN0XCI7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0cmVmOiB3LFxuXHRcdGNsYXNzTmFtZTogZGUsXG5cdFx0Li4ubmUsXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fY2FudmFzXCIsXG5cdFx0XHRyZWY6IEEsXG5cdFx0XHRvblBvaW50ZXJEb3duOiBsZSxcblx0XHRcdG9uV2hlZWw6IHVlLFxuXHRcdFx0cm9sZTogXCJwcmVzZW50YXRpb25cIixcblx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIG8oXCJzdmdcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fY2FudmFzU3ZnXCIsXG5cdFx0XHRcdHJvbGU6IFwicHJlc2VudGF0aW9uXCIsXG5cdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gcyhcImdcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyYXBoX192aWV3cG9ydFwiLFxuXHRcdFx0XHRcdHRyYW5zZm9ybTogYWUsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFtOLm1hcCgoZSkgPT4ge1xuXHRcdFx0XHRcdFx0bGV0IHQgPSBqLmZpbmQoKHQpID0+IHQuaWQgPT09IGUuZnJvbUlkKSwgbiA9IGouZmluZCgodCkgPT4gdC5pZCA9PT0gZS50b0lkKTtcblx0XHRcdFx0XHRcdGlmICghdCB8fCAhbikgcmV0dXJuIG51bGw7XG5cdFx0XHRcdFx0XHRsZXQgciA9ICh0LnggKyB0LndpZHRoIC8gMiArIChuLnggKyBuLndpZHRoIC8gMikpIC8gMiwgaSA9ICh0LnkgKyB0LmhlaWdodCAvIDIgKyAobi55ICsgbi5oZWlnaHQgLyAyKSkgLyAyO1xuXHRcdFx0XHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZ1wiLCB7IGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJsaW5lXCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX2VkZ2VcIixcblx0XHRcdFx0XHRcdFx0eDE6IHQueCArIHQud2lkdGggLyAyLFxuXHRcdFx0XHRcdFx0XHR5MTogdC55ICsgdC5oZWlnaHQgLyAyLFxuXHRcdFx0XHRcdFx0XHR4Mjogbi54ICsgbi53aWR0aCAvIDIsXG5cdFx0XHRcdFx0XHRcdHkyOiBuLnkgKyBuLmhlaWdodCAvIDJcblx0XHRcdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gbyhcInRleHRcIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fZWRnZUxhYmVsXCIsXG5cdFx0XHRcdFx0XHRcdHg6IHIsXG5cdFx0XHRcdFx0XHRcdHk6IGkgLSA2LFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5sYWJlbFxuXHRcdFx0XHRcdFx0fSldIH0sIGUuaWQpO1xuXHRcdFx0XHRcdH0pLCBqLm1hcCgoZSkgPT4ge1xuXHRcdFx0XHRcdFx0bGV0IHQgPSB0ZShlLmxhYmVsLCBlLndpZHRoKSwgbiA9IGUueCArIGUud2lkdGggLyAyLCByID0gZS55ICsgZS5oZWlnaHQgLyAyIC0gKHQubGVuZ3RoIC0gMSkgKiAxMiAvIDIsIGkgPSB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogW1xuXHRcdFx0XHRcdFx0XHRcdFwibmFicy11aS1ncmFwaF9fc2hhcGVcIixcblx0XHRcdFx0XHRcdFx0XHRlLnR5cGUgPT09IFwiY2lyY2xlXCIgJiYgXCJuYWJzLXVpLWdyYXBoX19zaGFwZS0tY2lyY2xlXCIsXG5cdFx0XHRcdFx0XHRcdFx0ZS50eXBlID09PSBcInJlY3RhbmdsZVwiICYmIFwibmFicy11aS1ncmFwaF9fc2hhcGUtLXJlY3RhbmdsZVwiLFxuXHRcdFx0XHRcdFx0XHRcdGUudHlwZSA9PT0gXCJoZXhhZ29uXCIgJiYgXCJuYWJzLXVpLWdyYXBoX19zaGFwZS0taGV4YWdvblwiLFxuXHRcdFx0XHRcdFx0XHRcdGUudHlwZSA9PT0gXCJpbml0aWF0aXZlXCIgJiYgXCJuYWJzLXVpLWdyYXBoX19zaGFwZS0taW5pdGlhdGl2ZVwiLFxuXHRcdFx0XHRcdFx0XHRcdGUudHlwZSA9PT0gXCJzY2VuYXJpb1wiICYmIFwibmFicy11aS1ncmFwaF9fc2hhcGUtLXNjZW5hcmlvXCIsXG5cdFx0XHRcdFx0XHRcdFx0ZS50eXBlID09PSBcImxpZmVjeWNsZVwiICYmIFwibmFicy11aS1ncmFwaF9fc2hhcGUtLWxpZmVjeWNsZVwiLFxuXHRcdFx0XHRcdFx0XHRcdGUudHlwZSA9PT0gXCJjb250ZXh0XCIgJiYgXCJuYWJzLXVpLWdyYXBoX19zaGFwZS0tY29udGV4dFwiLFxuXHRcdFx0XHRcdFx0XHRcdHogPT09IGUuaWQgJiYgXCJuYWJzLXVpLWdyYXBoX19zaGFwZS0tc2VsZWN0ZWRcIlxuXHRcdFx0XHRcdFx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHRcdFx0XHRcdFx0b25Qb2ludGVyRG93bjogKHQpID0+ICQodCwgZS5pZCksXG5cdFx0XHRcdFx0XHRcdHJvbGU6IFwicHJlc2VudGF0aW9uXCIsXG5cdFx0XHRcdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogITBcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRpZiAoZS50eXBlID09PSBcImNpcmNsZVwiKSB7XG5cdFx0XHRcdFx0XHRcdGxldCBhID0gZS53aWR0aCAvIDIsIGMgPSBlLnggKyBhLCBsID0gZS55ICsgYTtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZ1wiLCB7IGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJjaXJjbGVcIiwge1xuXHRcdFx0XHRcdFx0XHRcdC4uLmksXG5cdFx0XHRcdFx0XHRcdFx0Y3g6IGMsXG5cdFx0XHRcdFx0XHRcdFx0Y3k6IGwsXG5cdFx0XHRcdFx0XHRcdFx0cjogYVxuXHRcdFx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIG8oXCJ0ZXh0XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fbm9kZUxhYmVsXCIsXG5cdFx0XHRcdFx0XHRcdFx0eDogbixcblx0XHRcdFx0XHRcdFx0XHR5OiByLFxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiB0Lm1hcCgodCwgcikgPT4gLyogQF9fUFVSRV9fICovIG8oXCJ0c3BhblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHR4OiBuLFxuXHRcdFx0XHRcdFx0XHRcdFx0ZHk6IHIgPT09IDAgPyAwIDogMTIsXG5cdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdFxuXHRcdFx0XHRcdFx0XHRcdH0sIGAke2UuaWR9LWxpbmUtJHtyfWApKVxuXHRcdFx0XHRcdFx0XHR9KV0gfSwgZS5pZCk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoZS50eXBlID09PSBcInNjZW5hcmlvXCIpIHtcblx0XHRcdFx0XHRcdFx0bGV0IGEgPSBNYXRoLm1pbigyNiwgTWF0aC5yb3VuZChlLndpZHRoICogLjE2KSksIGMgPSBbXG5cdFx0XHRcdFx0XHRcdFx0YCR7ZS54ICsgYX0sJHtlLnl9YCxcblx0XHRcdFx0XHRcdFx0XHRgJHtlLnggKyBlLndpZHRofSwke2UueX1gLFxuXHRcdFx0XHRcdFx0XHRcdGAke2UueCArIGUud2lkdGggLSBhfSwke2UueSArIGUuaGVpZ2h0fWAsXG5cdFx0XHRcdFx0XHRcdFx0YCR7ZS54fSwke2UueSArIGUuaGVpZ2h0fWBcblx0XHRcdFx0XHRcdFx0XS5qb2luKFwiIFwiKTtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZ1wiLCB7IGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG8oXCJwb2x5Z29uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHQuLi5pLFxuXHRcdFx0XHRcdFx0XHRcdHBvaW50czogY1xuXHRcdFx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIG8oXCJ0ZXh0XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fbm9kZUxhYmVsXCIsXG5cdFx0XHRcdFx0XHRcdFx0eDogbixcblx0XHRcdFx0XHRcdFx0XHR5OiByLFxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiB0Lm1hcCgodCwgcikgPT4gLyogQF9fUFVSRV9fICovIG8oXCJ0c3BhblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHR4OiBuLFxuXHRcdFx0XHRcdFx0XHRcdFx0ZHk6IHIgPT09IDAgPyAwIDogMTIsXG5cdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdFxuXHRcdFx0XHRcdFx0XHRcdH0sIGAke2UuaWR9LWxpbmUtJHtyfWApKVxuXHRcdFx0XHRcdFx0XHR9KV0gfSwgZS5pZCk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoZS50eXBlID09PSBcImNvbnRleHRcIikge1xuXHRcdFx0XHRcdFx0XHRsZXQgYSA9IE1hdGgubWluKDI0LCBNYXRoLnJvdW5kKGUud2lkdGggKiAuMTQpKSwgYyA9IGUueSArIGUuaGVpZ2h0IC0gOSwgbCA9IFtcblx0XHRcdFx0XHRcdFx0XHRgTSAke2UueH0gJHtlLnl9YCxcblx0XHRcdFx0XHRcdFx0XHRgSCAke2UueCArIGUud2lkdGggLSBhfWAsXG5cdFx0XHRcdFx0XHRcdFx0YEwgJHtlLnggKyBlLndpZHRofSAke2UueSArIGF9YCxcblx0XHRcdFx0XHRcdFx0XHRgViAke2N9YCxcblx0XHRcdFx0XHRcdFx0XHRgUSAke2UueCArIGUud2lkdGggKiAuNzZ9ICR7ZS55ICsgZS5oZWlnaHQgKyA5fSAke2UueCArIGUud2lkdGggKiAuNX0gJHtjfWAsXG5cdFx0XHRcdFx0XHRcdFx0YFEgJHtlLnggKyBlLndpZHRoICogLjI0fSAke2UueSArIGUuaGVpZ2h0IC0gMTh9ICR7ZS54fSAke2N9YCxcblx0XHRcdFx0XHRcdFx0XHRcIlpcIlxuXHRcdFx0XHRcdFx0XHRdLmpvaW4oXCIgXCIpO1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJnXCIsIHsgY2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcInBhdGhcIiwge1xuXHRcdFx0XHRcdFx0XHRcdC4uLmksXG5cdFx0XHRcdFx0XHRcdFx0ZDogbFxuXHRcdFx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIG8oXCJ0ZXh0XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fbm9kZUxhYmVsXCIsXG5cdFx0XHRcdFx0XHRcdFx0eDogbixcblx0XHRcdFx0XHRcdFx0XHR5OiByLFxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiB0Lm1hcCgodCwgcikgPT4gLyogQF9fUFVSRV9fICovIG8oXCJ0c3BhblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHR4OiBuLFxuXHRcdFx0XHRcdFx0XHRcdFx0ZHk6IHIgPT09IDAgPyAwIDogMTIsXG5cdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdFxuXHRcdFx0XHRcdFx0XHRcdH0sIGAke2UuaWR9LWxpbmUtJHtyfWApKVxuXHRcdFx0XHRcdFx0XHR9KV0gfSwgZS5pZCk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAoZS50eXBlID09PSBcImhleGFnb25cIikge1xuXHRcdFx0XHRcdFx0XHRsZXQgYSA9IFtcblx0XHRcdFx0XHRcdFx0XHRgJHtlLnggKyBlLndpZHRoICogLjI1fSwke2UueX1gLFxuXHRcdFx0XHRcdFx0XHRcdGAke2UueCArIGUud2lkdGggKiAuNzV9LCR7ZS55fWAsXG5cdFx0XHRcdFx0XHRcdFx0YCR7ZS54ICsgZS53aWR0aH0sJHtlLnkgKyBlLmhlaWdodCAqIC41fWAsXG5cdFx0XHRcdFx0XHRcdFx0YCR7ZS54ICsgZS53aWR0aCAqIC43NX0sJHtlLnkgKyBlLmhlaWdodH1gLFxuXHRcdFx0XHRcdFx0XHRcdGAke2UueCArIGUud2lkdGggKiAuMjV9LCR7ZS55ICsgZS5oZWlnaHR9YCxcblx0XHRcdFx0XHRcdFx0XHRgJHtlLnh9LCR7ZS55ICsgZS5oZWlnaHQgKiAuNX1gXG5cdFx0XHRcdFx0XHRcdF0uam9pbihcIiBcIik7XG5cdFx0XHRcdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImdcIiwgeyBjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBvKFwicG9seWdvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0Li4uaSxcblx0XHRcdFx0XHRcdFx0XHRwb2ludHM6IGFcblx0XHRcdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBvKFwidGV4dFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JhcGhfX25vZGVMYWJlbFwiLFxuXHRcdFx0XHRcdFx0XHRcdHg6IG4sXG5cdFx0XHRcdFx0XHRcdFx0eTogcixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdC5tYXAoKHQsIHIpID0+IC8qIEBfX1BVUkVfXyAqLyBvKFwidHNwYW5cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0eDogbixcblx0XHRcdFx0XHRcdFx0XHRcdGR5OiByID09PSAwID8gMCA6IDEyLFxuXHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IHRcblx0XHRcdFx0XHRcdFx0XHR9LCBgJHtlLmlkfS1saW5lLSR7cn1gKSlcblx0XHRcdFx0XHRcdFx0fSldIH0sIGUuaWQpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0bGV0IGEgPSBlLnR5cGUgPT09IFwicmVjdGFuZ2xlXCIgfHwgZS50eXBlID09PSBcImluaXRpYXRpdmVcIiA/IDE0IDogNDtcblx0XHRcdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImdcIiwgeyBjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBvKFwicmVjdFwiLCB7XG5cdFx0XHRcdFx0XHRcdC4uLmksXG5cdFx0XHRcdFx0XHRcdHg6IGUueCxcblx0XHRcdFx0XHRcdFx0eTogZS55LFxuXHRcdFx0XHRcdFx0XHR3aWR0aDogZS53aWR0aCxcblx0XHRcdFx0XHRcdFx0aGVpZ2h0OiBlLmhlaWdodCxcblx0XHRcdFx0XHRcdFx0cng6IGFcblx0XHRcdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gbyhcInRleHRcIiwge1xuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmFwaF9fbm9kZUxhYmVsXCIsXG5cdFx0XHRcdFx0XHRcdHg6IG4sXG5cdFx0XHRcdFx0XHRcdHk6IHIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiB0Lm1hcCgodCwgcikgPT4gLyogQF9fUFVSRV9fICovIG8oXCJ0c3BhblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0eDogbixcblx0XHRcdFx0XHRcdFx0XHRkeTogciA9PT0gMCA/IDAgOiAxMixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdFxuXHRcdFx0XHRcdFx0XHR9LCBgJHtlLmlkfS1saW5lLSR7cn1gKSlcblx0XHRcdFx0XHRcdH0pXSB9LCBlLmlkKTtcblx0XHRcdFx0XHR9KV1cblx0XHRcdFx0fSlcblx0XHRcdH0pXG5cdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBvKGIsIHtcblx0XHRcdHRvb2xib3hMYWJlbDogbCxcblx0XHRcdHRvb2xzZXRzOiBrLFxuXHRcdFx0aXNDb2xsYXBzZWQ6IFIsXG5cdFx0XHRpc0VkZ2VUb29sRW5hYmxlZDogZmUsXG5cdFx0XHRlZGdlSGludDogcGUsXG5cdFx0XHRhY3RpdmVUb29sSWRzQnlTZXQ6IHJlLFxuXHRcdFx0b25Ub2dnbGVDb2xsYXBzZTogY2UsXG5cdFx0XHRvblRvb2xDbGljazogb2UsXG5cdFx0XHRvblRvb2xEb3VibGVDbGljazogc2Vcblx0XHR9KV1cblx0fSk7XG59KTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUyBhcyBHcmFwaCwgYyBhcyBTaW1wbGVHcmFwaFRvb2xzZXQsIGQgYXMgYWdlbnRpY1dvcmtmbG93VG9vbHNldCwgZiBhcyBhZ2VudGljV29ya2Zsb3dUb29sc2V0cywgbCBhcyBzaW1wbGVHcmFwaFRvb2xzZXQsIHUgYXMgc2ltcGxlR3JhcGhUb29sc2V0cyB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlLCB1c2VFZmZlY3QgYXMgdCwgdXNlSWQgYXMgbiwgdXNlTWVtbyBhcyByLCB1c2VSZWYgYXMgaSwgdXNlU3RhdGUgYXMgYSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgRnJhZ21lbnQgYXMgbywganN4IGFzIHMsIGpzeHMgYXMgYyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIC4uL25hYnMtdWktYnV0dG9ucy9zcmMvYnV0dG9uLnV0aWxzLnRzXG52YXIgbCA9IHtcblx0cHJpbWFyeTogXCJuYWJzLXVpLWJ1dHRvbi0tcHJpbWFyeVwiLFxuXHRzZWNvbmRhcnk6IFwibmFicy11aS1idXR0b24tLXNlY29uZGFyeVwiLFxuXHRnaG9zdDogXCJuYWJzLXVpLWJ1dHRvbi0tZ2hvc3RcIlxufSwgdSA9IGUoZnVuY3Rpb24oeyBjaGlsZHJlbjogZSwgY2xhc3NOYW1lOiB0ID0gXCJcIiwgdmFyaWFudDogbiA9IFwicHJpbWFyeVwiLCB0eXBlOiByID0gXCJidXR0b25cIiwgLi4uaSB9LCBhKSB7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0cmVmOiBhLFxuXHRcdGNsYXNzTmFtZTogW1xuXHRcdFx0XCJuYWJzLXVpLWJ1dHRvblwiLFxuXHRcdFx0bFtuXSA/PyBsLnByaW1hcnksXG5cdFx0XHR0XG5cdFx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0dHlwZTogcixcblx0XHQuLi5pLFxuXHRcdGNoaWxkcmVuOiBlXG5cdH0pO1xufSk7XG51LmRpc3BsYXlOYW1lID0gXCJCdXR0b25cIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uL25hYnMtdWktZGlhbG9nL3NyYy9EaWFsb2cudHN4XG52YXIgZCA9IFwiYVtocmVmXSwgYXJlYVtocmVmXSwgYnV0dG9uOm5vdChbZGlzYWJsZWRdKSwgaW5wdXQ6bm90KFtkaXNhYmxlZF0pOm5vdChbdHlwZT1cXFwiaGlkZGVuXFxcIl0pLCBzZWxlY3Q6bm90KFtkaXNhYmxlZF0pLCB0ZXh0YXJlYTpub3QoW2Rpc2FibGVkXSksIFt0YWJpbmRleF06bm90KFt0YWJpbmRleD1cXFwiLTFcXFwiXSlcIjtcbmZ1bmN0aW9uIGYoZSkge1xuXHRyZXR1cm4gQXJyYXkuZnJvbShlLnF1ZXJ5U2VsZWN0b3JBbGwoZCkpLmZpbHRlcigoZSkgPT4gIWUuaGFzQXR0cmlidXRlKFwiZGlzYWJsZWRcIikgJiYgZS5nZXRBdHRyaWJ1dGUoXCJhcmlhLWhpZGRlblwiKSAhPT0gXCJ0cnVlXCIpO1xufVxudmFyIHAgPSBlKGZ1bmN0aW9uKHsgdGl0bGU6IGUsIGRlc2NyaXB0aW9uOiByLCBoZWFkZXI6IGEsIGZvb3Rlcjogbywgc2hvd0hlYWRlcjogbCA9ICEwLCBzaG93Rm9vdGVyOiB1ID0gITAsIG9uUmVxdWVzdENsb3NlOiBkLCBjbG9zZU9uQmFja2Ryb3BDbGljazogcCA9ICEwLCBjbG9zZU9uRXNjYXBlOiBlZSA9ICEwLCBpbml0aWFsRm9jdXNTZWxlY3RvcjogbSwgZGlhbG9nUm9sZTogaCA9IFwiZGlhbG9nXCIsIGNsYXNzTmFtZTogZyA9IFwiXCIsIGJhY2tkcm9wQ2xhc3NOYW1lOiBfID0gXCJcIiwgaGVhZGVyQ2xhc3NOYW1lOiB2ID0gXCJcIiwgZGVzY3JpcHRpb25DbGFzc05hbWU6IHRlID0gXCJcIiwgY29udGVudENsYXNzTmFtZTogeSA9IFwiXCIsIGZvb3RlckNsYXNzTmFtZTogYiA9IFwiXCIsIG9uS2V5RG93bjogeCwgdGFiSW5kZXg6IG5lLCBjaGlsZHJlbjogcmUsIC4uLmllIH0sIGFlKSB7XG5cdGxldCBTID0gaShudWxsKSwgQyA9IGkobnVsbCksIG9lID0gYG5hYnMtdWktZGlhbG9nLXRpdGxlLSR7bigpLnJlcGxhY2UoLzovZywgXCJcIil9YCwgc2UgPSBgbmFicy11aS1kaWFsb2ctZGVzY3JpcHRpb24tJHtuKCkucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCB3ID0gaWVbXCJhcmlhLWxhYmVsbGVkYnlcIl0sIGNlID0gaWVbXCJhcmlhLWRlc2NyaWJlZGJ5XCJdLCBUID0gIWEgJiYgISFlLCBFID0gISFyLCBsZSA9IGwgJiYgKCEhYSB8fCBUKSwgdWUgPSB1ICYmIG8gIT0gbnVsbCwgZGUgPSB3ID8/IChUID8gb2UgOiB2b2lkIDApLCBEID0gY2UgPz8gKEUgPyBzZSA6IHZvaWQgMCksIGZlID0gW1wibmFicy11aS1kaWFsb2dfX2JhY2tkcm9wXCIsIF9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgcGUgPSBbXCJuYWJzLXVpLWRpYWxvZ1wiLCBnXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIG1lID0gW1wibmFicy11aS1kaWFsb2dfX2hlYWRlclwiLCB2XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGhlID0gW1wibmFicy11aS1kaWFsb2dfX2Rlc2NyaXB0aW9uXCIsIHRlXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGdlID0gW1wibmFicy11aS1kaWFsb2dfX2NvbnRlbnRcIiwgeV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBfZSA9IFtcIm5hYnMtdWktZGlhbG9nX19mb290ZXJcIiwgYl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gdCgoKSA9PiB7XG5cdFx0bGV0IGUgPSBTLmN1cnJlbnQ7XG5cdFx0aWYgKCFlKSByZXR1cm47XG5cdFx0aWYgKEMuY3VycmVudCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCA/IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgOiBudWxsLCBtKSB0cnkge1xuXHRcdFx0bGV0IHQgPSBlLnF1ZXJ5U2VsZWN0b3IobSk7XG5cdFx0XHRpZiAodCkgcmV0dXJuIHQuZm9jdXMoKSwgKCkgPT4ge1xuXHRcdFx0XHRDLmN1cnJlbnQ/LmZvY3VzKCksIEMuY3VycmVudCA9IG51bGw7XG5cdFx0XHR9O1xuXHRcdH0gY2F0Y2gge31cblx0XHRsZXQgdCA9IGYoZSk7XG5cdFx0cmV0dXJuIHQubGVuZ3RoID4gMCA/IHRbMF0uZm9jdXMoKSA6IGUuZm9jdXMoKSwgKCkgPT4ge1xuXHRcdFx0Qy5jdXJyZW50Py5mb2N1cygpLCBDLmN1cnJlbnQgPSBudWxsO1xuXHRcdH07XG5cdH0sIFttXSksIC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IGZlLFxuXHRcdHJvbGU6IFwicHJlc2VudGF0aW9uXCIsXG5cdFx0b25DbGljazogKGUpID0+IHtcblx0XHRcdCFwIHx8IGUudGFyZ2V0ICE9PSBlLmN1cnJlbnRUYXJnZXQgfHwgZD8uKCk7XG5cdFx0fSxcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGMoXCJzZWN0aW9uXCIsIHtcblx0XHRcdHJlZjogKGUpID0+IHtcblx0XHRcdFx0aWYgKFMuY3VycmVudCA9IGUsIHR5cGVvZiBhZSA9PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdFx0XHRhZShlKTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdFx0YWUgJiYgKGFlLmN1cnJlbnQgPSBlKTtcblx0XHRcdH0sXG5cdFx0XHRjbGFzc05hbWU6IHBlLFxuXHRcdFx0cm9sZTogaCxcblx0XHRcdFwiYXJpYS1tb2RhbFwiOiBcInRydWVcIixcblx0XHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IGRlLFxuXHRcdFx0XCJhcmlhLWRlc2NyaWJlZGJ5XCI6IEQsXG5cdFx0XHR0YWJJbmRleDogbmUgPz8gLTEsXG5cdFx0XHRvbktleURvd246IChlKSA9PiB7XG5cdFx0XHRcdGlmICh4Py4oZSksIGUuZGVmYXVsdFByZXZlbnRlZCkgcmV0dXJuO1xuXHRcdFx0XHRpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIgJiYgZWUpIHtcblx0XHRcdFx0XHRlLnByZXZlbnREZWZhdWx0KCksIGQ/LigpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoZS5rZXkgIT09IFwiVGFiXCIgfHwgIVMuY3VycmVudCkgcmV0dXJuO1xuXHRcdFx0XHRsZXQgdCA9IGYoUy5jdXJyZW50KTtcblx0XHRcdFx0aWYgKHQubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpLCBTLmN1cnJlbnQuZm9jdXMoKTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdFx0bGV0IG4gPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50LCByID0gdFswXSwgaSA9IHRbdC5sZW5ndGggLSAxXTtcblx0XHRcdFx0aWYgKGUuc2hpZnRLZXkpIHtcblx0XHRcdFx0XHQoIW4gfHwgbiA9PT0gciB8fCAhUy5jdXJyZW50LmNvbnRhaW5zKG4pKSAmJiAoZS5wcmV2ZW50RGVmYXVsdCgpLCBpLmZvY3VzKCkpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHQoIW4gfHwgbiA9PT0gaSB8fCAhUy5jdXJyZW50LmNvbnRhaW5zKG4pKSAmJiAoZS5wcmV2ZW50RGVmYXVsdCgpLCByLmZvY3VzKCkpO1xuXHRcdFx0fSxcblx0XHRcdC4uLmllLFxuXHRcdFx0Y2hpbGRyZW46IFtcblx0XHRcdFx0bGUgPyAvKiBAX19QVVJFX18gKi8gcyhcImhlYWRlclwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBtZSxcblx0XHRcdFx0XHRjaGlsZHJlbjogYSA/PyAoVCA/IC8qIEBfX1BVUkVfXyAqLyBzKFwiaDNcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZGlhbG9nX190aXRsZVwiLFxuXHRcdFx0XHRcdFx0aWQ6IG9lLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGVcblx0XHRcdFx0XHR9KSA6IG51bGwpXG5cdFx0XHRcdH0pIDogbnVsbCxcblx0XHRcdFx0RSA/IC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRpZDogc2UsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBoZSxcblx0XHRcdFx0XHRjaGlsZHJlbjogclxuXHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IGdlLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiByZVxuXHRcdFx0XHR9KSxcblx0XHRcdFx0dWUgPyAvKiBAX19QVVJFX18gKi8gcyhcImZvb3RlclwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBfZSxcblx0XHRcdFx0XHRjaGlsZHJlbjogb1xuXHRcdFx0XHR9KSA6IG51bGxcblx0XHRcdF1cblx0XHR9KVxuXHR9KTtcbn0pO1xucC5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nXCI7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvZ3JpZC51dGlscy50c1xudmFyIGVlID0gYXN5bmMgKGUpID0+IHtcblx0bGV0IHQgPSBhd2FpdCBmZXRjaChlKTtcblx0aWYgKCF0Lm9rKSB0aHJvdyBFcnJvcihgRmFpbGVkIHJlcXVlc3QgZm9yICR7ZX06ICR7dC5zdGF0dXN9YCk7XG5cdHJldHVybiB0Lmpzb24oKTtcbn07XG5mdW5jdGlvbiBtKGUpIHtcblx0aWYgKCFlIHx8ICFBcnJheS5pc0FycmF5KGUuY29sdW1ucykpIHJldHVybiB7XG5cdFx0aWRGaWVsZDogXCJpZFwiLFxuXHRcdHBhZ2VTaXplOiAxMCxcblx0XHRwYWdlU2l6ZU9wdGlvbnM6IFtcblx0XHRcdDEwLFxuXHRcdFx0MjAsXG5cdFx0XHQ1MFxuXHRcdF0sXG5cdFx0c2VsZWN0aW9uTW9kZTogXCJtdWx0aXBsZVwiLFxuXHRcdGNvbHVtbnM6IFtdXG5cdH07XG5cdGxldCB0ID0gZS5jb2x1bW5zLm1hcCgoZSkgPT4gKHtcblx0XHR0eXBlOiBcInN0cmluZ1wiLFxuXHRcdHNvcnRhYmxlOiAhMCxcblx0XHRmaWx0ZXJhYmxlOiAhMCxcblx0XHRncm91cGFibGU6ICExLFxuXHRcdGVkaXRhYmxlOiAhMSxcblx0XHRhZ2dyZWdhdGU6IFwibm9uZVwiLFxuXHRcdGZvcm1hdDogXCJwbGFpblwiLFxuXHRcdC4uLmVcblx0fSkpO1xuXHRyZXR1cm4ge1xuXHRcdGlkRmllbGQ6IGUuaWRGaWVsZCA/PyBcImlkXCIsXG5cdFx0cGFnZVNpemU6IGUucGFnZVNpemUgPz8gMTAsXG5cdFx0cGFnZVNpemVPcHRpb25zOiBlLnBhZ2VTaXplT3B0aW9ucz8ubGVuZ3RoID8gZS5wYWdlU2l6ZU9wdGlvbnMgOiBbXG5cdFx0XHQxMCxcblx0XHRcdDIwLFxuXHRcdFx0NTBcblx0XHRdLFxuXHRcdHNlbGVjdGlvbk1vZGU6IGUuc2VsZWN0aW9uTW9kZSA/PyBcIm11bHRpcGxlXCIsXG5cdFx0ZGVmYXVsdEdyb3VwQnk6IGUuZGVmYXVsdEdyb3VwQnksXG5cdFx0ZGVmYXVsdFNvcnQ6IGUuZGVmYXVsdFNvcnQsXG5cdFx0Zm9vdGVyOiB7XG5cdFx0XHRzaG93Q29sdW1uQWdncmVnYXRlczogZS5mb290ZXI/LnNob3dDb2x1bW5BZ2dyZWdhdGVzID8/ICEwLFxuXHRcdFx0cm93QWdncmVnYXRlczogZS5mb290ZXI/LnJvd0FnZ3JlZ2F0ZXM/Lmxlbmd0aCA/IGUuZm9vdGVyLnJvd0FnZ3JlZ2F0ZXMgOiBbXG5cdFx0XHRcdFwiZmlsdGVyZWRSb3dzXCIsXG5cdFx0XHRcdFwicGFnZWRSb3dzXCIsXG5cdFx0XHRcdFwic2VsZWN0ZWRSb3dzXCIsXG5cdFx0XHRcdFwiZ3JvdXBDb3VudFwiXG5cdFx0XHRdXG5cdFx0fSxcblx0XHRjb2x1bW5zOiB0XG5cdH07XG59XG5mdW5jdGlvbiBoKGUsIHQpIHtcblx0cmV0dXJuIHQgPT09IFwiZGF0ZVwiID8gXCJkYXRlXCIgOiB0ID09PSBcImRhdGUtdGltZVwiID8gXCJkYXRldGltZVwiIDogZSA9PT0gXCJudW1iZXJcIiB8fCBlID09PSBcImludGVnZXJcIiA/IFwibnVtYmVyXCIgOiBlID09PSBcImJvb2xlYW5cIiA/IFwiYm9vbGVhblwiIDogXCJzdHJpbmdcIjtcbn1cbmZ1bmN0aW9uIGcoZSkge1xuXHRyZXR1cm4gZSA9PT0gXCJkYXRlXCIgPyBcImRhdGVcIiA6IGUgPT09IFwiZGF0ZS10aW1lXCIgPyBcImRhdGV0aW1lXCIgOiBlID09PSBcImN1cnJlbmN5XCIgPyBcImN1cnJlbmN5XCIgOiBlID09PSBcInBlcmNlbnRcIiA/IFwicGVyY2VudFwiIDogXCJwbGFpblwiO1xufVxuZnVuY3Rpb24gXyhlKSB7XG5cdGlmIChlPy5sZW5ndGgpIHJldHVybiBlLm1hcCgoZSkgPT4gKHtcblx0XHRsYWJlbDogZSA9PT0gbnVsbCA/IFwiKGVtcHR5KVwiIDogU3RyaW5nKGUpLFxuXHRcdHZhbHVlOiBlXG5cdH0pKTtcbn1cbmZ1bmN0aW9uIHYoZSkge1xuXHRpZiAoIWU/LnByb3BlcnRpZXMpIHJldHVybiBtKHZvaWQgMCk7XG5cdGxldCB0ID0gbmV3IFNldChlLnJlcXVpcmVkID8/IFtdKSwgbiA9IGVbXCJ4LWdyaWRcIl0sIHIgPSBPYmplY3QuZW50cmllcyhlLnByb3BlcnRpZXMpLm1hcCgoW2UsIG5dKSA9PiB7XG5cdFx0bGV0IHIgPSBuW1wieC1ncmlkXCJdLCBpID0gaChuLnR5cGUsIG4uZm9ybWF0KSwgYSA9IGcobi5mb3JtYXQpLCBvID0gcj8uZWRpdG9yID8/IChpID09PSBcImJvb2xlYW5cIiA/IFwiY2hlY2tib3hcIiA6IGkgPT09IFwibnVtYmVyXCIgPyBcIm51bWJlclwiIDogaSA9PT0gXCJkYXRlXCIgPyBcImRhdGVcIiA6IHZvaWQgMCk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGtleTogcj8ua2V5ID8/IGUsXG5cdFx0XHRsYWJlbDogbi50aXRsZSA/PyBlLFxuXHRcdFx0dHlwZTogaSxcblx0XHRcdHNvcnRhYmxlOiByPy5zb3J0YWJsZSA/PyAhMCxcblx0XHRcdGZpbHRlcmFibGU6IHI/LmZpbHRlcmFibGUgPz8gITAsXG5cdFx0XHRncm91cGFibGU6IHI/Lmdyb3VwYWJsZSA/PyAhMSxcblx0XHRcdGVkaXRhYmxlOiByPy5lZGl0YWJsZSA/PyB0LmhhcyhlKSxcblx0XHRcdGVkaXRvcjogbyxcblx0XHRcdGFnZ3JlZ2F0ZTogcj8uYWdncmVnYXRlID8/IFwibm9uZVwiLFxuXHRcdFx0d2lkdGg6IHI/LndpZHRoLFxuXHRcdFx0bWluV2lkdGg6IHI/Lm1pbldpZHRoLFxuXHRcdFx0b3B0aW9uczogcj8ub3B0aW9ucyA/PyBfKG4uZW51bSksXG5cdFx0XHRmb3JtYXQ6IHI/LmZvcm1hdCA/PyBhXG5cdFx0fTtcblx0fSk7XG5cdHJldHVybiBtKHtcblx0XHRpZEZpZWxkOiBuPy5pZEZpZWxkLFxuXHRcdHBhZ2VTaXplOiBuPy5wYWdlU2l6ZSxcblx0XHRwYWdlU2l6ZU9wdGlvbnM6IG4/LnBhZ2VTaXplT3B0aW9ucyxcblx0XHRzZWxlY3Rpb25Nb2RlOiBuPy5zZWxlY3Rpb25Nb2RlLFxuXHRcdGRlZmF1bHRHcm91cEJ5OiBuPy5kZWZhdWx0R3JvdXBCeSxcblx0XHRkZWZhdWx0U29ydDogbj8uZGVmYXVsdFNvcnQsXG5cdFx0Zm9vdGVyOiBuPy5mb290ZXIsXG5cdFx0Y29sdW1uczogclxuXHR9KTtcbn1cbmZ1bmN0aW9uIHRlKGUpIHtcblx0aWYgKGUpIHtcblx0XHRpZiAodHlwZW9mIGUgPT0gXCJzdHJpbmdcIikge1xuXHRcdFx0bGV0IHQgPSBKU09OLnBhcnNlKGUpO1xuXHRcdFx0aWYgKCF0IHx8IHR5cGVvZiB0ICE9IFwib2JqZWN0XCIpIHRocm93IEVycm9yKFwiSW52YWxpZCBqc29uSXNsYW5kOiBleHBlY3RlZCBhIEpTT04gb2JqZWN0LlwiKTtcblx0XHRcdHJldHVybiB0O1xuXHRcdH1cblx0XHRyZXR1cm4gZTtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24geShlLCB0KSB7XG5cdGlmIChlICE9PSB2b2lkIDApIHJldHVybiB0eXBlb2YgZSA9PSBcImZ1bmN0aW9uXCIgPyBlKCkgOiB0eXBlb2YgZSA9PSBcInN0cmluZ1wiID8gYXdhaXQgKHQgPz8gZWUpKGUpIDogZTtcbn1cbmZ1bmN0aW9uIGIoLi4uZSkge1xuXHRyZXR1cm4gZS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG59XG5mdW5jdGlvbiB4KGUsIHQsIG4pIHtcblx0bGV0IHIgPSBlW3RdO1xuXHRyZXR1cm4gciA9PSBudWxsID8gYHJvdy0ke259YCA6IFN0cmluZyhyKTtcbn1cbmZ1bmN0aW9uIG5lKGUsIHQsIG4sIHIpIHtcblx0bGV0IGkgPSBuLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuXHRyZXR1cm4gZS5maWx0ZXIoKGUpID0+IGkubGVuZ3RoID09PSAwIHx8IHQuc29tZSgodCkgPT4gdyhlW3Qua2V5XSkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpKSkgPyB0LmV2ZXJ5KCh0KSA9PiB7XG5cdFx0bGV0IG4gPSAoclt0LmtleV0gPz8gXCJcIikudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG5cdFx0aWYgKCFuKSByZXR1cm4gITA7XG5cdFx0bGV0IGkgPSBlW3Qua2V5XTtcblx0XHRpZiAodC50eXBlID09PSBcImJvb2xlYW5cIikge1xuXHRcdFx0aWYgKG4gPT09IFwidHJ1ZVwiKSByZXR1cm4gaSA9PT0gITA7XG5cdFx0XHRpZiAobiA9PT0gXCJmYWxzZVwiKSByZXR1cm4gaSA9PT0gITE7XG5cdFx0fVxuXHRcdHJldHVybiB3KGkpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMobik7XG5cdH0pIDogITEpO1xufVxuZnVuY3Rpb24gcmUoZSwgdCwgbikge1xuXHRpZiAoIXQpIHJldHVybiBlO1xuXHRsZXQgciA9IG4uZmluZCgoZSkgPT4gZS5rZXkgPT09IHQuY29sdW1uS2V5KTtcblx0aWYgKCFyIHx8ICFyLnNvcnRhYmxlKSByZXR1cm4gZTtcblx0bGV0IGkgPSB0LmRpcmVjdGlvbiA9PT0gXCJhc2NcIiA/IDEgOiAtMTtcblx0cmV0dXJuIFsuLi5lXS5zb3J0KChlLCBuKSA9PiB7XG5cdFx0bGV0IGEgPSBlW3QuY29sdW1uS2V5XSwgbyA9IG5bdC5jb2x1bW5LZXldO1xuXHRcdHJldHVybiBzZShhLCBvLCByLnR5cGUpICogaTtcblx0fSk7XG59XG5mdW5jdGlvbiBpZShlLCB0LCBuLCByKSB7XG5cdGlmICghbikgcmV0dXJuIGUubWFwKChlLCB0KSA9PiAoe1xuXHRcdGtpbmQ6IFwiZGF0YVwiLFxuXHRcdGtleTogYGRhdGEtJHt0fWAsXG5cdFx0cm93OiBlLFxuXHRcdHJvd0luZGV4OiB0XG5cdH0pKTtcblx0bGV0IGkgPSB0LmZpbmQoKGUpID0+IGUua2V5ID09PSBuKTtcblx0aWYgKCFpIHx8ICFpLmdyb3VwYWJsZSkgcmV0dXJuIGUubWFwKChlLCB0KSA9PiAoe1xuXHRcdGtpbmQ6IFwiZGF0YVwiLFxuXHRcdGtleTogYGRhdGEtJHt0fWAsXG5cdFx0cm93OiBlLFxuXHRcdHJvd0luZGV4OiB0XG5cdH0pKTtcblx0bGV0IGEgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRlLmZvckVhY2goKGUpID0+IHtcblx0XHRsZXQgdCA9IHcoZVtuXSkgfHwgXCIoZW1wdHkpXCIsIHIgPSBhLmdldCh0KTtcblx0XHRpZiAocikge1xuXHRcdFx0ci5wdXNoKGUpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRhLnNldCh0LCBbZV0pO1xuXHR9KTtcblx0bGV0IG8gPSBbXTtcblx0cmV0dXJuIEFycmF5LmZyb20oYS5lbnRyaWVzKCkpLmZvckVhY2goKFtlLCB0XSkgPT4ge1xuXHRcdGxldCBuID0gYGdyb3VwLSR7ZX1gO1xuXHRcdG8ucHVzaCh7XG5cdFx0XHRraW5kOiBcImdyb3VwXCIsXG5cdFx0XHRrZXk6IG4sXG5cdFx0XHRncm91cFZhbHVlOiBlLFxuXHRcdFx0Z3JvdXBTaXplOiB0Lmxlbmd0aCxcblx0XHRcdGdyb3VwUm93czogdFxuXHRcdH0pLCByLmhhcyhlKSAmJiB0LmZvckVhY2goKHQsIHIpID0+IHtcblx0XHRcdG8ucHVzaCh7XG5cdFx0XHRcdGtpbmQ6IFwiZGF0YVwiLFxuXHRcdFx0XHRrZXk6IGAke259LXJvdy0ke3J9YCxcblx0XHRcdFx0cm93OiB0LFxuXHRcdFx0XHRyb3dJbmRleDogcixcblx0XHRcdFx0Z3JvdXBWYWx1ZTogZVxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH0pLCBvO1xufVxuZnVuY3Rpb24gYWUoZSwgdCwgbikge1xuXHRpZiAodCA8PSAwKSByZXR1cm4gZTtcblx0bGV0IHIgPSBNYXRoLm1heCgwLCBuKSAqIHQ7XG5cdHJldHVybiBlLnNsaWNlKHIsIHIgKyB0KTtcbn1cbmZ1bmN0aW9uIFMoZSwgdCkge1xuXHRpZiAoZSA9PSBudWxsKSByZXR1cm4gXCJcIjtcblx0aWYgKHQuZm9ybWF0ID09PSBcImN1cnJlbmN5XCIgJiYgdHlwZW9mIGUgPT0gXCJudW1iZXJcIikgcmV0dXJuIG5ldyBJbnRsLk51bWJlckZvcm1hdCh2b2lkIDAsIHtcblx0XHRzdHlsZTogXCJjdXJyZW5jeVwiLFxuXHRcdGN1cnJlbmN5OiBcIlVTRFwiLFxuXHRcdG1heGltdW1GcmFjdGlvbkRpZ2l0czogMlxuXHR9KS5mb3JtYXQoZSk7XG5cdGlmICh0LmZvcm1hdCA9PT0gXCJwZXJjZW50XCIgJiYgdHlwZW9mIGUgPT0gXCJudW1iZXJcIikgcmV0dXJuIG5ldyBJbnRsLk51bWJlckZvcm1hdCh2b2lkIDAsIHtcblx0XHRzdHlsZTogXCJwZXJjZW50XCIsXG5cdFx0bWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyXG5cdH0pLmZvcm1hdChlKTtcblx0aWYgKCh0LmZvcm1hdCA9PT0gXCJkYXRlXCIgfHwgdC50eXBlID09PSBcImRhdGVcIikgJiYgKHR5cGVvZiBlID09IFwic3RyaW5nXCIgfHwgZSBpbnN0YW5jZW9mIERhdGUpKSB7XG5cdFx0bGV0IHQgPSBuZXcgRGF0ZShlKTtcblx0XHRpZiAoIU51bWJlci5pc05hTih0LmdldFRpbWUoKSkpIHJldHVybiBuZXcgSW50bC5EYXRlVGltZUZvcm1hdCh2b2lkIDAsIHsgZGF0ZVN0eWxlOiBcIm1lZGl1bVwiIH0pLmZvcm1hdCh0KTtcblx0fVxuXHRpZiAoKHQuZm9ybWF0ID09PSBcImRhdGV0aW1lXCIgfHwgdC50eXBlID09PSBcImRhdGV0aW1lXCIpICYmICh0eXBlb2YgZSA9PSBcInN0cmluZ1wiIHx8IGUgaW5zdGFuY2VvZiBEYXRlKSkge1xuXHRcdGxldCB0ID0gbmV3IERhdGUoZSk7XG5cdFx0aWYgKCFOdW1iZXIuaXNOYU4odC5nZXRUaW1lKCkpKSByZXR1cm4gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQodm9pZCAwLCB7XG5cdFx0XHRkYXRlU3R5bGU6IFwibWVkaXVtXCIsXG5cdFx0XHR0aW1lU3R5bGU6IFwic2hvcnRcIlxuXHRcdH0pLmZvcm1hdCh0KTtcblx0fVxuXHRyZXR1cm4gdyhlKTtcbn1cbmZ1bmN0aW9uIEMoZSwgdCkge1xuXHRsZXQgbiA9IHQuYWdncmVnYXRlID8/IFwibm9uZVwiO1xuXHRpZiAobiA9PT0gXCJub25lXCIpIHJldHVybiB7XG5cdFx0dHlwZTogXCJub25lXCIsXG5cdFx0dmFsdWU6IG51bGxcblx0fTtcblx0bGV0IHIgPSBlLm1hcCgoZSkgPT4gZVt0LmtleV0pLmZpbHRlcigoZSkgPT4gdHlwZW9mIGUgPT0gXCJudW1iZXJcIiAmJiBOdW1iZXIuaXNGaW5pdGUoZSkpO1xuXHRyZXR1cm4gbiA9PT0gXCJjb3VudFwiID8ge1xuXHRcdHR5cGU6IFwiY291bnRcIixcblx0XHR2YWx1ZTogZS5sZW5ndGhcblx0fSA6IHIubGVuZ3RoID09PSAwID8ge1xuXHRcdHR5cGU6IG4sXG5cdFx0dmFsdWU6IG51bGxcblx0fSA6IG4gPT09IFwic3VtXCIgPyB7XG5cdFx0dHlwZTogXCJzdW1cIixcblx0XHR2YWx1ZTogci5yZWR1Y2UoKGUsIHQpID0+IGUgKyB0LCAwKVxuXHR9IDogbiA9PT0gXCJhdmdcIiA/IHtcblx0XHR0eXBlOiBcImF2Z1wiLFxuXHRcdHZhbHVlOiByLnJlZHVjZSgoZSwgdCkgPT4gZSArIHQsIDApIC8gci5sZW5ndGhcblx0fSA6IG4gPT09IFwibWluXCIgPyB7XG5cdFx0dHlwZTogXCJtaW5cIixcblx0XHR2YWx1ZTogTWF0aC5taW4oLi4ucilcblx0fSA6IG4gPT09IFwibWF4XCIgPyB7XG5cdFx0dHlwZTogXCJtYXhcIixcblx0XHR2YWx1ZTogTWF0aC5tYXgoLi4ucilcblx0fSA6IHtcblx0XHR0eXBlOiBuLFxuXHRcdHZhbHVlOiBudWxsXG5cdH07XG59XG5mdW5jdGlvbiBvZShlKSB7XG5cdHJldHVybiBlLnR5cGUgPT09IFwibm9uZVwiID8gXCJcIiA6IGUudmFsdWUgPT09IG51bGwgfHwgZS52YWx1ZSA9PT0gdm9pZCAwID8gXCItXCIgOiBlLnR5cGUgPT09IFwiY291bnRcIiA/IGAke01hdGgucm91bmQoZS52YWx1ZSl9YCA6IG5ldyBJbnRsLk51bWJlckZvcm1hdCh2b2lkIDAsIHtcblx0XHRtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDAsXG5cdFx0bWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyXG5cdH0pLmZvcm1hdChlLnZhbHVlKTtcbn1cbmZ1bmN0aW9uIHNlKGUsIHQsIG4pIHtcblx0aWYgKGUgPT09IHQpIHJldHVybiAwO1xuXHRpZiAoZSA9PSBudWxsKSByZXR1cm4gLTE7XG5cdGlmICh0ID09IG51bGwpIHJldHVybiAxO1xuXHRpZiAobiA9PT0gXCJudW1iZXJcIikge1xuXHRcdGxldCBuID0gTnVtYmVyKGUpLCByID0gTnVtYmVyKHQpO1xuXHRcdGlmIChOdW1iZXIuaXNGaW5pdGUobikgJiYgTnVtYmVyLmlzRmluaXRlKHIpKSByZXR1cm4gbiAtIHI7XG5cdH1cblx0aWYgKG4gPT09IFwiZGF0ZVwiIHx8IG4gPT09IFwiZGF0ZXRpbWVcIikge1xuXHRcdGxldCBuID0gbmV3IERhdGUoU3RyaW5nKGUpKS5nZXRUaW1lKCksIHIgPSBuZXcgRGF0ZShTdHJpbmcodCkpLmdldFRpbWUoKTtcblx0XHRpZiAoIU51bWJlci5pc05hTihuKSAmJiAhTnVtYmVyLmlzTmFOKHIpKSByZXR1cm4gbiAtIHI7XG5cdH1cblx0cmV0dXJuIG4gPT09IFwiYm9vbGVhblwiID8gISFlIC0gKyEhdCA6IHcoZSkubG9jYWxlQ29tcGFyZSh3KHQpKTtcbn1cbmZ1bmN0aW9uIHcoZSkge1xuXHRpZiAoZSA9PSBudWxsKSByZXR1cm4gXCJcIjtcblx0aWYgKHR5cGVvZiBlID09IFwic3RyaW5nXCIpIHJldHVybiBlO1xuXHRpZiAodHlwZW9mIGUgPT0gXCJudW1iZXJcIiB8fCB0eXBlb2YgZSA9PSBcImJvb2xlYW5cIikgcmV0dXJuIFN0cmluZyhlKTtcblx0aWYgKGUgaW5zdGFuY2VvZiBEYXRlKSByZXR1cm4gZS50b0lTT1N0cmluZygpO1xuXHRpZiAoQXJyYXkuaXNBcnJheShlKSkgcmV0dXJuIGUubWFwKChlKSA9PiB3KGUpKS5qb2luKFwiLCBcIik7XG5cdGlmICh0eXBlb2YgZSA9PSBcIm9iamVjdFwiKSB0cnkge1xuXHRcdHJldHVybiBKU09OLnN0cmluZ2lmeShlKTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIFwiW29iamVjdF1cIjtcblx0fVxuXHRyZXR1cm4gU3RyaW5nKGUpO1xufVxuZnVuY3Rpb24gY2UoZSwgdCkge1xuXHRyZXR1cm4gdC5zb3J0YWJsZSA/ICFlIHx8IGUuY29sdW1uS2V5ICE9PSB0LmtleSA/IHtcblx0XHRjb2x1bW5LZXk6IHQua2V5LFxuXHRcdGRpcmVjdGlvbjogXCJhc2NcIlxuXHR9IDogZS5kaXJlY3Rpb24gPT09IFwiYXNjXCIgPyB7XG5cdFx0Y29sdW1uS2V5OiB0LmtleSxcblx0XHRkaXJlY3Rpb246IFwiZGVzY1wiXG5cdH0gOiBudWxsIDogZTtcbn1cbmZ1bmN0aW9uIFQoZSwgdCkge1xuXHRpZiAoZSA9PSBudWxsKSByZXR1cm4gXCJcIjtcblx0aWYgKHQgPT09IFwiZGF0ZVwiIHx8IHQgPT09IFwiZGF0ZXRpbWVcIikge1xuXHRcdGxldCBuID0gbmV3IERhdGUoU3RyaW5nKGUpKTtcblx0XHRyZXR1cm4gTnVtYmVyLmlzTmFOKG4uZ2V0VGltZSgpKSA/IFwiXCIgOiB0ID09PSBcImRhdGVcIiA/IG4udG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCkgOiBuLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTYpO1xuXHR9XG5cdHJldHVybiB3KGUpO1xufVxuZnVuY3Rpb24gRShlLCB0KSB7XG5cdGlmICh0LmVkaXRvciA9PT0gXCJjaGVja2JveFwiIHx8IHQudHlwZSA9PT0gXCJib29sZWFuXCIpIHJldHVybiBlID09PSBcInRydWVcIjtcblx0aWYgKHQuZWRpdG9yID09PSBcIm51bWJlclwiIHx8IHQudHlwZSA9PT0gXCJudW1iZXJcIikge1xuXHRcdGxldCB0ID0gTnVtYmVyKGUpO1xuXHRcdHJldHVybiBOdW1iZXIuaXNGaW5pdGUodCkgPyB0IDogbnVsbDtcblx0fVxuXHRyZXR1cm4gdC50eXBlID09PSBcImRhdGVcIiB8fCB0LnR5cGUgPT09IFwiZGF0ZXRpbWVcIiA/IGUgfHwgbnVsbCA6IGU7XG59XG5mdW5jdGlvbiBsZShlKSB7XG5cdGxldCB0ID0gZS50cmltKCkudG9Mb3dlckNhc2UoKTtcblx0cmV0dXJuIHQgPT09IFwidHJ1ZVwiIHx8IHQgPT09IFwiZmFsc2VcIiA/IHQgOiBcIlwiO1xufVxuZnVuY3Rpb24gdWUoZSkge1xuXHRyZXR1cm4gZSA9PT0gXCJub25lXCIgPyBcIlwiIDogZS50b1VwcGVyQ2FzZSgpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL0dyaWQudHN4XG5mdW5jdGlvbiBkZSh7IGNvbHVtbnM6IGUsIGRyYWZ0OiBuLCByb3dJZDogciwgb25DYW5jZWw6IGksIG9uU2F2ZTogbCB9KSB7XG5cdGxldCBbZCwgZl0gPSBhKG4pO1xuXHRyZXR1cm4gdCgoKSA9PiB7XG5cdFx0ZihuKTtcblx0fSwgW25dKSwgLyogQF9fUFVSRV9fICovIHMocCwge1xuXHRcdHRpdGxlOiBgRWRpdCByb3cgJHtyfWAsXG5cdFx0XCJhcmlhLWxhYmVsXCI6IGBFZGl0IHJvdyAke3J9YCxcblx0XHRvblJlcXVlc3RDbG9zZTogaSxcblx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19lZGl0RGlhbG9nXCIsXG5cdFx0Y29udGVudENsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2VkaXREaWFsb2dDb250ZW50XCIsXG5cdFx0Zm9vdGVyQ2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZWRpdERpYWxvZ0Zvb3RlclwiLFxuXHRcdGZvb3RlcjogLyogQF9fUFVSRV9fICovIGMobywgeyBjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKHUsIHtcblx0XHRcdHZhcmlhbnQ6IFwic2Vjb25kYXJ5XCIsXG5cdFx0XHRvbkNsaWNrOiBpLFxuXHRcdFx0Y2hpbGRyZW46IFwiQ2FuY2VsXCJcblx0XHR9KSwgLyogQF9fUFVSRV9fICovIHModSwge1xuXHRcdFx0b25DbGljazogKCkgPT4gbChkKSxcblx0XHRcdGNoaWxkcmVuOiBcIlNhdmVcIlxuXHRcdH0pXSB9KSxcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZGlhbG9nQm9keVwiLFxuXHRcdFx0Y2hpbGRyZW46IGUuZmlsdGVyKChlKSA9PiBlLmVkaXRhYmxlKS5tYXAoKGUpID0+IHtcblx0XHRcdFx0bGV0IHQgPSBUKGRbZS5rZXldLCBlLnR5cGUpO1xuXHRcdFx0XHRyZXR1cm4gZS5lZGl0b3IgPT09IFwiY2hlY2tib3hcIiB8fCBlLnR5cGUgPT09IFwiYm9vbGVhblwiID8gLyogQF9fUFVSRV9fICovIGMoXCJsYWJlbFwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZmllbGRcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7IGNoaWxkcmVuOiBlLmxhYmVsIH0pLCAvKiBAX19QVVJFX18gKi8gYyhcInNlbGVjdFwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19pbnB1dFwiLFxuXHRcdFx0XHRcdFx0dmFsdWU6IHQgPT09IFwidHJ1ZVwiID8gXCJ0cnVlXCIgOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XHRvbkNoYW5nZTogKHQpID0+IHtcblx0XHRcdFx0XHRcdFx0bGV0IG4gPSB0LnRhcmdldC52YWx1ZSA9PT0gXCJ0cnVlXCI7XG5cdFx0XHRcdFx0XHRcdGYoKHQpID0+ICh7XG5cdFx0XHRcdFx0XHRcdFx0Li4udCxcblx0XHRcdFx0XHRcdFx0XHRbZS5rZXldOiBuXG5cdFx0XHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0dmFsdWU6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJUcnVlXCJcblx0XHRcdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIkZhbHNlXCJcblx0XHRcdFx0XHRcdH0pXVxuXHRcdFx0XHRcdH0pXVxuXHRcdFx0XHR9LCBlLmtleSkgOiBlLmVkaXRvciA9PT0gXCJzZWxlY3RcIiAmJiBlLm9wdGlvbnM/Lmxlbmd0aCA/IC8qIEBfX1BVUkVfXyAqLyBjKFwibGFiZWxcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2ZpZWxkXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwgeyBjaGlsZHJlbjogZS5sYWJlbCB9KSwgLyogQF9fUFVSRV9fICovIGMoXCJzZWxlY3RcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faW5wdXRcIixcblx0XHRcdFx0XHRcdHZhbHVlOiB0LFxuXHRcdFx0XHRcdFx0b25DaGFuZ2U6ICh0KSA9PiB7XG5cdFx0XHRcdFx0XHRcdGxldCBuID0gRSh0LnRhcmdldC52YWx1ZSwgZSk7XG5cdFx0XHRcdFx0XHRcdGYoKHQpID0+ICh7XG5cdFx0XHRcdFx0XHRcdFx0Li4udCxcblx0XHRcdFx0XHRcdFx0XHRbZS5rZXldOiBuXG5cdFx0XHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0dmFsdWU6IFwiXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIihlbXB0eSlcIlxuXHRcdFx0XHRcdFx0fSksIGUub3B0aW9ucy5tYXAoKGUpID0+IC8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0dmFsdWU6IFN0cmluZyhlLnZhbHVlKSxcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUubGFiZWxcblx0XHRcdFx0XHRcdH0sIFN0cmluZyhlLnZhbHVlKSkpXVxuXHRcdFx0XHRcdH0pXVxuXHRcdFx0XHR9LCBlLmtleSkgOiBlLmVkaXRvciA9PT0gXCJ0ZXh0YXJlYVwiID8gLyogQF9fUFVSRV9fICovIGMoXCJsYWJlbFwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZmllbGRcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7IGNoaWxkcmVuOiBlLmxhYmVsIH0pLCAvKiBAX19QVVJFX18gKi8gcyhcInRleHRhcmVhXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2lucHV0IG5hYnMtdWktZ3JpZF9faW5wdXQtLXRleHRhcmVhXCIsXG5cdFx0XHRcdFx0XHR2YWx1ZTogdCxcblx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAodCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRsZXQgbiA9IEUodC50YXJnZXQudmFsdWUsIGUpO1xuXHRcdFx0XHRcdFx0XHRmKCh0KSA9PiAoe1xuXHRcdFx0XHRcdFx0XHRcdC4uLnQsXG5cdFx0XHRcdFx0XHRcdFx0W2Uua2V5XTogblxuXHRcdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSldXG5cdFx0XHRcdH0sIGUua2V5KSA6IC8qIEBfX1BVUkVfXyAqLyBjKFwibGFiZWxcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2ZpZWxkXCIsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwgeyBjaGlsZHJlbjogZS5sYWJlbCB9KSwgLyogQF9fUFVSRV9fICovIHMoXCJpbnB1dFwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19pbnB1dFwiLFxuXHRcdFx0XHRcdFx0dHlwZTogZS5lZGl0b3IgPT09IFwibnVtYmVyXCIgfHwgZS50eXBlID09PSBcIm51bWJlclwiID8gXCJudW1iZXJcIiA6IGUudHlwZSA9PT0gXCJkYXRlXCIgPyBcImRhdGVcIiA6IFwidGV4dFwiLFxuXHRcdFx0XHRcdFx0dmFsdWU6IHQsXG5cdFx0XHRcdFx0XHRvbkNoYW5nZTogKHQpID0+IHtcblx0XHRcdFx0XHRcdFx0bGV0IG4gPSBFKHQudGFyZ2V0LnZhbHVlLCBlKTtcblx0XHRcdFx0XHRcdFx0ZigodCkgPT4gKHtcblx0XHRcdFx0XHRcdFx0XHQuLi50LFxuXHRcdFx0XHRcdFx0XHRcdFtlLmtleV06IG5cblx0XHRcdFx0XHRcdFx0fSkpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0pXVxuXHRcdFx0XHR9LCBlLmtleSk7XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH0pO1xufVxudmFyIEQgPSBlKGZ1bmN0aW9uKHsgbW9kZTogZSwgc2NoZW1hOiBuLCBqc29uU2NoZW1hOiBsLCBqc29uSXNsYW5kOiB1LCBkYXRhOiBkLCBzY2hlbWFTb3VyY2U6IGYsIGpzb25TY2hlbWFTb3VyY2U6IHAsIGpzb25Jc2xhbmRTb3VyY2U6IGVlLCBkYXRhU291cmNlOiBoLCBzZXJ2ZXJEYXRhU291cmNlOiBnLCBmZXRjaGVyOiBfLCBoZWlnaHQ6IHNlID0gNDQwLCByb3dIZWlnaHQ6IHcgPSA0MCwgb3ZlcnNjYW46IEQgPSA2LCBlZGl0TW9kZTogZmUgPSBcImJvdGhcIiwgc2VhcmNoYWJsZTogcGUgPSAhMCwgZmlsdGVyYWJsZTogbWUgPSAhMCwgZ3JvdXBhYmxlOiBoZSA9ICEwLCBwYWdlYWJsZTogZ2UgPSAhMCwgc2VsZWN0YWJsZTogX2UgPSAhMCwgY2xhc3NOYW1lOiB2ZSA9IFwiXCIsIG9uRGF0YUNoYW5nZTogeWUsIG9uU2VsZWN0aW9uQ2hhbmdlOiBiZSwgb25TY2hlbWFMb2FkZWQ6IHhlLCBvbkRhdGFMb2FkZWQ6IFNlLCBvbkVycm9yOiBDZSwgdmFsdWVGb3JtYXR0ZXJzOiB3ZSwgLi4uVGUgfSwgRWUpIHtcblx0bGV0IFtPLCBrXSA9IGEoKCkgPT4gbiA/IG0obikgOiBsID8gdihsKSA6IG0odm9pZCAwKSksIFtEZSwgT2VdID0gYShlID8/IFwiY2xpZW50XCIpLCBbQSwgal0gPSBhKGQgPz8gW10pLCBba2UsIEFlXSA9IGEodm9pZCAwKSwgW2plLCBNZV0gPSBhKHZvaWQgMCksIFtOZSwgUGVdID0gYSh2b2lkIDApLCBbRmUsIEllXSA9IGEoITEpLCBbTGUsIFJlXSA9IGEoXCJcIiksIFtNLCB6ZV0gPSBhKFwiXCIpLCBbTiwgQmVdID0gYSh7fSksIFtQLCBGXSA9IGEobnVsbCksIFtJLCBMXSA9IGEobnVsbCksIFtSLCBWZV0gPSBhKC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpLCBbeiwgQl0gPSBhKDApLCBbViwgSF0gPSBhKE8ucGFnZVNpemUgPz8gMTApLCBbSGUsIFVlXSA9IGEoLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSksIFtXZSwgR2VdID0gYShudWxsKSwgW0tlLCBVXSA9IGEobnVsbCksIFtxZSwgSmVdID0gYShudWxsKSwgW1llLCBYZV0gPSBhKDApLCBbWmUsIFFlXSA9IGEoMCksICRlID0gaShiZSksIGV0ID0gaShnKSwgVyA9IGtlID8/IGplO1xuXHR0KCgpID0+IHtcblx0XHR0cnkge1xuXHRcdFx0bGV0IHQgPSB0ZSh1KTtcblx0XHRcdEFlKHQpLCAhZCAmJiB0Py5kYXRhICYmIGoodC5kYXRhKSwgT2UoZSA/PyB0Py5tb2RlID8/IFwiY2xpZW50XCIpO1xuXHRcdH0gY2F0Y2ggKHQpIHtcblx0XHRcdGxldCBuID0gdCBpbnN0YW5jZW9mIEVycm9yID8gdCA6IC8qIEBfX1BVUkVfXyAqLyBFcnJvcihcIkludmFsaWQganNvbklzbGFuZCB2YWx1ZS5cIik7XG5cdFx0XHRSZShuLm1lc3NhZ2UpLCBDZT8uKG4pLCBBZSh2b2lkIDApLCBPZShlID8/IFwiY2xpZW50XCIpO1xuXHRcdH1cblx0fSwgW1xuXHRcdGQsXG5cdFx0dSxcblx0XHRlXG5cdF0pLCB0KCgpID0+IHtcblx0XHRpZiAobikge1xuXHRcdFx0ayhtKG4pKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0aWYgKGwpIHtcblx0XHRcdGsodihsKSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChXPy5zY2hlbWEpIHtcblx0XHRcdGsobShXLnNjaGVtYSkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoVz8uanNvblNjaGVtYSkge1xuXHRcdFx0ayh2KFcuanNvblNjaGVtYSkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRrKG0odm9pZCAwKSk7XG5cdH0sIFtcblx0XHRXLFxuXHRcdGwsXG5cdFx0blxuXHRdKSwgdCgoKSA9PiB7XG5cdFx0ZCAmJiAoaihkKSwgUGUodm9pZCAwKSk7XG5cdH0sIFtkXSksIHQoKCkgPT4ge1xuXHRcdGxldCBlID0gbiA/IG0obikgOiBsID8gdihsKSA6IFc/LnNjaGVtYSA/IG0oVy5zY2hlbWEpIDogdihXPy5qc29uU2NoZW1hKTtcblx0XHRIKGUucGFnZVNpemUgPz8gMTApLCBlLmRlZmF1bHRTb3J0ICYmIEYoZS5kZWZhdWx0U29ydCksIGUuZGVmYXVsdEdyb3VwQnkgJiYgKEwoZS5kZWZhdWx0R3JvdXBCeSksIFZlKCh0KSA9PiB7XG5cdFx0XHRsZXQgbiA9IG5ldyBTZXQodCk7XG5cdFx0XHRyZXR1cm4gbi5hZGQoZS5kZWZhdWx0R3JvdXBCeSksIG47XG5cdFx0fSkpO1xuXHR9LCBbXG5cdFx0Vyxcblx0XHRsLFxuXHRcdG5cblx0XSksIHQoKCkgPT4ge1xuXHRcdGxldCB0ID0gITE7XG5cdFx0cmV0dXJuIChhc3luYyAoKSA9PiB7XG5cdFx0XHRpZiAoISghZiAmJiAhcCAmJiAhZWUgJiYgIWgpKSB0cnkge1xuXHRcdFx0XHRJZSghMCksIFJlKFwiXCIpO1xuXHRcdFx0XHRsZXQgW24sIHIsIGksIGFdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuXHRcdFx0XHRcdHkoZiwgXyksXG5cdFx0XHRcdFx0eShwLCBfKSxcblx0XHRcdFx0XHR5KGVlLCBfKSxcblx0XHRcdFx0XHR5KGgsIF8pXG5cdFx0XHRcdF0pLCBvID0gdGUoaSk7XG5cdFx0XHRcdGlmIChNZShvKSwgdCkgcmV0dXJuO1xuXHRcdFx0XHRpZiAobikge1xuXHRcdFx0XHRcdGxldCBlID0gbShuKTtcblx0XHRcdFx0XHRrKGUpLCBIKGUucGFnZVNpemUgPz8gMTApLCBlLmRlZmF1bHRTb3J0ICYmIEYoZS5kZWZhdWx0U29ydCksIGUuZGVmYXVsdEdyb3VwQnkgJiYgTChlLmRlZmF1bHRHcm91cEJ5KSwgeGU/LihlKTtcblx0XHRcdFx0fSBlbHNlIGlmIChyKSB7XG5cdFx0XHRcdFx0bGV0IGUgPSB2KHIpO1xuXHRcdFx0XHRcdGsoZSksIEgoZS5wYWdlU2l6ZSA/PyAxMCksIGUuZGVmYXVsdFNvcnQgJiYgRihlLmRlZmF1bHRTb3J0KSwgZS5kZWZhdWx0R3JvdXBCeSAmJiBMKGUuZGVmYXVsdEdyb3VwQnkpLCB4ZT8uKGUpO1xuXHRcdFx0XHR9IGVsc2UgaWYgKG8/LnNjaGVtYSkge1xuXHRcdFx0XHRcdGxldCBlID0gbShvLnNjaGVtYSk7XG5cdFx0XHRcdFx0ayhlKSwgSChlLnBhZ2VTaXplID8/IDEwKSwgZS5kZWZhdWx0U29ydCAmJiBGKGUuZGVmYXVsdFNvcnQpLCBlLmRlZmF1bHRHcm91cEJ5ICYmIEwoZS5kZWZhdWx0R3JvdXBCeSksIHhlPy4oZSk7XG5cdFx0XHRcdH0gZWxzZSBpZiAobz8uanNvblNjaGVtYSkge1xuXHRcdFx0XHRcdGxldCBlID0gdihvLmpzb25TY2hlbWEpO1xuXHRcdFx0XHRcdGsoZSksIEgoZS5wYWdlU2l6ZSA/PyAxMCksIGUuZGVmYXVsdFNvcnQgJiYgRihlLmRlZmF1bHRTb3J0KSwgZS5kZWZhdWx0R3JvdXBCeSAmJiBMKGUuZGVmYXVsdEdyb3VwQnkpLCB4ZT8uKGUpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdEFycmF5LmlzQXJyYXkoYSkgPyAoaihhKSwgUGUodm9pZCAwKSwgU2U/LihhKSkgOiBvPy5kYXRhICYmICFkICYmIChqKG8uZGF0YSksIFBlKHZvaWQgMCksIFNlPy4oby5kYXRhKSksICFlICYmIG8/Lm1vZGUgJiYgT2Uoby5tb2RlKTtcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0aWYgKHQpIHJldHVybjtcblx0XHRcdFx0bGV0IG4gPSBlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogLyogQF9fUFVSRV9fICovIEVycm9yKFwiRmFpbGVkIHRvIGxvYWQgZ3JpZCBzb3VyY2VzLlwiKTtcblx0XHRcdFx0UmUobi5tZXNzYWdlKSwgQ2U/LihuKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdHQgfHwgSWUoITEpO1xuXHRcdFx0fVxuXHRcdH0pKCksICgpID0+IHtcblx0XHRcdHQgPSAhMDtcblx0XHR9O1xuXHR9LCBbXG5cdFx0ZCxcblx0XHRoLFxuXHRcdF8sXG5cdFx0ZWUsXG5cdFx0cCxcblx0XHRlLFxuXHRcdGZcblx0XSksIHQoKCkgPT4ge1xuXHRcdCRlLmN1cnJlbnQgPSBiZTtcblx0fSwgW2JlXSksIHQoKCkgPT4ge1xuXHRcdGV0LmN1cnJlbnQgPSBnO1xuXHR9LCBbZ10pLCB0KCgpID0+IHtcblx0XHRpZiAoRGUgIT09IFwic2VydmVyXCIgfHwgIWcpIHJldHVybjtcblx0XHRsZXQgZSA9ICExLCB0ID0ge1xuXHRcdFx0cGFnZUluZGV4OiB6LFxuXHRcdFx0cGFnZVNpemU6IFYsXG5cdFx0XHRzZWFyY2hUZXJtOiBNLFxuXHRcdFx0c29ydDogUCxcblx0XHRcdGdyb3VwQnk6IEksXG5cdFx0XHRmaWx0ZXJzOiBOXG5cdFx0fTtcblx0XHRyZXR1cm4gKGFzeW5jICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGxldCBuID0gZXQuY3VycmVudDtcblx0XHRcdFx0aWYgKCFuKSByZXR1cm47XG5cdFx0XHRcdEllKCEwKSwgUmUoXCJcIik7XG5cdFx0XHRcdGxldCByID0gYXdhaXQgbih0LCBPKTtcblx0XHRcdFx0aWYgKGUpIHJldHVybjtcblx0XHRcdFx0aWYgKEFycmF5LmlzQXJyYXkocikpIHtcblx0XHRcdFx0XHRqKHIpLCBQZShyLmxlbmd0aCksIFNlPy4ocik7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGooci5yb3dzKSwgUGUoci50b3RhbENvdW50ID8/IHIucm93cy5sZW5ndGgpLCBTZT8uKHIucm93cyk7XG5cdFx0XHR9IGNhdGNoICh0KSB7XG5cdFx0XHRcdGlmIChlKSByZXR1cm47XG5cdFx0XHRcdGxldCBuID0gdCBpbnN0YW5jZW9mIEVycm9yID8gdCA6IC8qIEBfX1BVUkVfXyAqLyBFcnJvcihcIkZhaWxlZCB0byBsb2FkIHNlcnZlciBkYXRhLlwiKTtcblx0XHRcdFx0UmUobi5tZXNzYWdlKSwgQ2U/LihuKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdGUgfHwgSWUoITEpO1xuXHRcdFx0fVxuXHRcdH0pKCksICgpID0+IHtcblx0XHRcdGUgPSAhMDtcblx0XHR9O1xuXHR9LCBbXG5cdFx0Tixcblx0XHRJLFxuXHRcdHosXG5cdFx0Vixcblx0XHREZSxcblx0XHRPLFxuXHRcdE0sXG5cdFx0UFxuXHRdKTtcblx0bGV0IEcgPSBPLmNvbHVtbnMsIEsgPSBPLmlkRmllbGQgPz8gXCJpZFwiLCBxID0gX2UgPyBPLnNlbGVjdGlvbk1vZGUgPz8gXCJtdWx0aXBsZVwiIDogXCJub25lXCIsIHR0ID0gcGUsIG50ID0gbWUsIHJ0ID0gaGUsIGl0ID0gZ2UsIGF0ID0gZmUgPT09IFwiaW5saW5lXCIgfHwgZmUgPT09IFwiYm90aFwiLCBvdCA9IGZlID09PSBcImRpYWxvZ1wiIHx8IGZlID09PSBcImJvdGhcIiwgSiA9IERlID09PSBcInNlcnZlclwiLCBZID0gcigoKSA9PiBKID8gQSA6IG5lKEEsIEcsIHR0ID8gTSA6IFwiXCIsIG50ID8gTiA6IHt9KSwgW1xuXHRcdG50LFxuXHRcdHR0LFxuXHRcdE4sXG5cdFx0Ryxcblx0XHRKLFxuXHRcdEEsXG5cdFx0TVxuXHRdKSwgWCA9IHIoKCkgPT4gSiA/IFkgOiByZShZLCBQLCBHKSwgW1xuXHRcdEcsXG5cdFx0WSxcblx0XHRKLFxuXHRcdFBcblx0XSksIHN0ID0gSiA/IE5lID8/IFgubGVuZ3RoIDogWC5sZW5ndGgsIFogPSBNYXRoLm1heCgxLCBNYXRoLmNlaWwoc3QgLyBNYXRoLm1heCgxLCBWKSkpLCBRID0gTWF0aC5taW4oeiwgWiAtIDEpO1xuXHR0KCgpID0+IHtcblx0XHRRICE9PSB6ICYmIEIoUSk7XG5cdH0sIFtRLCB6XSk7XG5cdGxldCBjdCA9IHIoKCkgPT4gSiA/IFggOiBpdCA/IGFlKFgsIFYsIFEpIDogWCwgW1xuXHRcdGl0LFxuXHRcdFEsXG5cdFx0Sixcblx0XHRWLFxuXHRcdFhcblx0XSksIGx0ID0gcigoKSA9PiB7XG5cdFx0bGV0IGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHJldHVybiBJICYmIGN0LmZvckVhY2goKHQpID0+IHtcblx0XHRcdGxldCBuID0gdFtJXTtcblx0XHRcdGUuYWRkKG4gPT0gbnVsbCB8fCBuID09PSBcIlwiID8gXCIoZW1wdHkpXCIgOiBTdHJpbmcobikpO1xuXHRcdH0pLCBlO1xuXHR9LCBbSSwgY3RdKTtcblx0dCgoKSA9PiB7XG5cdFx0SSAmJiBSLnNpemUgPT09IDAgJiYgbHQuc2l6ZSA+IDAgJiYgVmUobHQpO1xuXHR9LCBbXG5cdFx0bHQsXG5cdFx0Ui5zaXplLFxuXHRcdElcblx0XSk7XG5cdGxldCAkID0gcigoKSA9PiBpZShjdCwgRywgcnQgPyBJIDogbnVsbCwgUiksIFtcblx0XHRydCxcblx0XHRHLFxuXHRcdFIsXG5cdFx0SSxcblx0XHRjdFxuXHRdKSwgdXQgPSAkLmZpbHRlcigoZSkgPT4gZS5raW5kID09PSBcImRhdGFcIikubGVuZ3RoLCBkdCA9IE1hdGgubWF4KDEsIHV0ICsgJC5maWx0ZXIoKGUpID0+IGUua2luZCA9PT0gXCJncm91cFwiKS5sZW5ndGgpICogdywgZnQgPSBNYXRoLmNlaWwoc2UgLyB3KSArIEQgKiAyLCBwdCA9IE1hdGgubWF4KDAsIE1hdGguZmxvb3IoWWUgLyB3KSAtIEQpLCBtdCA9IE1hdGgubWluKCQubGVuZ3RoLCBwdCArIGZ0KSwgaHQgPSAkLnNsaWNlKHB0LCBtdCksIGd0ID0gcHQgKiB3LCBfdCA9IE1hdGgubWF4KDAsIGR0IC0gZ3QgLSBodC5sZW5ndGggKiB3KSwgdnQgPSByKCgpID0+IHtcblx0XHRsZXQgZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0cmV0dXJuIEEuZm9yRWFjaCgodCwgbikgPT4ge1xuXHRcdFx0ZS5zZXQoeCh0LCBLLCBuKSwgdCk7XG5cdFx0fSksIEFycmF5LmZyb20oSGUudmFsdWVzKCkpLm1hcCgodCkgPT4gZS5nZXQodCkpLmZpbHRlcigoZSkgPT4gISFlKTtcblx0fSwgW1xuXHRcdEssXG5cdFx0QSxcblx0XHRIZVxuXHRdKTtcblx0dCgoKSA9PiB7XG5cdFx0JGUuY3VycmVudD8uKHZ0KTtcblx0fSwgW3Z0XSk7XG5cdGxldCB5dCA9IHIoKCkgPT4ge1xuXHRcdGxldCBlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRyZXR1cm4gRy5mb3JFYWNoKCh0KSA9PiB7XG5cdFx0XHRsZXQgbiA9IEMoWSwgdCk7XG5cdFx0XHRuLnR5cGUgIT09IFwibm9uZVwiICYmIGUuc2V0KHQua2V5LCBgJHt1ZShuLnR5cGUpfSAke29lKG4pfWApO1xuXHRcdH0pLCBlO1xuXHR9LCBbRywgWV0pLCBidCA9IHIoKCkgPT4gJC5maWx0ZXIoKGUpID0+IGUua2luZCA9PT0gXCJkYXRhXCIgJiYgISFlLnJvdykubWFwKChlKSA9PiB4KGUucm93LCBLLCBlLnJvd0luZGV4ID8/IDApKSwgWyQsIEtdKSwgeHQgPSBxICE9PSBcIm5vbmVcIiAmJiBidC5sZW5ndGggPiAwICYmIGJ0LmV2ZXJ5KChlKSA9PiBIZS5oYXMoZSkpO1xuXHRmdW5jdGlvbiBTdChlKSB7XG5cdFx0aihlKSwgeWU/LihlKTtcblx0fVxuXHRmdW5jdGlvbiBDdChlLCB0KSB7XG5cdFx0QmUoKG4pID0+ICh7XG5cdFx0XHQuLi5uLFxuXHRcdFx0W2VdOiB0XG5cdFx0fSkpLCBCKDApO1xuXHR9XG5cdGZ1bmN0aW9uIHd0KGUpIHtcblx0XHRGKCh0KSA9PiBjZSh0LCBlKSksIEIoMCk7XG5cdH1cblx0ZnVuY3Rpb24gVHQoZSwgdCwgbikge1xuXHRcdGxldCByID0gd2U/LltuLmtleV0sIGkgPSBlW24ua2V5XTtcblx0XHRyZXR1cm4gciA/IHIoe1xuXHRcdFx0cm93OiBlLFxuXHRcdFx0cm93SW5kZXg6IHQsXG5cdFx0XHRjb2x1bW46IG4sXG5cdFx0XHR2YWx1ZTogaVxuXHRcdH0pIDogUyhpLCBuKTtcblx0fVxuXHRmdW5jdGlvbiBFdChlLCB0KSB7XG5cdFx0bGV0IG4gPSB4KGUsIEssIHQpO1xuXHRcdEdlKG4pLCBVKHsgLi4uZSB9KTtcblx0fVxuXHRmdW5jdGlvbiBEdChlKSB7XG5cdFx0S2UgJiYgKFN0KEEubWFwKCh0LCBuKSA9PiB4KHQsIEssIG4pID09PSBlID8geyAuLi5LZSB9IDogdCkpLCBHZShudWxsKSwgVShudWxsKSk7XG5cdH1cblx0ZnVuY3Rpb24gT3QoKSB7XG5cdFx0R2UobnVsbCksIFUobnVsbCk7XG5cdH1cblx0ZnVuY3Rpb24ga3QoZSwgdCkge1xuXHRcdGxldCBuID0geChlLCBLLCB0KTtcblx0XHRKZSh7XG5cdFx0XHRyb3dJZDogbixcblx0XHRcdGRyYWZ0OiB7IC4uLmUgfVxuXHRcdH0pO1xuXHR9XG5cdGZ1bmN0aW9uIEF0KGUsIHQpIHtcblx0XHRTdChBLm1hcCgobiwgcikgPT4geChuLCBLLCByKSA9PT0gZSA/IHsgLi4udCB9IDogbikpLCBKZShudWxsKTtcblx0fVxuXHRmdW5jdGlvbiBqdChlKSB7XG5cdFx0VmUoKHQpID0+IHtcblx0XHRcdGxldCBuID0gbmV3IFNldCh0KTtcblx0XHRcdHJldHVybiBuLmhhcyhlKSA/IG4uZGVsZXRlKGUpIDogbi5hZGQoZSksIG47XG5cdFx0fSk7XG5cdH1cblx0ZnVuY3Rpb24gTXQoZSwgdCwgbikge1xuXHRcdGlmIChxID09PSBcIm5vbmVcIikgcmV0dXJuO1xuXHRcdGxldCByID0geChlLCBLLCB0KTtcblx0XHRVZSgoZSkgPT4ge1xuXHRcdFx0aWYgKHEgPT09IFwic2luZ2xlXCIpIHJldHVybiBuID8gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW3JdKSA6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0XHRsZXQgdCA9IG5ldyBTZXQoZSk7XG5cdFx0XHRyZXR1cm4gbiA/IHQuYWRkKHIpIDogdC5kZWxldGUociksIHQ7XG5cdFx0fSk7XG5cdH1cblx0ZnVuY3Rpb24gTnQoZSkge1xuXHRcdGlmIChxICE9PSBcIm5vbmVcIikge1xuXHRcdFx0aWYgKHEgPT09IFwic2luZ2xlXCIpIHtcblx0XHRcdFx0bGV0IHQgPSAkLmZpbmQoKGUpID0+IGUua2luZCA9PT0gXCJkYXRhXCIgJiYgZS5yb3cpO1xuXHRcdFx0XHRpZiAoIXQgfHwgIXQucm93KSB7XG5cdFx0XHRcdFx0VWUoLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdFVlKGUgPyAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbeCh0LnJvdywgSywgdC5yb3dJbmRleCA/PyAwKV0pIDogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdFVlKCh0KSA9PiB7XG5cdFx0XHRcdGxldCBuID0gbmV3IFNldCh0KTtcblx0XHRcdFx0cmV0dXJuIGJ0LmZvckVhY2goKHQpID0+IHtcblx0XHRcdFx0XHRlID8gbi5hZGQodCkgOiBuLmRlbGV0ZSh0KTtcblx0XHRcdFx0fSksIG47XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0bGV0IFB0ID0gYihcIm5hYnMtdWktZ3JpZFwiLCB2ZSksIEZ0ID0gRy5sZW5ndGggKyAocSA9PT0gXCJub25lXCIgPyAwIDogMSkgKyAxLCBJdCA9IEcuZmlsdGVyKChlKSA9PiBlLmdyb3VwYWJsZSksIEx0ID0gTy5mb290ZXI/LnNob3dDb2x1bW5BZ2dyZWdhdGVzICE9PSAhMSwgUnQgPSBKID8gc3QgOiBZLmxlbmd0aCwgenQgPSAoTy5mb290ZXI/LnJvd0FnZ3JlZ2F0ZXMgPz8gW10pLm1hcCgoZSkgPT4gZSA9PT0gXCJmaWx0ZXJlZFJvd3NcIiA/IGBGaWx0ZXJlZCByb3dzICR7UnR9YCA6IGUgPT09IFwicGFnZWRSb3dzXCIgPyBgUGFnZSByb3dzICR7Y3QubGVuZ3RofWAgOiBlID09PSBcInNlbGVjdGVkUm93c1wiID8gYFNlbGVjdGVkIHJvd3MgJHt2dC5sZW5ndGh9YCA6IGUgPT09IFwiZ3JvdXBDb3VudFwiID8gYEdyb3VwcyAke0kgPyAkLmZpbHRlcigoZSkgPT4gZS5raW5kID09PSBcImdyb3VwXCIpLmxlbmd0aCA6IDB9YCA6IFwiXCIpLmZpbHRlcihCb29sZWFuKSwgQnQgPSBaZSA9PT0gMCA/IHZvaWQgMCA6IHsgdHJhbnNmb3JtOiBgdHJhbnNsYXRlWCgkey1aZX1weClgIH07XG5cdGZ1bmN0aW9uIFZ0KCkge1xuXHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gYyhcImNvbGdyb3VwXCIsIHsgY2hpbGRyZW46IFtcblx0XHRcdHEgPT09IFwibm9uZVwiID8gbnVsbCA6IC8qIEBfX1BVUkVfXyAqLyBzKFwiY29sXCIsIHsgY2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY29sIG5hYnMtdWktZ3JpZF9fY29sLS1zZWxlY3Rpb25cIiB9KSxcblx0XHRcdEcubWFwKChlKSA9PiB7XG5cdFx0XHRcdGxldCB0ID0gZS53aWR0aCwgbiA9IGUubWluV2lkdGg7XG5cdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcImNvbFwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY29sXCIsXG5cdFx0XHRcdFx0c3R5bGU6IHtcblx0XHRcdFx0XHRcdHdpZHRoOiB0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0eXBlb2YgdCA9PSBcIm51bWJlclwiID8gYCR7dH1weGAgOiB0LFxuXHRcdFx0XHRcdFx0bWluV2lkdGg6IG4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IGAke259cHhgXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9LCBlLmtleSk7XG5cdFx0XHR9KSxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwiY29sXCIsIHsgY2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY29sIG5hYnMtdWktZ3JpZF9fY29sLS1hY3Rpb25zXCIgfSlcblx0XHRdIH0pO1xuXHR9XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gYyhcImRpdlwiLCB7XG5cdFx0cmVmOiBFZSxcblx0XHRjbGFzc05hbWU6IFB0LFxuXHRcdC4uLlRlLFxuXHRcdGNoaWxkcmVuOiBbXG5cdFx0XHQvKiBAX19QVVJFX18gKi8gYyhcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3Rvb2xiYXJcIixcblx0XHRcdFx0Y2hpbGRyZW46IFtcblx0XHRcdFx0XHR0dCA/IC8qIEBfX1BVUkVfXyAqLyBzKFwiaW5wdXRcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faW5wdXQgbmFicy11aS1ncmlkX19zZWFyY2hcIixcblx0XHRcdFx0XHRcdHR5cGU6IFwic2VhcmNoXCIsXG5cdFx0XHRcdFx0XHR2YWx1ZTogTSxcblx0XHRcdFx0XHRcdHBsYWNlaG9sZGVyOiBcIkZpbmQgcm93cy4uLlwiLFxuXHRcdFx0XHRcdFx0b25DaGFuZ2U6IChlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdHplKGUudGFyZ2V0LnZhbHVlKSwgQigwKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdFx0cnQgPyAvKiBAX19QVVJFX18gKi8gYyhcImxhYmVsXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2dyb3VwQ29udHJvbFwiLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwgeyBjaGlsZHJlbjogXCJHcm91cCBieVwiIH0pLCAvKiBAX19QVVJFX18gKi8gYyhcInNlbGVjdFwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2lucHV0XCIsXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBJID8/IFwiXCIsXG5cdFx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGxldCB0ID0gZS50YXJnZXQudmFsdWUgfHwgbnVsbDtcblx0XHRcdFx0XHRcdFx0XHRMKHQpLCBWZSgvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpKTtcblx0XHRcdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0dmFsdWU6IFwiXCIsXG5cdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiTm9uZVwiXG5cdFx0XHRcdFx0XHRcdH0pLCBJdC5tYXAoKGUpID0+IC8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogZS5rZXksXG5cdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUubGFiZWxcblx0XHRcdFx0XHRcdFx0fSwgZS5rZXkpKV1cblx0XHRcdFx0XHRcdH0pXVxuXHRcdFx0XHRcdH0pIDogbnVsbCxcblx0XHRcdFx0XHRpdCA/IC8qIEBfX1BVUkVfXyAqLyBjKFwibGFiZWxcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZ3JvdXBDb250cm9sXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7IGNoaWxkcmVuOiBcIlBhZ2Ugc2l6ZVwiIH0pLCAvKiBAX19QVVJFX18gKi8gcyhcInNlbGVjdFwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2lucHV0XCIsXG5cdFx0XHRcdFx0XHRcdHZhbHVlOiBTdHJpbmcoViksXG5cdFx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGxldCB0ID0gTnVtYmVyKGUudGFyZ2V0LnZhbHVlKTtcblx0XHRcdFx0XHRcdFx0XHRIKE51bWJlci5pc0Zpbml0ZSh0KSAmJiB0ID4gMCA/IHQgOiAxMCksIEIoMCk7XG5cdFx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAoTy5wYWdlU2l6ZU9wdGlvbnMgPz8gW1xuXHRcdFx0XHRcdFx0XHRcdDEwLFxuXHRcdFx0XHRcdFx0XHRcdDIwLFxuXHRcdFx0XHRcdFx0XHRcdDUwXG5cdFx0XHRcdFx0XHRcdF0pLm1hcCgoZSkgPT4gLyogQF9fUFVSRV9fICovIHMoXCJvcHRpb25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBTdHJpbmcoZSksXG5cdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IGVcblx0XHRcdFx0XHRcdFx0fSwgZSkpXG5cdFx0XHRcdFx0XHR9KV1cblx0XHRcdFx0XHR9KSA6IG51bGxcblx0XHRcdFx0XVxuXHRcdFx0fSksXG5cdFx0XHRMZSA/IC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fc3RhdHVzXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBMZVxuXHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0RmUgPyAvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3N0YXR1c1wiLFxuXHRcdFx0XHRjaGlsZHJlbjogXCJMb2FkaW5nIGRhdGEuLi5cIlxuXHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0LyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19zdXJmYWNlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faGVhZGVyVmlld3BvcnRcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gYyhcInRhYmxlXCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fdGFibGVcIixcblx0XHRcdFx0XHRcdFx0c3R5bGU6IEJ0LFxuXHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW1Z0KCksIC8qIEBfX1BVUkVfXyAqLyBzKFwidGhlYWRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2hlYWRcIixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGMoXCJ0clwiLCB7IGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHRcdFx0XHRxID09PSBcIm5vbmVcIiA/IG51bGwgOiAvKiBAX19QVVJFX18gKi8gcyhcInRoXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbCBuYWJzLXVpLWdyaWRfX2NlbGwtLWhlYWQgbmFicy11aS1ncmlkX19jZWxsLS1zZWxlY3Rpb25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBzKFwiaW5wdXRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHR5cGU6IFwiY2hlY2tib3hcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGVja2VkOiB4dCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNoYW5nZTogKGUpID0+IE50KGUudGFyZ2V0LmNoZWNrZWQpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBcIlNlbGVjdCB2aXNpYmxlIHJvd3NcIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0XHRcdFx0XHRHLm1hcCgoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgdCA9IFA/LmNvbHVtbktleSA9PT0gZS5rZXkgPyBgICgke1AuZGlyZWN0aW9ufSlgIDogXCJcIiwgbiA9ICEhTltlLmtleV07XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcInRoXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsIG5hYnMtdWktZ3JpZF9fY2VsbC0taGVhZFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gYyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19oZWFkQ2VsbFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gYyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3NvcnRCdXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DbGljazogKCkgPT4gd3QoZSksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGRpc2FibGVkOiAhZS5zb3J0YWJsZSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XCJhcmlhLWxhYmVsXCI6IGAke2UubGFiZWx9JHt0fWAsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHsgY2hpbGRyZW46IGUubGFiZWwgfSksIGUuc29ydGFibGUgPyAvKiBAX19QVVJFX18gKi8gcyhcInNwYW5cIiwgeyBjaGlsZHJlbjogUD8uY29sdW1uS2V5ID09PSBlLmtleSA/IFAuZGlyZWN0aW9uIDogXCItXCIgfSkgOiBudWxsXVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSksIG50ICYmIGUuZmlsdGVyYWJsZSA/IGUudHlwZSA9PT0gXCJib29sZWFuXCIgPyAvKiBAX19QVVJFX18gKi8gYyhcInNlbGVjdFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogYihcIm5hYnMtdWktZ3JpZF9faW5wdXRcIiwgbiA/IFwibmFicy11aS1ncmlkX19pbnB1dC0tYWN0aXZlXCIgOiBcIlwiKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IGxlKE5bZS5rZXldID8/IFwiXCIpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNoYW5nZTogKHQpID0+IEN0KGUua2V5LCB0LnRhcmdldC52YWx1ZSksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIHMoXCJvcHRpb25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IFwiXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJBbGxcIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBcInRydWVcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIlRydWVcIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwib3B0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiBcImZhbHNlXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJGYWxzZVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSkgOiAvKiBAX19QVVJFX18gKi8gcyhcImlucHV0XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBiKFwibmFicy11aS1ncmlkX19pbnB1dFwiLCBuID8gXCJuYWJzLXVpLWdyaWRfX2lucHV0LS1hY3RpdmVcIiA6IFwiXCIpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcInRleHRcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IE5bZS5rZXldID8/IFwiXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHBsYWNlaG9sZGVyOiBcIkZpbHRlclwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNoYW5nZTogKHQpID0+IEN0KGUua2V5LCB0LnRhcmdldC52YWx1ZSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pIDogbnVsbF1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9LCBlLmtleSk7XG5cdFx0XHRcdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwidGhcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsIG5hYnMtdWktZ3JpZF9fY2VsbC0taGVhZCBuYWJzLXVpLWdyaWRfX2NlbGwtLWFjdGlvbnNcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiQWN0aW9uc1wiXG5cdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdF0gfSlcblx0XHRcdFx0XHRcdFx0fSldXG5cdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3ZpZXdwb3J0XCIsXG5cdFx0XHRcdFx0XHRzdHlsZTogeyBoZWlnaHQ6IGAke3NlfXB4YCB9LFxuXHRcdFx0XHRcdFx0b25TY3JvbGw6IChlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdGxldCB0ID0gZS50YXJnZXQ7XG5cdFx0XHRcdFx0XHRcdFhlKHQuc2Nyb2xsVG9wKSwgUWUodC5zY3JvbGxMZWZ0KTtcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGMoXCJ0YWJsZVwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3RhYmxlXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbVnQoKSwgLyogQF9fUFVSRV9fICovIGMoXCJ0Ym9keVwiLCB7IGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHRcdFx0Z3QgPiAwID8gLyogQF9fUFVSRV9fICovIHMoXCJ0clwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19zcGFjZXJcIixcblx0XHRcdFx0XHRcdFx0XHRcdHN0eWxlOiB7IGhlaWdodDogYCR7Z3R9cHhgIH0sXG5cdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIHMoXCJ0ZFwiLCB7IGNvbFNwYW46IEZ0IH0pXG5cdFx0XHRcdFx0XHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0XHRcdFx0XHRcdGh0Lm1hcCgoZSwgdCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0aWYgKGUua2luZCA9PT0gXCJncm91cFwiKSB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGxldCB0ID0gZS5ncm91cFZhbHVlID8/IFwiKGVtcHR5KVwiLCBuID0gUi5oYXModCk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gcyhcInRyXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19ncm91cFJvd1wiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHN0eWxlOiB7IGhlaWdodDogYCR7d31weGAgfSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIHMoXCJ0ZFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjb2xTcGFuOiBGdCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2dyb3VwQ2VsbFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBjKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZ3JvdXBUb2dnbGVcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DbGljazogKCkgPT4ganQodCksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIHMoXCJzcGFuXCIsIHsgY2hpbGRyZW46IG4gPyBcIkhpZGVcIiA6IFwiU2hvd1wiIH0pLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7IGNoaWxkcmVuOiB0IH0pLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBjKFwic3BhblwiLCB7IGNoaWxkcmVuOiBbZS5ncm91cFNpemUgPz8gMCwgXCIgcm93c1wiXSB9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRdXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0XHRcdH0sIGUua2V5KTtcblx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRcdGlmICghZS5yb3cpIHJldHVybiBudWxsO1xuXHRcdFx0XHRcdFx0XHRcdFx0bGV0IG4gPSBlLnJvdywgciA9IGUucm93SW5kZXggPz8gdCwgaSA9IHgobiwgSywgciksIGEgPSBIZS5oYXMoaSksIGwgPSBXZSA9PT0gaTtcblx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gYyhcInRyXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBiKFwibmFicy11aS1ncmlkX19kYXRhUm93XCIsIGEgPyBcIm5hYnMtdWktZ3JpZF9fZGF0YVJvdy0tc2VsZWN0ZWRcIiA6IFwiXCIpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRzdHlsZTogeyBoZWlnaHQ6IGAke3d9cHhgIH0sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0cSA9PT0gXCJub25lXCIgPyBudWxsIDogLyogQF9fUFVSRV9fICovIHMoXCJ0ZFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsIG5hYnMtdWktZ3JpZF9fY2VsbC0tc2VsZWN0aW9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIHMoXCJpbnB1dFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHR5cGU6IFwiY2hlY2tib3hcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hlY2tlZDogYSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DaGFuZ2U6IChlKSA9PiBNdChuLCByLCBlLnRhcmdldC5jaGVja2VkKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XCJhcmlhLWxhYmVsXCI6IGBTZWxlY3Qgcm93ICR7aX1gXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdEcubWFwKChlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgdCA9IFQoKGwgPyBLZSA6IG4pPy5bZS5rZXldLCBlLnR5cGUpO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0cmV0dXJuIGwgJiYgZS5lZGl0YWJsZSA/IGUuZWRpdG9yID09PSBcImNoZWNrYm94XCIgfHwgZS50eXBlID09PSBcImJvb2xlYW5cIiA/IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gYyhcInNlbGVjdFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9faW5wdXRcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogdCA9PT0gXCJ0cnVlXCIgPyBcInRydWVcIiA6IFwiZmFsc2VcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNoYW5nZTogKHQpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGxldCBuID0gdC50YXJnZXQudmFsdWUgPT09IFwidHJ1ZVwiO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0VSgodCkgPT4gKHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Li4udCA/PyB7fSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0W2Uua2V5XTogblxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSkpO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcIm9wdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJUcnVlXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIHMoXCJvcHRpb25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IFwiZmFsc2VcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIkZhbHNlXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KV1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0sIGUua2V5KSA6IGUuZWRpdG9yID09PSBcInNlbGVjdFwiICYmIGUub3B0aW9ucz8ubGVuZ3RoID8gLyogQF9fUFVSRV9fICovIHMoXCJ0ZFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NlbGxcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBjKFwic2VsZWN0XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19pbnB1dFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZhbHVlOiB0LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdG9uQ2hhbmdlOiAodCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0bGV0IG4gPSBFKHQudGFyZ2V0LnZhbHVlLCBlKTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFUoKHQpID0+ICh7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC4uLnQgPz8ge30sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFtlLmtleV06IG5cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJvcHRpb25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IFwiXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCIoZW1wdHkpXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSwgZS5vcHRpb25zLm1hcCgoZSkgPT4gLyogQF9fUFVSRV9fICovIHMoXCJvcHRpb25cIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IFN0cmluZyhlLnZhbHVlKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmxhYmVsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSwgU3RyaW5nKGUudmFsdWUpKSldXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9LCBlLmtleSkgOiBlLmVkaXRvciA9PT0gXCJ0ZXh0YXJlYVwiID8gLyogQF9fUFVSRV9fICovIHMoXCJ0ZFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NlbGxcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBzKFwidGV4dGFyZWFcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2lucHV0IG5hYnMtdWktZ3JpZF9faW5wdXQtLXRleHRhcmVhXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IHQsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0b25DaGFuZ2U6ICh0KSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgbiA9IEUodC50YXJnZXQudmFsdWUsIGUpO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0VSgodCkgPT4gKHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Li4udCA/PyB7fSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0W2Uua2V5XTogblxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSkpO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0sIGUua2V5KSA6IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gcyhcImlucHV0XCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19pbnB1dFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHR5cGU6IGUuZWRpdG9yID09PSBcIm51bWJlclwiIHx8IGUudHlwZSA9PT0gXCJudW1iZXJcIiA/IFwibnVtYmVyXCIgOiBlLnR5cGUgPT09IFwiZGF0ZVwiID8gXCJkYXRlXCIgOiBcInRleHRcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2YWx1ZTogdCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNoYW5nZTogKHQpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGxldCBuID0gRSh0LnRhcmdldC52YWx1ZSwgZSk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRVKCh0KSA9PiAoe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQuLi50ID8/IHt9LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRbZS5rZXldOiBuXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSwgZS5rZXkpIDogLyogQF9fUFVSRV9fICovIHMoXCJ0ZFwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NlbGxcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dGl0bGU6IFMobltlLmtleV0sIGUpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogVHQobiwgciwgZSlcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0sIGUua2V5KTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcInRkXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2NlbGwgbmFicy11aS1ncmlkX19jZWxsLS1hY3Rpb25zXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19hY3Rpb25TdGFja1wiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW2F0ID8gbCA/IC8qIEBfX1BVUkVfXyAqLyBjKG8sIHsgY2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fYnV0dG9uIG5hYnMtdWktZ3JpZF9fYnV0dG9uLS1wcmltYXJ5XCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBEdChpKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJTYXZlXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBzKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19idXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdG9uQ2xpY2s6IE90LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIkNhbmNlbFwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pXSB9KSA6IC8qIEBfX1BVUkVfXyAqLyBzKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19idXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IEV0KG4sIHIpLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIklubGluZVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pIDogbnVsbCwgb3QgPyAvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBrdChuLCByKSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJEaWFsb2dcIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0XHRcdF1cblx0XHRcdFx0XHRcdFx0XHRcdH0sIGUua2V5KTtcblx0XHRcdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdFx0XHRfdCA+IDAgPyAvKiBAX19QVVJFX18gKi8gcyhcInRyXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3NwYWNlclwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0c3R5bGU6IHsgaGVpZ2h0OiBgJHtfdH1weGAgfSxcblx0XHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gcyhcInRkXCIsIHsgY29sU3BhbjogRnQgfSlcblx0XHRcdFx0XHRcdFx0XHR9KSA6IG51bGxcblx0XHRcdFx0XHRcdFx0XSB9KV1cblx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0THQgfHwgenQubGVuZ3RoID8gLyogQF9fUFVSRV9fICovIGMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZm9vdGVyXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogW0x0ID8gLyogQF9fUFVSRV9fICovIGMoXCJzZWN0aW9uXCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZm9vdGVyU2VjdGlvbiBuYWJzLXVpLWdyaWRfX2Zvb3RlclNlY3Rpb24tLWNvbHVtbnNcIixcblx0XHRcdFx0XHRcdFx0XCJhcmlhLWxhYmVsXCI6IFwiQ29sdW1uIGFnZ3JlZ2F0ZXNcIixcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fZm9vdGVyU2VjdGlvbkhlYWRlclwiLFxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBcIkNvbHVtbiBhZ2dyZWdhdGVzXCJcblx0XHRcdFx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBjKFwidGFibGVcIiwge1xuXHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX3RhYmxlXCIsXG5cdFx0XHRcdFx0XHRcdFx0c3R5bGU6IEJ0LFxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbVnQoKSwgLyogQF9fUFVSRV9fICovIHMoXCJ0Ym9keVwiLCB7IGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gYyhcInRyXCIsIHsgY2hpbGRyZW46IFtcblx0XHRcdFx0XHRcdFx0XHRcdHEgPT09IFwibm9uZVwiID8gbnVsbCA6IC8qIEBfX1BVUkVfXyAqLyBzKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsIG5hYnMtdWktZ3JpZF9fY2VsbC0tZm9vdFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogdnQubGVuZ3RoXG5cdFx0XHRcdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdFx0XHRcdEcubWFwKChlLCB0KSA9PiAvKiBAX19QVVJFX18gKi8gYyhcInRkXCIsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbCBuYWJzLXVpLWdyaWRfX2NlbGwtLWZvb3RcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IFtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0ID09PSAwID8gYFJvd3MgJHtSdH1gIDogXCJcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0ID09PSAwICYmIHl0LmhhcyhlLmtleSkgPyBcIiB8IFwiIDogXCJcIixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR5dC5nZXQoZS5rZXkpID8/IFwiXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XVxuXHRcdFx0XHRcdFx0XHRcdFx0fSwgZS5rZXkpKSxcblx0XHRcdFx0XHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBjKFwidGRcIiwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19jZWxsIG5hYnMtdWktZ3JpZF9fY2VsbC0tZm9vdFwiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogW1wiU2VsZWN0ZWQgXCIsIHZ0Lmxlbmd0aF1cblx0XHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0XSB9KSB9KV1cblx0XHRcdFx0XHRcdFx0fSldXG5cdFx0XHRcdFx0XHR9KSA6IG51bGwsIHp0Lmxlbmd0aCA/IC8qIEBfX1BVUkVfXyAqLyBjKFwic2VjdGlvblwiLCB7XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2Zvb3RlclNlY3Rpb24gbmFicy11aS1ncmlkX19mb290ZXJTZWN0aW9uLS1yb3dzXCIsXG5cdFx0XHRcdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBcIlJvdyBhZ2dyZWdhdGVzXCIsXG5cdFx0XHRcdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2Zvb3RlclNlY3Rpb25IZWFkZXJcIixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJSb3cgYWdncmVnYXRlc1wiXG5cdFx0XHRcdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8gcyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fY2VsbCBuYWJzLXVpLWdyaWRfX2NlbGwtLWZvb3RcIixcblx0XHRcdFx0XHRcdFx0XHRjaGlsZHJlbjogenQuam9pbihcIiB8IFwiKVxuXHRcdFx0XHRcdFx0XHR9KV1cblx0XHRcdFx0XHRcdH0pIDogbnVsbF1cblx0XHRcdFx0XHR9KSA6IG51bGxcblx0XHRcdFx0XVxuXHRcdFx0fSksXG5cdFx0XHRpdCA/IC8qIEBfX1BVUkVfXyAqLyBjKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fcGFnZXJcIixcblx0XHRcdFx0Y2hpbGRyZW46IFtcblx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19idXR0b25cIixcblx0XHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBCKDApLFxuXHRcdFx0XHRcdFx0ZGlzYWJsZWQ6IFEgPT09IDAsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJGaXJzdFwiXG5cdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIHMoXCJidXR0b25cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktZ3JpZF9fYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHR0eXBlOiBcImJ1dHRvblwiLFxuXHRcdFx0XHRcdFx0b25DbGljazogKCkgPT4gQigoZSkgPT4gTWF0aC5tYXgoMCwgZSAtIDEpKSxcblx0XHRcdFx0XHRcdGRpc2FibGVkOiBRID09PSAwLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiUHJldlwiXG5cdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0LyogQF9fUFVSRV9fICovIGMoXCJzcGFuXCIsIHsgY2hpbGRyZW46IFtcblx0XHRcdFx0XHRcdFwiUGFnZSBcIixcblx0XHRcdFx0XHRcdFEgKyAxLFxuXHRcdFx0XHRcdFx0XCIgLyBcIixcblx0XHRcdFx0XHRcdFpcblx0XHRcdFx0XHRdIH0pLFxuXHRcdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBzKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWdyaWRfX2J1dHRvblwiLFxuXHRcdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IEIoKGUpID0+IE1hdGgubWluKFogLSAxLCBlICsgMSkpLFxuXHRcdFx0XHRcdFx0ZGlzYWJsZWQ6IFEgPj0gWiAtIDEsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogXCJOZXh0XCJcblx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHQvKiBAX19QVVJFX18gKi8gcyhcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1ncmlkX19idXR0b25cIixcblx0XHRcdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBCKFogLSAxKSxcblx0XHRcdFx0XHRcdGRpc2FibGVkOiBRID49IFogLSAxLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IFwiTGFzdFwiXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0XVxuXHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0cWUgPyAvKiBAX19QVVJFX18gKi8gcyhkZSwge1xuXHRcdFx0XHRjb2x1bW5zOiBHLFxuXHRcdFx0XHRkcmFmdDogcWUuZHJhZnQsXG5cdFx0XHRcdHJvd0lkOiBxZS5yb3dJZCxcblx0XHRcdFx0b25DYW5jZWw6ICgpID0+IEplKG51bGwpLFxuXHRcdFx0XHRvblNhdmU6IChlKSA9PiBBdChxZS5yb3dJZCwgZSlcblx0XHRcdH0pIDogbnVsbFxuXHRcdF1cblx0fSk7XG59KTtcbkQuZGlzcGxheU5hbWUgPSBcIkdyaWRcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgRCBhcyBHcmlkIH07XG4iLCJpbXBvcnQgKiBhcyBlIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyB0LCB1c2VFZmZlY3QgYXMgbiwgdXNlSWQgYXMgciwgdXNlUmVmIGFzIGksIHVzZVN0YXRlIGFzIGEgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyBvLCBqc3hzIGFzIHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiAuLi9uYWJzLXVpLXRvb2xiYXIvc3JjL3Rvb2xiYXIudXRpbHMudHNcbnZhciBjID0ge1xuXHRsZWZ0OiBcIm5hYnMtdWktdG9vbGJhcl9fY29udGVudC0tbGFiZWwtbGVmdFwiLFxuXHRyaWdodDogXCJuYWJzLXVpLXRvb2xiYXJfX2NvbnRlbnQtLWxhYmVsLXJpZ2h0XCIsXG5cdHRvcDogXCJuYWJzLXVpLXRvb2xiYXJfX2NvbnRlbnQtLWxhYmVsLXRvcFwiLFxuXHRib3R0b206IFwibmFicy11aS10b29sYmFyX19jb250ZW50LS1sYWJlbC1ib3R0b21cIlxufTtcbmZ1bmN0aW9uIGwoZSkge1xuXHRyZXR1cm4gZSB8fCBcInJpZ2h0XCI7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi9uYWJzLXVpLXRvb2xiYXIvc3JjL1Rvb2xiYXIudHN4XG52YXIgdSA9IHQoZnVuY3Rpb24oeyBpdGVtczogZSwgYWN0aXZlSXRlbUlkOiB0LCBjbGFzc05hbWU6IG4gPSBcIlwiLCBidXR0b25DbGFzc05hbWU6IHIgPSBcIlwiLCBpY29uQ2xhc3NOYW1lOiBpID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IGEgPSBcIlwiLCBvbkl0ZW1TZWxlY3Q6IHUsIC4uLmQgfSwgZikge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdHJlZjogZixcblx0XHRjbGFzc05hbWU6IFtcIm5hYnMtdWktdG9vbGJhclwiLCBuXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksXG5cdFx0cm9sZTogXCJ0b29sYmFyXCIsXG5cdFx0Li4uZCxcblx0XHRjaGlsZHJlbjogZS5tYXAoKGUpID0+IHtcblx0XHRcdGxldCBuID0gZS5pY29uLCBkID0gISFlLmxhYmVsLCBmID0gZS5pZCA9PT0gdCB8fCBlLnByZXNzZWQgPT09ICEwLCBwID0gW1wibmFicy11aS10b29sYmFyX19jb250ZW50XCIsIGNbbChlLmxhYmVsUG9zaXRpb24pXV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBtID0gW1xuXHRcdFx0XHRcIm5hYnMtdWktdG9vbGJhcl9fYnV0dG9uXCIsXG5cdFx0XHRcdGYgPyBcIm5hYnMtdWktdG9vbGJhcl9fYnV0dG9uLS1hY3RpdmVcIiA6IFwiXCIsXG5cdFx0XHRcdGQgPyBcIlwiIDogXCJuYWJzLXVpLXRvb2xiYXJfX2J1dHRvbi0taWNvbi1vbmx5XCIsXG5cdFx0XHRcdHJcblx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBoID0gW1wibmFicy11aS10b29sYmFyX19pY29uXCIsIGldLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktdG9vbGJhcl9fbGFiZWxcIiwgYV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBfID0gdHlwZW9mIGUubGFiZWwgPT0gXCJzdHJpbmdcIiA/IGUubGFiZWwgOiBlLnRpdGxlO1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBvKFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0Y2xhc3NOYW1lOiBtLFxuXHRcdFx0XHRkaXNhYmxlZDogZS5kaXNhYmxlZCxcblx0XHRcdFx0dGl0bGU6IGUudGl0bGUsXG5cdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBfLFxuXHRcdFx0XHRcImFyaWEtcHJlc3NlZFwiOiB0eXBlb2YgZS5wcmVzc2VkID09IFwiYm9vbGVhblwiID8gZS5wcmVzc2VkIDogdm9pZCAwLFxuXHRcdFx0XHRvbkNsaWNrOiAodCkgPT4ge1xuXHRcdFx0XHRcdHU/Lih7XG5cdFx0XHRcdFx0XHRpdGVtSWQ6IGUuaWQsXG5cdFx0XHRcdFx0XHRpdGVtOiBlLFxuXHRcdFx0XHRcdFx0ZXZlbnQ6IHRcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fSxcblx0XHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBzKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBwLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbbiA/IC8qIEBfX1BVUkVfXyAqLyBvKG4sIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogaCxcblx0XHRcdFx0XHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XHRcdFx0XHRmb2N1c2FibGU6IFwiZmFsc2VcIlxuXHRcdFx0XHRcdH0pIDogbnVsbCwgZS5sYWJlbCA/IC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IGcsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogZS5sYWJlbFxuXHRcdFx0XHRcdH0pIDogbnVsbF1cblx0XHRcdFx0fSlcblx0XHRcdH0sIGUuaWQpO1xuXHRcdH0pXG5cdH0pO1xufSk7XG51LmRpc3BsYXlOYW1lID0gXCJUb29sYmFyXCI7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGhlcm9pY29ucytyZWFjdEAyLjIuMF9yZWFjdEAxOS4yLjcvbm9kZV9tb2R1bGVzL0BoZXJvaWNvbnMvcmVhY3QvMjQvb3V0bGluZS9lc20vQ2hhdEJ1YmJsZUxlZnRFbGxpcHNpc0ljb24uanNcbmZ1bmN0aW9uIGQoeyB0aXRsZTogdCwgdGl0bGVJZDogbiwgLi4uciB9LCBpKSB7XG5cdHJldHVybiAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInN2Z1wiLCBPYmplY3QuYXNzaWduKHtcblx0XHR4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuXHRcdGZpbGw6IFwibm9uZVwiLFxuXHRcdHZpZXdCb3g6IFwiMCAwIDI0IDI0XCIsXG5cdFx0c3Ryb2tlV2lkdGg6IDEuNSxcblx0XHRzdHJva2U6IFwiY3VycmVudENvbG9yXCIsXG5cdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcImRhdGEtc2xvdFwiOiBcImljb25cIixcblx0XHRyZWY6IGksXG5cdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogblxuXHR9LCByKSwgdCA/IC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwidGl0bGVcIiwgeyBpZDogbiB9LCB0KSA6IG51bGwsIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7XG5cdFx0c3Ryb2tlTGluZWNhcDogXCJyb3VuZFwiLFxuXHRcdHN0cm9rZUxpbmVqb2luOiBcInJvdW5kXCIsXG5cdFx0ZDogXCJNOC42MjUgOS43NWEuMzc1LjM3NSAwIDEgMS0uNzUgMCAuMzc1LjM3NSAwIDAgMSAuNzUgMFptMCAwSDguMjVtNC4xMjUgMGEuMzc1LjM3NSAwIDEgMS0uNzUgMCAuMzc1LjM3NSAwIDAgMSAuNzUgMFptMCAwSDEybTQuMTI1IDBhLjM3NS4zNzUgMCAxIDEtLjc1IDAgLjM3NS4zNzUgMCAwIDEgLjc1IDBabTAgMGgtLjM3NW0tMTMuNSAzLjAxYzAgMS42IDEuMTIzIDIuOTk0IDIuNzA3IDMuMjI3IDEuMDg3LjE2IDIuMTg1LjI4MyAzLjI5My4zNjlWMjFsNC4xODQtNC4xODNhMS4xNCAxLjE0IDAgMCAxIC43NzgtLjMzMiA0OC4yOTQgNDguMjk0IDAgMCAwIDUuODMtLjQ5OGMxLjU4NS0uMjMzIDIuNzA4LTEuNjI2IDIuNzA4LTMuMjI4VjYuNzQxYzAtMS42MDItMS4xMjMtMi45OTUtMi43MDctMy4yMjhBNDguMzk0IDQ4LjM5NCAwIDAgMCAxMiAzYy0yLjM5MiAwLTQuNzQ0LjE3NS03LjA0My41MTNDMy4zNzMgMy43NDYgMi4yNSA1LjE0IDIuMjUgNi43NDF2Ni4wMThaXCJcblx0fSkpO1xufVxudmFyIGYgPSAvKiNfX1BVUkVfXyovIGUuZm9yd2FyZFJlZihkKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AaGVyb2ljb25zK3JlYWN0QDIuMi4wX3JlYWN0QDE5LjIuNy9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC8yNC9vdXRsaW5lL2VzbS9Db2RlQnJhY2tldEljb24uanNcbmZ1bmN0aW9uIHAoeyB0aXRsZTogdCwgdGl0bGVJZDogbiwgLi4uciB9LCBpKSB7XG5cdHJldHVybiAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInN2Z1wiLCBPYmplY3QuYXNzaWduKHtcblx0XHR4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuXHRcdGZpbGw6IFwibm9uZVwiLFxuXHRcdHZpZXdCb3g6IFwiMCAwIDI0IDI0XCIsXG5cdFx0c3Ryb2tlV2lkdGg6IDEuNSxcblx0XHRzdHJva2U6IFwiY3VycmVudENvbG9yXCIsXG5cdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcImRhdGEtc2xvdFwiOiBcImljb25cIixcblx0XHRyZWY6IGksXG5cdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogblxuXHR9LCByKSwgdCA/IC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwidGl0bGVcIiwgeyBpZDogbiB9LCB0KSA6IG51bGwsIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7XG5cdFx0c3Ryb2tlTGluZWNhcDogXCJyb3VuZFwiLFxuXHRcdHN0cm9rZUxpbmVqb2luOiBcInJvdW5kXCIsXG5cdFx0ZDogXCJNMTcuMjUgNi43NSAyMi41IDEybC01LjI1IDUuMjVtLTEwLjUgMEwxLjUgMTJsNS4yNS01LjI1bTcuNS0zLTQuNSAxNi41XCJcblx0fSkpO1xufVxudmFyIG0gPSAvKiNfX1BVUkVfXyovIGUuZm9yd2FyZFJlZihwKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AaGVyb2ljb25zK3JlYWN0QDIuMi4wX3JlYWN0QDE5LjIuNy9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC8yNC9vdXRsaW5lL2VzbS9Eb2N1bWVudFRleHRJY29uLmpzXG5mdW5jdGlvbiBoKHsgdGl0bGU6IHQsIHRpdGxlSWQ6IG4sIC4uLnIgfSwgaSkge1xuXHRyZXR1cm4gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgT2JqZWN0LmFzc2lnbih7XG5cdFx0eG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcblx0XHRmaWxsOiBcIm5vbmVcIixcblx0XHR2aWV3Qm94OiBcIjAgMCAyNCAyNFwiLFxuXHRcdHN0cm9rZVdpZHRoOiAxLjUsXG5cdFx0c3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuXHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XCJkYXRhLXNsb3RcIjogXCJpY29uXCIsXG5cdFx0cmVmOiBpLFxuXHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IG5cblx0fSwgciksIHQgPyAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIHsgaWQ6IG4gfSwgdCkgOiBudWxsLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwiTTE5LjUgMTQuMjV2LTIuNjI1YTMuMzc1IDMuMzc1IDAgMCAwLTMuMzc1LTMuMzc1aC0xLjVBMS4xMjUgMS4xMjUgMCAwIDEgMTMuNSA3LjEyNXYtMS41YTMuMzc1IDMuMzc1IDAgMCAwLTMuMzc1LTMuMzc1SDguMjVtMCAxMi43NWg3LjVtLTcuNSAzSDEyTTEwLjUgMi4yNUg1LjYyNWMtLjYyMSAwLTEuMTI1LjUwNC0xLjEyNSAxLjEyNXYxNy4yNWMwIC42MjEuNTA0IDEuMTI1IDEuMTI1IDEuMTI1aDEyLjc1Yy42MjEgMCAxLjEyNS0uNTA0IDEuMTI1LTEuMTI1VjExLjI1YTkgOSAwIDAgMC05LTlaXCJcblx0fSkpO1xufVxudmFyIGcgPSAvKiNfX1BVUkVfXyovIGUuZm9yd2FyZFJlZihoKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AaGVyb2ljb25zK3JlYWN0QDIuMi4wX3JlYWN0QDE5LjIuNy9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC8yNC9vdXRsaW5lL2VzbS9FeWVJY29uLmpzXG5mdW5jdGlvbiBfKHsgdGl0bGU6IHQsIHRpdGxlSWQ6IG4sIC4uLnIgfSwgaSkge1xuXHRyZXR1cm4gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgT2JqZWN0LmFzc2lnbih7XG5cdFx0eG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcblx0XHRmaWxsOiBcIm5vbmVcIixcblx0XHR2aWV3Qm94OiBcIjAgMCAyNCAyNFwiLFxuXHRcdHN0cm9rZVdpZHRoOiAxLjUsXG5cdFx0c3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuXHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XCJkYXRhLXNsb3RcIjogXCJpY29uXCIsXG5cdFx0cmVmOiBpLFxuXHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IG5cblx0fSwgciksIHQgPyAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIHsgaWQ6IG4gfSwgdCkgOiBudWxsLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwiTTIuMDM2IDEyLjMyMmExLjAxMiAxLjAxMiAwIDAgMSAwLS42MzlDMy40MjMgNy41MSA3LjM2IDQuNSAxMiA0LjVjNC42MzggMCA4LjU3MyAzLjAwNyA5Ljk2MyA3LjE3OC4wNy4yMDcuMDcuNDMxIDAgLjYzOUMyMC41NzcgMTYuNDkgMTYuNjQgMTkuNSAxMiAxOS41Yy00LjYzOCAwLTguNTczLTMuMDA3LTkuOTYzLTcuMTc4WlwiXG5cdH0pLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwiTTE1IDEyYTMgMyAwIDEgMS02IDAgMyAzIDAgMCAxIDYgMFpcIlxuXHR9KSk7XG59XG52YXIgdiA9IC8qI19fUFVSRV9fKi8gZS5mb3J3YXJkUmVmKF8pO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BoZXJvaWNvbnMrcmVhY3RAMi4yLjBfcmVhY3RAMTkuMi43L25vZGVfbW9kdWxlcy9AaGVyb2ljb25zL3JlYWN0LzI0L291dGxpbmUvZXNtL0hhc2h0YWdJY29uLmpzXG5mdW5jdGlvbiB5KHsgdGl0bGU6IHQsIHRpdGxlSWQ6IG4sIC4uLnIgfSwgaSkge1xuXHRyZXR1cm4gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgT2JqZWN0LmFzc2lnbih7XG5cdFx0eG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcblx0XHRmaWxsOiBcIm5vbmVcIixcblx0XHR2aWV3Qm94OiBcIjAgMCAyNCAyNFwiLFxuXHRcdHN0cm9rZVdpZHRoOiAxLjUsXG5cdFx0c3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuXHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XCJkYXRhLXNsb3RcIjogXCJpY29uXCIsXG5cdFx0cmVmOiBpLFxuXHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IG5cblx0fSwgciksIHQgPyAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIHsgaWQ6IG4gfSwgdCkgOiBudWxsLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwiTTUuMjUgOC4yNWgxNW0tMTYuNSA3LjVoMTVtLTEuOC0xMy41LTMuOSAxOS41bS0yLjEtMTkuNS0zLjkgMTkuNVwiXG5cdH0pKTtcbn1cbnZhciBiID0gLyojX19QVVJFX18qLyBlLmZvcndhcmRSZWYoeSk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGhlcm9pY29ucytyZWFjdEAyLjIuMF9yZWFjdEAxOS4yLjcvbm9kZV9tb2R1bGVzL0BoZXJvaWNvbnMvcmVhY3QvMjQvb3V0bGluZS9lc20vTGlua0ljb24uanNcbmZ1bmN0aW9uIHgoeyB0aXRsZTogdCwgdGl0bGVJZDogbiwgLi4uciB9LCBpKSB7XG5cdHJldHVybiAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInN2Z1wiLCBPYmplY3QuYXNzaWduKHtcblx0XHR4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuXHRcdGZpbGw6IFwibm9uZVwiLFxuXHRcdHZpZXdCb3g6IFwiMCAwIDI0IDI0XCIsXG5cdFx0c3Ryb2tlV2lkdGg6IDEuNSxcblx0XHRzdHJva2U6IFwiY3VycmVudENvbG9yXCIsXG5cdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcImRhdGEtc2xvdFwiOiBcImljb25cIixcblx0XHRyZWY6IGksXG5cdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogblxuXHR9LCByKSwgdCA/IC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwidGl0bGVcIiwgeyBpZDogbiB9LCB0KSA6IG51bGwsIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7XG5cdFx0c3Ryb2tlTGluZWNhcDogXCJyb3VuZFwiLFxuXHRcdHN0cm9rZUxpbmVqb2luOiBcInJvdW5kXCIsXG5cdFx0ZDogXCJNMTMuMTkgOC42ODhhNC41IDQuNSAwIDAgMSAxLjI0MiA3LjI0NGwtNC41IDQuNWE0LjUgNC41IDAgMCAxLTYuMzY0LTYuMzY0bDEuNzU3LTEuNzU3bTEzLjM1LS42MjIgMS43NTctMS43NTdhNC41IDQuNSAwIDAgMC02LjM2NC02LjM2NGwtNC41IDQuNWE0LjUgNC41IDAgMCAwIDEuMjQyIDcuMjQ0XCJcblx0fSkpO1xufVxudmFyIFMgPSAvKiNfX1BVUkVfXyovIGUuZm9yd2FyZFJlZih4KTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AaGVyb2ljb25zK3JlYWN0QDIuMi4wX3JlYWN0QDE5LjIuNy9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC8yNC9vdXRsaW5lL2VzbS9MaXN0QnVsbGV0SWNvbi5qc1xuZnVuY3Rpb24gQyh7IHRpdGxlOiB0LCB0aXRsZUlkOiBuLCAuLi5yIH0sIGkpIHtcblx0cmV0dXJuIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwic3ZnXCIsIE9iamVjdC5hc3NpZ24oe1xuXHRcdHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG5cdFx0ZmlsbDogXCJub25lXCIsXG5cdFx0dmlld0JveDogXCIwIDAgMjQgMjRcIixcblx0XHRzdHJva2VXaWR0aDogMS41LFxuXHRcdHN0cm9rZTogXCJjdXJyZW50Q29sb3JcIixcblx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFwiZGF0YS1zbG90XCI6IFwiaWNvblwiLFxuXHRcdHJlZjogaSxcblx0XHRcImFyaWEtbGFiZWxsZWRieVwiOiBuXG5cdH0sIHIpLCB0ID8gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJ0aXRsZVwiLCB7IGlkOiBuIH0sIHQpIDogbnVsbCwgLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHtcblx0XHRzdHJva2VMaW5lY2FwOiBcInJvdW5kXCIsXG5cdFx0c3Ryb2tlTGluZWpvaW46IFwicm91bmRcIixcblx0XHRkOiBcIk04LjI1IDYuNzVoMTJNOC4yNSAxMmgxMm0tMTIgNS4yNWgxMk0zLjc1IDYuNzVoLjAwN3YuMDA4SDMuNzVWNi43NVptLjM3NSAwYS4zNzUuMzc1IDAgMSAxLS43NSAwIC4zNzUuMzc1IDAgMCAxIC43NSAwWk0zLjc1IDEyaC4wMDd2LjAwOEgzLjc1VjEyWm0uMzc1IDBhLjM3NS4zNzUgMCAxIDEtLjc1IDAgLjM3NS4zNzUgMCAwIDEgLjc1IDBabS0uMzc1IDUuMjVoLjAwN3YuMDA4SDMuNzV2LS4wMDhabS4zNzUgMGEuMzc1LjM3NSAwIDEgMS0uNzUgMCAuMzc1LjM3NSAwIDAgMSAuNzUgMFpcIlxuXHR9KSk7XG59XG52YXIgdyA9IC8qI19fUFVSRV9fKi8gZS5mb3J3YXJkUmVmKEMpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BoZXJvaWNvbnMrcmVhY3RAMi4yLjBfcmVhY3RAMTkuMi43L25vZGVfbW9kdWxlcy9AaGVyb2ljb25zL3JlYWN0LzI0L291dGxpbmUvZXNtL1BlbmNpbFNxdWFyZUljb24uanNcbmZ1bmN0aW9uIFQoeyB0aXRsZTogdCwgdGl0bGVJZDogbiwgLi4uciB9LCBpKSB7XG5cdHJldHVybiAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInN2Z1wiLCBPYmplY3QuYXNzaWduKHtcblx0XHR4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuXHRcdGZpbGw6IFwibm9uZVwiLFxuXHRcdHZpZXdCb3g6IFwiMCAwIDI0IDI0XCIsXG5cdFx0c3Ryb2tlV2lkdGg6IDEuNSxcblx0XHRzdHJva2U6IFwiY3VycmVudENvbG9yXCIsXG5cdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcImRhdGEtc2xvdFwiOiBcImljb25cIixcblx0XHRyZWY6IGksXG5cdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogblxuXHR9LCByKSwgdCA/IC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwidGl0bGVcIiwgeyBpZDogbiB9LCB0KSA6IG51bGwsIC8qI19fUFVSRV9fKi8gZS5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7XG5cdFx0c3Ryb2tlTGluZWNhcDogXCJyb3VuZFwiLFxuXHRcdHN0cm9rZUxpbmVqb2luOiBcInJvdW5kXCIsXG5cdFx0ZDogXCJtMTYuODYyIDQuNDg3IDEuNjg3LTEuNjg4YTEuODc1IDEuODc1IDAgMSAxIDIuNjUyIDIuNjUyTDEwLjU4MiAxNi4wN2E0LjUgNC41IDAgMCAxLTEuODk3IDEuMTNMNiAxOGwuOC0yLjY4NWE0LjUgNC41IDAgMCAxIDEuMTMtMS44OTdsOC45MzItOC45MzFabTAgMEwxOS41IDcuMTI1TTE4IDE0djQuNzVBMi4yNSAyLjI1IDAgMCAxIDE1Ljc1IDIxSDUuMjVBMi4yNSAyLjI1IDAgMCAxIDMgMTguNzVWOC4yNUEyLjI1IDIuMjUgMCAwIDEgNS4yNSA2SDEwXCJcblx0fSkpO1xufVxudmFyIEUgPSAvKiNfX1BVUkVfXyovIGUuZm9yd2FyZFJlZihUKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AaGVyb2ljb25zK3JlYWN0QDIuMi4wX3JlYWN0QDE5LjIuNy9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC8yNC9vdXRsaW5lL2VzbS9RdWV1ZUxpc3RJY29uLmpzXG5mdW5jdGlvbiBEKHsgdGl0bGU6IHQsIHRpdGxlSWQ6IG4sIC4uLnIgfSwgaSkge1xuXHRyZXR1cm4gLyojX19QVVJFX18qLyBlLmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgT2JqZWN0LmFzc2lnbih7XG5cdFx0eG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcblx0XHRmaWxsOiBcIm5vbmVcIixcblx0XHR2aWV3Qm94OiBcIjAgMCAyNCAyNFwiLFxuXHRcdHN0cm9rZVdpZHRoOiAxLjUsXG5cdFx0c3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuXHRcdFwiYXJpYS1oaWRkZW5cIjogXCJ0cnVlXCIsXG5cdFx0XCJkYXRhLXNsb3RcIjogXCJpY29uXCIsXG5cdFx0cmVmOiBpLFxuXHRcdFwiYXJpYS1sYWJlbGxlZGJ5XCI6IG5cblx0fSwgciksIHQgPyAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIHsgaWQ6IG4gfSwgdCkgOiBudWxsLCAvKiNfX1BVUkVfXyovIGUuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuXHRcdHN0cm9rZUxpbmVjYXA6IFwicm91bmRcIixcblx0XHRzdHJva2VMaW5lam9pbjogXCJyb3VuZFwiLFxuXHRcdGQ6IFwiTTMuNzUgMTJoMTYuNW0tMTYuNSAzLjc1aDE2LjVNMy43NSAxOS41aDE2LjVNNS42MjUgNC41aDEyLjc1YTEuODc1IDEuODc1IDAgMCAxIDAgMy43NUg1LjYyNWExLjg3NSAxLjg3NSAwIDAgMSAwLTMuNzVaXCJcblx0fSkpO1xufVxudmFyIE8gPSAvKiNfX1BVUkVfXyovIGUuZm9yd2FyZFJlZihEKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tYXJrZG93bi51dGlscy50c1xuZnVuY3Rpb24gayhlKSB7XG5cdHJldHVybiBlLnNwbGl0KFwiJlwiKS5qb2luKFwiJmFtcDtcIikuc3BsaXQoXCI8XCIpLmpvaW4oXCImbHQ7XCIpLnNwbGl0KFwiPlwiKS5qb2luKFwiJmd0O1wiKS5zcGxpdChcIlxcXCJcIikuam9pbihcIiZxdW90O1wiKS5zcGxpdChcIidcIikuam9pbihcIiYjMzk7XCIpO1xufVxuZnVuY3Rpb24gQShlKSB7XG5cdGxldCB0ID0gZS50cmltKCk7XG5cdHJldHVybiAvXihodHRwcz86fG1haWx0bzp8XFwvfCMpL2kudGVzdCh0KSA/IGsodCkgOiBcIiNcIjtcbn1cbmZ1bmN0aW9uIGooZSkge1xuXHRsZXQgdCA9IGsoZSk7XG5cdHJldHVybiB0ID0gdC5yZXBsYWNlKC9cXFsoW15cXF1dKylcXF1cXCgoW14pXSspXFwpL2csIChlLCB0LCBuKSA9PiBgPGEgaHJlZj1cIiR7QShuKX1cIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub3JlZmVycmVyIG5vb3BlbmVyXCI+JHt0fTwvYT5gKSwgdCA9IHQucmVwbGFjZSgvXFwqXFwqKFteKl0rKVxcKlxcKi9nLCBcIjxzdHJvbmc+JDE8L3N0cm9uZz5cIiksIHQgPSB0LnJlcGxhY2UoL19fKFteX10rKV9fL2csIFwiPHN0cm9uZz4kMTwvc3Ryb25nPlwiKSwgdCA9IHQucmVwbGFjZSgvXFwqKFteKl0rKVxcKi9nLCBcIjxlbT4kMTwvZW0+XCIpLCB0ID0gdC5yZXBsYWNlKC9fKFteX10rKV8vZywgXCI8ZW0+JDE8L2VtPlwiKSwgdCA9IHQucmVwbGFjZSgvfn4oW15+XSspfn4vZywgXCI8ZGVsPiQxPC9kZWw+XCIpLCB0ID0gdC5yZXBsYWNlKC9gKFteYF0rKWAvZywgXCI8Y29kZT4kMTwvY29kZT5cIiksIHQ7XG59XG5mdW5jdGlvbiBNKGUpIHtcblx0bGV0IHQgPSBlLnNwbGl0KFwiXFxyXFxuXCIpLmpvaW4oXCJcXG5cIikuc3BsaXQoXCJcXG5cIiksIG4gPSBbXSwgciA9IDA7XG5cdGZvciAoOyByIDwgdC5sZW5ndGg7KSB7XG5cdFx0bGV0IGUgPSB0W3JdO1xuXHRcdGlmICghZS50cmltKCkpIHtcblx0XHRcdHIgKz0gMTtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRpZiAoZS5zdGFydHNXaXRoKFwiYGBgXCIpKSB7XG5cdFx0XHRsZXQgZSA9IFtdO1xuXHRcdFx0Zm9yIChyICs9IDE7IHIgPCB0Lmxlbmd0aCAmJiAhdFtyXS5zdGFydHNXaXRoKFwiYGBgXCIpOykgZS5wdXNoKHRbcl0pLCByICs9IDE7XG5cdFx0XHRyIDwgdC5sZW5ndGggJiYgKHIgKz0gMSksIG4ucHVzaChgPHByZT48Y29kZT4ke2soZS5qb2luKFwiXFxuXCIpKX08L2NvZGU+PC9wcmU+YCk7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0bGV0IGkgPSBlLm1hdGNoKC9eKCN7MSw2fSlcXHMrKC4qKSQvKTtcblx0XHRpZiAoaSkge1xuXHRcdFx0bGV0IGUgPSBpWzFdLmxlbmd0aDtcblx0XHRcdG4ucHVzaChgPGgke2V9PiR7aihpWzJdKX08L2gke2V9PmApLCByICs9IDE7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0aWYgKGUuc3RhcnRzV2l0aChcIj5cIikpIHtcblx0XHRcdGxldCBlID0gW107XG5cdFx0XHRmb3IgKDsgciA8IHQubGVuZ3RoICYmIHRbcl0uc3RhcnRzV2l0aChcIj5cIik7KSBlLnB1c2godFtyXS5yZXBsYWNlKC9ePiA/LywgXCJcIikpLCByICs9IDE7XG5cdFx0XHRuLnB1c2goYDxibG9ja3F1b3RlPiR7ZS5tYXAoaikuam9pbihcIjxiciAvPlwiKX08L2Jsb2NrcXVvdGU+YCk7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0aWYgKGUubWF0Y2goL15bLSorXVxccysoLiopJC8pKSB7XG5cdFx0XHRsZXQgZSA9IFtdO1xuXHRcdFx0Zm9yICg7IHIgPCB0Lmxlbmd0aDspIHtcblx0XHRcdFx0bGV0IG4gPSB0W3JdLm1hdGNoKC9eWy0qK11cXHMrKC4qKSQvKTtcblx0XHRcdFx0aWYgKCFuKSBicmVhaztcblx0XHRcdFx0ZS5wdXNoKGA8bGk+JHtqKG5bMV0pfTwvbGk+YCksIHIgKz0gMTtcblx0XHRcdH1cblx0XHRcdG4ucHVzaChgPHVsPiR7ZS5qb2luKFwiXCIpfTwvdWw+YCk7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0aWYgKGUubWF0Y2goL15cXGQrXFwuXFxzKyguKikkLykpIHtcblx0XHRcdGxldCBlID0gW107XG5cdFx0XHRmb3IgKDsgciA8IHQubGVuZ3RoOykge1xuXHRcdFx0XHRsZXQgbiA9IHRbcl0ubWF0Y2goL15cXGQrXFwuXFxzKyguKikkLyk7XG5cdFx0XHRcdGlmICghbikgYnJlYWs7XG5cdFx0XHRcdGUucHVzaChgPGxpPiR7aihuWzFdKX08L2xpPmApLCByICs9IDE7XG5cdFx0XHR9XG5cdFx0XHRuLnB1c2goYDxvbD4ke2Uuam9pbihcIlwiKX08L29sPmApO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGxldCBhID0gW107XG5cdFx0Zm9yICg7IHIgPCB0Lmxlbmd0aCAmJiB0W3JdLnRyaW0oKTspIHtcblx0XHRcdGxldCBlID0gdFtyXSwgbiA9IGUuc3RhcnRzV2l0aChcImBgYFwiKSB8fCAvXigjezEsNn0pXFxzKy8udGVzdChlKSB8fCBlLnN0YXJ0c1dpdGgoXCI+XCIpIHx8IC9eWy0qK11cXHMrLy50ZXN0KGUpIHx8IC9eXFxkK1xcLlxccysvLnRlc3QoZSk7XG5cdFx0XHRpZiAoYS5sZW5ndGggPiAwICYmIG4pIGJyZWFrO1xuXHRcdFx0YS5wdXNoKGUpLCByICs9IDE7XG5cdFx0fVxuXHRcdG4ucHVzaChgPHA+JHtqKGEuam9pbihcIiBcIikpfTwvcD5gKTtcblx0fVxuXHRyZXR1cm4gbi5qb2luKFwiXCIpO1xufVxuZnVuY3Rpb24gTihlLCB0LCBuKSB7XG5cdGxldCByID0gZS5sYXN0SW5kZXhPZihcIlxcblwiLCBNYXRoLm1heCgwLCB0IC0gMSkpICsgMSwgaSA9IGUuaW5kZXhPZihcIlxcblwiLCBuKSwgYSA9IGkgPT09IC0xID8gZS5sZW5ndGggOiBpO1xuXHRyZXR1cm4ge1xuXHRcdGJlZm9yZTogZS5zbGljZSgwLCByKSxcblx0XHRzZWxlY3RlZDogZS5zbGljZShyLCBhKSxcblx0XHRhZnRlcjogZS5zbGljZShhKSxcblx0XHRsaW5lU3RhcnQ6IHIsXG5cdFx0bGluZUVuZDogYVxuXHR9O1xufVxuZnVuY3Rpb24gUChlLCB0LCBuKSB7XG5cdGxldCByID0gZS52YWx1ZSwgaSA9IGUuc2VsZWN0aW9uU3RhcnQgPz8gMCwgYSA9IGUuc2VsZWN0aW9uRW5kID8/IGksIG8gPSBpICE9PSBhLCB7IGJlZm9yZTogcywgc2VsZWN0ZWQ6IGMsIGFmdGVyOiBsLCBsaW5lU3RhcnQ6IHUgfSA9IE4ociwgaSwgYSk7XG5cdGlmICghbykge1xuXHRcdGxldCBlID0gYCR7dH0ke259YDtcblx0XHRyZXR1cm4ge1xuXHRcdFx0bmV4dFZhbHVlOiBgJHtyLnNsaWNlKDAsIGkpfSR7ZX0ke3Iuc2xpY2UoYSl9YCxcblx0XHRcdG5leHRTdGFydDogaSArIHQubGVuZ3RoLFxuXHRcdFx0bmV4dEVuZDogaSArIGUubGVuZ3RoXG5cdFx0fTtcblx0fVxuXHRsZXQgZCA9IGMuc3BsaXQoXCJcXG5cIikubWFwKChlKSA9PiBlLnRyaW0oKSA/IGAke3R9JHtlfWAgOiB0LnRyaW1FbmQoKSkuam9pbihcIlxcblwiKTtcblx0cmV0dXJuIHtcblx0XHRuZXh0VmFsdWU6IGAke3N9JHtkfSR7bH1gLFxuXHRcdG5leHRTdGFydDogdSxcblx0XHRuZXh0RW5kOiB1ICsgZC5sZW5ndGhcblx0fTtcbn1cbmZ1bmN0aW9uIEYoZSwgdCwgbiwgcikge1xuXHRsZXQgaSA9IGUudmFsdWUsIGEgPSBlLnNlbGVjdGlvblN0YXJ0ID8/IDAsIG8gPSBlLnNlbGVjdGlvbkVuZCA/PyBhLCBzID0gYSA9PT0gbyA/IHIgOiBpLnNsaWNlKGEsIG8pLCBjID0gYCR7dH0ke3N9JHtufWA7XG5cdHJldHVybiB7XG5cdFx0bmV4dFZhbHVlOiBgJHtpLnNsaWNlKDAsIGEpfSR7Y30ke2kuc2xpY2Uobyl9YCxcblx0XHRuZXh0U3RhcnQ6IGEgKyB0Lmxlbmd0aCxcblx0XHRuZXh0RW5kOiBhICsgdC5sZW5ndGggKyBzLmxlbmd0aFxuXHR9O1xufVxuZnVuY3Rpb24gSShlKSB7XG5cdGxldCB0ID0gZS52YWx1ZSwgbiA9IGUuc2VsZWN0aW9uU3RhcnQgPz8gMCwgciA9IGUuc2VsZWN0aW9uRW5kID8/IG4sIGkgPSBuID09PSByID8gXCJsaW5rIHRleHRcIiA6IHQuc2xpY2UobiwgciksIGEgPSBgWyR7aX1dKGh0dHBzOi8vZXhhbXBsZS5jb20pYDtcblx0cmV0dXJuIHtcblx0XHRuZXh0VmFsdWU6IGAke3Quc2xpY2UoMCwgbil9JHthfSR7dC5zbGljZShyKX1gLFxuXHRcdG5leHRTdGFydDogbiArIGkubGVuZ3RoICsgMyxcblx0XHRuZXh0RW5kOiBuICsgaS5sZW5ndGggKyAzICsgMTlcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9NYXJrZG93bi50c3hcbmZ1bmN0aW9uIEwoeyBsYWJlbDogZSA9IFwiTWFya2Rvd25cIiwgaGVscGVyVGV4dDogdCA9IFwiVXNlIHRoZSB0b29sYmFyIHRvIGZvcm1hdCBtYXJrZG93biBhbmQgdG9nZ2xlIGJldHdlZW4gZWRpdCBhbmQgcHJldmlldyBtb2Rlcy5cIiwgcGxhY2Vob2xkZXI6IGMgPSBcIldyaXRlIG1hcmtkb3duIGhlcmUuLi5cIiwgdmFsdWU6IGwgPSBcIlwiLCBkaXNhYmxlZDogZCA9ICExLCBjbGFzc05hbWU6IHAgPSBcIlwiLCBlZGl0b3JDbGFzc05hbWU6IGggPSBcIlwiLCB0b29sYmFyQ2xhc3NOYW1lOiBfID0gXCJcIiwgcHJldmlld0NsYXNzTmFtZTogeSA9IFwiXCIsIGh0bWxDbGFzc05hbWU6IHggPSBcIlwiLCBpZDogQywgcm93czogVCA9IDEyLCBvbkNoYW5nZTogRCwgb25Ub29sYmFyQWN0aW9uOiBrLCAuLi5BIH0pIHtcblx0bGV0IGogPSByKCksIE4gPSBDID8/IGBuYWJzLXVpLW1hcmtkb3duLSR7ai5yZXBsYWNlKC86L2csIFwiXCIpfWAsIEwgPSBpKG51bGwpLCBbUiwgel0gPSBhKGwpLCBbQiwgVl0gPSBhKFwiZWRpdFwiKTtcblx0bigoKSA9PiB7XG5cdFx0eihsKTtcblx0fSwgW2xdKTtcblx0bGV0IEggPSBNKFIpLCBVID0gW1xuXHRcdFwibmFicy11aS1tYXJrZG93blwiLFxuXHRcdFwibmFicy11aS1tYXJrZG93bi0tc2luZ2xlLXBhbmVsXCIsXG5cdFx0ZCA/IFwibmFicy11aS1tYXJrZG93bi0tZGlzYWJsZWRcIiA6IFwiXCIsXG5cdFx0cFxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgVyA9IFtcIm5hYnMtdWktbWFya2Rvd25fX3Rvb2xiYXJcIiwgX10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBHID0gW1wibmFicy11aS1tYXJrZG93bl9fZWRpdG9yXCIsIGhdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgSyA9IFtcIm5hYnMtdWktbWFya2Rvd25fX3ByZXZpZXdcIiwgeV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBxID0gW1wibmFicy11aS1tYXJrZG93bl9faHRtbFwiLCB4XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEogPSBbXG5cdFx0e1xuXHRcdFx0aWQ6IFwibW9kZS10b2dnbGVcIixcblx0XHRcdGljb246IHYsXG5cdFx0XHR0aXRsZTogQiA9PT0gXCJlZGl0XCIgPyBcIlByZXZpZXdcIiA6IFwiRWRpdFwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJoZWFkaW5nXCIsXG5cdFx0XHRpY29uOiBiLFxuXHRcdFx0dGl0bGU6IFwiSGVhZGluZ1wiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJib2xkXCIsXG5cdFx0XHRpY29uOiBnLFxuXHRcdFx0dGl0bGU6IFwiQm9sZFwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJpdGFsaWNcIixcblx0XHRcdGljb246IEUsXG5cdFx0XHR0aXRsZTogXCJJdGFsaWNcIlxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0aWQ6IFwicXVvdGVcIixcblx0XHRcdGljb246IGYsXG5cdFx0XHR0aXRsZTogXCJRdW90ZVwiXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRpZDogXCJidWxsZXQtbGlzdFwiLFxuXHRcdFx0aWNvbjogdyxcblx0XHRcdHRpdGxlOiBcIkJ1bGxldCBsaXN0XCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcIm51bWJlcmVkLWxpc3RcIixcblx0XHRcdGljb246IE8sXG5cdFx0XHR0aXRsZTogXCJOdW1iZXJlZCBsaXN0XCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcImNvZGVcIixcblx0XHRcdGljb246IG0sXG5cdFx0XHR0aXRsZTogXCJDb2RlXCJcblx0XHR9LFxuXHRcdHtcblx0XHRcdGlkOiBcImxpbmtcIixcblx0XHRcdGljb246IFMsXG5cdFx0XHR0aXRsZTogXCJMaW5rXCJcblx0XHR9XG5cdF0sIFkgPSAoZSwgdCkgPT4ge1xuXHRcdGlmIChkKSByZXR1cm47XG5cdFx0bGV0IG4gPSBMLmN1cnJlbnQ7XG5cdFx0aWYgKCFuKSByZXR1cm47XG5cdFx0bGV0IHIgPSB0KG4pO1xuXHRcdHIgJiYgKG4udmFsdWUgPSByLm5leHRWYWx1ZSwgbi5zZXRTZWxlY3Rpb25SYW5nZShyLm5leHRTdGFydCwgci5uZXh0RW5kKSwgeihyLm5leHRWYWx1ZSksIEQ/LihyLm5leHRWYWx1ZSksIGs/LihlKSk7XG5cdH0sIFggPSAoZSkgPT4ge1xuXHRcdGxldCB0ID0gZS5jdXJyZW50VGFyZ2V0LnZhbHVlO1xuXHRcdHoodCksIEQ/Lih0KTtcblx0fSwgWiA9IChlKSA9PiB7XG5cdFx0aWYgKGUgPT09IFwibW9kZS10b2dnbGVcIikge1xuXHRcdFx0bGV0IGUgPSBCID09PSBcImVkaXRcIiA/IFwicHJldmlld1wiIDogXCJlZGl0XCI7XG5cdFx0XHRWKGUpLCBrPy4oYG1vZGUtJHtlfWApO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRzd2l0Y2ggKGUpIHtcblx0XHRcdGNhc2UgXCJoZWFkaW5nXCI6XG5cdFx0XHRcdFkoXCJoZWFkaW5nXCIsIChlKSA9PiBQKGUsIFwiIyBcIiwgXCJIZWFkaW5nXCIpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIFwiYm9sZFwiOlxuXHRcdFx0XHRZKFwiYm9sZFwiLCAoZSkgPT4gRihlLCBcIioqXCIsIFwiKipcIiwgXCJib2xkIHRleHRcIikpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgXCJpdGFsaWNcIjpcblx0XHRcdFx0WShcIml0YWxpY1wiLCAoZSkgPT4gRihlLCBcIipcIiwgXCIqXCIsIFwiaXRhbGljIHRleHRcIikpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgXCJxdW90ZVwiOlxuXHRcdFx0XHRZKFwicXVvdGVcIiwgKGUpID0+IFAoZSwgXCI+IFwiLCBcIlF1b3RlXCIpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIFwiYnVsbGV0LWxpc3RcIjpcblx0XHRcdFx0WShcImJ1bGxldC1saXN0XCIsIChlKSA9PiBQKGUsIFwiLSBcIiwgXCJMaXN0IGl0ZW1cIikpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgXCJudW1iZXJlZC1saXN0XCI6XG5cdFx0XHRcdFkoXCJudW1iZXJlZC1saXN0XCIsIChlKSA9PiBQKGUsIFwiMS4gXCIsIFwiTGlzdCBpdGVtXCIpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIFwiY29kZVwiOlxuXHRcdFx0XHRZKFwiY29kZVwiLCAoZSkgPT4gRihlLCBcImBcIiwgXCJgXCIsIFwiY29kZVwiKSk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSBcImxpbmtcIjpcblx0XHRcdFx0WShcImxpbmtcIiwgSSk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0ZGVmYXVsdDogYnJlYWs7XG5cdFx0fVxuXHR9O1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdGNsYXNzTmFtZTogVSxcblx0XHQuLi5BLFxuXHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktbWFya2Rvd25fX2VkaXRvclBhbmVsXCIsXG5cdFx0XHRjaGlsZHJlbjogW1xuXHRcdFx0XHQvKiBAX19QVVJFX18gKi8gbyhcImxhYmVsXCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1tYXJrZG93bl9fbGFiZWxcIixcblx0XHRcdFx0XHRodG1sRm9yOiBOLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0XHRcdH0pLFxuXHRcdFx0XHR0ID8gLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLW1hcmtkb3duX19oZWxwZXJcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogdFxuXHRcdFx0XHR9KSA6IG51bGwsXG5cdFx0XHRcdC8qIEBfX1BVUkVfXyAqLyBvKHUsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFcsXG5cdFx0XHRcdFx0XCJhcmlhLWxhYmVsXCI6IFwiTWFya2Rvd24gZm9ybWF0dGluZyB0b29sYmFyXCIsXG5cdFx0XHRcdFx0aXRlbXM6IEoubWFwKChlKSA9PiB7XG5cdFx0XHRcdFx0XHRsZXQgdCA9IGUuaWQgPT09IFwibW9kZS10b2dnbGVcIjtcblx0XHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHRcdC4uLmUsXG5cdFx0XHRcdFx0XHRcdGxhYmVsOiB0ID8gQiA9PT0gXCJlZGl0XCIgPyBcIlByZXZpZXdcIiA6IFwiRWRpdFwiIDogdm9pZCAwLFxuXHRcdFx0XHRcdFx0XHRkaXNhYmxlZDogZCB8fCAhdCAmJiBCID09PSBcInByZXZpZXdcIixcblx0XHRcdFx0XHRcdFx0cHJlc3NlZDogdCA/IEIgPT09IFwicHJldmlld1wiIDogdm9pZCAwXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdG9uTW91c2VEb3duOiAoZSkgPT4ge1xuXHRcdFx0XHRcdFx0ZS50YXJnZXQ/LmNsb3Nlc3QoXCJidXR0b25cIikgJiYgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0b25JdGVtU2VsZWN0OiAoeyBpdGVtSWQ6IGUgfSkgPT4gWihlKVxuXHRcdFx0XHR9KSxcblx0XHRcdFx0QiA9PT0gXCJlZGl0XCIgPyAvKiBAX19QVVJFX18gKi8gbyhcInRleHRhcmVhXCIsIHtcblx0XHRcdFx0XHRpZDogTixcblx0XHRcdFx0XHRyZWY6IEwsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBHLFxuXHRcdFx0XHRcdHJvd3M6IFQsXG5cdFx0XHRcdFx0cGxhY2Vob2xkZXI6IGMsXG5cdFx0XHRcdFx0dmFsdWU6IFIsXG5cdFx0XHRcdFx0ZGlzYWJsZWQ6IGQsXG5cdFx0XHRcdFx0b25DaGFuZ2U6IFhcblx0XHRcdFx0fSkgOiBudWxsXG5cdFx0XHRdXG5cdFx0fSksIEIgPT09IFwicHJldmlld1wiID8gLyogQF9fUFVSRV9fICovIHMoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktbWFya2Rvd25fX3ByZXZpZXdQYW5lbFwiLFxuXHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLW1hcmtkb3duX19wcmV2aWV3TGFiZWxcIixcblx0XHRcdFx0Y2hpbGRyZW46IFwiUmVuZGVyZWQgcHJldmlld1wiXG5cdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIG8oXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IEssXG5cdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gbyhcImRpdlwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBxLFxuXHRcdFx0XHRcdGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOiB7IF9faHRtbDogSCB8fCBcIjxwPlByZXZpZXcgYXBwZWFycyBoZXJlLjwvcD5cIiB9XG5cdFx0XHRcdH0pXG5cdFx0XHR9KV1cblx0XHR9KSA6IG51bGxdXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBMIGFzIE1hcmtkb3duIH07XG4iLCJpbXBvcnQgeyBqc3ggYXMgZSB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9uYXZpZ2F0aW9uLnV0aWxzLnRzXG52YXIgdCA9IHtcblx0dmVydGljYWw6IFwibmFicy11aS1uYXZpZ2F0aW9uLS12ZXJ0aWNhbFwiLFxuXHRob3Jpem9udGFsOiBcIm5hYnMtdWktbmF2aWdhdGlvbi0taG9yaXpvbnRhbFwiXG59O1xuZnVuY3Rpb24gbihlKSB7XG5cdHJldHVybiBbXG5cdFx0XCJuYWJzLXVpLW5hdmlnYXRpb25fX2l0ZW1Db250ZW50XCIsXG5cdFx0ZSA9PT0gXCJjZW50ZXJcIiA/IFwibmFicy11aS1uYXZpZ2F0aW9uX19pdGVtQ29udGVudC0tY2VudGVyXCIgOiBcIlwiLFxuXHRcdGUgPT09IFwicmlnaHRcIiA/IFwibmFicy11aS1uYXZpZ2F0aW9uX19pdGVtQ29udGVudC0tcmlnaHRcIiA6IFwiXCJcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvTmF2aWdhdGlvbi50c3hcbmZ1bmN0aW9uIHIoeyBpdGVtOiB0LCBhY3RpdmVJdGVtSWQ6IHIsIHRleHRBbGlnbm1lbnQ6IGksIGl0ZW1DbGFzc05hbWU6IGEsIG9uSXRlbVNlbGVjdDogbyB9KSB7XG5cdGxldCBzID0gW1xuXHRcdFwibmFicy11aS1uYXZpZ2F0aW9uX19pdGVtXCIsXG5cdFx0dC5pZCA9PT0gciA/IFwibmFicy11aS1uYXZpZ2F0aW9uX19pdGVtLS1hY3RpdmVcIiA6IFwiXCIsXG5cdFx0dC5kaXNhYmxlZCA/IFwibmFicy11aS1uYXZpZ2F0aW9uX19pdGVtLS1kaXNhYmxlZFwiIDogXCJcIixcblx0XHRhXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBjID0gKGUpID0+IHtcblx0XHRpZiAodC5kaXNhYmxlZCkge1xuXHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRvPy4odC5pZCwgdCwgZSk7XG5cdH07XG5cdHJldHVybiBcImhyZWZcIiBpbiB0ID8gLyogQF9fUFVSRV9fICovIGUoXCJsaVwiLCB7IGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gZShcImFcIiwge1xuXHRcdGNsYXNzTmFtZTogcyxcblx0XHRocmVmOiB0LmhyZWYsXG5cdFx0XCJhcmlhLWN1cnJlbnRcIjogdC5pZCA9PT0gciA/IFwicGFnZVwiIDogdm9pZCAwLFxuXHRcdG9uQ2xpY2s6IGMsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBlKFwic3BhblwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IG4oaSksXG5cdFx0XHRjaGlsZHJlbjogdC5sYWJlbFxuXHRcdH0pXG5cdH0pIH0pIDogLyogQF9fUFVSRV9fICovIGUoXCJsaVwiLCB7IGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gZShcImJ1dHRvblwiLCB7XG5cdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRjbGFzc05hbWU6IHMsXG5cdFx0ZGlzYWJsZWQ6IHQuZGlzYWJsZWQsXG5cdFx0XCJhcmlhLWN1cnJlbnRcIjogdC5pZCA9PT0gciA/IFwicGFnZVwiIDogdm9pZCAwLFxuXHRcdG9uQ2xpY2s6IGMsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBlKFwic3BhblwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IG4oaSksXG5cdFx0XHRjaGlsZHJlbjogdC5sYWJlbFxuXHRcdH0pXG5cdH0pIH0pO1xufVxuZnVuY3Rpb24gaSh7IGl0ZW1zOiBuID0gW10sIGRpcmVjdGlvbjogaSA9IFwidmVydGljYWxcIiwgdGV4dEFsaWdubWVudDogYSA9IFwibGVmdFwiLCBhY3RpdmVJdGVtSWQ6IG8sIGNsYXNzTmFtZTogcyA9IFwiXCIsIGl0ZW1DbGFzc05hbWU6IGMgPSBcIlwiLCBvbkl0ZW1TZWxlY3Q6IGwsIC4uLnUgfSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGUoXCJuYXZcIiwge1xuXHRcdGNsYXNzTmFtZTogW1xuXHRcdFx0XCJuYWJzLXVpLW5hdmlnYXRpb25cIixcblx0XHRcdHRbaV0gPz8gdC52ZXJ0aWNhbCxcblx0XHRcdHNcblx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSxcblx0XHQuLi51LFxuXHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gZShcInVsXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLW5hdmlnYXRpb25fX2xpc3RcIixcblx0XHRcdGNoaWxkcmVuOiBuLm1hcCgodCkgPT4gLyogQF9fUFVSRV9fICovIGUociwge1xuXHRcdFx0XHRpdGVtOiB0LFxuXHRcdFx0XHRhY3RpdmVJdGVtSWQ6IG8sXG5cdFx0XHRcdHRleHRBbGlnbm1lbnQ6IGEsXG5cdFx0XHRcdGl0ZW1DbGFzc05hbWU6IGMsXG5cdFx0XHRcdG9uSXRlbVNlbGVjdDogbFxuXHRcdFx0fSwgdC5pZCkpXG5cdFx0fSlcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGkgYXMgTmF2aWdhdGlvbiB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgdCwganN4cyBhcyBuIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL1BhbmVsLnRzeFxudmFyIHIgPSBlKCh7IGhlYWRlcjogZSA9IFwiUGFuZWxcIiwgZm9vdGVyOiByLCBzaG93SGVhZGVyOiBpID0gITAsIHNob3dGb290ZXI6IGEgPSAhMSwgY2hpbGRyZW46IG8sIGNsYXNzTmFtZTogcyA9IFwiXCIsIGhlYWRlckNsYXNzTmFtZTogYyA9IFwiXCIsIGNvbnRlbnRDbGFzc05hbWU6IGwgPSBcIlwiLCBmb290ZXJDbGFzc05hbWU6IHUgPSBcIlwiLCAuLi5kIH0sIGYpID0+IHtcblx0bGV0IHAgPSBbXCJuYWJzLXVpLXBhbmVsXCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgbSA9IFtcIm5hYnMtdWktcGFuZWxfX2hlYWRlclwiLCBjXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGggPSBbXCJuYWJzLXVpLXBhbmVsX19jb250ZW50XCIsIGxdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktcGFuZWxfX2Zvb3RlclwiLCB1XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gbihcInNlY3Rpb25cIiwge1xuXHRcdHJlZjogZixcblx0XHRjbGFzc05hbWU6IHAsXG5cdFx0Li4uZCxcblx0XHRjaGlsZHJlbjogW1xuXHRcdFx0aSA/IC8qIEBfX1BVUkVfXyAqLyB0KFwiaGVhZGVyXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBtLFxuXHRcdFx0XHRjaGlsZHJlbjogZVxuXHRcdFx0fSkgOiBudWxsLFxuXHRcdFx0LyogQF9fUFVSRV9fICovIHQoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IGgsXG5cdFx0XHRcdGNoaWxkcmVuOiBvXG5cdFx0XHR9KSxcblx0XHRcdGEgPyAvKiBAX19QVVJFX18gKi8gdChcImZvb3RlclwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogZyxcblx0XHRcdFx0Y2hpbGRyZW46IHJcblx0XHRcdH0pIDogbnVsbFxuXHRcdF1cblx0fSk7XG59KTtcbnIuZGlzcGxheU5hbWUgPSBcIlBhbmVsXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHIgYXMgUGFuZWwgfTtcbiIsImltcG9ydCB7IHVzZUlkIGFzIGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyB0LCBqc3hzIGFzIG4gfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvcmFkaW9idXR0b24udXRpbHMudHNcbnZhciByID0ge1xuXHRyaWdodDogXCJuYWJzLXVpLXJhZGlvYnV0dG9uLS1sYWJlbC1yaWdodFwiLFxuXHRsZWZ0OiBcIm5hYnMtdWktcmFkaW9idXR0b24tLWxhYmVsLWxlZnRcIixcblx0dG9wOiBcIm5hYnMtdWktcmFkaW9idXR0b24tLWxhYmVsLXRvcFwiLFxuXHRib3R0b206IFwibmFicy11aS1yYWRpb2J1dHRvbi0tbGFiZWwtYm90dG9tXCJcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvUmFkaW9CdXR0b24udHN4XG5mdW5jdGlvbiBpKHsgbGFiZWw6IGkgPSBcIlJhZGlvIGJ1dHRvblwiLCBsYWJlbFBvc2l0aW9uOiBhID0gXCJyaWdodFwiLCBjbGFzc05hbWU6IG8gPSBcIlwiLCBpbnB1dENsYXNzTmFtZTogcyA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBjID0gXCJcIiwgaWQ6IGwsIC4uLnUgfSkge1xuXHRsZXQgZCA9IHUuZGlzYWJsZWQgPT09ICEwLCBmID0gZSgpLCBwID0gbCA/PyBgbmFicy11aS1yYWRpb2J1dHRvbi0ke2YucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBtID0gW1xuXHRcdFwibmFicy11aS1yYWRpb2J1dHRvblwiLFxuXHRcdGQgPyBcIm5hYnMtdWktcmFkaW9idXR0b24tLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdHJbYV0gPz8gci5yaWdodCxcblx0XHRvXG5cdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBoID0gW1wibmFicy11aS1yYWRpb2J1dHRvbl9faW5wdXRcIiwgc10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBnID0gW1wibmFicy11aS1yYWRpb2J1dHRvbl9fbGFiZWxcIiwgY10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG4oXCJsYWJlbFwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBtLFxuXHRcdGh0bWxGb3I6IHAsXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gdChcImlucHV0XCIsIHtcblx0XHRcdGlkOiBwLFxuXHRcdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdFx0dHlwZTogXCJyYWRpb1wiLFxuXHRcdFx0Li4udVxuXHRcdH0pLCAvKiBAX19QVVJFX18gKi8gdChcInNwYW5cIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0Y2hpbGRyZW46IGlcblx0XHR9KV1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGkgYXMgUmFkaW9CdXR0b24gfTtcbiIsImltcG9ydCB7IHVzZUVmZmVjdCBhcyBlLCB1c2VJZCBhcyB0LCB1c2VSZWYgYXMgbiwgdXNlU3RhdGUgYXMgciB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIGksIGpzeHMgYXMgYSB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9zaWduYXR1cmUudXRpbHMudHNcbmZ1bmN0aW9uIG8oZSwgdCkge1xuXHRsZXQgbiA9IHQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cdHJldHVybiB7XG5cdFx0eDogZS5jbGllbnRYIC0gbi5sZWZ0LFxuXHRcdHk6IGUuY2xpZW50WSAtIG4udG9wXG5cdH07XG59XG5mdW5jdGlvbiBzKGUsIHQpIHtcblx0aWYgKHQubGVuZ3RoICE9PSAwKSB7XG5cdFx0ZS5iZWdpblBhdGgoKSwgZS5tb3ZlVG8odFswXS54LCB0WzBdLnkpO1xuXHRcdGZvciAobGV0IG4gPSAxOyBuIDwgdC5sZW5ndGg7IG4gKz0gMSkgZS5saW5lVG8odFtuXS54LCB0W25dLnkpO1xuXHRcdGUuc3Ryb2tlKCk7XG5cdH1cbn1cbmZ1bmN0aW9uIGMoZSwgdCwgbikge1xuXHRlLmZpbGxTdHlsZSA9IG4sIGUuZmlsbFJlY3QoMCwgMCwgdC53aWR0aCwgdC5oZWlnaHQpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL1NpZ25hdHVyZS50c3hcbmZ1bmN0aW9uIGwoeyBsYWJlbDogbCA9IFwiU2lnbmF0dXJlXCIsIGhlbHBlclRleHQ6IHUgPSBcIlVzZSB5b3VyIG1vdXNlIHRvIGRyYXcgeW91ciBzaWduYXR1cmUuXCIsIHZhbHVlOiBkID0gXCJcIiwgZGlzYWJsZWQ6IGYgPSAhMSwgY2xhc3NOYW1lOiBwID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IG0gPSBcIlwiLCBoZWxwZXJUZXh0Q2xhc3NOYW1lOiBoID0gXCJcIiwgcGFkQ2xhc3NOYW1lOiBnID0gXCJcIiwgY2FudmFzQ2xhc3NOYW1lOiBfID0gXCJcIiwgaWQ6IHYsIHdpZHRoOiB5ID0gNzIwLCBoZWlnaHQ6IGIgPSAyNDAsIGJhY2tncm91bmRDb2xvcjogeCA9IFwiI2ZmZmZmZlwiLCBwZW5Db2xvcjogUyA9IFwiIzBmMTcyYVwiLCBwZW5XaWR0aDogQyA9IDIuNSwgb25DaGFuZ2U6IHcsIG9uQmVnaW5TdHJva2U6IFQsIG9uRW5kU3Ryb2tlOiBFLCBvbkNsZWFyOiBEIH0pIHtcblx0bGV0IE8gPSB0KCksIGsgPSB2ID8/IGBuYWJzLXVpLXNpZ25hdHVyZS0ke08ucmVwbGFjZSgvOi9nLCBcIlwiKX1gLCBBID0gbihudWxsKSwgaiA9IG4obnVsbCksIE0gPSBuKCExKSwgTiA9IG4oW10pLCBbUCwgRl0gPSByKCFkKSwgSSA9IFtcblx0XHRcIm5hYnMtdWktc2lnbmF0dXJlXCIsXG5cdFx0ZiA/IFwibmFicy11aS1zaWduYXR1cmUtLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdHBcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIEwgPSBbXCJuYWJzLXVpLXNpZ25hdHVyZV9fbGFiZWxcIiwgbV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBSID0gW1wibmFicy11aS1zaWduYXR1cmVfX2hlbHBlclwiLCBoXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIHogPSBbXCJuYWJzLXVpLXNpZ25hdHVyZV9fcGFkXCIsIGddLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgQiA9IFtcIm5hYnMtdWktc2lnbmF0dXJlX19jYW52YXNcIiwgX10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRlKCgpID0+IHtcblx0XHRsZXQgZSA9IEEuY3VycmVudDtcblx0XHRpZiAoIWUpIHJldHVybjtcblx0XHRsZXQgdCA9IGUuZ2V0Q29udGV4dChcIjJkXCIpO1xuXHRcdGlmICghdCkgcmV0dXJuO1xuXHRcdGxldCBuID0gd2luZG93LmRldmljZVBpeGVsUmF0aW8gfHwgMSwgciA9IE1hdGgucm91bmQoeSksIGkgPSBNYXRoLnJvdW5kKGIpO1xuXHRcdGlmIChlLndpZHRoID0gTWF0aC5yb3VuZChyICogbiksIGUuaGVpZ2h0ID0gTWF0aC5yb3VuZChpICogbiksIGUuc3R5bGUud2lkdGggPSBgJHtyfXB4YCwgZS5zdHlsZS5oZWlnaHQgPSBgJHtpfXB4YCwgai5jdXJyZW50ID0gdCwgdC5saW5lQ2FwID0gXCJyb3VuZFwiLCB0LmxpbmVKb2luID0gXCJyb3VuZFwiLCB0LmxpbmVXaWR0aCA9IEMgKiBuLCB0LnN0cm9rZVN0eWxlID0gUywgdC5zY2FsZShuLCBuKSwgYyh0LCBlLCB4KSwgZCkge1xuXHRcdFx0bGV0IGUgPSBuZXcgSW1hZ2UoKTtcblx0XHRcdGUub25sb2FkID0gKCkgPT4ge1xuXHRcdFx0XHR0LmNsZWFyUmVjdCgwLCAwLCByLCBpKSwgdC5maWxsU3R5bGUgPSB4LCB0LmZpbGxSZWN0KDAsIDAsIHIsIGkpLCB0LmRyYXdJbWFnZShlLCAwLCAwLCByLCBpKSwgRighMSk7XG5cdFx0XHR9LCBlLnNyYyA9IGQ7XG5cdFx0fVxuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRqLmN1cnJlbnQgPSBudWxsO1xuXHRcdH07XG5cdH0sIFtcblx0XHR4LFxuXHRcdFMsXG5cdFx0Qyxcblx0XHRkLFxuXHRcdHksXG5cdFx0YlxuXHRdKTtcblx0bGV0IFYgPSAoZSkgPT4ge1xuXHRcdHc/LihlLnRvRGF0YVVSTChcImltYWdlL3BuZ1wiKSk7XG5cdH0sIEggPSAoZSkgPT4ge1xuXHRcdGlmIChmIHx8IE0uY3VycmVudCkgcmV0dXJuO1xuXHRcdGxldCB0ID0gQS5jdXJyZW50LCBuID0gai5jdXJyZW50O1xuXHRcdCF0IHx8ICFuIHx8IChcInBvaW50ZXJJZFwiIGluIGUgJiYgdHlwZW9mIGUucG9pbnRlcklkID09IFwibnVtYmVyXCIgJiYgdC5zZXRQb2ludGVyQ2FwdHVyZSAmJiB0LnNldFBvaW50ZXJDYXB0dXJlKGUucG9pbnRlcklkKSwgTS5jdXJyZW50ID0gITAsIE4uY3VycmVudCA9IFtvKGUsIHQpXSwgbi5iZWdpblBhdGgoKSwgbi5tb3ZlVG8oTi5jdXJyZW50WzBdLngsIE4uY3VycmVudFswXS55KSwgVD8uKCkpO1xuXHR9LCBVID0gKGUpID0+IHtcblx0XHRpZiAoZiB8fCAhTS5jdXJyZW50KSByZXR1cm47XG5cdFx0bGV0IHQgPSBBLmN1cnJlbnQsIG4gPSBqLmN1cnJlbnQ7XG5cdFx0aWYgKCF0IHx8ICFuKSByZXR1cm47XG5cdFx0bGV0IHIgPSBvKGUsIHQpO1xuXHRcdE4uY3VycmVudC5wdXNoKHIpLCBuLmxpbmVUbyhyLngsIHIueSksIG4uc3Ryb2tlKCksIEYoITEpO1xuXHR9LCBXID0gKGUpID0+IHtcblx0XHRsZXQgdCA9IEEuY3VycmVudCwgbiA9IGouY3VycmVudDtcblx0XHRpZiAoISghdCB8fCAhbiB8fCAhTS5jdXJyZW50KSkge1xuXHRcdFx0aWYgKGUgJiYgXCJwb2ludGVySWRcIiBpbiBlICYmIHR5cGVvZiBlLnBvaW50ZXJJZCA9PSBcIm51bWJlclwiICYmIHQucmVsZWFzZVBvaW50ZXJDYXB0dXJlKSB0cnkge1xuXHRcdFx0XHR0LnJlbGVhc2VQb2ludGVyQ2FwdHVyZShlLnBvaW50ZXJJZCk7XG5cdFx0XHR9IGNhdGNoIHt9XG5cdFx0XHRNLmN1cnJlbnQgPSAhMSwgcyhuLCBOLmN1cnJlbnQpLCBOLmN1cnJlbnQgPSBbXSwgVih0KSwgRT8uKCk7XG5cdFx0fVxuXHR9O1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGEoXCJkaXZcIiwge1xuXHRcdGNsYXNzTmFtZTogSSxcblx0XHRjaGlsZHJlbjogW1xuXHRcdFx0LyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRjbGFzc05hbWU6IEwsXG5cdFx0XHRcdGlkOiBgJHtrfS1sYWJlbGAsXG5cdFx0XHRcdGNoaWxkcmVuOiBsXG5cdFx0XHR9KSxcblx0XHRcdHUgPyAvKiBAX19QVVJFX18gKi8gaShcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogUixcblx0XHRcdFx0Y2hpbGRyZW46IHVcblx0XHRcdH0pIDogbnVsbCxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyBhKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiB6LFxuXHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBpKFwiY2FudmFzXCIsIHtcblx0XHRcdFx0XHRpZDogayxcblx0XHRcdFx0XHRyZWY6IEEsXG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiBCLFxuXHRcdFx0XHRcdHJvbGU6IFwiaW1nXCIsXG5cdFx0XHRcdFx0XCJhcmlhLWxhYmVsbGVkYnlcIjogYCR7a30tbGFiZWxgLFxuXHRcdFx0XHRcdFwiYXJpYS1sYWJlbFwiOiBsLFxuXHRcdFx0XHRcdG9uUG9pbnRlckRvd246IEgsXG5cdFx0XHRcdFx0b25Qb2ludGVyTW92ZTogVSxcblx0XHRcdFx0XHRvblBvaW50ZXJVcDogVyxcblx0XHRcdFx0XHRvblBvaW50ZXJDYW5jZWw6IFcsXG5cdFx0XHRcdFx0b25Qb2ludGVyTGVhdmU6IFcsXG5cdFx0XHRcdFx0b25Nb3VzZURvd246IEgsXG5cdFx0XHRcdFx0b25Nb3VzZU1vdmU6IFUsXG5cdFx0XHRcdFx0b25Nb3VzZVVwOiBXLFxuXHRcdFx0XHRcdG9uTW91c2VMZWF2ZTogV1xuXHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIGkoXCJkaXZcIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLXNpZ25hdHVyZV9fcGxhY2Vob2xkZXJcIixcblx0XHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBQID8gXCJEcmF3IGhlcmVcIiA6IG51bGxcblx0XHRcdFx0fSldXG5cdFx0XHR9KSxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyBpKFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktc2lnbmF0dXJlX19hY3Rpb25zXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gaShcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0dHlwZTogXCJidXR0b25cIixcblx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1zaWduYXR1cmVfX2NsZWFyQnV0dG9uXCIsXG5cdFx0XHRcdFx0b25DbGljazogKCkgPT4ge1xuXHRcdFx0XHRcdFx0bGV0IGUgPSBBLmN1cnJlbnQsIHQgPSBqLmN1cnJlbnQ7XG5cdFx0XHRcdFx0XHQhZSB8fCAhdCB8fCAodC5jbGVhclJlY3QoMCwgMCwgZS53aWR0aCwgZS5oZWlnaHQpLCBjKHQsIGUsIHgpLCBGKCEwKSwgdz8uKFwiXCIpLCBEPy4oKSk7XG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRkaXNhYmxlZDogZiB8fCBQLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBcIkNsZWFyXCJcblx0XHRcdFx0fSlcblx0XHRcdH0pXG5cdFx0XVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbCBhcyBTaWduYXR1cmUgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSwgdXNlSWQgYXMgdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIG4sIGpzeHMgYXMgciB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9TbGlkZXIudHN4XG52YXIgaSA9IGUoKHsgbGFiZWw6IGUgPSBcIlNsaWRlclwiLCB2YWx1ZTogaSA9IDAsIG1pbjogYSA9IDAsIG1heDogbyA9IDEwMCwgc3RlcDogcyA9IDEsIGRpc2FibGVkOiBjID0gITEsIGNsYXNzTmFtZTogbCA9IFwiXCIsIGlucHV0Q2xhc3NOYW1lOiB1ID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IGQgPSBcIlwiLCB2YWx1ZUNsYXNzTmFtZTogZiA9IFwiXCIsIGlkOiBwLCBvbkNoYW5nZTogbSwgLi4uaCB9LCBnKSA9PiB7XG5cdGxldCBfID0gdCgpLCB2ID0gcCA/PyBgbmFicy11aS1zbGlkZXItJHtfLnJlcGxhY2UoLzovZywgXCJcIil9YCwgeSA9IFtcblx0XHRcIm5hYnMtdWktc2xpZGVyXCIsXG5cdFx0YyA/IFwibmFicy11aS1zbGlkZXItLWRpc2FibGVkXCIgOiBcIlwiLFxuXHRcdGxcblx0XS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGIgPSBbXCJuYWJzLXVpLXNsaWRlcl9faW5wdXRcIiwgdV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCB4ID0gW1wibmFicy11aS1zbGlkZXJfX2xhYmVsXCIsIGRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgUyA9IFtcIm5hYnMtdWktc2xpZGVyX192YWx1ZVwiLCBmXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcihcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiB5LFxuXHRcdGNoaWxkcmVuOiBbXG5cdFx0XHQvKiBAX19QVVJFX18gKi8gcihcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLXNsaWRlcl9faGVhZGVyXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiBbLyogQF9fUFVSRV9fICovIG4oXCJsYWJlbFwiLCB7XG5cdFx0XHRcdFx0Y2xhc3NOYW1lOiB4LFxuXHRcdFx0XHRcdGh0bWxGb3I6IHYsXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGVcblx0XHRcdFx0fSksIC8qIEBfX1BVUkVfXyAqLyBuKFwib3V0cHV0XCIsIHtcblx0XHRcdFx0XHRjbGFzc05hbWU6IFMsXG5cdFx0XHRcdFx0aHRtbEZvcjogdixcblx0XHRcdFx0XHRjaGlsZHJlbjogaVxuXHRcdFx0XHR9KV1cblx0XHRcdH0pLFxuXHRcdFx0LyogQF9fUFVSRV9fICovIG4oXCJpbnB1dFwiLCB7XG5cdFx0XHRcdHJlZjogZyxcblx0XHRcdFx0aWQ6IHYsXG5cdFx0XHRcdGNsYXNzTmFtZTogYixcblx0XHRcdFx0dHlwZTogXCJyYW5nZVwiLFxuXHRcdFx0XHR2YWx1ZTogaSxcblx0XHRcdFx0bWluOiBhLFxuXHRcdFx0XHRtYXg6IG8sXG5cdFx0XHRcdHN0ZXA6IHMsXG5cdFx0XHRcdGRpc2FibGVkOiBjLFxuXHRcdFx0XHRvbkNoYW5nZTogbSxcblx0XHRcdFx0Li4uaFxuXHRcdFx0fSksXG5cdFx0XHQvKiBAX19QVVJFX18gKi8gcihcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLXNsaWRlcl9fc2NhbGVcIixcblx0XHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbihcInNwYW5cIiwgeyBjaGlsZHJlbjogYSB9KSwgLyogQF9fUFVSRV9fICovIG4oXCJzcGFuXCIsIHsgY2hpbGRyZW46IG8gfSldXG5cdFx0XHR9KVxuXHRcdF1cblx0fSk7XG59KTtcbmkuZGlzcGxheU5hbWUgPSBcIlNsaWRlclwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpIGFzIFNsaWRlciB9O1xuIiwiaW1wb3J0IHsgQ2hpbGRyZW4gYXMgZSwgZm9yd2FyZFJlZiBhcyB0LCBpc1ZhbGlkRWxlbWVudCBhcyBuLCB1c2VNZW1vIGFzIHIsIHVzZVN0YXRlIGFzIGkgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEZyYWdtZW50IGFzIGEsIGpzeCBhcyBvLCBqc3hzIGFzIHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvc3RlcHBlci51dGlscy50c1xuZnVuY3Rpb24gYyhlKSB7XG5cdHJldHVybiBlID09PSBcInRvcFwiIHx8IGUgPT09IFwiYm90dG9tXCIgPyBcImhvcml6b250YWxcIiA6IFwidmVydGljYWxcIjtcbn1cbmZ1bmN0aW9uIGwoZSwgdCkge1xuXHRyZXR1cm4gW1xuXHRcdFwibmFicy11aS1zdGVwcGVyXCIsXG5cdFx0YG5hYnMtdWktc3RlcHBlci0tJHtlfWAsXG5cdFx0dFxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcbn1cbmZ1bmN0aW9uIHUoZSkge1xuXHRyZXR1cm4gW1wibmFicy11aS1zdGVwcGVyX19zdGVwc1wiLCBgbmFicy11aS1zdGVwcGVyX19zdGVwcy0tJHtlfWBdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcbn1cbmZ1bmN0aW9uIGQoZSkge1xuXHRyZXR1cm4gW1wibmFicy11aS1zdGVwcGVyX19jb250ZW50XCIsIGBuYWJzLXVpLXN0ZXBwZXJfX2NvbnRlbnQtLSR7ZX1gXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG59XG5mdW5jdGlvbiBmKHQpIHtcblx0cmV0dXJuIGUudG9BcnJheSh0KS5mbGF0TWFwKChlKSA9PiB7XG5cdFx0aWYgKCFuKGUpKSByZXR1cm4gW107XG5cdFx0bGV0IHQgPSBOdW1iZXIoZS5wcm9wcy5pbmRleCk7XG5cdFx0cmV0dXJuIE51bWJlci5pc0Zpbml0ZSh0KSA/IFt7XG5cdFx0XHRpbmRleDogdCxcblx0XHRcdGxhYmVsOiBlLnByb3BzLmxhYmVsID8/IGUucHJvcHMuY2hpbGRyZW4gPz8gYFN0ZXAgJHt0fWAsXG5cdFx0XHRpY29uOiBlLnByb3BzLmljb24sXG5cdFx0XHRkaXNhYmxlZDogISFlLnByb3BzLmRpc2FibGVkXG5cdFx0fV0gOiBbXTtcblx0fSkuc29ydCgoZSwgdCkgPT4gZS5pbmRleCAtIHQuaW5kZXgpO1xufVxuZnVuY3Rpb24gcCh0KSB7XG5cdHJldHVybiBlLnRvQXJyYXkodCkuZmxhdE1hcCgoZSkgPT4ge1xuXHRcdGlmICghbihlKSkgcmV0dXJuIFtdO1xuXHRcdGxldCB0ID0gTnVtYmVyKGUucHJvcHMuaW5kZXgpO1xuXHRcdHJldHVybiBOdW1iZXIuaXNGaW5pdGUodCkgPyBbe1xuXHRcdFx0aW5kZXg6IHQsXG5cdFx0XHRjb250ZW50OiBlLnByb3BzLmNoaWxkcmVuXG5cdFx0fV0gOiBbXTtcblx0fSkuc29ydCgoZSwgdCkgPT4gZS5pbmRleCAtIHQuaW5kZXgpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL1N0ZXBwZXIudHN4XG5mdW5jdGlvbiBtKHsgY2hpbGRyZW46IGUgfSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG8oYSwgeyBjaGlsZHJlbjogZSB9KTtcbn1cbmZ1bmN0aW9uIGgoZSkge1xuXHRyZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIGcoeyBjaGlsZHJlbjogZSB9KSB7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gbyhhLCB7IGNoaWxkcmVuOiBlIH0pO1xufVxuZnVuY3Rpb24gXyhlKSB7XG5cdHJldHVybiBudWxsO1xufVxudmFyIHYgPSBtLCB5ID0gZywgYiA9IHQoKHsgY2hpbGRyZW46IHQsIGNsYXNzTmFtZTogYSA9IFwiXCIsIHN0ZXBzUG9zaXRpb246IG0gPSBcInRvcFwiLCBzdGVwc0FsaWdubWVudDogaCA9IFwibGVmdFwiLCBzdGVwTGFiZWxBbGlnbm1lbnQ6IGcgPSBcInJpZ2h0XCIsIHNob3dDZW50ZXJMaW5lOiBfID0gITAsIGFjdGl2ZUluZGV4OiBiLCBkZWZhdWx0QWN0aXZlSW5kZXg6IHgsIG9uU3RlcENoYW5nZTogUywgLi4uQyB9LCB3KSA9PiB7XG5cdGxldCBbVCwgRV0gPSBpKHgpLCB7IHBhcnNlZFN0ZXBzOiBELCBwYXJzZWRDb250ZW50U3RlcHM6IE8gfSA9IHIoKCkgPT4ge1xuXHRcdGxldCByID0gZS50b0FycmF5KHQpLCBpID0gci5maW5kKChlKSA9PiBuKGUpICYmIGUudHlwZSA9PT0gdiksIGEgPSByLmZpbmQoKGUpID0+IG4oZSkgJiYgZS50eXBlID09PSB5KTtcblx0XHRyZXR1cm4ge1xuXHRcdFx0cGFyc2VkU3RlcHM6IGYoaT8ucHJvcHMuY2hpbGRyZW4pLFxuXHRcdFx0cGFyc2VkQ29udGVudFN0ZXBzOiBwKGE/LnByb3BzLmNoaWxkcmVuKVxuXHRcdH07XG5cdH0sIFt0XSksIGsgPSBEWzBdPy5pbmRleCA/PyBPWzBdPy5pbmRleCA/PyAwLCBBID0gYiA/PyBUID8/IGssIGogPSBPLmZpbmQoKGUpID0+IGUuaW5kZXggPT09IEEpLCBNID0gYyhtKSwgTiA9IFtcblx0XHRsKG0sIGEpLFxuXHRcdGBuYWJzLXVpLXN0ZXBwZXItLWxhYmVsLSR7Z31gLFxuXHRcdGBuYWJzLXVpLXN0ZXBwZXItLWFsaWduLSR7aH1gLFxuXHRcdF8gPyBcIm5hYnMtdWktc3RlcHBlci0td2l0aC1jZW50ZXItbGluZVwiIDogXCJuYWJzLXVpLXN0ZXBwZXItLXdpdGhvdXQtY2VudGVyLWxpbmVcIlxuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgUCA9IHUobSksIEYgPSBkKG0pO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHMoXCJzZWN0aW9uXCIsIHtcblx0XHRyZWY6IHcsXG5cdFx0Y2xhc3NOYW1lOiBOLFxuXHRcdC4uLkMsXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbyhcIm5hdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFAsXG5cdFx0XHRyb2xlOiBcInRhYmxpc3RcIixcblx0XHRcdFwiYXJpYS1vcmllbnRhdGlvblwiOiBNLFxuXHRcdFx0Y2hpbGRyZW46IEQubWFwKChlKSA9PiB7XG5cdFx0XHRcdGxldCB0ID0gZS5pbmRleCA9PT0gQTtcblx0XHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBzKFwiZGl2XCIsIHtcblx0XHRcdFx0XHRyb2xlOiBcInRhYlwiLFxuXHRcdFx0XHRcdFwiYXJpYS1zZWxlY3RlZFwiOiB0LFxuXHRcdFx0XHRcdFwiYXJpYS1kaXNhYmxlZFwiOiBlLmRpc2FibGVkLFxuXHRcdFx0XHRcdHRhYkluZGV4OiBlLmRpc2FibGVkID8gLTEgOiAwLFxuXHRcdFx0XHRcdGNsYXNzTmFtZTogW1xuXHRcdFx0XHRcdFx0XCJuYWJzLXVpLXN0ZXBwZXJfX3N0ZXBcIixcblx0XHRcdFx0XHRcdHQgPyBcIm5hYnMtdWktc3RlcHBlcl9fc3RlcC0tYWN0aXZlXCIgOiBcIlwiLFxuXHRcdFx0XHRcdFx0ZS5kaXNhYmxlZCA/IFwibmFicy11aS1zdGVwcGVyX19zdGVwLS1kaXNhYmxlZFwiIDogXCJcIlxuXHRcdFx0XHRcdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICh0KSA9PiB7XG5cdFx0XHRcdFx0XHRlLmRpc2FibGVkIHx8IChiID09PSB2b2lkIDAgJiYgRShlLmluZGV4KSwgUz8uKGUuaW5kZXgsIHQpKTtcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBbZS5pY29uID8gLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLXN0ZXBwZXJfX3N0ZXBJbmRpY2F0b3JzXCIsXG5cdFx0XHRcdFx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIG8oXCJzcGFuXCIsIHtcblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktc3RlcHBlcl9fc3RlcEljb25cIixcblx0XHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUuaWNvblxuXHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHR9KSA6IG51bGwsIC8qIEBfX1BVUkVfXyAqLyBvKFwic3BhblwiLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1zdGVwcGVyX19zdGVwTGFiZWxcIixcblx0XHRcdFx0XHRcdGNoaWxkcmVuOiBlLmxhYmVsXG5cdFx0XHRcdFx0fSldXG5cdFx0XHRcdH0sIGUuaW5kZXgpO1xuXHRcdFx0fSlcblx0XHR9KSwgLyogQF9fUFVSRV9fICovIG8oXCJzZWN0aW9uXCIsIHtcblx0XHRcdGNsYXNzTmFtZTogRixcblx0XHRcdHJvbGU6IFwidGFicGFuZWxcIixcblx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gbyhcImRpdlwiLCB7XG5cdFx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLXN0ZXBwZXJfX2NvbnRlbnRJbm5lclwiLFxuXHRcdFx0XHRjaGlsZHJlbjogaj8uY29udGVudCA/PyBudWxsXG5cdFx0XHR9KVxuXHRcdH0pXVxuXHR9KTtcbn0pO1xuYi5kaXNwbGF5TmFtZSA9IFwiU3RlcHBlclwiLCBtLmRpc3BsYXlOYW1lID0gXCJTdGVwcGVyLlN0ZXBzXCIsIGguZGlzcGxheU5hbWUgPSBcIlN0ZXBwZXIuU3RlcFwiLCBnLmRpc3BsYXlOYW1lID0gXCJTdGVwcGVyLkNvbnRlbnRTdGVwc1wiLCBfLmRpc3BsYXlOYW1lID0gXCJTdGVwcGVyLkNvbnRlbnRTdGVwXCIsIGIuU3RlcHMgPSBtLCBiLlN0ZXAgPSBoLCBiLkNvbnRlbnRTdGVwcyA9IGcsIGIuQ29udGVudFN0ZXAgPSBfO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBiIGFzIFN0ZXBwZXIgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIHQsIGpzeHMgYXMgbiB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9UYWIudHN4XG52YXIgciA9IGUoKHsgbGFiZWw6IGUgPSBcIlRhYlwiLCBjaGlsZHJlbjogciwgc2hvd0hlYWRlcjogaSA9ICEwLCBjbGFzc05hbWU6IGEgPSBcIlwiLCBoZWFkZXJDbGFzc05hbWU6IG8gPSBcIlwiLCBjb250ZW50Q2xhc3NOYW1lOiBzID0gXCJcIiwgbGFiZWxDbGFzc05hbWU6IGMgPSBcIlwiLCBpZDogbCwgLi4udSB9LCBkKSA9PiB7XG5cdGxldCBmID0gW1wibmFicy11aS10YWJcIiwgYV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBwID0gW1wibmFicy11aS10YWJfX2hlYWRlclwiLCBvXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIG0gPSBbXCJuYWJzLXVpLXRhYl9fY29udGVudFwiLCBzXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGggPSBbXCJuYWJzLXVpLXRhYl9fbGFiZWxcIiwgY10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG4oXCJzZWN0aW9uXCIsIHtcblx0XHRyZWY6IGQsXG5cdFx0aWQ6IGwsXG5cdFx0Y2xhc3NOYW1lOiBmLFxuXHRcdC4uLnUsXG5cdFx0Y2hpbGRyZW46IFtpID8gLyogQF9fUFVSRV9fICovIHQoXCJkaXZcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBwLFxuXHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyB0KFwiZGl2XCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdFx0XHRjaGlsZHJlbjogZVxuXHRcdFx0fSlcblx0XHR9KSA6IG51bGwsIC8qIEBfX1BVUkVfXyAqLyB0KFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogbSxcblx0XHRcdGNoaWxkcmVuOiByXG5cdFx0fSldXG5cdH0pO1xufSk7XG5yLmRpc3BsYXlOYW1lID0gXCJUYWJcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgciBhcyBUYWIgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSwgdXNlSWQgYXMgdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IGFzIG4sIGpzeHMgYXMgciB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9UZXh0YXJlYS50c3hcbnZhciBpID0gZSgoeyBsYWJlbDogZSwgY2xhc3NOYW1lOiBpID0gXCJcIiwgaW5wdXRDbGFzc05hbWU6IGEgPSBcIlwiLCBsYWJlbENsYXNzTmFtZTogbyA9IFwiXCIsIGlkOiBzLCByb3dzOiBjID0gNCwgcmVzaXplOiBsID0gXCJ2ZXJ0aWNhbFwiLCAuLi51IH0sIGQpID0+IHtcblx0bGV0IGYgPSB0KCksIHAgPSBzID8/IGBuYWJzLXVpLXRleHRhcmVhLSR7Zi5yZXBsYWNlKC86L2csIFwiXCIpfWAsIG0gPSBbXCJuYWJzLXVpLXRleHRhcmVhXCIsIGldLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaCA9IFtcIm5hYnMtdWktdGV4dGFyZWFfX2lucHV0XCIsIGFdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktdGV4dGFyZWFfX2xhYmVsXCIsIG9dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyByKFwiZGl2XCIsIHtcblx0XHRjbGFzc05hbWU6IG0sXG5cdFx0Y2hpbGRyZW46IFtlID8gLyogQF9fUFVSRV9fICovIG4oXCJsYWJlbFwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IGcsXG5cdFx0XHRodG1sRm9yOiBwLFxuXHRcdFx0Y2hpbGRyZW46IGVcblx0XHR9KSA6IG51bGwsIC8qIEBfX1BVUkVfXyAqLyBuKFwidGV4dGFyZWFcIiwge1xuXHRcdFx0cmVmOiBkLFxuXHRcdFx0aWQ6IHAsXG5cdFx0XHRjbGFzc05hbWU6IGgsXG5cdFx0XHRyb3dzOiBjLFxuXHRcdFx0XCJkYXRhLXJlc2l6ZVwiOiBsLFxuXHRcdFx0Li4udVxuXHRcdH0pXVxuXHR9KTtcbn0pO1xuaS5kaXNwbGF5TmFtZSA9IFwiVGV4dGFyZWFcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaSBhcyBUZXh0YXJlYSB9O1xuIiwiaW1wb3J0IHsgZm9yd2FyZFJlZiBhcyBlLCB1c2VJZCBhcyB0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggYXMgbiwganN4cyBhcyByIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL3RleHRib3gudXRpbHMudHNcbnZhciBpID0ge1xuXHRub25lOiBcIlwiLFxuXHR0b3A6IFwibmFicy11aS10ZXh0Ym94LS1sYWJlbC10b3BcIixcblx0bGVmdDogXCJuYWJzLXVpLXRleHRib3gtLWxhYmVsLWxlZnRcIlxufSwgYSA9IGUoKHsgbGFiZWw6IGUsIGxhYmVsUG9zaXRpb246IGEgPSBcInRvcFwiLCBjbGFzc05hbWU6IG8gPSBcIlwiLCBpbnB1dENsYXNzTmFtZTogcyA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBjID0gXCJcIiwgaWQ6IGwsIHR5cGU6IHUgPSBcInRleHRcIiwgLi4uZCB9LCBmKSA9PiB7XG5cdGxldCBwID0gdCgpLCBtID0gbCA/PyBgbmFicy11aS10ZXh0Ym94LSR7cC5yZXBsYWNlKC86L2csIFwiXCIpfWAsIGggPSBbXG5cdFx0XCJuYWJzLXVpLXRleHRib3hcIixcblx0XHRlID8gaVthXSA/PyBpLnRvcCA6IFwiXCIsXG5cdFx0b1xuXHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgZyA9IFtcIm5hYnMtdWktdGV4dGJveF9faW5wdXRcIiwgc10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBfID0gW1wibmFicy11aS10ZXh0Ym94X19sYWJlbFwiLCBjXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8gcihcImRpdlwiLCB7XG5cdFx0Y2xhc3NOYW1lOiBoLFxuXHRcdGNoaWxkcmVuOiBbZSA/IC8qIEBfX1BVUkVfXyAqLyBuKFwibGFiZWxcIiwge1xuXHRcdFx0Y2xhc3NOYW1lOiBfLFxuXHRcdFx0aHRtbEZvcjogbSxcblx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0fSkgOiBudWxsLCAvKiBAX19QVVJFX18gKi8gbihcImlucHV0XCIsIHtcblx0XHRcdHJlZjogZixcblx0XHRcdGlkOiBtLFxuXHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0dHlwZTogdSxcblx0XHRcdC4uLmRcblx0XHR9KV1cblx0fSk7XG59KTtcbmEuZGlzcGxheU5hbWUgPSBcIlRleHRib3hcIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYSBhcyBUZXh0Ym94IH07XG4iLCJpbXBvcnQgeyBmb3J3YXJkUmVmIGFzIGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCBhcyB0LCBqc3hzIGFzIG4gfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvdG9vbGJhci51dGlscy50c1xudmFyIHIgPSB7XG5cdGxlZnQ6IFwibmFicy11aS10b29sYmFyX19jb250ZW50LS1sYWJlbC1sZWZ0XCIsXG5cdHJpZ2h0OiBcIm5hYnMtdWktdG9vbGJhcl9fY29udGVudC0tbGFiZWwtcmlnaHRcIixcblx0dG9wOiBcIm5hYnMtdWktdG9vbGJhcl9fY29udGVudC0tbGFiZWwtdG9wXCIsXG5cdGJvdHRvbTogXCJuYWJzLXVpLXRvb2xiYXJfX2NvbnRlbnQtLWxhYmVsLWJvdHRvbVwiXG59O1xuZnVuY3Rpb24gaShlKSB7XG5cdHJldHVybiBlIHx8IFwicmlnaHRcIjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9Ub29sYmFyLnRzeFxudmFyIGEgPSBlKGZ1bmN0aW9uKHsgaXRlbXM6IGUsIGFjdGl2ZUl0ZW1JZDogYSwgY2xhc3NOYW1lOiBvID0gXCJcIiwgYnV0dG9uQ2xhc3NOYW1lOiBzID0gXCJcIiwgaWNvbkNsYXNzTmFtZTogYyA9IFwiXCIsIGxhYmVsQ2xhc3NOYW1lOiBsID0gXCJcIiwgb25JdGVtU2VsZWN0OiB1LCAuLi5kIH0sIGYpIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyB0KFwiZGl2XCIsIHtcblx0XHRyZWY6IGYsXG5cdFx0Y2xhc3NOYW1lOiBbXCJuYWJzLXVpLXRvb2xiYXJcIiwgb10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdHJvbGU6IFwidG9vbGJhclwiLFxuXHRcdC4uLmQsXG5cdFx0Y2hpbGRyZW46IGUubWFwKChlKSA9PiB7XG5cdFx0XHRsZXQgbyA9IGUuaWNvbiwgZCA9ICEhZS5sYWJlbCwgZiA9IGUuaWQgPT09IGEgfHwgZS5wcmVzc2VkID09PSAhMCwgcCA9IFtcIm5hYnMtdWktdG9vbGJhcl9fY29udGVudFwiLCByW2koZS5sYWJlbFBvc2l0aW9uKV1dLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgbSA9IFtcblx0XHRcdFx0XCJuYWJzLXVpLXRvb2xiYXJfX2J1dHRvblwiLFxuXHRcdFx0XHRmID8gXCJuYWJzLXVpLXRvb2xiYXJfX2J1dHRvbi0tYWN0aXZlXCIgOiBcIlwiLFxuXHRcdFx0XHRkID8gXCJcIiA6IFwibmFicy11aS10b29sYmFyX19idXR0b24tLWljb24tb25seVwiLFxuXHRcdFx0XHRzXG5cdFx0XHRdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaCA9IFtcIm5hYnMtdWktdG9vbGJhcl9faWNvblwiLCBjXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIGcgPSBbXCJuYWJzLXVpLXRvb2xiYXJfX2xhYmVsXCIsIGxdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgXyA9IHR5cGVvZiBlLmxhYmVsID09IFwic3RyaW5nXCIgPyBlLmxhYmVsIDogZS50aXRsZTtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8gdChcImJ1dHRvblwiLCB7XG5cdFx0XHRcdHR5cGU6IFwiYnV0dG9uXCIsXG5cdFx0XHRcdGNsYXNzTmFtZTogbSxcblx0XHRcdFx0ZGlzYWJsZWQ6IGUuZGlzYWJsZWQsXG5cdFx0XHRcdHRpdGxlOiBlLnRpdGxlLFxuXHRcdFx0XHRcImFyaWEtbGFiZWxcIjogXyxcblx0XHRcdFx0XCJhcmlhLXByZXNzZWRcIjogdHlwZW9mIGUucHJlc3NlZCA9PSBcImJvb2xlYW5cIiA/IGUucHJlc3NlZCA6IHZvaWQgMCxcblx0XHRcdFx0b25DbGljazogKHQpID0+IHtcblx0XHRcdFx0XHR1Py4oe1xuXHRcdFx0XHRcdFx0aXRlbUlkOiBlLmlkLFxuXHRcdFx0XHRcdFx0aXRlbTogZSxcblx0XHRcdFx0XHRcdGV2ZW50OiB0XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8gbihcInNwYW5cIiwge1xuXHRcdFx0XHRcdGNsYXNzTmFtZTogcCxcblx0XHRcdFx0XHRjaGlsZHJlbjogW28gPyAvKiBAX19QVVJFX18gKi8gdChvLCB7XG5cdFx0XHRcdFx0XHRjbGFzc05hbWU6IGgsXG5cdFx0XHRcdFx0XHRcImFyaWEtaGlkZGVuXCI6IFwidHJ1ZVwiLFxuXHRcdFx0XHRcdFx0Zm9jdXNhYmxlOiBcImZhbHNlXCJcblx0XHRcdFx0XHR9KSA6IG51bGwsIGUubGFiZWwgPyAvKiBAX19QVVJFX18gKi8gdChcInNwYW5cIiwge1xuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lOiBnLFxuXHRcdFx0XHRcdFx0Y2hpbGRyZW46IGUubGFiZWxcblx0XHRcdFx0XHR9KSA6IG51bGxdXG5cdFx0XHRcdH0pXG5cdFx0XHR9LCBlLmlkKTtcblx0XHR9KVxuXHR9KTtcbn0pO1xuYS5kaXNwbGF5TmFtZSA9IFwiVG9vbGJhclwiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhIGFzIFRvb2xiYXIgfTtcbiIsImltcG9ydCB7IGZvcndhcmRSZWYgYXMgZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGF5b3V0IGFzIHQgfSBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1sYXlvdXRcIjtcbmltcG9ydCB7IGpzeCBhcyBuLCBqc3hzIGFzIHIgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWxheW91dFwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktYWNjb3JkaW9uXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1hdmF0YXJcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWJ1dHRvbnNcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWNhcmRzXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1jaGVja2JveFwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktY29kZVwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktY29tYm9ib3hcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWRhdGVwaWNrZXJcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWRpYWxvZ1wiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktZHJvcGRvd25saXN0XCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1kcm9wZG93bm1lbnVcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLWR5bmFtaWNmb3JtXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1maWxldXBsb2FkXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1ncmFwaFwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktZ3JpZFwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktbWFya2Rvd25cIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLW5hdmlnYXRpb25cIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXBhbmVsXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1yYWRpb2J1dHRvblwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktc2lnbmF0dXJlXCI7XG5leHBvcnQgKiBmcm9tIFwiQG5ldC1hZHZhbnRhZ2UvbmFicy11aS1zbGlkZXJcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXN0ZXBwZXJcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXRhYlwiO1xuZXhwb3J0ICogZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktdGV4dGFyZWFcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXRleHRib3hcIjtcbmV4cG9ydCAqIGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXRvb2xiYXJcIjtcbi8vI3JlZ2lvbiBzcmMvU2hlbGwudHN4XG52YXIgaSA9IGUoKHsgaGVhZGVyOiBlLCBuYXZpZ2F0aW9uOiByLCBmb290ZXI6IGksIGNoaWxkcmVuOiBhLCBjbGFzc05hbWU6IG8gPSBcIlwiLCBoZWFkZXJDbGFzc05hbWU6IHMgPSBcIlwiLCBuYXZpZ2F0aW9uQ2xhc3NOYW1lOiBjID0gXCJcIiwgY29udGVudENsYXNzTmFtZTogbCA9IFwiXCIsIGZvb3RlckNsYXNzTmFtZTogdSA9IFwiXCIsIC4uLmQgfSwgZikgPT4ge1xuXHRsZXQgcCA9IFtcIm5hYnMtdWktc2hlbGxcIiwgb10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBtID0gW1wibmFicy11aS1zaGVsbF9faGVhZGVyXCIsIHNdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIFwiKSwgaCA9IFtcIm5hYnMtdWktc2hlbGxfX25hdmlnYXRpb25cIiwgY10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLCBnID0gW1wibmFicy11aS1zaGVsbF9fY29udGVudFwiLCBsXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIiksIF8gPSBbXCJuYWJzLXVpLXNoZWxsX19mb290ZXJcIiwgdV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIG4oXCJkaXZcIiwge1xuXHRcdHJlZjogZixcblx0XHRjbGFzc05hbWU6IHAsXG5cdFx0Li4uZCxcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIG4odCwge1xuXHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktc2hlbGxfX2xheW91dFwiLFxuXHRcdFx0aGVhZGVyOiBlLFxuXHRcdFx0Zm9vdGVyOiBpLFxuXHRcdFx0bGVmdFNpZGVQYW5lbDogcixcblx0XHRcdGhlYWRlckNsYXNzTmFtZTogbSxcblx0XHRcdGZvb3RlckNsYXNzTmFtZTogXyxcblx0XHRcdGxlZnRTaWRlUGFuZWxDbGFzc05hbWU6IGgsXG5cdFx0XHRjb250ZW50Q2xhc3NOYW1lOiBnLFxuXHRcdFx0Y2hpbGRyZW46IGFcblx0XHR9KVxuXHR9KTtcbn0pO1xuaS5kaXNwbGF5TmFtZSA9IFwiU2hlbGxcIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9CcmFuZGluZy50c3hcbnZhciBhID0gZShmdW5jdGlvbih7IGxvZ286IGUsIHRpdGxlOiB0LCBieWxpbmU6IGksIGNsYXNzTmFtZTogYSA9IFwiXCIsIC4uLm8gfSwgcykge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIHIoXCJkaXZcIiwge1xuXHRcdHJlZjogcyxcblx0XHRjbGFzc05hbWU6IFtcIm5hYnMtdWktYnJhbmRpbmdcIiwgYV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpLFxuXHRcdC4uLm8sXG5cdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8gbihcImRpdlwiLCB7XG5cdFx0XHRjbGFzc05hbWU6IFwibmFicy11aS1icmFuZGluZ19fbG9nb1wiLFxuXHRcdFx0XCJhcmlhLWhpZGRlblwiOiBcInRydWVcIixcblx0XHRcdGNoaWxkcmVuOiBlXG5cdFx0fSksIC8qIEBfX1BVUkVfXyAqLyByKFwiZGl2XCIsIHtcblx0XHRcdGNsYXNzTmFtZTogXCJuYWJzLXVpLWJyYW5kaW5nX190ZXh0XCIsXG5cdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBuKFwic3Ryb25nXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYnJhbmRpbmdfX3RpdGxlXCIsXG5cdFx0XHRcdGNoaWxkcmVuOiB0XG5cdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIG4oXCJzcGFuXCIsIHtcblx0XHRcdFx0Y2xhc3NOYW1lOiBcIm5hYnMtdWktYnJhbmRpbmdfX2J5bGluZVwiLFxuXHRcdFx0XHRjaGlsZHJlbjogaVxuXHRcdFx0fSldXG5cdFx0fSldXG5cdH0pO1xufSk7XG5hLmRpc3BsYXlOYW1lID0gXCJCcmFuZGluZ1wiO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhIGFzIEJyYW5kaW5nLCBpIGFzIFNoZWxsIH07XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFFQSxTQUFTQSxLQUFFLEVBQUUsSUFBSSxJQUFJLE9BQU8sV0FBVyxJQUFJLElBQUksVUFBVSxHQUFHLEdBQUcsS0FBSztDQUNuRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxHQUFHO0VBQzNCLFdBQVc7RUFDWCxHQUFHO0VBQ0gsVUFBVTtDQUNYLENBQUM7QUFDRjtBQUNBLFNBQVNDLElBQUUsRUFBRSxRQUFRLEdBQUcsUUFBUSxHQUFHLGVBQWUsR0FBRyxnQkFBZ0IsR0FBRyxVQUFVLEdBQUcsV0FBVyxJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLHdCQUF3QixJQUFJLElBQUkseUJBQXlCLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLEdBQUcsS0FBSztDQUM1UCxJQUFJLElBQUksS0FBSyxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUk7RUFDbkg7RUFDQSxLQUFLLElBQUksMkNBQTJDO0VBQ3BELEtBQUssQ0FBQyxJQUFJLDBDQUEwQztFQUNwRCxDQUFDLEtBQUssSUFBSSwyQ0FBMkM7Q0FDdEQsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQzFCLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsV0FBVyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztFQUN6RCxHQUFHO0VBQ0gsVUFBVTtHQUNULElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFRCxNQUFHO0lBQ3hCLElBQUk7SUFDSixXQUFXO0lBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUNsQyxXQUFXLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0tBQ2pFLFVBQVU7SUFDWCxDQUFDO0dBQ0YsQ0FBQyxJQUFJO0dBQ1csaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztJQUN4QixXQUFXO0lBQ1gsVUFBVTtLQUNULElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFQSxNQUFHO01BQ3hCLElBQUk7TUFDSixXQUFXO09BQ1Y7T0FDQTtPQUNBO01BQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO01BQzFCLFVBQVU7S0FDWCxDQUFDLElBQUk7S0FDVyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUEsTUFBRztNQUNwQixJQUFJO01BQ0osV0FBVyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztNQUNsRSxVQUFVO0tBQ1gsQ0FBQztLQUNELElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFQSxNQUFHO01BQ3hCLElBQUk7TUFDSixXQUFXO09BQ1Y7T0FDQTtPQUNBO01BQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO01BQzFCLFVBQVU7S0FDWCxDQUFDLElBQUk7SUFDTjtHQUNELENBQUM7R0FDRCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUEsTUFBRztJQUN4QixJQUFJO0lBQ0osV0FBVztJQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDbEMsV0FBVyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztLQUNqRSxVQUFVO0lBQ1gsQ0FBQztHQUNGLENBQUMsSUFBSTtFQUNOO0NBQ0QsQ0FBQztBQUNGOzs7QUMvREEsU0FBU0UsS0FBRSxHQUFHLEdBQUcsR0FBRztDQUNuQixJQUFJLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxJQUFJLElBQUksRUFBRSxLQUFLLE1BQU0sRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLEVBQUUsUUFBUSxHQUFHLEdBQUcsTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQztDQUMxRyxPQUFPLE1BQU0sV0FBVyxFQUFFLE1BQU0sR0FBRyxDQUFDLElBQUk7QUFDekM7QUFDQSxTQUFTQyxLQUFFLEdBQUcsR0FBRyxHQUFHO0NBQ25CLElBQUksSUFBSSxFQUFFLFNBQVMsQ0FBQztDQUNwQixPQUFPLE1BQU0sV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsUUFBUSxNQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUM7QUFDL0U7QUFDQSxTQUFTQyxLQUFFLEdBQUc7Q0FDYixPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0FBQ3pEO0FBR0EsSUFBSSxLQUFBLEdBQUlDLGFBQUFBLFdBQUFBLENBQUUsU0FBUyxFQUFFLE9BQU8sR0FBRyxNQUFNLElBQUksWUFBWSxpQkFBaUIsR0FBRyx3QkFBd0IsR0FBRyx5QkFBeUIsR0FBRyxXQUFXLElBQUksSUFBSSxlQUFlLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdPLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLHFCQUFxQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQUEsR0FBS0MsYUFBQUEsU0FBQUEsRUFBQUEsR0FBRUMsYUFBQUEsUUFBQUEsT0FBUU4sS0FBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHO0VBQ2hHO0VBQ0E7RUFDQTtDQUNELENBQUMsQ0FBQztDQUNGLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLEdBQUcsTUFBTUEsS0FBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0NBQ3BCLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztDQUNULElBQUksS0FBQSxHQUFJTSxhQUFBQSxRQUFBQSxPQUFRTixLQUFFLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsR0FBRztFQUM5QztFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxXQUFXO0VBQ25DLEtBQUs7RUFDTCxJQUFJO0VBQ0osV0FBV0UsS0FBRSxDQUFDO0VBQ2QsR0FBRztFQUNILFVBQVUsRUFBRSxLQUFLLE1BQU07R0FDdEIsSUFBSSxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUUsR0FBRyxJQUFJLEdBQUcsRUFBRSxTQUFTLEVBQUUsTUFBTSxJQUFJLEdBQUcsRUFBRSxXQUFXLEVBQUUsTUFBTSxJQUFJO0lBQ25GO0lBQ0EsSUFBSSxzQ0FBc0M7SUFDMUM7R0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssTUFBTTtJQUN2SyxJQUFJLElBQUlELEtBQUUsR0FBRyxFQUFFLElBQUksQ0FBQztJQUNwQixNQUFNLEtBQUssS0FBSyxFQUFFLENBQUMsR0FBRyxJQUFJO0tBQ3pCLFFBQVEsRUFBRTtLQUNWLGlCQUFpQjtLQUNqQixPQUFPO0lBQ1IsQ0FBQztHQUNGO0dBQ0EsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsV0FBVztJQUNuQyxXQUFXO0lBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO0tBQ2xDLFdBQVc7S0FDWCxVQUFVLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7TUFDekMsSUFBSTtNQUNKLE1BQU07TUFDTixXQUFXO01BQ1gsaUJBQWlCO01BQ2pCLGlCQUFpQjtNQUNqQixVQUFVLEVBQUU7TUFDWixTQUFTO01BQ1QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO09BQ3ZGLFdBQVc7T0FDWCxlQUFlO09BQ2YsVUFBVTtNQUNYLENBQUMsQ0FBQztLQUNILENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtNQUNoQyxJQUFJO01BQ0osTUFBTTtNQUNOLFdBQVc7TUFDWCxpQkFBaUI7TUFDakIsaUJBQWlCO01BQ2pCLFVBQVUsRUFBRTtNQUNaLFNBQVM7TUFDVCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7T0FDdkYsV0FBVztPQUNYLGVBQWU7T0FDZixVQUFVO01BQ1gsQ0FBQyxDQUFDO0tBQ0gsQ0FBQztJQUNGLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsV0FBVztLQUNoQyxJQUFJO0tBQ0osV0FBVztLQUNYLE1BQU07S0FDTixtQkFBbUI7S0FDbkIsUUFBUSxDQUFDO0tBQ1QsVUFBVSxFQUFFO0lBQ2IsQ0FBQyxDQUFDO0dBQ0gsR0FBRyxFQUFFLEVBQUU7RUFDUixDQUFDO0NBQ0YsQ0FBQztBQUNGLENBQUM7QUFDRCxFQUFFLGNBQWM7Ozs7QUN4RmhCLFNBQVNNLElBQUUsR0FBRztDQUNiLE9BQU8sQ0FBQyxFQUFFLEtBQUssVUFBVSxLQUFLLEVBQUUsU0FBUztBQUMxQztBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLE9BQU8sRUFBRSxTQUFTLEVBQUUsWUFBWTtBQUNqQztBQUNBLFNBQVNDLElBQUUsR0FBRyxHQUFHO0NBQ2hCLE9BQU8sRUFBRSxTQUFTLEVBQUUsU0FBUyxRQUFRO0FBQ3RDO0FBR0EsU0FBU0MsSUFBRSxFQUFFLE9BQU8sSUFBSSxRQUFRLGdCQUFnQixHQUFHLGtCQUFrQixHQUFHLFdBQVcsSUFBSSxTQUFTLE9BQU8sSUFBSSxDQUFDLEdBQUcsV0FBVyxJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxlQUFlLElBQUksSUFBSSxlQUFlLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLElBQUksR0FBRyxjQUFjLEdBQUcsR0FBRyxLQUFLO0NBQ25RLElBQUksQ0FBQyxHQUFHLE1BQUEsR0FBS0MsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLENBQUMsR0FBRyxLQUFBLEdBQUlDLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxLQUFBLEdBQUlDLGFBQUFBLE1BQUFBLENBQUUsR0FBRyxJQUFJLEtBQUssd0JBQXdCLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUM5YixDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxJQUFJLEtBQUssTUFBTTtHQUNkLEVBQUUsa0JBQWtCLFFBQVEsRUFBRSxXQUFXLENBQUMsRUFBRSxRQUFRLFNBQVMsRUFBRSxNQUFNLEtBQUssRUFBRSxXQUFXLENBQUMsRUFBRSxRQUFRLFNBQVMsRUFBRSxNQUFNLEtBQUssRUFBRSxDQUFDLENBQUM7RUFDN0gsR0FBRyxLQUFLLE1BQU07R0FDYixFQUFFLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FBQztFQUMzQjtFQUNBLE9BQU8sU0FBUyxpQkFBaUIsZUFBZSxDQUFDLEdBQUcsU0FBUyxpQkFBaUIsV0FBVyxDQUFDLFNBQVM7R0FDbEcsU0FBUyxvQkFBb0IsZUFBZSxDQUFDLEdBQUcsU0FBUyxvQkFBb0IsV0FBVyxDQUFDO0VBQzFGO0NBQ0QsR0FBRyxDQUFDLENBQUMsSUFBQSxHQUFHQyxhQUFBQSxnQkFBQUEsT0FBUTtFQUNmLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxTQUFTO0VBQ3RCLElBQUksVUFBVTtHQUNiLElBQUksSUFBSSxFQUFFLFNBQVMsc0JBQXNCLEdBQUcsSUFBSSxFQUFFLFNBQVMsc0JBQXNCLEdBQUcsSUFBSSxFQUFFO0dBQzFGLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUc7R0FDcEIsSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFLE9BQU8sRUFBRSxLQUFLLEdBQUcsSUFBSSxPQUFPLGFBQWEsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEVBQUUsUUFBUSxJQUFJLEVBQUUsTUFBTSxJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksS0FBSyxJQUFJLEdBQUcsRUFBRSxTQUFTLEVBQUU7R0FDekssRUFBRSxNQUFNLFdBQVcsU0FBUyxFQUFFLE1BQU0sTUFBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sT0FBTyxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sUUFBUSxRQUFRLEVBQUUsTUFBTSxXQUFXLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxhQUFhO0VBQ3hKO0VBQ0EsT0FBTyxFQUFFLFlBQVksRUFBRSxRQUFRLE1BQU0sYUFBYSxXQUFXLEVBQUUsR0FBRyxPQUFPLGlCQUFpQixVQUFVLENBQUMsR0FBRyxPQUFPLGlCQUFpQixVQUFVLEdBQUcsQ0FBQyxDQUFDLFNBQVM7R0FDdkosT0FBTyxvQkFBb0IsVUFBVSxDQUFDLEdBQUcsT0FBTyxvQkFBb0IsVUFBVSxHQUFHLENBQUMsQ0FBQztFQUNwRjtDQUNELEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztDQUNULElBQUksS0FBSyxHQUFHLE1BQU07RUFDakIsSUFBSSxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsVUFBVTtHQUN0QixFQUFFLGVBQWU7R0FDakI7RUFDRDtFQUNBLElBQUksR0FBRyxDQUFDLEdBQUcsRUFBRSxXQUFXLEdBQUcsQ0FBQztDQUM3QjtDQUNBLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsS0FBSztFQUNMLFdBQVc7RUFDWCxHQUFHO0VBQ0gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0dBQ3RDLEtBQUs7R0FDTCxNQUFNO0dBQ04sV0FBVztHQUNYLGlCQUFpQjtHQUNqQixpQkFBaUI7R0FDakIsY0FBYyxLQUFLO0dBQ25CLGVBQWUsR0FBRyxNQUFNLENBQUMsQ0FBQztHQUMxQixVQUFVLEtBQXFCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFQyxtQkFBQUEsVUFBRyxFQUFFLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtJQUMxRSxXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtJQUM3QixXQUFXO0lBQ1gsZUFBZTtJQUNmLFVBQVU7R0FDWCxDQUFDLENBQUMsRUFBRSxDQUFDO0VBQ04sQ0FBQyxHQUFHLEtBQUssT0FBTyxXQUFXLE9BQUEsR0FBTUMsaUJBQUFBLGFBQUFBLENBQWtCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDM0QsS0FBSztHQUNMLElBQUk7R0FDSixXQUFXO0dBQ1gsY0FBYztHQUNkLFVBQVUsRUFBRSxLQUFLLEdBQUcsTUFBTTtJQUN6QixJQUFJVCxJQUFFLENBQUMsR0FBRyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQ3pDLFdBQVc7S0FDWCxNQUFNO0tBQ04sZUFBZTtJQUNoQixHQUFHLFdBQVcsR0FBRztJQUNqQixJQUFJLElBQUlDLElBQUUsQ0FBQyxHQUFHLElBQUk7S0FDakI7S0FDQSxFQUFFLFdBQVcseUNBQXlDO0tBQ3RELEVBQUUsU0FBUyx1Q0FBdUM7SUFDbkQsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSTtLQUNoQyxXQUFXO0tBQ1gsaUJBQWlCLEVBQUUsWUFBWSxLQUFLO0lBQ3JDO0lBQ0EsT0FBTyxFQUFFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLEtBQUs7S0FDdEMsR0FBRztLQUNILE1BQU0sRUFBRSxXQUFXLEtBQUssSUFBSSxFQUFFO0tBQzlCLFVBQVUsTUFBTSxFQUFFLEdBQUcsQ0FBQztLQUN0QixVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDcEMsV0FBVztNQUNYLFVBQVU7S0FDWCxDQUFDLEdBQUcsRUFBRSxjQUE4QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzdDLFdBQVc7TUFDWCxVQUFVLEVBQUU7S0FDYixDQUFDLElBQUksSUFBSTtJQUNWLEdBQUdDLElBQUUsR0FBRyxDQUFDLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtLQUN6QyxNQUFNO0tBQ04sV0FBVztLQUNYLFVBQVUsRUFBRTtLQUNaLFVBQVUsTUFBTSxFQUFFLEdBQUcsQ0FBQztLQUN0QixVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDcEMsV0FBVztNQUNYLFVBQVU7S0FDWCxDQUFDLEdBQUcsRUFBRSxjQUE4QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzdDLFdBQVc7TUFDWCxVQUFVLEVBQUU7S0FDYixDQUFDLElBQUksSUFBSTtJQUNWLEdBQUdBLElBQUUsR0FBRyxDQUFDLENBQUM7R0FDWCxDQUFDO0VBQ0YsQ0FBQyxHQUFHLFNBQVMsSUFBSSxJQUFJLElBQUk7Q0FDMUIsQ0FBQztBQUNGO0FBR0EsU0FBU1EsSUFBRSxHQUFHO0NBQ2IsSUFBSSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxPQUFPLE9BQU87Q0FDNUMsT0FBTyxFQUFFLFdBQVcsSUFBSSxNQUFNLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFLEVBQUUsRUFBRSxZQUFZLEtBQUssRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFO0FBQzFGO0FBR0EsSUFBSSxLQUFBLEdBQUlDLGFBQUFBLFdBQUFBLENBQUUsU0FBUyxFQUFFLGVBQWUsSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLGNBQWMsV0FBVyxJQUFJLElBQUksV0FBVyxHQUFHLGFBQWEsSUFBSSxLQUFLLFlBQVksSUFBSSxLQUFLLGNBQWMsR0FBRyxnQkFBZ0IsR0FBRyxlQUFlLEdBQUcsV0FBVyxJQUFJLElBQUksV0FBVyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQ2pQLElBQUksSUFBSSxFQUFFLEtBQUssS0FBSyxjQUFjLElBQUlELElBQUUsQ0FBQyxHQUFHLElBQUk7RUFDL0M7RUFDQSxJQUFJLGtDQUFrQztFQUN0QztDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssTUFBTTtFQUN2QyxNQUFNLEVBQUUsZUFBZSxHQUFHLEVBQUUsQ0FBQztDQUM5QixHQUFHLEtBQUssTUFBTTtFQUNiLE1BQU0sRUFBRSxlQUFlLEdBQUcsRUFBRSxDQUFDO0NBQzlCLEdBQUcsS0FBSyxNQUFNO0VBQ2IsTUFBTSxFQUFFLGVBQWUsR0FBRyxFQUFFLENBQUM7Q0FDOUI7Q0FDQSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0VBQy9CLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQVUsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVQLEtBQUc7R0FDbEMsV0FBVztHQUNYLE9BQU8sR0FBRyxFQUFFO0dBQ1osa0JBQWtCLEtBQUssR0FBRyxFQUFFO0dBQzVCLFdBQVc7R0FDWCxnQkFBZ0MsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUVLLG1CQUFBQSxVQUFHLEVBQUUsVUFBVTtJQUNoQyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0tBQ3pCLFdBQVc7S0FDWCxlQUFlO0tBQ2YsVUFBVSxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO01BQ3RDLFdBQVc7TUFDWCxLQUFLO01BQ0wsS0FBSztLQUNOLENBQUMsSUFBSTtJQUNOLENBQUM7SUFDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0tBQ3pCLFdBQVc7S0FDWCxVQUFVO0lBQ1gsQ0FBQztJQUNlLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7S0FDekIsV0FBVztLQUNYLGVBQWU7S0FDZixVQUFVO0lBQ1gsQ0FBQztHQUNGLEVBQUUsQ0FBQztHQUNILGtCQUFrQjtHQUNsQixlQUFlO0dBQ2YsZUFBZTtHQUNmLE9BQU8sQ0FBQztJQUNQLE9BQU87SUFDUCxNQUFNO0lBQ04sV0FBVyxHQUFHLE1BQU0sRUFBRSxDQUFDO0dBQ3hCLEdBQUc7SUFDRixPQUFPO0lBQ1AsTUFBTTtJQUNOLFFBQVEsQ0FBQztJQUNULFdBQVcsR0FBRyxNQUFNLEVBQUUsQ0FBQztHQUN4QixDQUFDO0VBQ0YsQ0FBQyxJQUFJLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLEtBQUs7R0FDL0IsV0FBVztHQUNYLE1BQU07R0FDTixTQUFTO0dBQ1QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQ3BDLFdBQVc7SUFDWCxlQUFlO0lBQ2YsVUFBVTtHQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtJQUM3QixXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsQ0FBQztFQUNILENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtHQUNoQyxNQUFNO0dBQ04sV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDcEMsV0FBVztJQUNYLGVBQWU7SUFDZixVQUFVO0dBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQzdCLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxDQUFDO0VBQ0gsQ0FBQztDQUNGLENBQUM7QUFDRixDQUFDO0FBQ0QsRUFBRSxjQUFjOzs7QUN0TWhCLElBQUlJLE9BQUk7Q0FDUCxTQUFTO0NBQ1QsV0FBVztDQUNYLE9BQU87QUFDUjtBQUFHLElBQUEsS0FBQSxHQUFJQyxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxVQUFVLEdBQUcsV0FBVyxJQUFJLElBQUksU0FBUyxJQUFJLFdBQVcsTUFBTSxJQUFJLFVBQVUsR0FBRyxLQUFLLEdBQUc7Q0FDMUcsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtFQUNsQyxLQUFLO0VBQ0wsV0FBVztHQUNWO0dBQ0FELEtBQUUsTUFBTUEsS0FBRTtHQUNWO0VBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0VBQzFCLE1BQU07RUFDTixHQUFHO0VBQ0gsVUFBVTtDQUNYLENBQUM7QUFDRixDQUFDO0FBQ0QsRUFBRSxjQUFjOzs7QUNqQmhCLFNBQVNFLEtBQUUsR0FBRztDQUNiLE9BQU8sTUFBTSxLQUFLLElBQUksSUFBSSxPQUFPLFNBQVMsQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzNGO0FBQ0EsU0FBU0MsS0FBRSxHQUFHLEdBQUcsR0FBRztDQUNuQixPQUFPLE1BQU0sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU07RUFDeEMsSUFBSSxJQUFJLEVBQUUsV0FBVyxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUUsR0FBRyxJQUFJLEVBQUUsV0FBVyxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUUsR0FBRyxJQUFJLEtBQUssTUFBTSxJQUFJLENBQUMsR0FBRyxJQUFJLEtBQUssTUFBTSxJQUFJLENBQUM7RUFDN0gsSUFBSSxNQUFNLEdBQUcsT0FBTyxJQUFJO0VBQ3hCLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJO0VBQ3ZCLFFBQVEsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtDQUNqRSxDQUFDLElBQUk7QUFDTjtBQUdBLElBQUlDLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxPQUFPLEdBQUcsUUFBUSxJQUFJLEtBQUssU0FBUyxHQUFHLFdBQVcsSUFBSSxJQUFJLGVBQWUsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLEdBQUcsS0FBSyxNQUFNO0NBQ3hMLElBQUksSUFBSUgsS0FBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyx1QkFBdUIsZ0NBQWdDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSUMsS0FBRSxHQUFHLEdBQUcsQ0FBQztDQUMzSyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxXQUFXO0VBQ25DLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDbEMsV0FBVztHQUNYLFVBQVUsRUFBRSxLQUFLLE1BQU07SUFDdEIsSUFBSSxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxFQUFFLFVBQVUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxHQUFHLElBQUksRUFBRSxXQUFXLFFBQVEsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLEVBQUUsV0FBVyxRQUFRLEVBQUUsWUFBWSxDQUFDO0lBQzFMLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFdBQVc7S0FDbkMsV0FBVztLQUNYLFVBQVU7TUFDVCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO09BQy9CLFdBQVcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7T0FDaEUsVUFBVSxFQUFFO01BQ2IsQ0FBQyxJQUFJO01BQ0wsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztPQUM1QixXQUFXLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO09BQ2pFLFVBQVUsRUFBRTtNQUNiLENBQUMsSUFBSTtNQUNMLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87T0FDNUIsV0FBVyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztPQUNqRSxVQUFVLEVBQUU7TUFDYixDQUFDLElBQUk7S0FDTjtJQUNELEdBQUcsRUFBRSxFQUFFO0dBQ1IsQ0FBQztFQUNGLENBQUM7Q0FDRixDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYzs7O0FDNUNoQixJQUFJRyxPQUFJO0NBQ1AsT0FBTztDQUNQLE1BQU07Q0FDTixLQUFLO0NBQ0wsUUFBUTtBQUNUO0FBQUdDLElBQUFBLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLENBQUUsU0FBUyxFQUFFLE9BQU8sSUFBSSxZQUFZLGVBQWUsSUFBSSxTQUFTLFdBQVcsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsVUFBVSxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQ3hLLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLG9CQUFvQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUNwRTtFQUNBLElBQUksK0JBQStCO0VBQ25DSCxLQUFFLE1BQU1BLEtBQUU7RUFDVjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQ3RKLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7RUFDakMsV0FBVztFQUNYLFNBQVM7RUFDVCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDckMsS0FBSztHQUNMLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLFVBQVU7R0FDVixHQUFHO0VBQ0osQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0dBQzdCLFdBQVc7R0FDWCxVQUFVO0VBQ1gsQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7OztBQzVCaEIsSUFBSUksT0FBSTtDQUNQLE1BQU07Q0FDTixLQUFLO0NBQ0wsTUFBTTtDQUNOLFFBQVE7QUFDVDtBQUFHLElBQUEsS0FBQSxHQUFJQyxhQUFBQSxXQUFBQSxFQUFHLEVBQUUsTUFBTSxHQUFHLFVBQVUsSUFBSSxRQUFRLGlCQUFpQixJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxHQUFHLE9BQU8sR0FBRyxXQUFXLElBQUksSUFBSSxjQUFjLElBQUksSUFBSSxlQUFlLElBQUksSUFBSSxHQUFHLEtBQUssTUFBTTtDQUN6SyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJO0VBQzFEO0VBQ0EsSUFBSSw0QkFBNEI7RUFDaEMsSUFBSSxtQ0FBbUM7RUFDdkM7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJO0VBQ2hDO0VBQ0EsMEJBQTBCO0VBQzFCO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxFQUFFLFFBQVEsU0FBUyxJQUFJLEdBQUcsSUFBSSxFQUFFLE1BQU0sSUFBSTtDQUMzRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxXQUFXO0VBQ25DLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtHQUN0QyxXQUFXO0dBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQ3BDLFdBQVc7SUFDWCxVQUFVRCxLQUFFO0dBQ2IsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQzdCLFdBQVc7SUFDWCxVQUFVLEtBQUs7R0FDaEIsQ0FBQyxDQUFDO0VBQ0gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQzVCLFdBQVc7R0FDWCxVQUFVLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDdkMsV0FBVztJQUNYLFVBQVUsRUFBRSxLQUFLLEdBQUcsTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsUUFBUTtLQUNuRCxXQUFXO0tBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVc7TUFDWCxVQUFVLElBQUk7S0FDZixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDN0IsV0FBVztNQUNYLFVBQVUsS0FBSztLQUNoQixDQUFDLENBQUM7SUFDSCxHQUFHLENBQUMsQ0FBQztHQUNOLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtJQUM5QixXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUM7RUFDRixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELEVBQUUsY0FBYzs7O0FDbERoQixTQUFTRSxJQUFFLEdBQUc7Q0FDYixPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRTtBQUNuQztBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLElBQUksSUFBSUQsSUFBRSxDQUFDO0NBQ1gsT0FBTyxPQUFPLEtBQUssWUFBWSxPQUFPLEtBQUssV0FBVyxHQUFHLE1BQU0sRUFBRTtBQUNsRTtBQUNBLFNBQVNFLElBQUUsR0FBRyxHQUFHO0NBQ2hCLE9BQU8sRUFBRSxTQUFTLFFBQVE7QUFDM0I7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRztDQUNoQixPQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsTUFBTSxNQUFNLEVBQUUsVUFBVSxDQUFDLEtBQUs7QUFDM0Q7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsWUFBWTtBQUM3QjtBQUdBLElBQUksS0FBQSxHQUFJQyxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxPQUFPLElBQUksQ0FBQyxHQUFHLE9BQU8sR0FBRyxjQUFjLEdBQUcsV0FBVyxJQUFJLENBQUMsR0FBRyxXQUFXLElBQUksUUFBUSxXQUFXLElBQUksSUFBSSxJQUFJLEdBQUcsVUFBVSxHQUFHLGFBQWEsR0FBRyxlQUFlLEdBQUcsU0FBUyxHQUFHLFFBQVEsR0FBRyxXQUFXLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDak8sSUFBSSxLQUFBLEdBQUlDLGFBQUFBLE1BQUFBLENBQUUsR0FBRyxLQUFBLEdBQUlDLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLElBQUkseUJBQXlCLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJLEtBQUssb0JBQW9CLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJLE1BQU0sS0FBSyxHQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtDLGFBQUFBLFNBQUFBLENBQUUsS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJTCxJQUFFLEdBQUcsQ0FBQyxHQUFHLElBQUksSUFBSUYsSUFBRSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsR0FBRyxNQUFBLEdBQUtPLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLEdBQUcsS0FBQSxHQUFJQyxhQUFBQSxRQUFBQSxPQUFRO0VBQ3hSLElBQUksSUFBSUwsSUFBRSxDQUFDO0VBQ1gsT0FBTyxFQUFFLFFBQVEsTUFBTTtHQUN0QixJQUFJLElBQUlBLElBQUVILElBQUUsQ0FBQyxDQUFDO0dBQ2QsT0FBTyxFQUFFLFdBQVcsS0FBSyxFQUFFLFNBQVMsQ0FBQztFQUN0QyxDQUFDO0NBQ0YsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUM7RUFDcEIsT0FBTztFQUNQLE9BQU87RUFDUCxVQUFVLENBQUM7RUFDWCxRQUFRLENBQUM7Q0FDVixHQUFHLEdBQUcsQ0FBQyxJQUFJO0NBQ1gsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFRO0VBQ1AsS0FBSyxFQUFFLENBQUM7Q0FDVCxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBQSxHQUFHUyxhQUFBQSxVQUFBQSxPQUFRO0VBQ25CLEtBQUssRUFBRSxVQUFVLEVBQUUsRUFBRSxXQUFXLElBQUksSUFBSSxFQUFFLFNBQVMsQ0FBQztDQUNyRCxHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxJQUFBLEdBQUdBLGFBQUFBLFVBQUFBLE9BQVE7RUFDMUIsSUFBSSxLQUFLLE1BQU07R0FDZCxFQUFFLFdBQVcsRUFBRSxrQkFBa0IsUUFBUSxDQUFDLEVBQUUsUUFBUSxTQUFTLEVBQUUsTUFBTSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0VBQy9FO0VBQ0EsT0FBTyxTQUFTLGlCQUFpQixlQUFlLENBQUMsU0FBUztHQUN6RCxTQUFTLG9CQUFvQixlQUFlLENBQUM7RUFDOUM7Q0FDRCxHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksS0FBSyxHQUFHLE1BQU07RUFDakIsS0FBSyxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJVCxJQUFFLENBQUMsSUFBSSxFQUFFO0NBQzdDLEdBQUcsS0FBSyxNQUFNO0VBQ2IsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLEdBQUc7R0FDTixJQUFJLFlBQVksR0FBRztJQUNsQixFQUFFLE1BQU0sSUFBSTtJQUNaO0dBQ0Q7R0FDQSxFQUFFLFlBQVksRUFBRSxFQUFFLE9BQU8sQ0FBQztFQUMzQjtDQUNELEdBQUcsS0FBSyxNQUFNO0VBQ2IsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7Q0FDekIsR0FBRyxLQUFLLE1BQU07RUFDYixFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQztDQUNuQixHQUFHLEtBQUssTUFBTTtFQUNiLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLE9BQU8sS0FBSyxHQUFHLEVBQUUsQ0FBQztDQUM5QixHQUFHLEtBQUssTUFBTTtFQUNiLElBQUksRUFBRSxRQUFRLGFBQWE7R0FDMUIsRUFBRSxlQUFlLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLElBQUksRUFBRSxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7R0FDOUU7RUFDRDtFQUNBLElBQUksRUFBRSxRQUFRLFdBQVc7R0FDeEIsRUFBRSxlQUFlLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDLENBQUM7R0FDdEQ7RUFDRDtFQUNBLElBQUksRUFBRSxRQUFRLFNBQVM7R0FDdEIsTUFBTSxFQUFFLGVBQWUsR0FBRyxFQUFFLENBQUM7R0FDN0I7RUFDRDtFQUNBLElBQUksRUFBRSxRQUFRLFVBQVU7R0FDdkIsRUFBRSxlQUFlLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7R0FDOUI7RUFDRDtFQUNBLElBQUksQ0FBQztDQUNOLEdBQUcsSUFBSSxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0VBQ3JDLEtBQUs7RUFDTCxJQUFJO0VBQ0osTUFBTTtFQUNOLGlCQUFpQjtFQUNqQixxQkFBcUI7RUFDckIsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQix5QkFBeUIsRUFBRSxLQUFLLEdBQUcsRUFBRSxVQUFVLE1BQU0sS0FBSztFQUMxRCxXQUFXO0VBQ1gsVUFBVTtFQUNWLGFBQWE7RUFDYixPQUFPO0VBQ1AsU0FBUztFQUNULFFBQVE7RUFDUixVQUFVO0VBQ1YsV0FBVztFQUNYLEdBQUc7Q0FDSixDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7RUFDL0IsS0FBSztFQUNMLElBQUk7RUFDSixNQUFNO0VBQ04saUJBQWlCO0VBQ2pCLHFCQUFxQjtFQUNyQixpQkFBaUI7RUFDakIsaUJBQWlCO0VBQ2pCLFdBQVc7RUFDWCxVQUFVO0VBQ1YsYUFBYTtFQUNiLE9BQU87RUFDUCxTQUFTO0VBQ1QsUUFBUTtFQUNSLFVBQVU7RUFDVixXQUFXO0VBQ1gsR0FBRztDQUNKLENBQUM7Q0FDRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLEtBQUs7RUFDTCxXQUFXO0dBQ1Y7R0FDQSxJQUFJLDJCQUEyQjtHQUMvQixJQUFJLCtCQUErQjtHQUNuQztFQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztFQUMxQixVQUFVLENBQUMsR0FBRyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQzFDLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLGNBQWM7R0FDZCxVQUFVLEVBQUUsV0FBVyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQ25ELFdBQVc7SUFDWCxNQUFNO0lBQ04saUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixVQUFVO0dBQ1gsQ0FBQyxJQUFJLEVBQUUsS0FBSyxHQUFHLE1BQU07SUFDcEIsSUFBSSxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxNQUFNLEVBQUUsT0FBTyxJQUFJO0tBQ25EO0tBQ0EsTUFBTSxJQUFJLHFDQUFxQztLQUMvQyxJQUFJLHVDQUF1QztLQUMzQyxJQUFJLG1DQUFtQztLQUN2QyxFQUFFLFdBQVcsdUNBQXVDO0lBQ3JELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztJQUMxQixPQUFPLElBQUksTUFBTSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQ2hELElBQUksR0FBRyxFQUFFLFVBQVU7S0FDbkIsV0FBVztLQUNYLE1BQU07S0FDTixpQkFBaUI7S0FDakIsaUJBQWlCO0tBQ2pCLFVBQVU7S0FDVixjQUFjLE1BQU0sRUFBRSxlQUFlO0tBQ3JDLGVBQWUsRUFBRSxDQUFDO0tBQ2xCLG9CQUFvQixFQUFFLENBQUM7S0FDdkIsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUNuQyxXQUFXO01BQ1gsVUFBVTtLQUNYLENBQUM7SUFDRixHQUFHLE1BQU0sSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUNyQyxJQUFJLEdBQUcsRUFBRSxVQUFVO0tBQ25CLFdBQVc7S0FDWCxNQUFNO0tBQ04saUJBQWlCO0tBQ2pCLGlCQUFpQjtLQUNqQixVQUFVO0tBQ1YsY0FBYyxNQUFNLEVBQUUsZUFBZTtLQUNyQyxlQUFlLEVBQUUsQ0FBQztLQUNsQixvQkFBb0IsRUFBRSxDQUFDO0tBQ3ZCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDbkMsV0FBVztNQUNYLFVBQVU7S0FDWCxDQUFDO0lBQ0YsR0FBRyxNQUFNLElBQUksRUFBRSxXQUFXLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87S0FDdEQsSUFBSSxHQUFHLEVBQUUsVUFBVTtLQUNuQixXQUFXO0tBQ1gsTUFBTTtLQUNOLGlCQUFpQjtLQUNqQixpQkFBaUI7S0FDakIsVUFBVTtLQUNWLGNBQWMsTUFBTSxFQUFFLGVBQWU7S0FDckMsZUFBZSxFQUFFLENBQUM7S0FDbEIsb0JBQW9CLEVBQUUsQ0FBQztLQUN2QixVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDcEMsV0FBVztNQUNYLFVBQVVELElBQUUsQ0FBQztLQUNkLENBQUMsR0FBRyxFQUFFLGNBQThCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDN0MsV0FBVztNQUNYLFVBQVUsRUFBRTtLQUNiLENBQUMsSUFBSSxJQUFJO0lBQ1YsR0FBR0UsSUFBRSxHQUFHLENBQUMsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0tBQ3RDLElBQUksR0FBRyxFQUFFLFVBQVU7S0FDbkIsV0FBVztLQUNYLE1BQU07S0FDTixpQkFBaUI7S0FDakIsaUJBQWlCO0tBQ2pCLFVBQVU7S0FDVixjQUFjLE1BQU0sRUFBRSxlQUFlO0tBQ3JDLGVBQWUsRUFBRSxDQUFDO0tBQ2xCLG9CQUFvQixFQUFFLENBQUM7S0FDdkIsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVc7TUFDWCxVQUFVRixJQUFFLENBQUM7S0FDZCxDQUFDLEdBQUcsRUFBRSxjQUE4QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzdDLFdBQVc7TUFDWCxVQUFVLEVBQUU7S0FDYixDQUFDLElBQUksSUFBSTtJQUNWLEdBQUdFLElBQUUsR0FBRyxDQUFDLENBQUMsSUFBSSxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0tBQzFDLElBQUksR0FBRyxFQUFFLFVBQVU7S0FDbkIsV0FBVztLQUNYLE1BQU07S0FDTixpQkFBaUI7S0FDakIsaUJBQWlCO0tBQ2pCLFVBQVU7S0FDVixjQUFjLE1BQU0sRUFBRSxlQUFlO0tBQ3JDLGVBQWUsRUFBRSxDQUFDO0tBQ2xCLG9CQUFvQixFQUFFLENBQUM7S0FDdkIsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVc7TUFDWCxVQUFVRixJQUFFLENBQUM7S0FDZCxDQUFDLEdBQUcsRUFBRSxjQUE4QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzdDLFdBQVc7TUFDWCxVQUFVLEVBQUU7S0FDYixDQUFDLElBQUksSUFBSTtJQUNWLEdBQUdFLElBQUUsR0FBRyxDQUFDLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztLQUN0QyxJQUFJLEdBQUcsRUFBRSxVQUFVO0tBQ25CLFdBQVc7S0FDWCxNQUFNO0tBQ04saUJBQWlCO0tBQ2pCLGlCQUFpQjtLQUNqQixVQUFVO0tBQ1YsY0FBYyxNQUFNLEVBQUUsZUFBZTtLQUNyQyxlQUFlLEVBQUUsQ0FBQztLQUNsQixvQkFBb0IsRUFBRSxDQUFDO0tBQ3ZCLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUNwQyxXQUFXO01BQ1gsVUFBVUYsSUFBRSxDQUFDO0tBQ2QsQ0FBQyxHQUFHLEVBQUUsY0FBOEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUM3QyxXQUFXO01BQ1gsVUFBVSxFQUFFO0tBQ2IsQ0FBQyxJQUFJLElBQUk7SUFDVixHQUFHRSxJQUFFLEdBQUcsQ0FBQyxDQUFDO0dBQ1gsQ0FBQztFQUNGLENBQUMsSUFBSSxJQUFJO0NBQ1YsQ0FBQztBQUNGLENBQUM7QUFDRCxFQUFFLGNBQWM7OztBQ2xQaEIsSUFBSVMsT0FBSTtDQUNQLE1BQU07Q0FDTixLQUFLO0NBQ0wsTUFBTTtBQUNQO0FBQUdDLElBQUFBLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxPQUFPLEdBQUcsZUFBZSxJQUFJLE9BQU8sV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLFdBQVcsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLE9BQU8sR0FBRyxVQUFVLEdBQUcsZUFBZSxHQUFHLEdBQUcsS0FBSyxNQUFNO0NBQ25NLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLHNCQUFzQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUN0RTtFQUNBLElBQUlILEtBQUUsTUFBTUEsS0FBRSxNQUFNO0VBQ3BCO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDMUosT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDekMsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0VBQ1gsQ0FBQyxJQUFJLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDckMsS0FBSztHQUNMLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLE9BQU8sTUFBTSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUs7R0FDcEMsV0FBVyxNQUFNO0lBQ2hCLElBQUksQ0FBQyxHQUFHLElBQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxLQUFLLE9BQU8sRUFBRSxPQUFPLE9BQU8sQ0FBQztHQUNsRTtHQUNBLEdBQUc7RUFDSixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYzs7O0FDN0JoQixJQUFJSSxNQUFJO0FBQ1IsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxNQUFNLEtBQUssRUFBRSxpQkFBaUJELEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxNQUFNLENBQUMsRUFBRSxhQUFhLFVBQVUsS0FBSyxFQUFFLGFBQWEsYUFBYSxNQUFNLE1BQU07QUFDL0g7QUFDQSxJQUFJLEtBQUEsR0FBSUUsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsT0FBTyxHQUFHLGFBQWEsR0FBRyxRQUFRLEdBQUcsUUFBUSxHQUFHLFlBQVksSUFBSSxDQUFDLEdBQUcsWUFBWSxJQUFJLENBQUMsR0FBRyxnQkFBZ0IsR0FBRyxzQkFBc0IsSUFBSSxDQUFDLEdBQUcsZUFBZSxJQUFJLENBQUMsR0FBRyxzQkFBc0IsR0FBRyxZQUFZLElBQUksVUFBVSxXQUFXLElBQUksSUFBSSxtQkFBbUIsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksc0JBQXNCLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksV0FBVyxHQUFHLFVBQVUsR0FBRyxVQUFVLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDbGIsSUFBSSxLQUFBLEdBQUlDLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsSUFBSSx5QkFBQSxHQUF3QkMsYUFBQUEsTUFBQUEsQ0FBRSxDQUFDLENBQUMsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJLCtCQUFBLEdBQThCQSxhQUFBQSxNQUFBQSxDQUFFLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUksRUFBRSxvQkFBb0IsSUFBSSxFQUFFLHFCQUFxQixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksTUFBTSxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxNQUFNLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxNQUFNLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQ3JxQixRQUFBLEdBQU9DLGFBQUFBLFVBQUFBLE9BQVE7RUFDZCxJQUFJLElBQUksRUFBRTtFQUNWLElBQUksQ0FBQyxHQUFHO0VBQ1IsSUFBSSxFQUFFLFVBQVUsU0FBUyx5QkFBeUIsY0FBYyxTQUFTLGdCQUFnQixNQUFNLEdBQUcsSUFBSTtHQUNyRyxJQUFJLElBQUksRUFBRSxjQUFjLENBQUM7R0FDekIsSUFBSSxHQUFHLE9BQU8sRUFBRSxNQUFNLFNBQVM7SUFDOUIsRUFBRSxTQUFTLE1BQU0sR0FBRyxFQUFFLFVBQVU7R0FDakM7RUFDRCxRQUFRLENBQUM7RUFDVCxJQUFJLElBQUlKLElBQUUsQ0FBQztFQUNYLE9BQU8sRUFBRSxTQUFTLElBQUksRUFBRSxFQUFFLENBQUMsTUFBTSxJQUFJLEVBQUUsTUFBTSxTQUFTO0dBQ3JELEVBQUUsU0FBUyxNQUFNLEdBQUcsRUFBRSxVQUFVO0VBQ2pDO0NBQ0QsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0VBQ2pDLFdBQVc7RUFDWCxNQUFNO0VBQ04sVUFBVSxNQUFNO0dBQ2YsQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLGlCQUFpQixJQUFJO0VBQzNDO0VBQ0EsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsV0FBVztHQUN0QyxNQUFNLE1BQU07SUFDWCxJQUFJLEVBQUUsVUFBVSxHQUFHLE9BQU8sS0FBSyxZQUFZO0tBQzFDLEVBQUUsQ0FBQztLQUNIO0lBQ0Q7SUFDQSxNQUFNLEVBQUUsVUFBVTtHQUNuQjtHQUNBLFdBQVc7R0FDWCxNQUFNO0dBQ04sY0FBYztHQUNkLG1CQUFtQjtHQUNuQixvQkFBb0I7R0FDcEIsVUFBVSxLQUFLO0dBQ2YsWUFBWSxNQUFNO0lBQ2pCLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxrQkFBa0I7SUFDaEMsSUFBSSxFQUFFLFFBQVEsWUFBWSxHQUFHO0tBQzVCLEVBQUUsZUFBZSxHQUFHLElBQUk7S0FDeEI7SUFDRDtJQUNBLElBQUksRUFBRSxRQUFRLFNBQVMsQ0FBQyxFQUFFLFNBQVM7SUFDbkMsSUFBSSxJQUFJQSxJQUFFLEVBQUUsT0FBTztJQUNuQixJQUFJLEVBQUUsV0FBVyxHQUFHO0tBQ25CLEVBQUUsZUFBZSxHQUFHLEVBQUUsUUFBUSxNQUFNO0tBQ3BDO0lBQ0Q7SUFDQSxJQUFJLElBQUksU0FBUyxlQUFlLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxFQUFFLFNBQVM7SUFDM0QsSUFBSSxFQUFFLFVBQVU7S0FDZixDQUFDLENBQUMsS0FBSyxNQUFNLEtBQUssQ0FBQyxFQUFFLFFBQVEsU0FBUyxDQUFDLE9BQU8sRUFBRSxlQUFlLEdBQUcsRUFBRSxNQUFNO0tBQzFFO0lBQ0Q7SUFDQSxDQUFDLENBQUMsS0FBSyxNQUFNLEtBQUssQ0FBQyxFQUFFLFFBQVEsU0FBUyxDQUFDLE9BQU8sRUFBRSxlQUFlLEdBQUcsRUFBRSxNQUFNO0dBQzNFO0dBQ0EsR0FBRztHQUNILFVBQVU7SUFDVCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0tBQy9CLFdBQVc7S0FDWCxVQUFVLE1BQU0sSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtNQUMzQyxXQUFXO01BQ1gsSUFBSTtNQUNKLFVBQVU7S0FDWCxDQUFDLElBQUk7SUFDTixDQUFDLElBQUk7SUFDTCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQzVCLElBQUk7S0FDSixXQUFXO0tBQ1gsVUFBVTtJQUNYLENBQUMsSUFBSTtJQUNXLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDeEIsV0FBVztLQUNYLFVBQVU7SUFDWCxDQUFDO0lBQ0QsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtLQUMvQixXQUFXO0tBQ1gsVUFBVTtJQUNYLENBQUMsSUFBSTtHQUNOO0VBQ0QsQ0FBQztDQUNGLENBQUM7QUFDRixDQUFDO0FBQ0QsRUFBRSxjQUFjOzs7QUNyRmhCLFNBQVNLLEtBQUUsR0FBRztDQUNiLE9BQU8sRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFO0FBQ25DO0FBQ0EsU0FBU0MsS0FBRSxHQUFHLEdBQUc7Q0FDaEIsT0FBTyxFQUFFLFNBQVMsUUFBUTtBQUMzQjtBQUNBLFNBQVNDLElBQUUsR0FBRyxHQUFHLEdBQUc7Q0FDbkIsT0FBTyxLQUFLLE1BQU0sUUFBUSxNQUFNO0FBQ2pDO0FBR0EsSUFBSSxLQUFBLEdBQUlDLGFBQUFBLFdBQUFBLENBQUUsU0FBUyxFQUFFLE9BQU8sSUFBSSxDQUFDLEdBQUcsT0FBTyxHQUFHLGNBQWMsR0FBRyxXQUFXLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxRQUFRLFdBQVcsSUFBSSxJQUFJLFVBQVUsR0FBRyxlQUFlLEdBQUcsSUFBSSxHQUFHLFVBQVUsR0FBRyxHQUFHLEtBQUssR0FBRztDQUN6TCxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyx3QkFBd0IsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUk7RUFDeEU7RUFDQSxJQUFJLG1DQUFtQztFQUN2QztDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUlGLElBQUUsR0FBRyxHQUFHLENBQUM7Q0FDMUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtFQUNsQyxLQUFLO0VBQ0wsSUFBSTtFQUNKLFdBQVc7RUFDWCxVQUFVO0VBQ1YsT0FBTyxLQUFLLEtBQUs7RUFDakIsY0FBYyxLQUFLLEtBQUs7RUFDeEIsV0FBVyxNQUFNO0dBQ2hCLElBQUksSUFBSSxFQUFFLE9BQU8sVUFBVSxLQUFLLE9BQU8sRUFBRSxPQUFPO0dBQ2hELElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO0VBQ2pCO0VBQ0EsR0FBRztFQUNILFVBQVUsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0dBQzFDLE9BQU87R0FDUCxVQUFVLENBQUM7R0FDWCxVQUFVO0VBQ1gsQ0FBQyxJQUFJLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtHQUN0RCxPQUFPLEVBQUU7R0FDVCxVQUFVLEVBQUU7R0FDWixVQUFVRixLQUFFLENBQUM7RUFDZCxHQUFHQyxLQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztDQUNiLENBQUM7QUFDRixDQUFDO0FBQ0QsRUFBRSxjQUFjOzs7QUN2Q2hCLFNBQVNJLElBQUUsR0FBRztDQUNiLE9BQU8sQ0FBQyxFQUFFLEtBQUssVUFBVSxLQUFLLEVBQUUsU0FBUztBQUMxQztBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLE9BQU8sRUFBRSxTQUFTLEVBQUUsWUFBWTtBQUNqQztBQUNBLFNBQVNDLElBQUUsR0FBRyxHQUFHO0NBQ2hCLE9BQU8sRUFBRSxTQUFTLEVBQUUsU0FBUyxRQUFRO0FBQ3RDO0FBR0EsU0FBUyxFQUFFLEVBQUUsT0FBTyxJQUFJLFFBQVEsZ0JBQWdCLEdBQUcsa0JBQWtCLEdBQUcsV0FBVyxJQUFJLFNBQVMsT0FBTyxJQUFJLENBQUMsR0FBRyxXQUFXLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLGVBQWUsSUFBSSxJQUFJLGVBQWUsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksSUFBSSxHQUFHLGNBQWMsR0FBRyxHQUFHLEtBQUs7Q0FDblEsSUFBSSxDQUFDLEdBQUcsTUFBQSxHQUFLQyxhQUFBQSxTQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLEtBQUEsR0FBSUMsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxLQUFBLEdBQUlBLGFBQUFBLE9BQUFBLENBQUUsSUFBSSxHQUFHLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyx3QkFBd0IsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsaUNBQWlDLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsaUNBQWlDLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQzliLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLElBQUksS0FBSyxNQUFNO0dBQ2QsRUFBRSxrQkFBa0IsUUFBUSxFQUFFLFdBQVcsQ0FBQyxFQUFFLFFBQVEsU0FBUyxFQUFFLE1BQU0sS0FBSyxFQUFFLFdBQVcsQ0FBQyxFQUFFLFFBQVEsU0FBUyxFQUFFLE1BQU0sS0FBSyxFQUFFLENBQUMsQ0FBQztFQUM3SCxHQUFHLEtBQUssTUFBTTtHQUNiLEVBQUUsUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUFDO0VBQzNCO0VBQ0EsT0FBTyxTQUFTLGlCQUFpQixlQUFlLENBQUMsR0FBRyxTQUFTLGlCQUFpQixXQUFXLENBQUMsU0FBUztHQUNsRyxTQUFTLG9CQUFvQixlQUFlLENBQUMsR0FBRyxTQUFTLG9CQUFvQixXQUFXLENBQUM7RUFDMUY7Q0FDRCxHQUFHLENBQUMsQ0FBQyxJQUFBLEdBQUdDLGFBQUFBLGdCQUFBQSxPQUFRO0VBQ2YsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLFNBQVM7RUFDdEIsSUFBSSxVQUFVO0dBQ2IsSUFBSSxJQUFJLEVBQUUsU0FBUyxzQkFBc0IsR0FBRyxJQUFJLEVBQUUsU0FBUyxzQkFBc0IsR0FBRyxJQUFJLEVBQUU7R0FDMUYsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRztHQUNwQixJQUFJLElBQUksS0FBSyxJQUFJLEVBQUUsT0FBTyxFQUFFLEtBQUssR0FBRyxJQUFJLE9BQU8sYUFBYSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsRUFBRSxRQUFRLElBQUksRUFBRSxNQUFNLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRyxFQUFFLFNBQVMsRUFBRTtHQUN6SyxFQUFFLE1BQU0sV0FBVyxTQUFTLEVBQUUsTUFBTSxNQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxPQUFPLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxRQUFRLFFBQVEsRUFBRSxNQUFNLFdBQVcsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLGFBQWE7RUFDeEo7RUFDQSxPQUFPLEVBQUUsWUFBWSxFQUFFLFFBQVEsTUFBTSxhQUFhLFdBQVcsRUFBRSxHQUFHLE9BQU8saUJBQWlCLFVBQVUsQ0FBQyxHQUFHLE9BQU8saUJBQWlCLFVBQVUsR0FBRyxDQUFDLENBQUMsU0FBUztHQUN2SixPQUFPLG9CQUFvQixVQUFVLENBQUMsR0FBRyxPQUFPLG9CQUFvQixVQUFVLEdBQUcsQ0FBQyxDQUFDO0VBQ3BGO0NBQ0QsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0NBQ1QsSUFBSSxLQUFLLEdBQUcsTUFBTTtFQUNqQixJQUFJLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxVQUFVO0dBQ3RCLEVBQUUsZUFBZTtHQUNqQjtFQUNEO0VBQ0EsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLFdBQVcsR0FBRyxDQUFDO0NBQzdCO0NBQ0EsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixLQUFLO0VBQ0wsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7R0FDdEMsS0FBSztHQUNMLE1BQU07R0FDTixXQUFXO0dBQ1gsaUJBQWlCO0dBQ2pCLGlCQUFpQjtHQUNqQixjQUFjLEtBQUs7R0FDbkIsZUFBZSxHQUFHLE1BQU0sQ0FBQyxDQUFDO0dBQzFCLFVBQVUsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUVDLG1CQUFBQSxVQUFHLEVBQUUsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQzFFLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0lBQzdCLFdBQVc7SUFDWCxlQUFlO0lBQ2YsVUFBVTtHQUNYLENBQUMsQ0FBQyxFQUFFLENBQUM7RUFDTixDQUFDLEdBQUcsS0FBSyxPQUFPLFdBQVcsT0FBQSxHQUFNQyxpQkFBQUEsYUFBQUEsQ0FBa0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztHQUMzRCxLQUFLO0dBQ0wsSUFBSTtHQUNKLFdBQVc7R0FDWCxjQUFjO0dBQ2QsVUFBVSxFQUFFLEtBQUssR0FBRyxNQUFNO0lBQ3pCLElBQUlSLElBQUUsQ0FBQyxHQUFHLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDekMsV0FBVztLQUNYLE1BQU07S0FDTixlQUFlO0lBQ2hCLEdBQUcsV0FBVyxHQUFHO0lBQ2pCLElBQUksSUFBSUMsSUFBRSxDQUFDLEdBQUcsSUFBSTtLQUNqQjtLQUNBLEVBQUUsV0FBVyx5Q0FBeUM7S0FDdEQsRUFBRSxTQUFTLHVDQUF1QztJQUNuRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJO0tBQ2hDLFdBQVc7S0FDWCxpQkFBaUIsRUFBRSxZQUFZLEtBQUs7SUFDckM7SUFDQSxPQUFPLEVBQUUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsS0FBSztLQUN0QyxHQUFHO0tBQ0gsTUFBTSxFQUFFLFdBQVcsS0FBSyxJQUFJLEVBQUU7S0FDOUIsVUFBVSxNQUFNLEVBQUUsR0FBRyxDQUFDO0tBQ3RCLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUNwQyxXQUFXO01BQ1gsVUFBVTtLQUNYLENBQUMsR0FBRyxFQUFFLGNBQThCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDN0MsV0FBVztNQUNYLFVBQVUsRUFBRTtLQUNiLENBQUMsSUFBSSxJQUFJO0lBQ1YsR0FBR0MsSUFBRSxHQUFHLENBQUMsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO0tBQ3pDLE1BQU07S0FDTixXQUFXO0tBQ1gsVUFBVSxFQUFFO0tBQ1osVUFBVSxNQUFNLEVBQUUsR0FBRyxDQUFDO0tBQ3RCLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUNwQyxXQUFXO01BQ1gsVUFBVTtLQUNYLENBQUMsR0FBRyxFQUFFLGNBQThCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDN0MsV0FBVztNQUNYLFVBQVUsRUFBRTtLQUNiLENBQUMsSUFBSSxJQUFJO0lBQ1YsR0FBR0EsSUFBRSxHQUFHLENBQUMsQ0FBQztHQUNYLENBQUM7RUFDRixDQUFDLEdBQUcsU0FBUyxJQUFJLElBQUksSUFBSTtDQUMxQixDQUFDO0FBQ0Y7OztBQzVHQSxJQUFJTyxNQUFJO0NBQ1AsT0FBTztDQUNQLE1BQU07Q0FDTixLQUFLO0NBQ0wsUUFBUTtBQUNUO0FBQUdDLElBQUFBLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLENBQUUsU0FBUyxFQUFFLE9BQU8sSUFBSSxZQUFZLGVBQWUsSUFBSSxTQUFTLFdBQVcsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsVUFBVSxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQ3hLLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLG9CQUFvQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUNwRTtFQUNBLElBQUksK0JBQStCO0VBQ25DSCxJQUFFLE1BQU1BLElBQUU7RUFDVjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQ3RKLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7RUFDakMsV0FBVztFQUNYLFNBQVM7RUFDVCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDckMsS0FBSztHQUNMLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLFVBQVU7R0FDVixHQUFHO0VBQ0osQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO0dBQzdCLFdBQVc7R0FDWCxVQUFVO0VBQ1gsQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7QUFHaEIsSUFBSUksTUFBSTtDQUNQLE9BQU87Q0FDUCxNQUFNO0NBQ04sS0FBSztDQUNMLFFBQVE7QUFDVDtBQUdBLFNBQVNDLElBQUUsRUFBRSxPQUFPLElBQUksZ0JBQWdCLGVBQWUsSUFBSSxTQUFTLFdBQVcsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsR0FBRyxLQUFLO0NBQ3JKLElBQUksSUFBSSxFQUFFLGFBQWEsQ0FBQyxHQUFHLEtBQUEsR0FBSUYsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyx1QkFBdUIsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUk7RUFDOUY7RUFDQSxJQUFJLGtDQUFrQztFQUN0Q0MsSUFBRSxNQUFNQSxJQUFFO0VBQ1Y7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUM1SixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO0VBQ2pDLFdBQVc7RUFDWCxTQUFTO0VBQ1QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0dBQ3JDLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLEdBQUc7RUFDSixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7R0FDN0IsV0FBVztHQUNYLFVBQVU7RUFDWCxDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0Y7QUFHQSxJQUFJRSxPQUFBQSxHQUFJSixhQUFBQSxXQUFBQSxFQUFHLEVBQUUsT0FBTyxHQUFHLFdBQVcsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLEdBQUcsUUFBUSxJQUFJLFlBQVksR0FBRyxLQUFLLE1BQU07Q0FDbkosSUFBSSxLQUFBLEdBQUlDLGFBQUFBLE1BQUFBLENBQUUsR0FBRyxJQUFJLEtBQUssb0JBQW9CLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDalAsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDekMsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0VBQ1gsQ0FBQyxJQUFJLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFlBQVk7R0FDeEMsS0FBSztHQUNMLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLGVBQWU7R0FDZixHQUFHO0VBQ0osQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7QUFHaEIsSUFBSUksTUFBSTtDQUNQLE1BQU07Q0FDTixLQUFLO0NBQ0wsTUFBTTtBQUNQO0FBQUdDLElBQUFBLE9BQUFBLEdBQUlOLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxPQUFPLEdBQUcsZUFBZSxJQUFJLE9BQU8sV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksR0FBRyxNQUFNLElBQUksUUFBUSxHQUFHLEtBQUssTUFBTTtDQUN6SixJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxtQkFBbUIsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUk7RUFDbkU7RUFDQSxJQUFJSSxJQUFFLE1BQU1BLElBQUUsTUFBTTtFQUNwQjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQ3BKLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztFQUNYLFVBQVUsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0dBQ3pDLFdBQVc7R0FDWCxTQUFTO0dBQ1QsVUFBVTtFQUNYLENBQUMsSUFBSSxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0dBQ3JDLEtBQUs7R0FDTCxJQUFJO0dBQ0osV0FBVztHQUNYLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQyxDQUFDO0NBQ0gsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFFLGNBQWM7QUFHaEIsU0FBU0UsSUFBRSxHQUFHO0NBQ2IsT0FBTyxPQUFPLEtBQUssWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sUUFBUSxDQUFDO0FBQ3ZEO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxDQUFDLEtBQUssRUFBRSxTQUFTLFlBQVksQ0FBQ0QsSUFBRSxFQUFFLFVBQVUsSUFBSSxDQUFDLElBQUksT0FBTyxZQUFZLE9BQU8sUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHRSxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkk7QUFDQSxTQUFTQSxJQUFFLEdBQUc7Q0FDYixJQUFJLENBQUMsS0FBSyxDQUFDRixJQUFFLENBQUMsR0FBRyxPQUFPO0NBQ3hCLElBQUksRUFBRSxZQUFZLEtBQUssR0FBRyxPQUFPLEVBQUU7Q0FDbkMsSUFBSSxNQUFNLFFBQVEsRUFBRSxJQUFJLEtBQUssRUFBRSxLQUFLLFNBQVMsR0FBRyxPQUFPLEVBQUUsS0FBSztDQUM5RCxRQUFRLEVBQUUsTUFBVjtFQUNDLEtBQUssV0FBVyxPQUFPLENBQUM7RUFDeEIsS0FBSztFQUNMLEtBQUssVUFBVSxPQUFPO0VBQ3RCLEtBQUssVUFBVSxPQUFPQyxJQUFFLENBQUM7RUFDekIsU0FBUyxPQUFPO0NBQ2pCO0FBQ0Q7QUFDQSxTQUFTRSxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLENBQUMsS0FBSyxDQUFDSCxJQUFFLENBQUMsR0FBRyxPQUFPO0NBQ3hCLElBQUksRUFBRSxTQUFTLFlBQVlBLElBQUUsRUFBRSxVQUFVLEdBQUc7RUFDM0MsSUFBSSxJQUFJQSxJQUFFLENBQUMsSUFBSSxJQUFJLENBQUM7RUFDcEIsT0FBTyxPQUFPLFlBQVksT0FBTyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsT0FBTyxDQUFDLEdBQUdHLElBQUUsR0FBRyxFQUFFLE9BQU8sS0FBSyxJQUFJRCxJQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7Q0FDakg7Q0FDQSxJQUFJLEVBQUUsU0FBUyxXQUFXLE9BQU8sTUFBTSxDQUFDO0NBQ3hDLElBQUksRUFBRSxTQUFTLFdBQVc7RUFDekIsSUFBSSxNQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU87RUFDbEMsSUFBSSxJQUFJLE9BQU8sU0FBUyxPQUFPLENBQUMsR0FBRyxFQUFFO0VBQ3JDLE9BQU8sT0FBTyxNQUFNLENBQUMsSUFBSSxLQUFLO0NBQy9CO0NBQ0EsSUFBSSxFQUFFLFNBQVMsVUFBVTtFQUN4QixJQUFJLE1BQU0sTUFBTSxLQUFLLE1BQU0sT0FBTztFQUNsQyxJQUFJLElBQUksT0FBTyxXQUFXLE9BQU8sQ0FBQyxDQUFDO0VBQ25DLE9BQU8sT0FBTyxNQUFNLENBQUMsSUFBSSxLQUFLO0NBQy9CO0NBQ0EsT0FBTyxLQUFLO0FBQ2I7QUFDQSxTQUFTRSxJQUFFLEdBQUc7Q0FDYixPQUFPLENBQUMsS0FBSyxDQUFDSixJQUFFLENBQUMsSUFBSSxZQUFZLE1BQU0sUUFBUSxFQUFFLElBQUksS0FBSyxFQUFFLEtBQUssU0FBUyxJQUFJLFVBQVUsRUFBRSxTQUFTLFdBQVcsRUFBRSxjQUFjLEtBQUssS0FBSyxFQUFFLFlBQVksS0FBSyxhQUFhLFlBQVksRUFBRSxTQUFTLFlBQVksUUFBUSxFQUFFLFNBQVMsV0FBVyxPQUFPLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQyxZQUFZLE1BQU0sWUFBWSxZQUFZLFdBQVcsRUFBRSxTQUFTLFlBQVksU0FBUztBQUN0VjtBQUdBLElBQUlLLE1BQUk7Q0FDUCxNQUFNO0NBQ04sWUFBWSxDQUFDO0FBQ2Q7QUFDQSxTQUFTQyxJQUFFLEVBQUUsUUFBUSxHQUFHLE1BQU0sR0FBRyxPQUFPLEdBQUcsVUFBVSxLQUFLO0NBQ3pELElBQUksSUFBSSxFQUFFLFNBQVMsR0FBRyxJQUFJLEVBQUUsYUFBYSxJQUFJRixJQUFFLENBQUMsR0FBRyxJQUFJLEtBQUtGLElBQUUsQ0FBQztDQUMvRCxJQUFJLE1BQU0sU0FBUztFQUNsQixJQUFJLElBQUksTUFBTSxRQUFRLEVBQUUsSUFBSSxJQUFJLEVBQUUsT0FBTyxDQUFDO0VBQzFDLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFlBQVk7R0FDcEMsV0FBVztHQUNYLFVBQVU7SUFDTyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0tBQzNCLFdBQVc7S0FDWCxVQUFVO0lBQ1gsQ0FBQztJQUNELElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLEtBQUs7S0FDMUIsV0FBVztLQUNYLFVBQVU7SUFDWCxDQUFDLElBQUk7SUFDVyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQ3hCLFdBQVc7S0FDWCxVQUFVLEVBQUUsS0FBSyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRU4sS0FBRztNQUMzQyxPQUFPLE9BQU8sQ0FBQztNQUNmLE1BQU07TUFDTixTQUFTLE1BQU07TUFDZixnQkFBZ0IsRUFBRSxDQUFDO0tBQ3BCLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNkLENBQUM7R0FDRjtFQUNELENBQUM7Q0FDRjtDQUNBLE9BQU8sTUFBTSxhQUE2QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUMsS0FBRztFQUM5QyxPQUFPO0VBQ1AsTUFBTTtFQUNOLE9BQU8sT0FBTyxLQUFLLEVBQUU7RUFDckIsYUFBYSxPQUFPLEVBQUUsV0FBVyxFQUFFO0VBQ25DLFdBQVcsTUFBTSxFQUFFLEVBQUUsT0FBTyxLQUFLO0NBQ2xDLENBQUMsSUFBSSxNQUFNLFNBQXlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFTCxLQUFHO0VBQ3hDLE9BQU87RUFDUCxTQUFTLE1BQU0sQ0FBQztFQUNoQixXQUFXLE1BQU0sRUFBRSxFQUFFLE9BQU8sT0FBTztDQUNwQyxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFTyxLQUFHO0VBQ3pCLE9BQU87RUFDUCxNQUFNLE1BQU0sU0FBUyxNQUFNLGFBQWEsTUFBTSxXQUFXLFdBQVc7RUFDcEUsTUFBTSxNQUFNLFFBQVEsSUFBSSxNQUFNLGFBQWEsTUFBTSxXQUFXLFFBQVEsS0FBSztFQUN6RSxPQUFPLE9BQU8sS0FBSyxFQUFFO0VBQ3JCLGFBQWEsT0FBTyxFQUFFLFdBQVcsRUFBRTtFQUNuQyxXQUFXLE1BQU07R0FDaEIsSUFBSSxJQUFJLEVBQUUsT0FBTztHQUNqQixJQUFJLE1BQU0sT0FBTztJQUNoQixFQUFFLE1BQU0sS0FBSyxLQUFLLE9BQU8sU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN4QztHQUNEO0dBQ0EsSUFBSSxNQUFNLGFBQWEsTUFBTSxVQUFVO0lBQ3RDLEVBQUUsTUFBTSxLQUFLLEtBQUssT0FBTyxXQUFXLENBQUMsQ0FBQztJQUN0QztHQUNEO0dBQ0EsRUFBRSxDQUFDO0VBQ0o7Q0FDRCxDQUFDO0FBQ0Y7QUFDQSxJQUFJLEtBQUEsR0FBSU4sYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsUUFBUSxHQUFHLE9BQU8sR0FBRyxVQUFVLEdBQUcsV0FBVyxJQUFJLElBQUksSUFBSSxHQUFHLFVBQVUsSUFBSSxDQUFDLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDN0csSUFBSSxLQUFBLEdBQUlDLGFBQUFBLE1BQUFBLENBQUUsR0FBRyxJQUFJLEtBQUssdUJBQXVCLEVBQUUsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLFdBQVcsSUFBSVcsS0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLRSxhQUFBQSxTQUFBQSxPQUFRSixJQUFFLEdBQUcsS0FBS0YsSUFBRSxDQUFDLENBQUMsQ0FBQztDQUMxSSxDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxFQUFFRSxJQUFFLEdBQUcsS0FBS0YsSUFBRSxDQUFDLENBQUMsQ0FBQztDQUNsQixHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDVCxJQUFJLElBQUlELElBQUUsQ0FBQyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksRUFBRSxTQUFTLGdCQUFnQixJQUFJLEVBQUUsYUFBYSxJQUFJO0VBQzVFO0VBQ0EsSUFBSSxrQ0FBa0M7RUFDdEM7Q0FDRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxLQUFLLE1BQU07RUFDdkMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDO0NBQ1o7Q0FDQSxPQUFPLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDbkMsS0FBSztFQUNMLElBQUk7RUFDSixXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLEdBQUc7RUFDSCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87R0FDbkMsV0FBVztHQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNuQyxXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsR0FBRyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQ2hDLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxJQUFJLElBQUk7RUFDVixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDNUIsV0FBVztHQUNYLFVBQVUsT0FBTyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDckYsV0FBVztJQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFTSxLQUFHO0tBQzlCLFFBQVE7S0FDUixNQUFNO0tBQ04sT0FBTyxFQUFFO0tBQ1QsV0FBVyxNQUFNLEVBQUU7TUFDbEIsR0FBRztPQUNGLElBQUlILElBQUUsR0FBRyxDQUFDO0tBQ1osQ0FBQztJQUNGLENBQUM7R0FDRixHQUFHLENBQUMsQ0FBQztFQUNOLENBQUMsQ0FBQztDQUNILENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUM3QixLQUFLO0VBQ0wsSUFBSTtFQUNKLFdBQVc7RUFDWCxHQUFHO0VBQ0gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0dBQ25DLFdBQVc7R0FDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDbkMsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLEdBQUcsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNoQyxXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsSUFBSSxJQUFJO0VBQ1YsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0dBQzVCLFdBQVc7R0FDWCxVQUFVLE9BQU8sUUFBUSxFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQ3JGLFdBQVc7SUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUcsS0FBRztLQUM5QixRQUFRO0tBQ1IsTUFBTTtLQUNOLE9BQU8sRUFBRTtLQUNULFdBQVcsTUFBTSxFQUFFO01BQ2xCLEdBQUc7T0FDRixJQUFJSCxJQUFFLEdBQUcsQ0FBQztLQUNaLENBQUM7SUFDRixDQUFDO0dBQ0YsR0FBRyxDQUFDLENBQUM7RUFDTixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELEVBQUUsY0FBYzs7O0FDL1JoQixTQUFTSyxLQUFFLEdBQUc7Q0FDYixPQUFPLEtBQUssTUFBTSxRQUFRLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUEsQ0FBRyxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUUsV0FBVyxHQUFHLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQzVKO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxHQUFHLElBQUlELEtBQUUsQ0FBQztDQUN4RixPQUFPLENBQUMsbUJBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDakM7QUFDQSxTQUFTRSxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLElBQUksRUFBRSxLQUFLLFlBQVksR0FBRyxLQUFLLEVBQUUsUUFBUSxHQUFBLENBQUksWUFBWTtDQUM3RCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxTQUFTLElBQUksSUFBSSxFQUFFLFdBQVcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUksRUFBRSxXQUFXLEdBQUcsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJLE1BQU07QUFDdkg7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLEVBQUUsV0FBVyxHQUFHLE9BQU87RUFDMUIsZUFBZTtFQUNmLGVBQWUsQ0FBQztDQUNqQjtDQUNBLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO0NBQ2pCLEtBQUssSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLE1BQU0sTUFBTUQsSUFBRSxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBQSxDQUFHLEtBQUssQ0FBQztDQUN4RCxPQUFPO0VBQ04sZUFBZTtFQUNmLGVBQWU7Q0FDaEI7QUFDRDtBQUdBLFNBQVMsRUFBRSxFQUFFLE9BQU8sSUFBSSx5Q0FBeUMsYUFBYSxJQUFJLG1FQUFtRSxRQUFRLElBQUksSUFBSSxZQUFZLElBQUksQ0FBQyxHQUFHLFVBQVUsSUFBSSxDQUFDLEdBQUcsVUFBVSxJQUFJLENBQUMsR0FBRyxXQUFXLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksc0JBQXNCLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksSUFBSSxHQUFHLGlCQUFpQixHQUFHLEdBQUcsS0FBSztDQUNuWixJQUFJLEtBQUEsR0FBSUUsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxzQkFBc0IsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLEtBQUEsR0FBSUMsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0MsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLENBQUMsR0FBRyxJQUFJTCxJQUFFLEdBQUcsQ0FBQyxHQUFHLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSTtFQUN6SjtFQUNBLElBQUksaUNBQWlDO0VBQ3JDLElBQUksa0NBQWtDO0VBQ3RDO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsTUFBTTtFQUNuWCxJQUFJLEVBQUUsZUFBZSxHQUFHLGVBQWUsTUFBTUUsSUFBRSxNQUFNLEtBQUssS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO0VBQ3JFLElBQUk7R0FDSCxlQUFlO0dBQ2YsZUFBZTtHQUNmLFFBQVE7RUFDVCxDQUFDO0NBQ0YsR0FBRyxVQUFVO0VBQ1osS0FBSyxFQUFFLFNBQVMsTUFBTTtDQUN2QixHQUFHLEtBQUssTUFBTTtFQUNiLEVBQUUsRUFBRSxPQUFPLE9BQU8sT0FBTyxHQUFHLEVBQUUsT0FBTyxRQUFRO0NBQzlDLEdBQUcsS0FBSyxNQUFNO0VBQ2IsRUFBRSxlQUFlLEdBQUcsS0FBSyxFQUFFLENBQUMsQ0FBQztDQUM5QixHQUFHLEtBQUssTUFBTTtFQUNiLEVBQUUsZUFBZSxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQztDQUN6RCxHQUFHLEtBQUssTUFBTTtFQUNiLEVBQUUsZUFBZSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxhQUFhLE9BQU8sTUFBTTtDQUNoRSxHQUFHLEtBQUssTUFBTTtFQUNiLENBQUMsRUFBRSxRQUFRLFdBQVcsRUFBRSxRQUFRLFNBQVMsRUFBRSxlQUFlLEdBQUcsRUFBRTtDQUNoRTtDQUNBLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0dBQ2xDLFdBQVc7R0FDWCxNQUFNO0dBQ04sVUFBVSxJQUFJLEtBQUs7R0FDbkIsY0FBYztHQUNkLGlCQUFpQixJQUFJLFNBQVMsS0FBSztHQUNuQyxTQUFTO0dBQ1QsV0FBVztHQUNYLFlBQVk7R0FDWixhQUFhO0dBQ2IsUUFBUTtHQUNSLFVBQVU7SUFDTyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0tBQzFCLEtBQUs7S0FDTCxJQUFJO0tBQ0osV0FBVztLQUNYLE1BQU07S0FDTixRQUFRO0tBQ1IsVUFBVTtLQUNWLFVBQVU7S0FDVixjQUFjO0tBQ2QsT0FBTztLQUNQLFVBQVU7SUFDWCxDQUFDO0lBQ2UsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztLQUN4QixXQUFXO0tBQ1gsVUFBVTtNQUNPLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7T0FDekIsV0FBVztPQUNYLFVBQVU7TUFDWCxDQUFDO01BQ0QsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtPQUM3QixXQUFXO09BQ1gsVUFBVTtNQUNYLENBQUMsSUFBSTtNQUNXLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFFBQVE7T0FDekIsV0FBVztPQUNYLFVBQVUsQ0FBQyxFQUFFLFNBQVMsSUFBSSxhQUFhLEVBQUUsS0FBSyxJQUFJLE1BQU0sdUJBQXVCLElBQUksc0JBQXNCLGdCQUFnQjtNQUMxSCxDQUFDO0tBQ0Y7SUFDRCxDQUFDO0lBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtLQUMzQixNQUFNO0tBQ04sV0FBVztLQUNYLFVBQVU7S0FDVixVQUFVLE1BQU07TUFDZixFQUFFLGdCQUFnQixHQUFHLEVBQUU7S0FDeEI7S0FDQSxVQUFVO0lBQ1gsQ0FBQztHQUNGO0VBQ0QsQ0FBQztDQUNGLENBQUM7QUFDRjs7O0FDM0dBLFNBQVNJLElBQUUsRUFBRSxjQUFjLEdBQUcsVUFBVSxHQUFHLGFBQWEsR0FBRyxtQkFBbUIsR0FBRyxVQUFVLEdBQUcsb0JBQW9CLEdBQUcsa0JBQWtCLEdBQUcsYUFBYSxHQUFHLG1CQUFtQixLQUFLO0NBQ2pMLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztFQUNYLE1BQU07RUFDTixjQUFjO0VBQ2QsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0dBQ3RDLE1BQU07R0FDTixXQUFXO0dBQ1gsU0FBUztHQUNULGNBQWMsSUFBSSxtQkFBbUI7R0FDckMsT0FBTyxJQUFJLG1CQUFtQjtHQUM5QixVQUFVLElBQUksTUFBTTtFQUNyQixDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0dBQy9DLFdBQVc7R0FDWCxnQkFBZ0IsRUFBRTtHQUNsQixVQUFVLENBQUMsRUFBRSxTQUF5QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQzlDLFdBQVc7SUFDWCxVQUFVLEVBQUU7R0FDYixDQUFDLEdBQUcsRUFBRSxNQUFNLEtBQUssTUFBTTtJQUN0QixJQUFJLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxJQUFJLElBQUksRUFBRSxTQUFTLFFBQVEsSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJLEVBQUUsaUJBQWlCLDRCQUE0QixFQUFFO0lBQ25ILE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7S0FDbEMsTUFBTTtLQUNOLFdBQVc7TUFDVjtNQUNBLElBQUksZ0NBQWdDO01BQ3BDLElBQUksa0NBQWtDO0tBQ3ZDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztLQUMxQixVQUFVO0tBQ1YsZUFBZSxFQUFFLEdBQUcsRUFBRSxFQUFFO0tBQ3hCLHFCQUFxQixFQUFFLEdBQUcsRUFBRSxFQUFFO0tBQzlCLGVBQWUsSUFBSSxTQUFTO0tBQzVCLGFBQWEsRUFBRTtLQUNmLE9BQU8sSUFBSSxJQUFJLEVBQUU7S0FDakIsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQ3BDLFdBQVcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO01BQ2xELGVBQWU7S0FDaEIsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO01BQzdCLFdBQVc7TUFDWCxVQUFVLEVBQUU7S0FDYixDQUFDLENBQUM7SUFDSCxHQUFHLEVBQUUsRUFBRTtHQUNSLENBQUMsQ0FBQztFQUNILEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztDQUNWLENBQUM7QUFDRjtBQUdBLElBQUlDLE1BQUk7Q0FDUCxJQUFJO0NBQ0osT0FBTztDQUNQLE9BQU87RUFDTjtHQUNDLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLFVBQVU7RUFDWDtFQUNBO0dBQ0MsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sVUFBVTtFQUNYO0VBQ0E7R0FDQyxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixVQUFVO0VBQ1g7RUFDQTtHQUNDLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLFVBQVU7RUFDWDtFQUNBO0dBQ0MsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0VBQ1A7Q0FDRDtBQUNEO0FBQUdDLElBQUFBLE1BQUksQ0FBQ0QsR0FBQztBQUFHLElBQUEsSUFBSTtDQUNmLElBQUk7Q0FDSixPQUFPO0NBQ1AsT0FBTztFQUNOO0dBQ0MsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sVUFBVTtFQUNYO0VBQ0E7R0FDQyxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixVQUFVO0VBQ1g7RUFDQTtHQUNDLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLFVBQVU7RUFDWDtFQUNBO0dBQ0MsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sVUFBVTtFQUNYO0VBQ0E7R0FDQyxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixlQUFlO0VBQ2hCO0NBQ0Q7QUFDRDtBQUFHRSxJQUFBQSxNQUFJLENBQUMsQ0FBQztBQUFHQyxJQUFBQSxNQUFJO0NBQ2YsUUFBUTtDQUNSLFFBQVE7Q0FDUixXQUFXO0NBQ1gsU0FBUztDQUNULFlBQVk7Q0FDWixVQUFVO0NBQ1YsV0FBVztDQUNYLFNBQVM7Q0FDVCxNQUFNO0FBQ1A7QUFBR0MsSUFBQUEsTUFBSTtDQUNOLFFBQVE7RUFDUCxPQUFPO0VBQ1AsUUFBUTtDQUNUO0NBQ0EsUUFBUTtFQUNQLE9BQU87RUFDUCxRQUFRO0NBQ1Q7Q0FDQSxXQUFXO0VBQ1YsT0FBTztFQUNQLFFBQVE7Q0FDVDtDQUNBLFNBQVM7RUFDUixPQUFPO0VBQ1AsUUFBUTtDQUNUO0NBQ0EsWUFBWTtFQUNYLE9BQU87RUFDUCxRQUFRO0NBQ1Q7Q0FDQSxVQUFVO0VBQ1QsT0FBTztFQUNQLFFBQVE7Q0FDVDtDQUNBLFdBQVc7RUFDVixPQUFPO0VBQ1AsUUFBUTtDQUNUO0NBQ0EsU0FBUztFQUNSLE9BQU87RUFDUCxRQUFRO0NBQ1Q7QUFDRDtBQUFHQyxJQUFBQSxNQUFJO0NBQ04sUUFBUTtDQUNSLG9CQUFvQjtBQUNyQjtBQUFHQyxJQUFBQSxNQUFJO0FBQUlDLElBQUFBLE1BQUk7QUFBS0MsSUFBQUEsTUFBSTtDQUN2QiwwQkFBMEI7Q0FDMUIsd0JBQXdCO0NBQ3hCLHVCQUF1QjtDQUN2QixzQkFBc0I7QUFDdkI7QUFBR0MsSUFBQUEsWUFBVSxPQUFPLFNBQVMsT0FBTyxnQkFBZ0IsU0FBUyxPQUFPLFdBQVcsSUFBSSxHQUFHLEtBQUssSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUUsR0FBRyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQUtDLElBQUFBLFFBQU0sR0FBRyxHQUFHLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQUdDLElBQUFBLE9BQUssR0FBRyxNQUFNSCxJQUFFLEdBQUcsRUFBRSxJQUFJLFFBQVE7QUFBTUksSUFBQUEsT0FBSyxHQUFHLEdBQUcsR0FBRyxNQUFNO0NBQ2pRLElBQUksSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLENBQUM7Q0FDL0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLE9BQU87RUFDcEIsU0FBUyxDQUFDO0VBQ1YsT0FBTztDQUNSO0NBQ0EsSUFBSSxJQUFJRCxJQUFFLEVBQUUsTUFBTSxFQUFFLElBQUk7Q0FDeEIsSUFBSSxDQUFDLEtBQUssRUFBRSxTQUFTLGNBQWMsRUFBRSxTQUFTLGVBQWUsRUFBRSxNQUFNLE1BQU0sRUFBRSxXQUFXLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEVBQUUsU0FBUyxjQUFjLENBQUMsQ0FBQyxHQUFHLE9BQU87RUFDOUosU0FBUyxDQUFDO0VBQ1YsT0FBTztDQUNSO0NBQ0EsSUFBSSxFQUFFLFNBQVMsZ0JBQWdCLEVBQUUsU0FBUyxjQUFjO0VBQ3ZELElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxTQUFTLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsU0FBUyxlQUFlLENBQUMsQ0FBQyxHQUFHLE9BQU87R0FDdEcsU0FBUyxDQUFDO0dBQ1YsT0FBTztFQUNSO0VBQ0EsSUFBSSxvQkFBb0IsSUFBSSxJQUFJO0VBQ2hDLEtBQUssSUFBSSxLQUFLLEdBQUc7R0FDaEIsSUFBSSxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sR0FBRyxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUk7R0FDM0UsSUFBSSxHQUFHLFNBQVMsZ0JBQWdCLEdBQUcsU0FBUyxjQUFjO0dBQzFELElBQUksSUFBSSxFQUFFLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztHQUM1QixFQUFFLEtBQUssRUFBRSxJQUFJLEdBQUcsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO0VBQ2xDO0VBQ0EsTUFBTSxHQUFHLE1BQU07R0FDZCxJQUFJLElBQUksQ0FBQyxDQUFDLEdBQUcsb0JBQW9CLElBQUksSUFBSTtHQUN6QyxPQUFPLEVBQUUsU0FBUyxJQUFJO0lBQ3JCLElBQUksSUFBSSxFQUFFLElBQUk7SUFDZCxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxHQUFHO0lBQ3BCLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQztJQUNyQixFQUFFLElBQUksQ0FBQztJQUNQLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDckIsS0FBSyxJQUFJLEtBQUssR0FBRyxFQUFFLEtBQUssQ0FBQztHQUMxQjtHQUNBLE9BQU8sQ0FBQztFQUNULEVBQUEsQ0FBRyxHQUFHLENBQUMsR0FBRyxPQUFPO0dBQ2hCLFNBQVMsQ0FBQztHQUNWLE9BQU87RUFDUjtDQUNEO0NBQ0EsT0FBTztFQUNOLFNBQVMsQ0FBQztFQUNWLE9BQU87Q0FDUjtBQUNEO0FBQUdFLElBQUFBLFFBQU0sR0FBRyxHQUFHLElBQUksTUFBTTtDQUN4QixJQUFJLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxRQUFRLFFBQVEsR0FBRztDQUNwQyxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsRUFBRTtDQUNsQixJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLElBQUksTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJLEVBQUUsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSTtDQUMvRSxLQUFLLElBQUksS0FBSyxHQUFHO0VBQ2hCLElBQUksSUFBSTtFQUNSLE9BQU8sRUFBRSxTQUFTLElBQUk7R0FDckIsSUFBSSxJQUFJLEVBQUUsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJO0dBQzVCLElBQUksSUFBSSxFQUFFLE1BQU0sSUFBSSxDQUFDLEdBQUcsRUFBRSxTQUFTLE1BQU0sRUFBRSxLQUFLLENBQUMsR0FBRyxJQUFJLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRyxFQUFFLFVBQVUsR0FBRztJQUN0RixJQUFJLElBQUksRUFBRSxNQUFNLEdBQUcsQ0FBQztJQUNwQixPQUFPLEVBQUUsSUFBSSxLQUFLLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJO0dBQ2hFO0VBQ0Q7RUFDQSxJQUFJLElBQUksRUFBRSxTQUFTLElBQUksR0FBRyxFQUFFLEdBQUcsTUFBTTtFQUNyQyxJQUFJLEVBQUUsVUFBVSxHQUFHO0dBQ2xCLElBQUk7R0FDSjtFQUNEO0VBQ0EsSUFBSSxFQUFFLFNBQVMsS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLFVBQVUsR0FBRztDQUN0RDtDQUNBLElBQUksRUFBRSxTQUFTLEtBQUssRUFBRSxTQUFTLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRyxFQUFFLFVBQVUsR0FBRyxPQUFPO0NBQ3JFLElBQUksSUFBSSxFQUFFLE1BQU0sR0FBRyxDQUFDO0NBQ3BCLE9BQU8sRUFBRSxJQUFJLEtBQUssR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDLE1BQU0sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUk7QUFDaEU7QUFBRyxJQUFBLEtBQUEsR0FBSUMsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsV0FBVyxHQUFHLGNBQWMsSUFBSSxTQUFTLFNBQVMsSUFBSSxVQUFVLFVBQVUsR0FBRyxrQkFBa0IsSUFBSWYsS0FBRyxZQUFZLEdBQUcsYUFBYSxHQUFHLEdBQUcsTUFBTSxHQUFHO0NBQ3BLLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxTQUFTLElBQUksSUFBSU0sSUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLE1BQU0sb0JBQW9CLEtBQUEsR0FBSVUsYUFBQUEsUUFBQUEsT0FBUSxLQUFLLEVBQUUsU0FBUyxJQUFJLElBQUksTUFBTSxxQkFBcUJiLE1BQUlELEtBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUEsR0FBSWUsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0MsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtBLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxNQUFBLEdBQUtBLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFO0VBQ25WLE9BQU87RUFDUCxTQUFTO0VBQ1QsU0FBUztDQUNWLENBQUMsR0FBRyxLQUFBLEdBQUlELGFBQUFBLE9BQUFBLENBQUUsQ0FBQztDQUNYLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLEVBQUUsVUFBVTtDQUNiLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBQSxHQUFHRSxhQUFBQSxVQUFBQSxPQUFRO0VBQ2hCLEdBQUcsTUFBTTtHQUNSLElBQUksSUFBSSxDQUFDO0dBQ1QsS0FBSyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsTUFBTSxFQUFFLEVBQUUsT0FBTztHQUN0QyxPQUFPO0VBQ1IsQ0FBQztDQUNGLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBQSxHQUFHQSxhQUFBQSxVQUFBQSxPQUFRO0VBQ2hCLElBQUksb0JBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDO0VBQ3hCLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxPQUFPLEVBQUUsU0FBUyxVQUFVLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxRQUFRO0VBQzNGLEdBQUcsTUFBTSxFQUFFLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQztDQUMxQixHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDVCxJQUFJLE1BQUEsR0FBS0gsYUFBQUEsUUFBQUEsT0FBUSxhQUFhLEVBQUUsUUFBUSxJQUFJLEVBQUUsUUFBUSxVQUFVLEVBQUUsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBQSxHQUFJSSxhQUFBQSxZQUFBQSxFQUFHLEdBQUcsR0FBRyxNQUFNO0VBQ3BHLElBQUksRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLFNBQVMsTUFBTSxFQUFFO0VBQzdDLE9BQU87R0FDTixJQUFJLElBQUksRUFBRSxPQUFPLEtBQUs7R0FDdEIsSUFBSSxJQUFJLEVBQUUsTUFBTSxLQUFLO0VBQ3RCO0NBQ0QsR0FBRyxDQUFDLENBQUMsR0FBRyxLQUFBLEdBQUlBLGFBQUFBLFlBQUFBLEVBQUcsR0FBRyxNQUFNO0VBQ3ZCLElBQUksSUFBSSxFQUFFLFNBQVMsc0JBQXNCO0VBQ3pDLElBQUksQ0FBQyxHQUFHO0VBQ1IsSUFBSSxJQUFJZixJQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLFFBQVEsR0FBRyxFQUFFLE1BQU0sRUFBRSxTQUFTLEdBQUcsQ0FBQztFQUNqRSxHQUFHLE1BQU07R0FDUixJQUFJLElBQUk7SUFDUCxJQUFJSyxJQUFFO0lBQ04sTUFBTTtJQUNOLE9BQU8sR0FBRyxLQUFLTixJQUFFLEdBQUcsR0FBRyxFQUFFLFNBQVM7SUFDbEMsT0FBTyxFQUFFO0lBQ1QsUUFBUSxFQUFFO0lBQ1YsR0FBRyxFQUFFLElBQUksRUFBRSxRQUFRO0lBQ25CLEdBQUcsRUFBRSxJQUFJLEVBQUUsU0FBUztJQUNwQixXQUFXLEtBQUssSUFBSTtHQUNyQixHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztHQUNmLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsR0FBRztFQUN6QixDQUFDO0NBQ0YsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBQSxHQUFJZ0IsYUFBQUEsWUFBQUEsRUFBRyxHQUFHLE1BQU07RUFDM0IsTUFBTSxLQUFLLEdBQUcsTUFBTTtHQUNuQixJQUFJLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxXQUFXLEtBQUssRUFBRSxTQUFTLENBQUMsSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLFdBQVcsS0FBSyxFQUFFLFNBQVMsS0FBSyxFQUFFLFdBQVcsS0FBSyxFQUFFLFNBQVMsQ0FBQyxHQUFHLE9BQU87R0FDaEosSUFBSSxJQUFJLFFBQVEsRUFBRSxTQUFTO0dBQzNCLElBQUksR0FBRztJQUNOLElBQUksSUFBSVAsSUFBRSxHQUFHLEdBQUcsR0FBRyxDQUFDO0lBQ3BCLElBQUksQ0FBQyxFQUFFLFdBQVcsQ0FBQyxFQUFFLE9BQU8sT0FBTztJQUNuQyxJQUFJLEVBQUU7R0FDUDtHQUNBLE9BQU8sQ0FBQyxHQUFHLEdBQUc7SUFDYixJQUFJSCxJQUFFO0lBQ04sUUFBUTtJQUNSLE1BQU07SUFDTixPQUFPO0lBQ1AsV0FBVyxLQUFLLElBQUk7R0FDckIsQ0FBQztFQUNGLENBQUM7Q0FDRixHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFBLEdBQUtVLGFBQUFBLFlBQUFBLEVBQUcsR0FBRyxNQUFNO0VBQzVCLElBQUksR0FBRyxPQUFPO0dBQ2IsR0FBRztJQUNGLElBQUksRUFBRTtFQUNSLEVBQUUsR0FBRyxFQUFFLFNBQVMsUUFBUTtHQUN2QixJQUFJLENBQUMsR0FBRztHQUNSLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztHQUNkO0VBQ0Q7RUFDQSxFQUFFLGFBQWEsRUFBRSxFQUFFLFFBQVEsR0FBRyxFQUFFLElBQUk7Q0FDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsWUFBQUEsRUFBRyxHQUFHLE1BQU07RUFDekIsRUFBRSxTQUFTLFVBQVUsRUFBRSxhQUFhLEdBQUcsT0FBTztHQUM3QyxHQUFHO0lBQ0YsSUFBSSxFQUFFO0VBQ1IsRUFBRSxHQUFHLEVBQUUsRUFBRSxRQUFRLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxFQUFFLFVBQVUsRUFBRSxLQUFLO0NBQ25ELEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFBLEdBQUtBLGFBQUFBLFlBQUFBLE9BQVE7RUFDckIsSUFBSSxNQUFNLENBQUMsQ0FBQztDQUNiLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxZQUFBQSxFQUFHLEdBQUcsTUFBTTtFQUN2QixJQUFJLEVBQUUsZUFBZSxHQUFHLEVBQUUsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDLEdBQUcsTUFBTSxRQUFRO0dBQ2hFLEtBQUssTUFBTSxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxDQUFDO0dBQ3RDO0VBQ0Q7RUFDQSxJQUFJLElBQUksRUFBRSxTQUFTLHNCQUFzQixHQUFHLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLENBQUM7RUFDeEUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHO0VBQ2QsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLE1BQU0sRUFBRSxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUM7RUFDOUMsRUFBRTtHQUNELElBQUk7R0FDSixTQUFTLElBQUksRUFBRTtHQUNmLFNBQVMsSUFBSSxFQUFFO0dBQ2YsV0FBVyxFQUFFO0VBQ2QsQ0FBQztDQUNGLEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxZQUFBQSxFQUFHLE1BQU07RUFDakIsSUFBSSxFQUFFLFdBQVcsR0FBRztFQUNwQixFQUFFLElBQUksR0FBRyxNQUFNLFdBQVcsRUFBRSxJQUFJLEdBQUcsRUFBRSxDQUFDO0VBQ3RDLElBQUksSUFBSSxFQUFFO0VBQ1YsRUFBRSxjQUFjLGtCQUFrQixDQUFDLEdBQUcsRUFBRTtHQUN2QyxXQUFXO0dBQ1gsUUFBUSxFQUFFO0dBQ1YsUUFBUSxFQUFFO0dBQ1YsY0FBYyxFQUFFO0dBQ2hCLGNBQWMsRUFBRTtFQUNqQixDQUFDO0NBQ0YsR0FBRztFQUNGO0VBQ0E7RUFDQTtDQUNELENBQUMsR0FBRyxNQUFBLEdBQUtBLGFBQUFBLFlBQUFBLEVBQUcsTUFBTTtFQUNqQixFQUFFLGVBQWU7RUFDakIsSUFBSSxJQUFJLEVBQUUsU0FBUyxzQkFBc0I7RUFDekMsSUFBSSxDQUFDLEdBQUc7RUFDUixJQUFJLElBQUksRUFBRSxVQUFVLEVBQUUsTUFBTSxJQUFJLEVBQUUsVUFBVSxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUUsU0FBUztFQUNuRSxHQUFHLE1BQU07R0FDUixJQUFJLElBQUlULEtBQUcsRUFBRSxRQUFRLEdBQUdKLEtBQUdDLEdBQUM7R0FDNUIsSUFBSSxNQUFNLEVBQUUsT0FBTyxPQUFPO0dBQzFCLElBQUksS0FBSyxJQUFJLEVBQUUsV0FBVyxFQUFFLE9BQU8sS0FBSyxJQUFJLEVBQUUsV0FBVyxFQUFFO0dBQzNELE9BQU87SUFDTixPQUFPO0lBQ1AsU0FBUyxJQUFJLElBQUk7SUFDakIsU0FBUyxJQUFJLElBQUk7R0FDbEI7RUFDRCxDQUFDO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FDTCxDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxJQUFJLENBQUMsR0FBRztFQUNSLElBQUksS0FBSyxNQUFNO0dBQ2QsSUFBSSxFQUFFLGNBQWMsRUFBRSxXQUFXO0dBQ2pDLElBQUksSUFBSSxFQUFFLFNBQVMsc0JBQXNCO0dBQ3pDLEtBQUssR0FBRyxNQUFNLEVBQUUsS0FBSyxNQUFNO0lBQzFCLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxPQUFPO0lBQzFCLElBQUksRUFBRSxHQUFHLEdBQUcsR0FBRyxNQUFNLEVBQUUsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLEdBQUcsSUFBSTtLQUNwRCxHQUFHO0tBQ0gsR0FBRyxJQUFJLEVBQUU7S0FDVCxHQUFHLElBQUksRUFBRTtJQUNWO0lBQ0EsT0FBTyxJQUFJLENBQUMsR0FBRztHQUNoQixDQUFDLENBQUM7RUFDSCxHQUFHLEtBQUssTUFBTTtHQUNiLEVBQUUsY0FBYyxFQUFFLGFBQWEsRUFBRSxJQUFJO0VBQ3RDO0VBQ0EsT0FBTyxTQUFTLGlCQUFpQixlQUFlLENBQUMsR0FBRyxTQUFTLGlCQUFpQixhQUFhLENBQUMsU0FBUztHQUNwRyxTQUFTLG9CQUFvQixlQUFlLENBQUMsR0FBRyxTQUFTLG9CQUFvQixhQUFhLENBQUM7RUFDNUY7Q0FDRCxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxJQUFBLEdBQUdXLGFBQUFBLFVBQUFBLE9BQVE7RUFDWCxJQUFJLENBQUMsR0FBRztFQUNSLElBQUksS0FBSyxNQUFNO0dBQ2QsSUFBSSxFQUFFLGNBQWMsRUFBRSxXQUFXO0dBQ2pDLElBQUksSUFBSSxFQUFFLFVBQVUsRUFBRSxRQUFRLElBQUksRUFBRSxVQUFVLEVBQUU7R0FDaEQsR0FBRyxPQUFPO0lBQ1QsR0FBRztJQUNILFNBQVMsRUFBRSxlQUFlO0lBQzFCLFNBQVMsRUFBRSxlQUFlO0dBQzNCLEVBQUU7RUFDSCxHQUFHLEtBQUssTUFBTTtHQUNiLEVBQUUsY0FBYyxFQUFFLGNBQWMsRUFBRSxTQUFTLHNCQUFzQixFQUFFLFNBQVMsR0FBRyxFQUFFLElBQUk7RUFDdEY7RUFDQSxPQUFPLFNBQVMsaUJBQWlCLGVBQWUsQ0FBQyxHQUFHLFNBQVMsaUJBQWlCLGFBQWEsQ0FBQyxTQUFTO0dBQ3BHLFNBQVMsb0JBQW9CLGVBQWUsQ0FBQyxHQUFHLFNBQVMsb0JBQW9CLGFBQWEsQ0FBQztFQUM1RjtDQUNELEdBQUcsQ0FBQyxDQUFDLENBQUM7Q0FDTixJQUFJLEtBQUs7RUFDUjtFQUNBLElBQUkscUNBQXFDO0VBQ3pDO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLFVBQVUsSUFBSSx3QkFBd0I7Q0FDL0YsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixLQUFLO0VBQ0wsV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDbkMsV0FBVztHQUNYLEtBQUs7R0FDTCxlQUFlO0dBQ2YsU0FBUztHQUNULE1BQU07R0FDTixlQUFlO0dBQ2YsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNsQyxXQUFXO0lBQ1gsTUFBTTtJQUNOLGVBQWU7SUFDZixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLO0tBQ2hDLFdBQVc7S0FDWCxXQUFXO0tBQ1gsVUFBVSxDQUFDLEVBQUUsS0FBSyxNQUFNO01BQ3ZCLElBQUksSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEdBQUcsSUFBSSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJO01BQzNFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUFPO01BQ3JCLElBQUksS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxNQUFNLEdBQUcsS0FBSyxFQUFFLElBQUksRUFBRSxTQUFTLEtBQUssRUFBRSxJQUFJLEVBQUUsU0FBUyxNQUFNO01BQ3pHLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLEtBQUssRUFBRSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7T0FDcEUsV0FBVztPQUNYLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUTtPQUNwQixJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVM7T0FDckIsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRO09BQ3BCLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUztNQUN0QixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7T0FDN0IsV0FBVztPQUNYLEdBQUc7T0FDSCxHQUFHLElBQUk7T0FDUCxVQUFVLEVBQUU7TUFDYixDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRTtLQUNaLENBQUMsR0FBRyxFQUFFLEtBQUssTUFBTTtNQUNoQixJQUFJLElBQUlMLEtBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSyxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxLQUFLLEVBQUUsU0FBUyxLQUFLLEtBQUssR0FBRyxJQUFJO09BQzFHLFdBQVc7UUFDVjtRQUNBLEVBQUUsU0FBUyxZQUFZO1FBQ3ZCLEVBQUUsU0FBUyxlQUFlO1FBQzFCLEVBQUUsU0FBUyxhQUFhO1FBQ3hCLEVBQUUsU0FBUyxnQkFBZ0I7UUFDM0IsRUFBRSxTQUFTLGNBQWM7UUFDekIsRUFBRSxTQUFTLGVBQWU7UUFDMUIsRUFBRSxTQUFTLGFBQWE7UUFDeEIsTUFBTSxFQUFFLE1BQU07T0FDZixDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7T0FDMUIsZ0JBQWdCLE1BQU0sRUFBRSxHQUFHLEVBQUUsRUFBRTtPQUMvQixNQUFNO09BQ04sZUFBZSxDQUFDO01BQ2pCO01BQ0EsSUFBSSxFQUFFLFNBQVMsVUFBVTtPQUN4QixJQUFJLElBQUksRUFBRSxRQUFRLEdBQUcsSUFBSSxFQUFFLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSTtPQUM1QyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLLEVBQUUsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO1FBQ3RFLEdBQUc7UUFDSCxJQUFJO1FBQ0osSUFBSTtRQUNKLEdBQUc7T0FDSixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7UUFDN0IsV0FBVztRQUNYLEdBQUc7UUFDSCxHQUFHO1FBQ0gsVUFBVSxFQUFFLEtBQUssR0FBRyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO1NBQ3BELEdBQUc7U0FDSCxJQUFJLE1BQU0sSUFBSSxJQUFJO1NBQ2xCLFVBQVU7UUFDWCxHQUFHLEdBQUcsRUFBRSxHQUFHLFFBQVEsR0FBRyxDQUFDO09BQ3hCLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFO01BQ1o7TUFDQSxJQUFJLEVBQUUsU0FBUyxZQUFZO09BQzFCLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRSxRQUFRLEdBQUcsQ0FBQyxHQUFHLElBQUk7UUFDcEQsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUU7UUFDaEIsR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRTtRQUN0QixHQUFHLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFO1FBQ2hDLEdBQUcsRUFBRSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUU7T0FDbkIsQ0FBQyxDQUFDLEtBQUssR0FBRztPQUNWLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLEtBQUssRUFBRSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFdBQVc7UUFDdkUsR0FBRztRQUNILFFBQVE7T0FDVCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7UUFDN0IsV0FBVztRQUNYLEdBQUc7UUFDSCxHQUFHO1FBQ0gsVUFBVSxFQUFFLEtBQUssR0FBRyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO1NBQ3BELEdBQUc7U0FDSCxJQUFJLE1BQU0sSUFBSSxJQUFJO1NBQ2xCLFVBQVU7UUFDWCxHQUFHLEdBQUcsRUFBRSxHQUFHLFFBQVEsR0FBRyxDQUFDO09BQ3hCLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFO01BQ1o7TUFDQSxJQUFJLEVBQUUsU0FBUyxXQUFXO09BQ3pCLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRSxRQUFRLEdBQUcsQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxHQUFHLElBQUk7UUFDNUUsS0FBSyxFQUFFLEVBQUUsR0FBRyxFQUFFO1FBQ2QsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRO1FBQ3JCLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSTtRQUM1QixLQUFLO1FBQ0wsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLElBQUksR0FBRyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxRQUFRLEdBQUcsR0FBRztRQUN4RSxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVEsSUFBSSxHQUFHLEVBQUUsSUFBSSxFQUFFLFNBQVMsR0FBRyxHQUFHLEVBQUUsRUFBRSxHQUFHO1FBQzFEO09BQ0QsQ0FBQyxDQUFDLEtBQUssR0FBRztPQUNWLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLEtBQUssRUFBRSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7UUFDcEUsR0FBRztRQUNILEdBQUc7T0FDSixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7UUFDN0IsV0FBVztRQUNYLEdBQUc7UUFDSCxHQUFHO1FBQ0gsVUFBVSxFQUFFLEtBQUssR0FBRyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO1NBQ3BELEdBQUc7U0FDSCxJQUFJLE1BQU0sSUFBSSxJQUFJO1NBQ2xCLFVBQVU7UUFDWCxHQUFHLEdBQUcsRUFBRSxHQUFHLFFBQVEsR0FBRyxDQUFDO09BQ3hCLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFO01BQ1o7TUFDQSxJQUFJLEVBQUUsU0FBUyxXQUFXO09BQ3pCLElBQUksSUFBSTtRQUNQLEdBQUcsRUFBRSxJQUFJLEVBQUUsUUFBUSxJQUFJLEdBQUcsRUFBRTtRQUM1QixHQUFHLEVBQUUsSUFBSSxFQUFFLFFBQVEsSUFBSSxHQUFHLEVBQUU7UUFDNUIsR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLEVBQUUsU0FBUztRQUNyQyxHQUFHLEVBQUUsSUFBSSxFQUFFLFFBQVEsSUFBSSxHQUFHLEVBQUUsSUFBSSxFQUFFO1FBQ2xDLEdBQUcsRUFBRSxJQUFJLEVBQUUsUUFBUSxJQUFJLEdBQUcsRUFBRSxJQUFJLEVBQUU7UUFDbEMsR0FBRyxFQUFFLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxTQUFTO09BQzVCLENBQUMsQ0FBQyxLQUFLLEdBQUc7T0FDVixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxLQUFLLEVBQUUsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxXQUFXO1FBQ3ZFLEdBQUc7UUFDSCxRQUFRO09BQ1QsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRO1FBQzdCLFdBQVc7UUFDWCxHQUFHO1FBQ0gsR0FBRztRQUNILFVBQVUsRUFBRSxLQUFLLEdBQUcsTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztTQUNwRCxHQUFHO1NBQ0gsSUFBSSxNQUFNLElBQUksSUFBSTtTQUNsQixVQUFVO1FBQ1gsR0FBRyxHQUFHLEVBQUUsR0FBRyxRQUFRLEdBQUcsQ0FBQztPQUN4QixDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRTtNQUNaO01BQ0EsSUFBSSxJQUFJLEVBQUUsU0FBUyxlQUFlLEVBQUUsU0FBUyxlQUFlLEtBQUs7TUFDakUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtPQUNwRSxHQUFHO09BQ0gsR0FBRyxFQUFFO09BQ0wsR0FBRyxFQUFFO09BQ0wsT0FBTyxFQUFFO09BQ1QsUUFBUSxFQUFFO09BQ1YsSUFBSTtNQUNMLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtPQUM3QixXQUFXO09BQ1gsR0FBRztPQUNILEdBQUc7T0FDSCxVQUFVLEVBQUUsS0FBSyxHQUFHLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7UUFDcEQsR0FBRztRQUNILElBQUksTUFBTSxJQUFJLElBQUk7UUFDbEIsVUFBVTtPQUNYLEdBQUcsR0FBRyxFQUFFLEdBQUcsUUFBUSxHQUFHLENBQUM7TUFDeEIsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUU7S0FDWixDQUFDLENBQUM7SUFDSCxDQUFDO0dBQ0YsQ0FBQztFQUNGLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsR0FBRztHQUN4QixjQUFjO0dBQ2QsVUFBVTtHQUNWLGFBQWE7R0FDYixtQkFBbUI7R0FDbkIsVUFBVTtHQUNWLG9CQUFvQjtHQUNwQixrQkFBa0I7R0FDbEIsYUFBYTtHQUNiLG1CQUFtQjtFQUNwQixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQzs7O0FDamtCRCxJQUFJTyxNQUFJO0NBQ1AsU0FBUztDQUNULFdBQVc7Q0FDWCxPQUFPO0FBQ1I7QUFBR0MsSUFBQUEsT0FBQUEsR0FBSUMsYUFBQUEsV0FBQUEsQ0FBRSxTQUFTLEVBQUUsVUFBVSxHQUFHLFdBQVcsSUFBSSxJQUFJLFNBQVMsSUFBSSxXQUFXLE1BQU0sSUFBSSxVQUFVLEdBQUcsS0FBSyxHQUFHO0NBQzFHLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7RUFDbEMsS0FBSztFQUNMLFdBQVc7R0FDVjtHQUNBRixJQUFFLE1BQU1BLElBQUU7R0FDVjtFQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztFQUMxQixNQUFNO0VBQ04sR0FBRztFQUNILFVBQVU7Q0FDWCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYztBQUdoQixJQUFJRyxNQUFJO0FBQ1IsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxNQUFNLEtBQUssRUFBRSxpQkFBaUJELEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxNQUFNLENBQUMsRUFBRSxhQUFhLFVBQVUsS0FBSyxFQUFFLGFBQWEsYUFBYSxNQUFNLE1BQU07QUFDL0g7QUFDQSxJQUFJRSxPQUFBQSxHQUFJSCxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUcsYUFBYSxHQUFHLFFBQVEsR0FBRyxRQUFRLEdBQUcsWUFBWSxJQUFJLENBQUMsR0FBRyxZQUFZLElBQUksQ0FBQyxHQUFHLGdCQUFnQixHQUFHLHNCQUFzQixJQUFJLENBQUMsR0FBRyxlQUFlLEtBQUssQ0FBQyxHQUFHLHNCQUFzQixHQUFHLFlBQVksSUFBSSxVQUFVLFdBQVcsSUFBSSxJQUFJLG1CQUFtQixJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxzQkFBc0IsS0FBSyxJQUFJLGtCQUFrQixJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxXQUFXLEdBQUcsVUFBVSxJQUFJLFVBQVUsSUFBSSxHQUFHLE1BQU0sSUFBSTtDQUN4YixJQUFJLEtBQUEsR0FBSUksYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxLQUFLLHlCQUFBLEdBQXdCQyxhQUFBQSxNQUFBQSxDQUFFLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxLQUFLLEtBQUssK0JBQUEsR0FBOEJBLGFBQUFBLE1BQUFBLENBQUUsQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSSxHQUFHLG9CQUFvQixLQUFLLEdBQUcscUJBQXFCLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxLQUFLLENBQUMsK0JBQStCLEVBQUUsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsS0FBSyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDdnJCLFFBQUEsR0FBT0MsYUFBQUEsVUFBQUEsT0FBUTtFQUNkLElBQUksSUFBSSxFQUFFO0VBQ1YsSUFBSSxDQUFDLEdBQUc7RUFDUixJQUFJLEVBQUUsVUFBVSxTQUFTLHlCQUF5QixjQUFjLFNBQVMsZ0JBQWdCLE1BQU0sR0FBRyxJQUFJO0dBQ3JHLElBQUksSUFBSSxFQUFFLGNBQWMsQ0FBQztHQUN6QixJQUFJLEdBQUcsT0FBTyxFQUFFLE1BQU0sU0FBUztJQUM5QixFQUFFLFNBQVMsTUFBTSxHQUFHLEVBQUUsVUFBVTtHQUNqQztFQUNELFFBQVEsQ0FBQztFQUNULElBQUksSUFBSUosSUFBRSxDQUFDO0VBQ1gsT0FBTyxFQUFFLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNLElBQUksRUFBRSxNQUFNLFNBQVM7R0FDckQsRUFBRSxTQUFTLE1BQU0sR0FBRyxFQUFFLFVBQVU7RUFDakM7Q0FDRCxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87RUFDakMsV0FBVztFQUNYLE1BQU07RUFDTixVQUFVLE1BQU07R0FDZixDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsaUJBQWlCLElBQUk7RUFDM0M7RUFDQSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxXQUFXO0dBQ3RDLE1BQU0sTUFBTTtJQUNYLElBQUksRUFBRSxVQUFVLEdBQUcsT0FBTyxNQUFNLFlBQVk7S0FDM0MsR0FBRyxDQUFDO0tBQ0o7SUFDRDtJQUNBLE9BQU8sR0FBRyxVQUFVO0dBQ3JCO0dBQ0EsV0FBVztHQUNYLE1BQU07R0FDTixjQUFjO0dBQ2QsbUJBQW1CO0dBQ25CLG9CQUFvQjtHQUNwQixVQUFVLE1BQU07R0FDaEIsWUFBWSxNQUFNO0lBQ2pCLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxrQkFBa0I7SUFDaEMsSUFBSSxFQUFFLFFBQVEsWUFBWSxJQUFJO0tBQzdCLEVBQUUsZUFBZSxHQUFHLElBQUk7S0FDeEI7SUFDRDtJQUNBLElBQUksRUFBRSxRQUFRLFNBQVMsQ0FBQyxFQUFFLFNBQVM7SUFDbkMsSUFBSSxJQUFJQSxJQUFFLEVBQUUsT0FBTztJQUNuQixJQUFJLEVBQUUsV0FBVyxHQUFHO0tBQ25CLEVBQUUsZUFBZSxHQUFHLEVBQUUsUUFBUSxNQUFNO0tBQ3BDO0lBQ0Q7SUFDQSxJQUFJLElBQUksU0FBUyxlQUFlLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxFQUFFLFNBQVM7SUFDM0QsSUFBSSxFQUFFLFVBQVU7S0FDZixDQUFDLENBQUMsS0FBSyxNQUFNLEtBQUssQ0FBQyxFQUFFLFFBQVEsU0FBUyxDQUFDLE9BQU8sRUFBRSxlQUFlLEdBQUcsRUFBRSxNQUFNO0tBQzFFO0lBQ0Q7SUFDQSxDQUFDLENBQUMsS0FBSyxNQUFNLEtBQUssQ0FBQyxFQUFFLFFBQVEsU0FBUyxDQUFDLE9BQU8sRUFBRSxlQUFlLEdBQUcsRUFBRSxNQUFNO0dBQzNFO0dBQ0EsR0FBRztHQUNILFVBQVU7SUFDVCxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0tBQ2hDLFdBQVc7S0FDWCxVQUFVLE1BQU0sSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtNQUMzQyxXQUFXO01BQ1gsSUFBSTtNQUNKLFVBQVU7S0FDWCxDQUFDLElBQUk7SUFDTixDQUFDLElBQUk7SUFDTCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQzVCLElBQUk7S0FDSixXQUFXO0tBQ1gsVUFBVTtJQUNYLENBQUMsSUFBSTtJQUNXLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDeEIsV0FBVztLQUNYLFVBQVU7SUFDWCxDQUFDO0lBQ0QsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtLQUNoQyxXQUFXO0tBQ1gsVUFBVTtJQUNYLENBQUMsSUFBSTtHQUNOO0VBQ0QsQ0FBQztDQUNGLENBQUM7QUFDRixDQUFDO0FBQ0QsSUFBRSxjQUFjO0FBR2hCLElBQUksS0FBSyxPQUFPLE1BQU07Q0FDckIsSUFBSSxJQUFJLE1BQU0sTUFBTSxDQUFDO0NBQ3JCLElBQUksQ0FBQyxFQUFFLElBQUksTUFBTSxNQUFNLHNCQUFzQixFQUFFLElBQUksRUFBRSxRQUFRO0NBQzdELE9BQU8sRUFBRSxLQUFLO0FBQ2Y7QUFDQSxTQUFTSyxJQUFFLEdBQUc7Q0FDYixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sUUFBUSxFQUFFLE9BQU8sR0FBRyxPQUFPO0VBQzNDLFNBQVM7RUFDVCxVQUFVO0VBQ1YsaUJBQWlCO0dBQ2hCO0dBQ0E7R0FDQTtFQUNEO0VBQ0EsZUFBZTtFQUNmLFNBQVMsQ0FBQztDQUNYO0NBQ0EsSUFBSSxJQUFJLEVBQUUsUUFBUSxLQUFLLE9BQU87RUFDN0IsTUFBTTtFQUNOLFVBQVUsQ0FBQztFQUNYLFlBQVksQ0FBQztFQUNiLFdBQVcsQ0FBQztFQUNaLFVBQVUsQ0FBQztFQUNYLFdBQVc7RUFDWCxRQUFRO0VBQ1IsR0FBRztDQUNKLEVBQUU7Q0FDRixPQUFPO0VBQ04sU0FBUyxFQUFFLFdBQVc7RUFDdEIsVUFBVSxFQUFFLFlBQVk7RUFDeEIsaUJBQWlCLEVBQUUsaUJBQWlCLFNBQVMsRUFBRSxrQkFBa0I7R0FDaEU7R0FDQTtHQUNBO0VBQ0Q7RUFDQSxlQUFlLEVBQUUsaUJBQWlCO0VBQ2xDLGdCQUFnQixFQUFFO0VBQ2xCLGFBQWEsRUFBRTtFQUNmLFFBQVE7R0FDUCxzQkFBc0IsRUFBRSxRQUFRLHdCQUF3QixDQUFDO0dBQ3pELGVBQWUsRUFBRSxRQUFRLGVBQWUsU0FBUyxFQUFFLE9BQU8sZ0JBQWdCO0lBQ3pFO0lBQ0E7SUFDQTtJQUNBO0dBQ0Q7RUFDRDtFQUNBLFNBQVM7Q0FDVjtBQUNEO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUc7Q0FDaEIsT0FBTyxNQUFNLFNBQVMsU0FBUyxNQUFNLGNBQWMsYUFBYSxNQUFNLFlBQVksTUFBTSxZQUFZLFdBQVcsTUFBTSxZQUFZLFlBQVk7QUFDOUk7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPLE1BQU0sU0FBUyxTQUFTLE1BQU0sY0FBYyxhQUFhLE1BQU0sYUFBYSxhQUFhLE1BQU0sWUFBWSxZQUFZO0FBQy9IO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsSUFBSSxHQUFHLFFBQVEsT0FBTyxFQUFFLEtBQUssT0FBTztFQUNuQyxPQUFPLE1BQU0sT0FBTyxZQUFZLE9BQU8sQ0FBQztFQUN4QyxPQUFPO0NBQ1IsRUFBRTtBQUNIO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsSUFBSSxDQUFDLEdBQUcsWUFBWSxPQUFPSixJQUFFLEtBQUssQ0FBQztDQUNuQyxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsV0FBVyxJQUFJLE9BQU8sUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLE9BQU87RUFDcEcsSUFBSSxJQUFJLEVBQUUsV0FBVyxJQUFJQyxJQUFFLEVBQUUsTUFBTSxFQUFFLE1BQU0sR0FBRyxJQUFJQyxJQUFFLEVBQUUsTUFBTSxHQUFHLElBQUksR0FBRyxXQUFXLE1BQU0sWUFBWSxhQUFhLE1BQU0sV0FBVyxXQUFXLE1BQU0sU0FBUyxTQUFTLEtBQUs7RUFDekssT0FBTztHQUNOLEtBQUssR0FBRyxPQUFPO0dBQ2YsT0FBTyxFQUFFLFNBQVM7R0FDbEIsTUFBTTtHQUNOLFVBQVUsR0FBRyxZQUFZLENBQUM7R0FDMUIsWUFBWSxHQUFHLGNBQWMsQ0FBQztHQUM5QixXQUFXLEdBQUcsYUFBYSxDQUFDO0dBQzVCLFVBQVUsR0FBRyxZQUFZLEVBQUUsSUFBSSxDQUFDO0dBQ2hDLFFBQVE7R0FDUixXQUFXLEdBQUcsYUFBYTtHQUMzQixPQUFPLEdBQUc7R0FDVixVQUFVLEdBQUc7R0FDYixTQUFTLEdBQUcsV0FBV0MsSUFBRSxFQUFFLElBQUk7R0FDL0IsUUFBUSxHQUFHLFVBQVU7RUFDdEI7Q0FDRCxDQUFDO0NBQ0QsT0FBT0gsSUFBRTtFQUNSLFNBQVMsR0FBRztFQUNaLFVBQVUsR0FBRztFQUNiLGlCQUFpQixHQUFHO0VBQ3BCLGVBQWUsR0FBRztFQUNsQixnQkFBZ0IsR0FBRztFQUNuQixhQUFhLEdBQUc7RUFDaEIsUUFBUSxHQUFHO0VBQ1gsU0FBUztDQUNWLENBQUM7QUFDRjtBQUNBLFNBQVMsR0FBRyxHQUFHO0NBQ2QsSUFBSSxHQUFHO0VBQ04sSUFBSSxPQUFPLEtBQUssVUFBVTtHQUN6QixJQUFJLElBQUksS0FBSyxNQUFNLENBQUM7R0FDcEIsSUFBSSxDQUFDLEtBQUssT0FBTyxLQUFLLFVBQVUsTUFBTSxNQUFNLDZDQUE2QztHQUN6RixPQUFPO0VBQ1I7RUFDQSxPQUFPO0NBQ1I7QUFDRDtBQUNBLGVBQWVLLElBQUUsR0FBRyxHQUFHO0NBQ3RCLElBQUksTUFBTSxLQUFLLEdBQUcsT0FBTyxPQUFPLEtBQUssYUFBYSxFQUFFLElBQUksT0FBTyxLQUFLLFdBQVcsT0FBTyxLQUFLLEdBQUEsQ0FBSSxDQUFDLElBQUk7QUFDckc7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRztDQUNoQixPQUFPLEVBQUUsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFDbEM7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRyxHQUFHO0NBQ25CLElBQUksSUFBSSxFQUFFO0NBQ1YsT0FBTyxLQUFLLE9BQU8sT0FBTyxNQUFNLE9BQU8sQ0FBQztBQUN6QztBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3ZCLElBQUksSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLFlBQVk7Q0FDN0IsT0FBTyxFQUFFLFFBQVEsTUFBTSxFQUFFLFdBQVcsS0FBSyxFQUFFLE1BQU0sTUFBTUMsSUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLE9BQU8sTUFBTTtFQUM5RyxJQUFJLEtBQUssRUFBRSxFQUFFLFFBQVEsR0FBQSxDQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDNUMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDO0VBQ2hCLElBQUksSUFBSSxFQUFFLEVBQUU7RUFDWixJQUFJLEVBQUUsU0FBUyxXQUFXO0dBQ3pCLElBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxDQUFDO0dBQ2hDLElBQUksTUFBTSxTQUFTLE9BQU8sTUFBTSxDQUFDO0VBQ2xDO0VBQ0EsT0FBT0EsSUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUM7Q0FDckMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNSO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3BCLElBQUksQ0FBQyxHQUFHLE9BQU87Q0FDZixJQUFJLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUztDQUMzQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsVUFBVSxPQUFPO0NBQzlCLElBQUksSUFBSSxFQUFFLGNBQWMsUUFBUSxJQUFJO0NBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNO0VBQzVCLElBQUksSUFBSSxFQUFFLEVBQUUsWUFBWSxJQUFJLEVBQUUsRUFBRTtFQUNoQyxPQUFPLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJO0NBQzNCLENBQUM7QUFDRjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3ZCLElBQUksQ0FBQyxHQUFHLE9BQU8sRUFBRSxLQUFLLEdBQUcsT0FBTztFQUMvQixNQUFNO0VBQ04sS0FBSyxRQUFRO0VBQ2IsS0FBSztFQUNMLFVBQVU7Q0FDWCxFQUFFO0NBQ0YsSUFBSSxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsUUFBUSxDQUFDO0NBQ2pDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxXQUFXLE9BQU8sRUFBRSxLQUFLLEdBQUcsT0FBTztFQUMvQyxNQUFNO0VBQ04sS0FBSyxRQUFRO0VBQ2IsS0FBSztFQUNMLFVBQVU7Q0FDWCxFQUFFO0NBQ0YsSUFBSSxvQkFBb0IsSUFBSSxJQUFJO0NBQ2hDLEVBQUUsU0FBUyxNQUFNO0VBQ2hCLElBQUksSUFBSUEsSUFBRSxFQUFFLEVBQUUsS0FBSyxXQUFXLElBQUksRUFBRSxJQUFJLENBQUM7RUFDekMsSUFBSSxHQUFHO0dBQ04sRUFBRSxLQUFLLENBQUM7R0FDUjtFQUNEO0VBQ0EsRUFBRSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7Q0FDYixDQUFDO0NBQ0QsSUFBSSxJQUFJLENBQUM7Q0FDVCxPQUFPLE1BQU0sS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTztFQUNsRCxJQUFJLElBQUksU0FBUztFQUNqQixFQUFFLEtBQUs7R0FDTixNQUFNO0dBQ04sS0FBSztHQUNMLFlBQVk7R0FDWixXQUFXLEVBQUU7R0FDYixXQUFXO0VBQ1osQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxTQUFTLEdBQUcsTUFBTTtHQUNuQyxFQUFFLEtBQUs7SUFDTixNQUFNO0lBQ04sS0FBSyxHQUFHLEVBQUUsT0FBTztJQUNqQixLQUFLO0lBQ0wsVUFBVTtJQUNWLFlBQVk7R0FDYixDQUFDO0VBQ0YsQ0FBQztDQUNGLENBQUMsR0FBRztBQUNMO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3BCLElBQUksS0FBSyxHQUFHLE9BQU87Q0FDbkIsSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLENBQUMsSUFBSTtDQUN6QixPQUFPLEVBQUUsTUFBTSxHQUFHLElBQUksQ0FBQztBQUN4QjtBQUNBLFNBQVNDLElBQUUsR0FBRyxHQUFHO0NBQ2hCLElBQUksS0FBSyxNQUFNLE9BQU87Q0FDdEIsSUFBSSxFQUFFLFdBQVcsY0FBYyxPQUFPLEtBQUssVUFBVSxPQUFPLElBQUksS0FBSyxhQUFhLEtBQUssR0FBRztFQUN6RixPQUFPO0VBQ1AsVUFBVTtFQUNWLHVCQUF1QjtDQUN4QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Q0FDWCxJQUFJLEVBQUUsV0FBVyxhQUFhLE9BQU8sS0FBSyxVQUFVLE9BQU8sSUFBSSxLQUFLLGFBQWEsS0FBSyxHQUFHO0VBQ3hGLE9BQU87RUFDUCx1QkFBdUI7Q0FDeEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0NBQ1gsS0FBSyxFQUFFLFdBQVcsVUFBVSxFQUFFLFNBQVMsWUFBWSxPQUFPLEtBQUssWUFBWSxhQUFhLE9BQU87RUFDOUYsSUFBSSxJQUFJLElBQUksS0FBSyxDQUFDO0VBQ2xCLElBQUksQ0FBQyxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsR0FBRyxPQUFPLElBQUksS0FBSyxlQUFlLEtBQUssR0FBRyxFQUFFLFdBQVcsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Q0FDekc7Q0FDQSxLQUFLLEVBQUUsV0FBVyxjQUFjLEVBQUUsU0FBUyxnQkFBZ0IsT0FBTyxLQUFLLFlBQVksYUFBYSxPQUFPO0VBQ3RHLElBQUksSUFBSSxJQUFJLEtBQUssQ0FBQztFQUNsQixJQUFJLENBQUMsT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEdBQUcsT0FBTyxJQUFJLEtBQUssZUFBZSxLQUFLLEdBQUc7R0FDdEUsV0FBVztHQUNYLFdBQVc7RUFDWixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Q0FDWjtDQUNBLE9BQU9ELElBQUUsQ0FBQztBQUNYO0FBQ0EsU0FBU0UsSUFBRSxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxJQUFJLEVBQUUsYUFBYTtDQUN2QixJQUFJLE1BQU0sUUFBUSxPQUFPO0VBQ3hCLE1BQU07RUFDTixPQUFPO0NBQ1I7Q0FDQSxJQUFJLElBQUksRUFBRSxLQUFLLE1BQU0sRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLFFBQVEsTUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPLFNBQVMsQ0FBQyxDQUFDO0NBQ3ZGLE9BQU8sTUFBTSxVQUFVO0VBQ3RCLE1BQU07RUFDTixPQUFPLEVBQUU7Q0FDVixJQUFJLEVBQUUsV0FBVyxJQUFJO0VBQ3BCLE1BQU07RUFDTixPQUFPO0NBQ1IsSUFBSSxNQUFNLFFBQVE7RUFDakIsTUFBTTtFQUNOLE9BQU8sRUFBRSxRQUFRLEdBQUcsTUFBTSxJQUFJLEdBQUcsQ0FBQztDQUNuQyxJQUFJLE1BQU0sUUFBUTtFQUNqQixNQUFNO0VBQ04sT0FBTyxFQUFFLFFBQVEsR0FBRyxNQUFNLElBQUksR0FBRyxDQUFDLElBQUksRUFBRTtDQUN6QyxJQUFJLE1BQU0sUUFBUTtFQUNqQixNQUFNO0VBQ04sT0FBTyxLQUFLLElBQUksR0FBRyxDQUFDO0NBQ3JCLElBQUksTUFBTSxRQUFRO0VBQ2pCLE1BQU07RUFDTixPQUFPLEtBQUssSUFBSSxHQUFHLENBQUM7Q0FDckIsSUFBSTtFQUNILE1BQU07RUFDTixPQUFPO0NBQ1I7QUFDRDtBQUNBLFNBQVMsR0FBRyxHQUFHO0NBQ2QsT0FBTyxFQUFFLFNBQVMsU0FBUyxLQUFLLEVBQUUsVUFBVSxRQUFRLEVBQUUsVUFBVSxLQUFLLElBQUksTUFBTSxFQUFFLFNBQVMsVUFBVSxHQUFHLEtBQUssTUFBTSxFQUFFLEtBQUssTUFBTSxJQUFJLEtBQUssYUFBYSxLQUFLLEdBQUc7RUFDNUosdUJBQXVCO0VBQ3ZCLHVCQUF1QjtDQUN4QixDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsS0FBSztBQUNsQjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUNwQixJQUFJLE1BQU0sR0FBRyxPQUFPO0NBQ3BCLElBQUksS0FBSyxNQUFNLE9BQU87Q0FDdEIsSUFBSSxLQUFLLE1BQU0sT0FBTztDQUN0QixJQUFJLE1BQU0sVUFBVTtFQUNuQixJQUFJLElBQUksT0FBTyxDQUFDLEdBQUcsSUFBSSxPQUFPLENBQUM7RUFDL0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxLQUFLLE9BQU8sU0FBUyxDQUFDLEdBQUcsT0FBTyxJQUFJO0NBQzFEO0NBQ0EsSUFBSSxNQUFNLFVBQVUsTUFBTSxZQUFZO0VBQ3JDLElBQUksSUFBSSxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtFQUN2RSxJQUFJLENBQUMsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sTUFBTSxDQUFDLEdBQUcsT0FBTyxJQUFJO0NBQ3REO0NBQ0EsT0FBTyxNQUFNLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSUYsSUFBRSxDQUFDLENBQUMsQ0FBQyxjQUFjQSxJQUFFLENBQUMsQ0FBQztBQUM5RDtBQUNBLFNBQVNBLElBQUUsR0FBRztDQUNiLElBQUksS0FBSyxNQUFNLE9BQU87Q0FDdEIsSUFBSSxPQUFPLEtBQUssVUFBVSxPQUFPO0NBQ2pDLElBQUksT0FBTyxLQUFLLFlBQVksT0FBTyxLQUFLLFdBQVcsT0FBTyxPQUFPLENBQUM7Q0FDbEUsSUFBSSxhQUFhLE1BQU0sT0FBTyxFQUFFLFlBQVk7Q0FDNUMsSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLE9BQU8sRUFBRSxLQUFLLE1BQU1BLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUk7Q0FDekQsSUFBSSxPQUFPLEtBQUssVUFBVSxJQUFJO0VBQzdCLE9BQU8sS0FBSyxVQUFVLENBQUM7Q0FDeEIsUUFBUTtFQUNQLE9BQU87Q0FDUjtDQUNBLE9BQU8sT0FBTyxDQUFDO0FBQ2hCO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNqQixPQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssRUFBRSxjQUFjLEVBQUUsTUFBTTtFQUNqRCxXQUFXLEVBQUU7RUFDYixXQUFXO0NBQ1osSUFBSSxFQUFFLGNBQWMsUUFBUTtFQUMzQixXQUFXLEVBQUU7RUFDYixXQUFXO0NBQ1osSUFBSSxPQUFPO0FBQ1o7QUFDQSxTQUFTRyxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLEtBQUssTUFBTSxPQUFPO0NBQ3RCLElBQUksTUFBTSxVQUFVLE1BQU0sWUFBWTtFQUNyQyxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUFDO0VBQzFCLE9BQU8sT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLElBQUksS0FBSyxNQUFNLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUU7Q0FDbEg7Q0FDQSxPQUFPSCxJQUFFLENBQUM7QUFDWDtBQUNBLFNBQVNJLElBQUUsR0FBRyxHQUFHO0NBQ2hCLElBQUksRUFBRSxXQUFXLGNBQWMsRUFBRSxTQUFTLFdBQVcsT0FBTyxNQUFNO0NBQ2xFLElBQUksRUFBRSxXQUFXLFlBQVksRUFBRSxTQUFTLFVBQVU7RUFDakQsSUFBSSxJQUFJLE9BQU8sQ0FBQztFQUNoQixPQUFPLE9BQU8sU0FBUyxDQUFDLElBQUksSUFBSTtDQUNqQztDQUNBLE9BQU8sRUFBRSxTQUFTLFVBQVUsRUFBRSxTQUFTLGFBQWEsS0FBSyxPQUFPO0FBQ2pFO0FBQ0EsU0FBUyxHQUFHLEdBQUc7Q0FDZCxJQUFJLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxZQUFZO0NBQzdCLE9BQU8sTUFBTSxVQUFVLE1BQU0sVUFBVSxJQUFJO0FBQzVDO0FBQ0EsU0FBUyxHQUFHLEdBQUc7Q0FDZCxPQUFPLE1BQU0sU0FBUyxLQUFLLEVBQUUsWUFBWTtBQUMxQztBQUdBLFNBQVMsR0FBRyxFQUFFLFNBQVMsR0FBRyxPQUFPLEdBQUcsT0FBTyxHQUFHLFVBQVUsR0FBRyxRQUFRLEtBQUs7Q0FDdkUsSUFBSSxDQUFDLEdBQUcsTUFBQSxHQUFLQyxhQUFBQSxTQUFBQSxDQUFFLENBQUM7Q0FDaEIsUUFBQSxHQUFPZCxhQUFBQSxVQUFBQSxPQUFRO0VBQ2QsRUFBRSxDQUFDO0NBQ0osR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUgsS0FBRztFQUM3QixPQUFPLFlBQVk7RUFDbkIsY0FBYyxZQUFZO0VBQzFCLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixRQUF3QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRWtCLG1CQUFBQSxVQUFHLEVBQUUsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRXRCLEtBQUc7R0FDOUQsU0FBUztHQUNULFNBQVM7R0FDVCxVQUFVO0VBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUEsS0FBRztHQUN4QixlQUFlLEVBQUUsQ0FBQztHQUNsQixVQUFVO0VBQ1gsQ0FBQyxDQUFDLEVBQUUsQ0FBQztFQUNMLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDbEMsV0FBVztHQUNYLFVBQVUsRUFBRSxRQUFRLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQyxLQUFLLE1BQU07SUFDaEQsSUFBSSxJQUFJbUIsSUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUk7SUFDMUIsT0FBTyxFQUFFLFdBQVcsY0FBYyxFQUFFLFNBQVMsWUFBNEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsU0FBUztLQUNuRixXQUFXO0tBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLE1BQU0sQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO01BQ3hGLFdBQVc7TUFDWCxPQUFPLE1BQU0sU0FBUyxTQUFTO01BQy9CLFdBQVcsTUFBTTtPQUNoQixJQUFJLElBQUksRUFBRSxPQUFPLFVBQVU7T0FDM0IsR0FBRyxPQUFPO1FBQ1QsR0FBRztTQUNGLEVBQUUsTUFBTTtPQUNWLEVBQUU7TUFDSDtNQUNBLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtPQUN0QyxPQUFPO09BQ1AsVUFBVTtNQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtPQUMvQixPQUFPO09BQ1AsVUFBVTtNQUNYLENBQUMsQ0FBQztLQUNILENBQUMsQ0FBQztJQUNILEdBQUcsRUFBRSxHQUFHLElBQUksRUFBRSxXQUFXLFlBQVksRUFBRSxTQUFTLFNBQXlCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7S0FDbkYsV0FBVztLQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTtNQUN4RixXQUFXO01BQ1gsT0FBTztNQUNQLFdBQVcsTUFBTTtPQUNoQixJQUFJLElBQUlDLElBQUUsRUFBRSxPQUFPLE9BQU8sQ0FBQztPQUMzQixHQUFHLE9BQU87UUFDVCxHQUFHO1NBQ0YsRUFBRSxNQUFNO09BQ1YsRUFBRTtNQUNIO01BQ0EsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO09BQ3RDLE9BQU87T0FDUCxVQUFVO01BQ1gsQ0FBQyxHQUFHLEVBQUUsUUFBUSxLQUFLLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7T0FDcEQsT0FBTyxPQUFPLEVBQUUsS0FBSztPQUNyQixVQUFVLEVBQUU7TUFDYixHQUFHLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO0tBQ3JCLENBQUMsQ0FBQztJQUNILEdBQUcsRUFBRSxHQUFHLElBQUksRUFBRSxXQUFXLGFBQTZCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7S0FDaEUsV0FBVztLQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsWUFBWTtNQUMxRixXQUFXO01BQ1gsT0FBTztNQUNQLFdBQVcsTUFBTTtPQUNoQixJQUFJLElBQUlBLElBQUUsRUFBRSxPQUFPLE9BQU8sQ0FBQztPQUMzQixHQUFHLE9BQU87UUFDVCxHQUFHO1NBQ0YsRUFBRSxNQUFNO09BQ1YsRUFBRTtNQUNIO0tBQ0QsQ0FBQyxDQUFDO0lBQ0gsR0FBRyxFQUFFLEdBQUcsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsU0FBUztLQUN0QyxXQUFXO0tBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLE1BQU0sQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO01BQ3ZGLFdBQVc7TUFDWCxNQUFNLEVBQUUsV0FBVyxZQUFZLEVBQUUsU0FBUyxXQUFXLFdBQVcsRUFBRSxTQUFTLFNBQVMsU0FBUztNQUM3RixPQUFPO01BQ1AsV0FBVyxNQUFNO09BQ2hCLElBQUksSUFBSUEsSUFBRSxFQUFFLE9BQU8sT0FBTyxDQUFDO09BQzNCLEdBQUcsT0FBTztRQUNULEdBQUc7U0FDRixFQUFFLE1BQU07T0FDVixFQUFFO01BQ0g7S0FDRCxDQUFDLENBQUM7SUFDSCxHQUFHLEVBQUUsR0FBRztHQUNULENBQUM7RUFDRixDQUFDO0NBQ0YsQ0FBQztBQUNGO0FBQ0EsSUFBSSxLQUFBLEdBQUluQixhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxNQUFNLEdBQUcsUUFBUSxHQUFHLFlBQVksR0FBRyxZQUFZLEdBQUcsTUFBTSxHQUFHLGNBQWMsR0FBRyxrQkFBa0IsR0FBRyxrQkFBa0IsSUFBSSxZQUFZLEdBQUcsa0JBQWtCLEdBQUcsU0FBUyxHQUFHLFFBQVEsS0FBSyxLQUFLLFdBQVcsSUFBSSxJQUFJLFVBQVUsSUFBSSxHQUFHLFVBQVUsS0FBSyxRQUFRLFlBQVksS0FBSyxDQUFDLEdBQUcsWUFBWSxLQUFLLENBQUMsR0FBRyxXQUFXLEtBQUssQ0FBQyxHQUFHLFVBQVUsS0FBSyxDQUFDLEdBQUcsWUFBWSxLQUFLLENBQUMsR0FBRyxXQUFXLEtBQUssSUFBSSxjQUFjLElBQUksbUJBQW1CLElBQUksZ0JBQWdCLElBQUksY0FBYyxJQUFJLFNBQVMsSUFBSSxpQkFBaUIsSUFBSSxHQUFHLE1BQU0sSUFBSTtDQUNoZ0IsSUFBSSxDQUFDLEdBQUcsTUFBQSxHQUFLb0IsYUFBQUEsU0FBQUEsT0FBUSxJQUFJYixJQUFFLENBQUMsSUFBSSxJQUFJSSxJQUFFLENBQUMsSUFBSUosSUFBRSxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1hLGFBQUFBLFNBQUFBLENBQUUsS0FBSyxRQUFRLEdBQUcsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksT0FBQSxHQUFNQSxhQUFBQSxTQUFBQSxDQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFBLEdBQU1BLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxFQUFFLEdBQUcsQ0FBQyxHQUFHLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxFQUFFLEdBQUcsQ0FBQyxHQUFHLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsT0FBQSxHQUFNQSxhQUFBQSxTQUFBQSxpQkFBa0IsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLEVBQUUsWUFBWSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsaUJBQWtCLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxJQUFJLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxJQUFJLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxJQUFJLEdBQUcsQ0FBQyxJQUFJLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLE9BQUEsR0FBTUEsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLEdBQUcsTUFBQSxHQUFLaEIsYUFBQUEsT0FBQUEsQ0FBRSxFQUFFLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxPQUFBQSxDQUFFLENBQUMsR0FBRyxJQUFJLE1BQU07Q0FDamhCLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLElBQUk7R0FDSCxJQUFJLElBQUksR0FBRyxDQUFDO0dBQ1osR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsUUFBUSxFQUFFLEVBQUUsSUFBSSxHQUFHLEdBQUcsS0FBSyxHQUFHLFFBQVEsUUFBUTtFQUMvRCxTQUFTLEdBQUc7R0FDWCxJQUFJLElBQUksYUFBYSxRQUFRLElBQW9CLHNCQUFNLDJCQUEyQjtHQUNsRixHQUFHLEVBQUUsT0FBTyxHQUFHLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDLEdBQUcsR0FBRyxLQUFLLFFBQVE7RUFDckQ7Q0FDRCxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxJQUFBLEdBQUdFLGFBQUFBLFVBQUFBLE9BQVE7RUFDWCxJQUFJLEdBQUc7R0FDTixFQUFFQyxJQUFFLENBQUMsQ0FBQztHQUNOO0VBQ0Q7RUFDQSxJQUFJLEdBQUc7R0FDTixFQUFFSSxJQUFFLENBQUMsQ0FBQztHQUNOO0VBQ0Q7RUFDQSxJQUFJLEdBQUcsUUFBUTtHQUNkLEVBQUVKLElBQUUsRUFBRSxNQUFNLENBQUM7R0FDYjtFQUNEO0VBQ0EsSUFBSSxHQUFHLFlBQVk7R0FDbEIsRUFBRUksSUFBRSxFQUFFLFVBQVUsQ0FBQztHQUNqQjtFQUNEO0VBQ0EsRUFBRUosSUFBRSxLQUFLLENBQUMsQ0FBQztDQUNaLEdBQUc7RUFDRjtFQUNBO0VBQ0E7Q0FDRCxDQUFDLElBQUEsR0FBR0QsYUFBQUEsVUFBQUEsT0FBUTtFQUNYLE1BQU0sRUFBRSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUM7Q0FDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFBLEdBQUdBLGFBQUFBLFVBQUFBLE9BQVE7RUFDaEIsSUFBSSxJQUFJLElBQUlDLElBQUUsQ0FBQyxJQUFJLElBQUlJLElBQUUsQ0FBQyxJQUFJLEdBQUcsU0FBU0osSUFBRSxFQUFFLE1BQU0sSUFBSUksSUFBRSxHQUFHLFVBQVU7RUFDdkUsRUFBRSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUUsZUFBZSxFQUFFLEVBQUUsV0FBVyxHQUFHLEVBQUUsbUJBQW1CLEVBQUUsRUFBRSxjQUFjLEdBQUcsSUFBSSxNQUFNO0dBQzNHLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQztHQUNqQixPQUFPLEVBQUUsSUFBSSxFQUFFLGNBQWMsR0FBRztFQUNqQyxDQUFDO0NBQ0YsR0FBRztFQUNGO0VBQ0E7RUFDQTtDQUNELENBQUMsSUFBQSxHQUFHTCxhQUFBQSxVQUFBQSxPQUFRO0VBQ1gsSUFBSSxJQUFJLENBQUM7RUFDVCxRQUFRLFlBQVk7R0FDbkIsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJO0lBQ2pDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxFQUFFO0lBQ2IsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssTUFBTSxRQUFRLElBQUk7S0FDcENNLElBQUUsR0FBRyxDQUFDO0tBQ05BLElBQUUsR0FBRyxDQUFDO0tBQ05BLElBQUUsSUFBSSxDQUFDO0tBQ1BBLElBQUUsR0FBRyxDQUFDO0lBQ1AsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDO0lBQ1osSUFBSSxHQUFHLENBQUMsR0FBRyxHQUFHO0lBQ2QsSUFBSSxHQUFHO0tBQ04sSUFBSSxJQUFJTCxJQUFFLENBQUM7S0FDWCxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsWUFBWSxFQUFFLEdBQUcsRUFBRSxlQUFlLEVBQUUsRUFBRSxXQUFXLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxFQUFFLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDOUcsT0FBTyxJQUFJLEdBQUc7S0FDYixJQUFJLElBQUlJLElBQUUsQ0FBQztLQUNYLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxZQUFZLEVBQUUsR0FBRyxFQUFFLGVBQWUsRUFBRSxFQUFFLFdBQVcsR0FBRyxFQUFFLGtCQUFrQixFQUFFLEVBQUUsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUM5RyxPQUFPLElBQUksR0FBRyxRQUFRO0tBQ3JCLElBQUksSUFBSUosSUFBRSxFQUFFLE1BQU07S0FDbEIsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUUsZUFBZSxFQUFFLEVBQUUsV0FBVyxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsRUFBRSxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlHLE9BQU8sSUFBSSxHQUFHLFlBQVk7S0FDekIsSUFBSSxJQUFJSSxJQUFFLEVBQUUsVUFBVTtLQUN0QixFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsWUFBWSxFQUFFLEdBQUcsRUFBRSxlQUFlLEVBQUUsRUFBRSxXQUFXLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxFQUFFLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDOUc7SUFDQSxNQUFNLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLEVBQUUsSUFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxFQUFFLElBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLEdBQUcsRUFBRSxJQUFJO0dBQ3BJLFNBQVMsR0FBRztJQUNYLElBQUksR0FBRztJQUNQLElBQUksSUFBSSxhQUFhLFFBQVEsSUFBb0Isc0JBQU0sOEJBQThCO0lBQ3JGLEdBQUcsRUFBRSxPQUFPLEdBQUcsS0FBSyxDQUFDO0dBQ3RCLFVBQVU7SUFDVCxLQUFLLEdBQUcsQ0FBQyxDQUFDO0dBQ1g7RUFDRCxFQUFBLENBQUcsU0FBUztHQUNYLElBQUksQ0FBQztFQUNOO0NBQ0QsR0FBRztFQUNGO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxJQUFBLEdBQUdMLGFBQUFBLFVBQUFBLE9BQVE7RUFDWCxHQUFHLFVBQVU7Q0FDZCxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUEsR0FBR0EsYUFBQUEsVUFBQUEsT0FBUTtFQUNqQixHQUFHLFVBQVU7Q0FDZCxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUEsR0FBR0EsYUFBQUEsVUFBQUEsT0FBUTtFQUNoQixJQUFJLE9BQU8sWUFBWSxDQUFDLEdBQUc7RUFDM0IsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJO0dBQ2YsV0FBVztHQUNYLFVBQVU7R0FDVixZQUFZO0dBQ1osTUFBTTtHQUNOLFNBQVM7R0FDVCxTQUFTO0VBQ1Y7RUFDQSxRQUFRLFlBQVk7R0FDbkIsSUFBSTtJQUNILElBQUksSUFBSSxHQUFHO0lBQ1gsSUFBSSxDQUFDLEdBQUc7SUFDUixHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRTtJQUNiLElBQUksSUFBSSxNQUFNLEVBQUUsR0FBRyxDQUFDO0lBQ3BCLElBQUksR0FBRztJQUNQLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRztLQUNyQixFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxHQUFHLEtBQUssQ0FBQztLQUMxQjtJQUNEO0lBQ0EsRUFBRSxFQUFFLElBQUksR0FBRyxHQUFHLEVBQUUsY0FBYyxFQUFFLEtBQUssTUFBTSxHQUFHLEtBQUssRUFBRSxJQUFJO0dBQzFELFNBQVMsR0FBRztJQUNYLElBQUksR0FBRztJQUNQLElBQUksSUFBSSxhQUFhLFFBQVEsSUFBb0Isc0JBQU0sNkJBQTZCO0lBQ3BGLEdBQUcsRUFBRSxPQUFPLEdBQUcsS0FBSyxDQUFDO0dBQ3RCLFVBQVU7SUFDVCxLQUFLLEdBQUcsQ0FBQyxDQUFDO0dBQ1g7RUFDRCxFQUFBLENBQUcsU0FBUztHQUNYLElBQUksQ0FBQztFQUNOO0NBQ0QsR0FBRztFQUNGO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsV0FBVyxNQUFNLElBQUksS0FBSyxFQUFFLGlCQUFpQixhQUFhLFFBQVEsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssT0FBTyxZQUFZLE9BQU8sUUFBUSxLQUFLLE9BQU8sWUFBWSxPQUFPLFFBQVEsSUFBSSxPQUFPLFVBQVUsS0FBQSxHQUFJZ0IsYUFBQUEsUUFBQUEsT0FBUSxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFHO0VBQ3pSO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxHQUFHLEtBQUEsR0FBSUEsYUFBQUEsUUFBQUEsT0FBUSxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHO0VBQ3BDO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxHQUFHLEtBQUssSUFBSSxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDO0NBQzlHLENBQUEsR0FBQSxhQUFBLFVBQUEsT0FBUTtFQUNQLE1BQU0sS0FBSyxFQUFFLENBQUM7Q0FDZixHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDVCxJQUFJLE1BQUEsR0FBS0EsYUFBQUEsUUFBQUEsT0FBUSxJQUFJLElBQUksS0FBSyxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksR0FBRztFQUM5QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxHQUFHLE1BQUEsR0FBS0EsYUFBQUEsUUFBQUEsT0FBUTtFQUNoQixJQUFJLG9CQUFvQixJQUFJLElBQUk7RUFDaEMsT0FBTyxLQUFLLEdBQUcsU0FBUyxNQUFNO0dBQzdCLElBQUksSUFBSSxFQUFFO0dBQ1YsRUFBRSxJQUFJLEtBQUssUUFBUSxNQUFNLEtBQUssWUFBWSxPQUFPLENBQUMsQ0FBQztFQUNwRCxDQUFDLEdBQUc7Q0FDTCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7Q0FDVixDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxLQUFLLEVBQUUsU0FBUyxLQUFLLEdBQUcsT0FBTyxLQUFLLEdBQUcsRUFBRTtDQUMxQyxHQUFHO0VBQ0Y7RUFDQSxFQUFFO0VBQ0Y7Q0FDRCxDQUFDO0NBQ0QsSUFBSSxLQUFBLEdBQUlBLGFBQUFBLFFBQUFBLE9BQVEsR0FBRyxJQUFJLEdBQUcsS0FBSyxJQUFJLE1BQU0sQ0FBQyxHQUFHO0VBQzVDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDLEdBQUcsS0FBSyxFQUFFLFFBQVEsTUFBTSxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUMsUUFBUSxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxTQUFTLE9BQU8sQ0FBQyxDQUFDLE1BQU0sSUFBSSxHQUFHLEtBQUssS0FBSyxLQUFLLEtBQUssQ0FBQyxJQUFJLElBQUksR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxLQUFLLElBQUksRUFBRSxRQUFRLEtBQUssRUFBRSxHQUFHLEtBQUssRUFBRSxNQUFNLElBQUksRUFBRSxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxLQUFLLEdBQUcsU0FBUyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxRQUFBQSxPQUFRO0VBQ2pVLElBQUksb0JBQW9CLElBQUksSUFBSTtFQUNoQyxPQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU07R0FDMUIsRUFBRSxJQUFJUixJQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUNwQixDQUFDLEdBQUcsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxNQUFNLENBQUMsQ0FBQyxDQUFDO0NBQ25FLEdBQUc7RUFDRjtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFRO0VBQ1AsR0FBRyxVQUFVLEVBQUU7Q0FDaEIsR0FBRyxDQUFDLEVBQUUsQ0FBQztDQUNQLElBQUksTUFBQSxHQUFLUSxhQUFBQSxRQUFBQSxPQUFRO0VBQ2hCLElBQUksb0JBQW9CLElBQUksSUFBSTtFQUNoQyxPQUFPLEVBQUUsU0FBUyxNQUFNO0dBQ3ZCLElBQUksSUFBSUwsSUFBRSxHQUFHLENBQUM7R0FDZCxFQUFFLFNBQVMsVUFBVSxFQUFFLElBQUksRUFBRSxLQUFLLEdBQUcsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHO0VBQzNELENBQUMsR0FBRztDQUNMLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLE1BQUEsR0FBS0ssYUFBQUEsUUFBQUEsT0FBUSxFQUFFLFFBQVEsTUFBTSxFQUFFLFNBQVMsVUFBVSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxLQUFLLE1BQU1SLElBQUUsRUFBRSxLQUFLLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxLQUFLLE1BQU0sVUFBVSxHQUFHLFNBQVMsS0FBSyxHQUFHLE9BQU8sTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDO0NBQ3pMLFNBQVMsR0FBRyxHQUFHO0VBQ2QsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDO0NBQ2I7Q0FDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0VBQ2pCLElBQUksT0FBTztHQUNWLEdBQUc7SUFDRixJQUFJO0VBQ04sRUFBRSxHQUFHLEVBQUUsQ0FBQztDQUNUO0NBQ0EsU0FBUyxHQUFHLEdBQUc7RUFDZCxHQUFHLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztDQUN4QjtDQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztFQUNwQixJQUFJLElBQUksS0FBSyxFQUFFLE1BQU0sSUFBSSxFQUFFLEVBQUU7RUFDN0IsT0FBTyxJQUFJLEVBQUU7R0FDWixLQUFLO0dBQ0wsVUFBVTtHQUNWLFFBQVE7R0FDUixPQUFPO0VBQ1IsQ0FBQyxJQUFJRSxJQUFFLEdBQUcsQ0FBQztDQUNaO0NBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztFQUNqQixJQUFJLElBQUlGLElBQUUsR0FBRyxHQUFHLENBQUM7RUFDakIsR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUFFLEdBQUcsRUFBRSxDQUFDO0NBQ2xCO0NBQ0EsU0FBUyxHQUFHLEdBQUc7RUFDZCxPQUFPLEdBQUcsRUFBRSxLQUFLLEdBQUcsTUFBTUEsSUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLElBQUksRUFBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksR0FBRyxFQUFFLElBQUk7Q0FDL0U7Q0FDQSxTQUFTLEtBQUs7RUFDYixHQUFHLElBQUksR0FBRyxFQUFFLElBQUk7Q0FDakI7Q0FDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0VBQ2pCLElBQUksSUFBSUEsSUFBRSxHQUFHLEdBQUcsQ0FBQztFQUNqQixHQUFHO0dBQ0YsT0FBTztHQUNQLE9BQU8sRUFBRSxHQUFHLEVBQUU7RUFDZixDQUFDO0NBQ0Y7Q0FDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0VBQ2pCLEdBQUcsRUFBRSxLQUFLLEdBQUcsTUFBTUEsSUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUk7Q0FDOUQ7Q0FDQSxTQUFTLEdBQUcsR0FBRztFQUNkLElBQUksTUFBTTtHQUNULElBQUksSUFBSSxJQUFJLElBQUksQ0FBQztHQUNqQixPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHO0VBQzNDLENBQUM7Q0FDRjtDQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztFQUNwQixJQUFJLE1BQU0sUUFBUTtFQUNsQixJQUFJLElBQUlBLElBQUUsR0FBRyxHQUFHLENBQUM7RUFDakIsSUFBSSxNQUFNO0dBQ1QsSUFBSSxNQUFNLFVBQVUsT0FBTyxvQkFBb0IsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixJQUFJLElBQUk7R0FDdEYsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDO0dBQ2pCLE9BQU8sSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLEdBQUc7RUFDcEMsQ0FBQztDQUNGO0NBQ0EsU0FBUyxHQUFHLEdBQUc7RUFDZCxJQUFJLE1BQU0sUUFBUTtHQUNqQixJQUFJLE1BQU0sVUFBVTtJQUNuQixJQUFJLElBQUksRUFBRSxNQUFNLE1BQU0sRUFBRSxTQUFTLFVBQVUsRUFBRSxHQUFHO0lBQ2hELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxLQUFLO0tBQ2pCLG1CQUFtQixJQUFJLElBQUksQ0FBQztLQUM1QjtJQUNEO0lBQ0EsR0FBRyxvQkFBb0IsSUFBSSxJQUFJLENBQUNBLElBQUUsRUFBRSxLQUFLLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixJQUFJLElBQUksQ0FBQztJQUMxRjtHQUNEO0dBQ0EsSUFBSSxNQUFNO0lBQ1QsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDO0lBQ2pCLE9BQU8sR0FBRyxTQUFTLE1BQU07S0FDeEIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO0lBQzFCLENBQUMsR0FBRztHQUNMLENBQUM7RUFDRjtDQUNEO0NBQ0EsSUFBSSxLQUFLRCxJQUFFLGdCQUFnQixFQUFFLEdBQUcsS0FBSyxFQUFFLFVBQVUsTUFBTSxTQUFTLElBQUksS0FBSyxHQUFHLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxTQUFTLEdBQUcsS0FBSyxFQUFFLFFBQVEseUJBQXlCLENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxFQUFFLFFBQVEsTUFBTSxFQUFFLFFBQVEsaUJBQWlCLENBQUMsRUFBQSxDQUFHLEtBQUssTUFBTSxNQUFNLGlCQUFpQixpQkFBaUIsT0FBTyxNQUFNLGNBQWMsYUFBYSxHQUFHLFdBQVcsTUFBTSxpQkFBaUIsaUJBQWlCLEdBQUcsV0FBVyxNQUFNLGVBQWUsVUFBVSxJQUFJLEVBQUUsUUFBUSxNQUFNLEVBQUUsU0FBUyxPQUFPLENBQUMsQ0FBQyxTQUFTLE1BQU0sRUFBRSxDQUFDLENBQUMsT0FBTyxPQUFPLEdBQUcsS0FBSyxPQUFPLElBQUksS0FBSyxJQUFJLEVBQUUsV0FBVyxjQUFjLENBQUMsR0FBRyxLQUFLO0NBQy9oQixTQUFTLEtBQUs7RUFDYixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxZQUFZLEVBQUUsVUFBVTtHQUNoRCxNQUFNLFNBQVMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTyxFQUFFLFdBQVcsaURBQWlELENBQUM7R0FDOUcsRUFBRSxLQUFLLE1BQU07SUFDWixJQUFJLElBQUksRUFBRSxPQUFPLElBQUksRUFBRTtJQUN2QixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0tBQy9CLFdBQVc7S0FDWCxPQUFPO01BQ04sT0FBTyxNQUFNLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxLQUFLLFdBQVcsR0FBRyxFQUFFLE1BQU07TUFDakUsVUFBVSxNQUFNLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxFQUFFO0tBQ3hDO0lBQ0QsR0FBRyxFQUFFLEdBQUc7R0FDVCxDQUFDO0dBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTyxFQUFFLFdBQVcsK0NBQStDLENBQUM7RUFDdkYsRUFBRSxDQUFDO0NBQ0o7Q0FDQSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQVU7R0FDTyxpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0lBQ3hCLFdBQVc7SUFDWCxVQUFVO0tBQ1QsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztNQUMvQixXQUFXO01BQ1gsTUFBTTtNQUNOLE9BQU87TUFDUCxhQUFhO01BQ2IsV0FBVyxNQUFNO09BQ2hCLEdBQUcsRUFBRSxPQUFPLEtBQUssR0FBRyxFQUFFLENBQUM7TUFDeEI7S0FDRCxDQUFDLElBQUk7S0FDTCxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO01BQy9CLFdBQVc7TUFDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLFdBQVcsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO09BQzNGLFdBQVc7T0FDWCxPQUFPLEtBQUs7T0FDWixXQUFXLE1BQU07UUFDaEIsSUFBSSxJQUFJLEVBQUUsT0FBTyxTQUFTO1FBQzFCLEVBQUUsQ0FBQyxHQUFHLG1CQUFtQixJQUFJLElBQUksQ0FBQztPQUNuQztPQUNBLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtRQUN0QyxPQUFPO1FBQ1AsVUFBVTtPQUNYLENBQUMsR0FBRyxHQUFHLEtBQUssTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtRQUM3QyxPQUFPLEVBQUU7UUFDVCxVQUFVLEVBQUU7T0FDYixHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7TUFDWCxDQUFDLENBQUM7S0FDSCxDQUFDLElBQUk7S0FDTCxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxTQUFTO01BQy9CLFdBQVc7TUFDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLFlBQVksQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO09BQzVGLFdBQVc7T0FDWCxPQUFPLE9BQU8sQ0FBQztPQUNmLFdBQVcsTUFBTTtRQUNoQixJQUFJLElBQUksT0FBTyxFQUFFLE9BQU8sS0FBSztRQUM3QixFQUFFLE9BQU8sU0FBUyxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztPQUM3QztPQUNBLFdBQVcsRUFBRSxtQkFBbUI7UUFDL0I7UUFDQTtRQUNBO09BQ0QsRUFBQSxDQUFHLEtBQUssTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtRQUN6QyxPQUFPLE9BQU8sQ0FBQztRQUNmLFVBQVU7T0FDWCxHQUFHLENBQUMsQ0FBQztNQUNOLENBQUMsQ0FBQztLQUNILENBQUMsSUFBSTtJQUNOO0dBQ0QsQ0FBQztHQUNELEtBQXFCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDN0IsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLElBQUk7R0FDTCxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQzdCLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxJQUFJO0dBQ1csaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztJQUN4QixXQUFXO0lBQ1gsVUFBVTtLQUNPLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87TUFDeEIsV0FBVztNQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7T0FDcEMsV0FBVztPQUNYLE9BQU87T0FDUCxVQUFVLENBQUMsR0FBRyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO1FBQzNDLFdBQVc7UUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxNQUFNLEVBQUUsVUFBVTtTQUM3QyxNQUFNLFNBQVMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtVQUM3QyxXQUFXO1VBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztXQUNwQyxNQUFNO1dBQ04sU0FBUztXQUNULFdBQVcsTUFBTSxHQUFHLEVBQUUsT0FBTyxPQUFPO1dBQ3BDLGNBQWM7VUFDZixDQUFDO1NBQ0YsQ0FBQztTQUNELEVBQUUsS0FBSyxNQUFNO1VBQ1osSUFBSSxJQUFJLEdBQUcsY0FBYyxFQUFFLE1BQU0sS0FBSyxFQUFFLFVBQVUsS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRTtVQUNyRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO1dBQzlCLFdBQVc7V0FDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO1lBQ2xDLFdBQVc7WUFDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7YUFDdEMsV0FBVzthQUNYLE1BQU07YUFDTixlQUFlLEdBQUcsQ0FBQzthQUNuQixVQUFVLENBQUMsRUFBRTthQUNiLGNBQWMsR0FBRyxFQUFFLFFBQVE7YUFDM0IsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLE1BQU0sQ0FBQyxHQUFHLEVBQUUsV0FBMkIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUSxFQUFFLFVBQVUsR0FBRyxjQUFjLEVBQUUsTUFBTSxFQUFFLFlBQVksSUFBSSxDQUFDLElBQUksSUFBSTtZQUNySyxDQUFDLEdBQUcsTUFBTSxFQUFFLGFBQWEsRUFBRSxTQUFTLFlBQTRCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFVBQVU7YUFDM0UsV0FBV0EsSUFBRSx1QkFBdUIsSUFBSSxnQ0FBZ0MsRUFBRTthQUMxRSxPQUFPLEdBQUcsRUFBRSxFQUFFLFFBQVEsRUFBRTthQUN4QixXQUFXLE1BQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLEtBQUs7YUFDekMsVUFBVTtjQUNPLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7ZUFDM0IsT0FBTztlQUNQLFVBQVU7Y0FDWCxDQUFDO2NBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtlQUMzQixPQUFPO2VBQ1AsVUFBVTtjQUNYLENBQUM7Y0FDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO2VBQzNCLE9BQU87ZUFDUCxVQUFVO2NBQ1gsQ0FBQzthQUNGO1lBQ0QsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO2FBQy9CLFdBQVdBLElBQUUsdUJBQXVCLElBQUksZ0NBQWdDLEVBQUU7YUFDMUUsTUFBTTthQUNOLE9BQU8sRUFBRSxFQUFFLFFBQVE7YUFDbkIsYUFBYTthQUNiLFdBQVcsTUFBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLE9BQU8sS0FBSztZQUMxQyxDQUFDLElBQUksSUFBSTtXQUNWLENBQUM7VUFDRixHQUFHLEVBQUUsR0FBRztTQUNULENBQUM7U0FDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO1VBQ3ZCLFdBQVc7VUFDWCxVQUFVO1NBQ1gsQ0FBQztRQUNGLEVBQUUsQ0FBQztPQUNKLENBQUMsQ0FBQztNQUNILENBQUM7S0FDRixDQUFDO0tBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztNQUN4QixXQUFXO01BQ1gsT0FBTyxFQUFFLFFBQVEsR0FBRyxHQUFHLElBQUk7TUFDM0IsV0FBVyxNQUFNO09BQ2hCLElBQUksSUFBSSxFQUFFO09BQ1YsR0FBRyxFQUFFLFNBQVMsR0FBRyxHQUFHLEVBQUUsVUFBVTtNQUNqQztNQUNBLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7T0FDcEMsV0FBVztPQUNYLFVBQVUsQ0FBQyxHQUFHLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVMsRUFBRSxVQUFVO1FBQ3ZELEtBQUssSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtTQUNoQyxXQUFXO1NBQ1gsT0FBTyxFQUFFLFFBQVEsR0FBRyxHQUFHLElBQUk7U0FDM0IsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTSxFQUFFLFNBQVMsR0FBRyxDQUFDO1FBQ2xELENBQUMsSUFBSTtRQUNMLEdBQUcsS0FBSyxHQUFHLE1BQU07U0FDaEIsSUFBSSxFQUFFLFNBQVMsU0FBUztVQUN2QixJQUFJLElBQUksRUFBRSxjQUFjLFdBQVcsSUFBSSxFQUFFLElBQUksQ0FBQztVQUM5QyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO1dBQzlCLFdBQVc7V0FDWCxPQUFPLEVBQUUsUUFBUSxHQUFHLEVBQUUsSUFBSTtXQUMxQixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO1lBQ2pDLFNBQVM7WUFDVCxXQUFXO1lBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsVUFBVTthQUNyQyxXQUFXO2FBQ1gsTUFBTTthQUNOLGVBQWUsR0FBRyxDQUFDO2FBQ25CLFVBQVU7Y0FDTyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxJQUFJLFNBQVMsT0FBTyxDQUFDO2NBQzNDLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsQ0FBQztjQUN6QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxDQUFDLEVBQUUsYUFBYSxHQUFHLE9BQU8sRUFBRSxDQUFDO2FBQ3BFO1lBQ0QsQ0FBQztXQUNGLENBQUM7VUFDRixHQUFHLEVBQUUsR0FBRztTQUNUO1NBQ0EsSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFPO1NBQ25CLElBQUksSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFLFlBQVksR0FBRyxJQUFJQyxJQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUksT0FBTztTQUM5RSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxNQUFNO1VBQzlCLFdBQVdELElBQUUseUJBQXlCLElBQUksb0NBQW9DLEVBQUU7VUFDaEYsT0FBTyxFQUFFLFFBQVEsR0FBRyxFQUFFLElBQUk7VUFDMUIsVUFBVTtXQUNULE1BQU0sU0FBUyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO1lBQzdDLFdBQVc7WUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO2FBQ3BDLE1BQU07YUFDTixTQUFTO2FBQ1QsV0FBVyxNQUFNLEdBQUcsR0FBRyxHQUFHLEVBQUUsT0FBTyxPQUFPO2FBQzFDLGNBQWMsY0FBYztZQUM3QixDQUFDO1dBQ0YsQ0FBQztXQUNELEVBQUUsS0FBSyxNQUFNO1lBQ1osSUFBSSxJQUFJSyxLQUFHLElBQUksS0FBSyxFQUFBLEdBQUssRUFBRSxNQUFNLEVBQUUsSUFBSTtZQUN2QyxPQUFPLEtBQUssRUFBRSxXQUFXLEVBQUUsV0FBVyxjQUFjLEVBQUUsU0FBUyxZQUE0QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO2FBQ2xHLFdBQVc7YUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO2NBQ3JDLFdBQVc7Y0FDWCxPQUFPLE1BQU0sU0FBUyxTQUFTO2NBQy9CLFdBQVcsTUFBTTtlQUNoQixJQUFJLElBQUksRUFBRSxPQUFPLFVBQVU7ZUFDM0IsR0FBRyxPQUFPO2dCQUNULEdBQUcsS0FBSyxDQUFDO2lCQUNSLEVBQUUsTUFBTTtlQUNWLEVBQUU7Y0FDSDtjQUNBLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtlQUN0QyxPQUFPO2VBQ1AsVUFBVTtjQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtlQUMvQixPQUFPO2VBQ1AsVUFBVTtjQUNYLENBQUMsQ0FBQzthQUNILENBQUM7WUFDRixHQUFHLEVBQUUsR0FBRyxJQUFJLEVBQUUsV0FBVyxZQUFZLEVBQUUsU0FBUyxTQUF5QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO2FBQ2hGLFdBQVc7YUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxVQUFVO2NBQ3JDLFdBQVc7Y0FDWCxPQUFPO2NBQ1AsV0FBVyxNQUFNO2VBQ2hCLElBQUksSUFBSUMsSUFBRSxFQUFFLE9BQU8sT0FBTyxDQUFDO2VBQzNCLEdBQUcsT0FBTztnQkFDVCxHQUFHLEtBQUssQ0FBQztpQkFDUixFQUFFLE1BQU07ZUFDVixFQUFFO2NBQ0g7Y0FDQSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7ZUFDdEMsT0FBTztlQUNQLFVBQVU7Y0FDWCxDQUFDLEdBQUcsRUFBRSxRQUFRLEtBQUssTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtlQUNwRCxPQUFPLE9BQU8sRUFBRSxLQUFLO2VBQ3JCLFVBQVUsRUFBRTtjQUNiLEdBQUcsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7YUFDckIsQ0FBQztZQUNGLEdBQUcsRUFBRSxHQUFHLElBQUksRUFBRSxXQUFXLGFBQTZCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE1BQU07YUFDN0QsV0FBVzthQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFlBQVk7Y0FDdkMsV0FBVztjQUNYLE9BQU87Y0FDUCxXQUFXLE1BQU07ZUFDaEIsSUFBSSxJQUFJQSxJQUFFLEVBQUUsT0FBTyxPQUFPLENBQUM7ZUFDM0IsR0FBRyxPQUFPO2dCQUNULEdBQUcsS0FBSyxDQUFDO2lCQUNSLEVBQUUsTUFBTTtlQUNWLEVBQUU7Y0FDSDthQUNELENBQUM7WUFDRixHQUFHLEVBQUUsR0FBRyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO2FBQ25DLFdBQVc7YUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO2NBQ3BDLFdBQVc7Y0FDWCxNQUFNLEVBQUUsV0FBVyxZQUFZLEVBQUUsU0FBUyxXQUFXLFdBQVcsRUFBRSxTQUFTLFNBQVMsU0FBUztjQUM3RixPQUFPO2NBQ1AsV0FBVyxNQUFNO2VBQ2hCLElBQUksSUFBSUEsSUFBRSxFQUFFLE9BQU8sT0FBTyxDQUFDO2VBQzNCLEdBQUcsT0FBTztnQkFDVCxHQUFHLEtBQUssQ0FBQztpQkFDUixFQUFFLE1BQU07ZUFDVixFQUFFO2NBQ0g7YUFDRCxDQUFDO1lBQ0YsR0FBRyxFQUFFLEdBQUcsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTthQUNuQyxXQUFXO2FBQ1gsT0FBT0gsSUFBRSxFQUFFLEVBQUUsTUFBTSxDQUFDO2FBQ3BCLFVBQVUsR0FBRyxHQUFHLEdBQUcsQ0FBQztZQUNyQixHQUFHLEVBQUUsR0FBRztXQUNULENBQUM7V0FDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO1lBQ3ZCLFdBQVc7WUFDWCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO2FBQ2xDLFdBQVc7YUFDWCxVQUFVLENBQUMsS0FBSyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRUssbUJBQUFBLFVBQUcsRUFBRSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7Y0FDakYsV0FBVztjQUNYLE1BQU07Y0FDTixlQUFlLEdBQUcsQ0FBQztjQUNuQixVQUFVO2FBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO2NBQy9CLFdBQVc7Y0FDWCxNQUFNO2NBQ04sU0FBUztjQUNULFVBQVU7YUFDWCxDQUFDLENBQUMsRUFBRSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7Y0FDcEMsV0FBVztjQUNYLE1BQU07Y0FDTixlQUFlLEdBQUcsR0FBRyxDQUFDO2NBQ3RCLFVBQVU7YUFDWCxDQUFDLElBQUksTUFBTSxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO2NBQzNDLFdBQVc7Y0FDWCxNQUFNO2NBQ04sZUFBZSxHQUFHLEdBQUcsQ0FBQztjQUN0QixVQUFVO2FBQ1gsQ0FBQyxJQUFJLElBQUk7WUFDVixDQUFDO1dBQ0YsQ0FBQztVQUNGO1NBQ0QsR0FBRyxFQUFFLEdBQUc7UUFDVCxDQUFDO1FBQ0QsS0FBSyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO1NBQ2hDLFdBQVc7U0FDWCxPQUFPLEVBQUUsUUFBUSxHQUFHLEdBQUcsSUFBSTtTQUMzQixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNLEVBQUUsU0FBUyxHQUFHLENBQUM7UUFDbEQsQ0FBQyxJQUFJO09BQ04sRUFBRSxDQUFDLENBQUM7TUFDTCxDQUFDO0tBQ0YsQ0FBQztLQUNELE1BQU0sR0FBRyxTQUF5QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO01BQzFDLFdBQVc7TUFDWCxVQUFVLENBQUMsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsV0FBVztPQUM1QyxXQUFXO09BQ1gsY0FBYztPQUNkLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztRQUNuQyxXQUFXO1FBQ1gsVUFBVTtPQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsU0FBUztRQUM5QixXQUFXO1FBQ1gsT0FBTztRQUNQLFVBQVUsQ0FBQyxHQUFHLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVMsRUFBRSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxNQUFNLEVBQUUsVUFBVTtTQUMzRixNQUFNLFNBQVMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTTtVQUM3QyxXQUFXO1VBQ1gsVUFBVSxHQUFHO1NBQ2QsQ0FBQztTQUNELEVBQUUsS0FBSyxHQUFHLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE1BQU07VUFDdkMsV0FBVztVQUNYLFVBQVU7V0FDVCxNQUFNLElBQUksUUFBUSxPQUFPO1dBQ3pCLE1BQU0sS0FBSyxHQUFHLElBQUksRUFBRSxHQUFHLElBQUksUUFBUTtXQUNuQyxHQUFHLElBQUksRUFBRSxHQUFHLEtBQUs7VUFDbEI7U0FDRCxHQUFHLEVBQUUsR0FBRyxDQUFDO1NBQ08saUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsTUFBTTtVQUN2QixXQUFXO1VBQ1gsVUFBVSxDQUFDLGFBQWEsR0FBRyxNQUFNO1NBQ2xDLENBQUM7UUFDRixFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7T0FDUixDQUFDLENBQUM7TUFDSCxDQUFDLElBQUksTUFBTSxHQUFHLFNBQXlCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFdBQVc7T0FDbkQsV0FBVztPQUNYLGNBQWM7T0FDZCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87UUFDbkMsV0FBVztRQUNYLFVBQVU7T0FDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87UUFDNUIsV0FBVztRQUNYLFVBQVUsR0FBRyxLQUFLLEtBQUs7T0FDeEIsQ0FBQyxDQUFDO01BQ0gsQ0FBQyxJQUFJLElBQUk7S0FDVixDQUFDLElBQUk7SUFDTjtHQUNELENBQUM7R0FDRCxLQUFxQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0lBQzdCLFdBQVc7SUFDWCxVQUFVO0tBQ08saUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtNQUMzQixXQUFXO01BQ1gsTUFBTTtNQUNOLGVBQWUsRUFBRSxDQUFDO01BQ2xCLFVBQVUsTUFBTTtNQUNoQixVQUFVO0tBQ1gsQ0FBQztLQUNlLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7TUFDM0IsV0FBVztNQUNYLE1BQU07TUFDTixlQUFlLEdBQUcsTUFBTSxLQUFLLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQztNQUMxQyxVQUFVLE1BQU07TUFDaEIsVUFBVTtLQUNYLENBQUM7S0FDZSxpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVTtNQUNyQztNQUNBLElBQUk7TUFDSjtNQUNBO0tBQ0QsRUFBRSxDQUFDO0tBQ2EsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtNQUMzQixXQUFXO01BQ1gsTUFBTTtNQUNOLGVBQWUsR0FBRyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUM7TUFDOUMsVUFBVSxLQUFLLElBQUk7TUFDbkIsVUFBVTtLQUNYLENBQUM7S0FDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO01BQzNCLFdBQVc7TUFDWCxNQUFNO01BQ04sZUFBZSxFQUFFLElBQUksQ0FBQztNQUN0QixVQUFVLEtBQUssSUFBSTtNQUNuQixVQUFVO0tBQ1gsQ0FBQztJQUNGO0dBQ0QsQ0FBQyxJQUFJO0dBQ0wsS0FBcUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsSUFBSTtJQUMxQixTQUFTO0lBQ1QsT0FBTyxHQUFHO0lBQ1YsT0FBTyxHQUFHO0lBQ1YsZ0JBQWdCLEdBQUcsSUFBSTtJQUN2QixTQUFTLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQztHQUM5QixDQUFDLElBQUk7RUFDTjtDQUNELENBQUM7QUFDRixDQUFDO0FBQ0QsRUFBRSxjQUFjOzs7QUN2cUNoQixJQUFJRSxNQUFJO0NBQ1AsTUFBTTtDQUNOLE9BQU87Q0FDUCxLQUFLO0NBQ0wsUUFBUTtBQUNUO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxLQUFLO0FBQ2I7QUFHQSxJQUFJQyxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUcsY0FBYyxHQUFHLFdBQVcsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksZUFBZSxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxjQUFjLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDdEssT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztFQUMvQixLQUFLO0VBQ0wsV0FBVyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztFQUMxRCxNQUFNO0VBQ04sR0FBRztFQUNILFVBQVUsRUFBRSxLQUFLLE1BQU07R0FDdEIsSUFBSSxJQUFJLEVBQUUsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFFLE9BQU8sSUFBSSxFQUFFLE9BQU8sS0FBSyxFQUFFLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQyw0QkFBNEJILElBQUVDLElBQUUsRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSTtJQUN6SjtJQUNBLElBQUksb0NBQW9DO0lBQ3hDLElBQUksS0FBSztJQUNUO0dBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLE9BQU8sRUFBRSxTQUFTLFdBQVcsRUFBRSxRQUFRLEVBQUU7R0FDbk0sT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtJQUNsQyxNQUFNO0lBQ04sV0FBVztJQUNYLFVBQVUsRUFBRTtJQUNaLE9BQU8sRUFBRTtJQUNULGNBQWM7SUFDZCxnQkFBZ0IsT0FBTyxFQUFFLFdBQVcsWUFBWSxFQUFFLFVBQVUsS0FBSztJQUNqRSxVQUFVLE1BQU07S0FDZixJQUFJO01BQ0gsUUFBUSxFQUFFO01BQ1YsTUFBTTtNQUNOLE9BQU87S0FDUixDQUFDO0lBQ0Y7SUFDQSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxRQUFRO0tBQ25DLFdBQVc7S0FDWCxVQUFVLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsR0FBRztNQUNuQyxXQUFXO01BQ1gsZUFBZTtNQUNmLFdBQVc7S0FDWixDQUFDLElBQUksTUFBTSxFQUFFLFFBQXdCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDOUMsV0FBVztNQUNYLFVBQVUsRUFBRTtLQUNiLENBQUMsSUFBSSxJQUFJO0lBQ1YsQ0FBQztHQUNGLEdBQUcsRUFBRSxFQUFFO0VBQ1IsQ0FBQztDQUNGLENBQUM7QUFDRixDQUFDO0FBQ0QsSUFBRSxjQUFjO0FBR2hCLFNBQVNHLElBQUUsRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdDLE9BQXFCLDJCQUFFLGNBQWMsT0FBTyxPQUFPLE9BQU87RUFDekQsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDUixlQUFlO0VBQ2YsYUFBYTtFQUNiLEtBQUs7RUFDTCxtQkFBbUI7Q0FDcEIsR0FBRyxDQUFDLEdBQUcsSUFBa0IsMkJBQUUsY0FBYyxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQW9CLDJCQUFFLGNBQWMsUUFBUTtFQUM3RyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLENBQUM7QUFDSDtBQUNBLElBQUlDLE1BQWtCLDJCQUFFLFdBQVdELEdBQUM7QUFHcEMsU0FBU0UsSUFBRSxFQUFFLE9BQU8sR0FBRyxTQUFTLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDN0MsT0FBcUIsMkJBQUUsY0FBYyxPQUFPLE9BQU8sT0FBTztFQUN6RCxPQUFPO0VBQ1AsTUFBTTtFQUNOLFNBQVM7RUFDVCxhQUFhO0VBQ2IsUUFBUTtFQUNSLGVBQWU7RUFDZixhQUFhO0VBQ2IsS0FBSztFQUNMLG1CQUFtQjtDQUNwQixHQUFHLENBQUMsR0FBRyxJQUFrQiwyQkFBRSxjQUFjLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksTUFBb0IsMkJBQUUsY0FBYyxRQUFRO0VBQzdHLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsR0FBRztDQUNKLENBQUMsQ0FBQztBQUNIO0FBQ0EsSUFBSUMsTUFBa0IsMkJBQUUsV0FBV0QsR0FBQztBQUdwQyxTQUFTRSxJQUFFLEVBQUUsT0FBTyxHQUFHLFNBQVMsR0FBRyxHQUFHLEtBQUssR0FBRztDQUM3QyxPQUFxQiwyQkFBRSxjQUFjLE9BQU8sT0FBTyxPQUFPO0VBQ3pELE9BQU87RUFDUCxNQUFNO0VBQ04sU0FBUztFQUNULGFBQWE7RUFDYixRQUFRO0VBQ1IsZUFBZTtFQUNmLGFBQWE7RUFDYixLQUFLO0VBQ0wsbUJBQW1CO0NBQ3BCLEdBQUcsQ0FBQyxHQUFHLElBQWtCLDJCQUFFLGNBQWMsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxNQUFvQiwyQkFBRSxjQUFjLFFBQVE7RUFDN0csZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixHQUFHO0NBQ0osQ0FBQyxDQUFDO0FBQ0g7QUFDQSxJQUFJQyxNQUFrQiwyQkFBRSxXQUFXRCxHQUFDO0FBR3BDLFNBQVNFLElBQUUsRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdDLE9BQXFCLDJCQUFFLGNBQWMsT0FBTyxPQUFPLE9BQU87RUFDekQsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDUixlQUFlO0VBQ2YsYUFBYTtFQUNiLEtBQUs7RUFDTCxtQkFBbUI7Q0FDcEIsR0FBRyxDQUFDLEdBQUcsSUFBa0IsMkJBQUUsY0FBYyxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQW9CLDJCQUFFLGNBQWMsUUFBUTtFQUM3RyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLEdBQWlCLDJCQUFFLGNBQWMsUUFBUTtFQUN6QyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLENBQUM7QUFDSDtBQUNBLElBQUlDLE1BQWtCLDJCQUFFLFdBQVdELEdBQUM7QUFHcEMsU0FBU0UsSUFBRSxFQUFFLE9BQU8sR0FBRyxTQUFTLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDN0MsT0FBcUIsMkJBQUUsY0FBYyxPQUFPLE9BQU8sT0FBTztFQUN6RCxPQUFPO0VBQ1AsTUFBTTtFQUNOLFNBQVM7RUFDVCxhQUFhO0VBQ2IsUUFBUTtFQUNSLGVBQWU7RUFDZixhQUFhO0VBQ2IsS0FBSztFQUNMLG1CQUFtQjtDQUNwQixHQUFHLENBQUMsR0FBRyxJQUFrQiwyQkFBRSxjQUFjLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksTUFBb0IsMkJBQUUsY0FBYyxRQUFRO0VBQzdHLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsR0FBRztDQUNKLENBQUMsQ0FBQztBQUNIO0FBQ0EsSUFBSUMsTUFBa0IsMkJBQUUsV0FBV0QsR0FBQztBQUdwQyxTQUFTLEVBQUUsRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdDLE9BQXFCLDJCQUFFLGNBQWMsT0FBTyxPQUFPLE9BQU87RUFDekQsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDUixlQUFlO0VBQ2YsYUFBYTtFQUNiLEtBQUs7RUFDTCxtQkFBbUI7Q0FDcEIsR0FBRyxDQUFDLEdBQUcsSUFBa0IsMkJBQUUsY0FBYyxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQW9CLDJCQUFFLGNBQWMsUUFBUTtFQUM3RyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLENBQUM7QUFDSDtBQUNBLElBQUlFLE1BQWtCLDJCQUFFLFdBQVcsQ0FBQztBQUdwQyxTQUFTLEVBQUUsRUFBRSxPQUFPLEdBQUcsU0FBUyxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQzdDLE9BQXFCLDJCQUFFLGNBQWMsT0FBTyxPQUFPLE9BQU87RUFDekQsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDUixlQUFlO0VBQ2YsYUFBYTtFQUNiLEtBQUs7RUFDTCxtQkFBbUI7Q0FDcEIsR0FBRyxDQUFDLEdBQUcsSUFBa0IsMkJBQUUsY0FBYyxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQW9CLDJCQUFFLGNBQWMsUUFBUTtFQUM3RyxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLEdBQUc7Q0FDSixDQUFDLENBQUM7QUFDSDtBQUNBLElBQUksSUFBa0IsMkJBQUUsV0FBVyxDQUFDO0FBR3BDLFNBQVMsRUFBRSxFQUFFLE9BQU8sR0FBRyxTQUFTLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDN0MsT0FBcUIsMkJBQUUsY0FBYyxPQUFPLE9BQU8sT0FBTztFQUN6RCxPQUFPO0VBQ1AsTUFBTTtFQUNOLFNBQVM7RUFDVCxhQUFhO0VBQ2IsUUFBUTtFQUNSLGVBQWU7RUFDZixhQUFhO0VBQ2IsS0FBSztFQUNMLG1CQUFtQjtDQUNwQixHQUFHLENBQUMsR0FBRyxJQUFrQiwyQkFBRSxjQUFjLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksTUFBb0IsMkJBQUUsY0FBYyxRQUFRO0VBQzdHLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsR0FBRztDQUNKLENBQUMsQ0FBQztBQUNIO0FBQ0EsSUFBSSxJQUFrQiwyQkFBRSxXQUFXLENBQUM7QUFHcEMsU0FBU0MsSUFBRSxFQUFFLE9BQU8sR0FBRyxTQUFTLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDN0MsT0FBcUIsMkJBQUUsY0FBYyxPQUFPLE9BQU8sT0FBTztFQUN6RCxPQUFPO0VBQ1AsTUFBTTtFQUNOLFNBQVM7RUFDVCxhQUFhO0VBQ2IsUUFBUTtFQUNSLGVBQWU7RUFDZixhQUFhO0VBQ2IsS0FBSztFQUNMLG1CQUFtQjtDQUNwQixHQUFHLENBQUMsR0FBRyxJQUFrQiwyQkFBRSxjQUFjLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksTUFBb0IsMkJBQUUsY0FBYyxRQUFRO0VBQzdHLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsR0FBRztDQUNKLENBQUMsQ0FBQztBQUNIO0FBQ0EsSUFBSSxJQUFrQiwyQkFBRSxXQUFXQSxHQUFDO0FBR3BDLFNBQVMsRUFBRSxHQUFHO0NBQ2IsT0FBTyxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssTUFBTSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssT0FBTztBQUNySTtBQUNBLFNBQVMsRUFBRSxHQUFHO0NBQ2IsSUFBSSxJQUFJLEVBQUUsS0FBSztDQUNmLE9BQU8sMkJBQTJCLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJO0FBQ3BEO0FBQ0EsU0FBUyxFQUFFLEdBQUc7Q0FDYixJQUFJLElBQUksRUFBRSxDQUFDO0NBQ1gsT0FBTyxJQUFJLEVBQUUsUUFBUSw2QkFBNkIsR0FBRyxHQUFHLE1BQU0sWUFBWSxFQUFFLENBQUMsRUFBRSw4Q0FBOEMsRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFFLFFBQVEsb0JBQW9CLHFCQUFxQixHQUFHLElBQUksRUFBRSxRQUFRLGdCQUFnQixxQkFBcUIsR0FBRyxJQUFJLEVBQUUsUUFBUSxnQkFBZ0IsYUFBYSxHQUFHLElBQUksRUFBRSxRQUFRLGNBQWMsYUFBYSxHQUFHLElBQUksRUFBRSxRQUFRLGdCQUFnQixlQUFlLEdBQUcsSUFBSSxFQUFFLFFBQVEsY0FBYyxpQkFBaUIsR0FBRztBQUNsYjtBQUNBLFNBQVMsRUFBRSxHQUFHO0NBQ2IsSUFBSSxJQUFJLEVBQUUsTUFBTSxNQUFNLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUk7Q0FDNUQsT0FBTyxJQUFJLEVBQUUsU0FBUztFQUNyQixJQUFJLElBQUksRUFBRTtFQUNWLElBQUksQ0FBQyxFQUFFLEtBQUssR0FBRztHQUNkLEtBQUs7R0FDTDtFQUNEO0VBQ0EsSUFBSSxFQUFFLFdBQVcsS0FBSyxHQUFHO0dBQ3hCLElBQUksSUFBSSxDQUFDO0dBQ1QsS0FBSyxLQUFLLEdBQUcsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxXQUFXLEtBQUssSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLEdBQUcsS0FBSztHQUMxRSxJQUFJLEVBQUUsV0FBVyxLQUFLLElBQUksRUFBRSxLQUFLLGNBQWMsRUFBRSxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUUsY0FBYztHQUM3RTtFQUNEO0VBQ0EsSUFBSSxJQUFJLEVBQUUsTUFBTSxtQkFBbUI7RUFDbkMsSUFBSSxHQUFHO0dBQ04sSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFDO0dBQ2IsRUFBRSxLQUFLLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsR0FBRyxLQUFLO0dBQzFDO0VBQ0Q7RUFDQSxJQUFJLEVBQUUsV0FBVyxHQUFHLEdBQUc7R0FDdEIsSUFBSSxJQUFJLENBQUM7R0FDVCxPQUFPLElBQUksRUFBRSxVQUFVLEVBQUUsRUFBRSxDQUFDLFdBQVcsR0FBRyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxRQUFRLFFBQVEsRUFBRSxDQUFDLEdBQUcsS0FBSztHQUNyRixFQUFFLEtBQUssZUFBZSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEVBQUUsY0FBYztHQUM1RDtFQUNEO0VBQ0EsSUFBSSxFQUFFLE1BQU0sZ0JBQWdCLEdBQUc7R0FDOUIsSUFBSSxJQUFJLENBQUM7R0FDVCxPQUFPLElBQUksRUFBRSxTQUFTO0lBQ3JCLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNLGdCQUFnQjtJQUNuQyxJQUFJLENBQUMsR0FBRztJQUNSLEVBQUUsS0FBSyxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsTUFBTSxHQUFHLEtBQUs7R0FDckM7R0FDQSxFQUFFLEtBQUssT0FBTyxFQUFFLEtBQUssRUFBRSxFQUFFLE1BQU07R0FDL0I7RUFDRDtFQUNBLElBQUksRUFBRSxNQUFNLGdCQUFnQixHQUFHO0dBQzlCLElBQUksSUFBSSxDQUFDO0dBQ1QsT0FBTyxJQUFJLEVBQUUsU0FBUztJQUNyQixJQUFJLElBQUksRUFBRSxFQUFFLENBQUMsTUFBTSxnQkFBZ0I7SUFDbkMsSUFBSSxDQUFDLEdBQUc7SUFDUixFQUFFLEtBQUssT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLE1BQU0sR0FBRyxLQUFLO0dBQ3JDO0dBQ0EsRUFBRSxLQUFLLE9BQU8sRUFBRSxLQUFLLEVBQUUsRUFBRSxNQUFNO0dBQy9CO0VBQ0Q7RUFDQSxJQUFJLElBQUksQ0FBQztFQUNULE9BQU8sSUFBSSxFQUFFLFVBQVUsRUFBRSxFQUFFLENBQUMsS0FBSyxJQUFJO0dBQ3BDLElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLFdBQVcsS0FBSyxLQUFLLGVBQWUsS0FBSyxDQUFDLEtBQUssRUFBRSxXQUFXLEdBQUcsS0FBSyxZQUFZLEtBQUssQ0FBQyxLQUFLLFlBQVksS0FBSyxDQUFDO0dBQ2pJLElBQUksRUFBRSxTQUFTLEtBQUssR0FBRztHQUN2QixFQUFFLEtBQUssQ0FBQyxHQUFHLEtBQUs7RUFDakI7RUFDQSxFQUFFLEtBQUssTUFBTSxFQUFFLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxLQUFLO0NBQ2xDO0NBQ0EsT0FBTyxFQUFFLEtBQUssRUFBRTtBQUNqQjtBQUNBLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRztDQUNuQixJQUFJLElBQUksRUFBRSxZQUFZLE1BQU0sS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLE1BQU0sQ0FBQyxHQUFHLElBQUksTUFBTSxLQUFLLEVBQUUsU0FBUztDQUN2RyxPQUFPO0VBQ04sUUFBUSxFQUFFLE1BQU0sR0FBRyxDQUFDO0VBQ3BCLFVBQVUsRUFBRSxNQUFNLEdBQUcsQ0FBQztFQUN0QixPQUFPLEVBQUUsTUFBTSxDQUFDO0VBQ2hCLFdBQVc7RUFDWCxTQUFTO0NBQ1Y7QUFDRDtBQUNBLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRztDQUNuQixJQUFJLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxrQkFBa0IsR0FBRyxJQUFJLEVBQUUsZ0JBQWdCLEdBQUcsSUFBSSxNQUFNLEdBQUcsRUFBRSxRQUFRLEdBQUcsVUFBVSxHQUFHLE9BQU8sR0FBRyxXQUFXLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQztDQUNoSixJQUFJLENBQUMsR0FBRztFQUNQLElBQUksSUFBSSxHQUFHLElBQUk7RUFDZixPQUFPO0dBQ04sV0FBVyxHQUFHLEVBQUUsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLEVBQUUsTUFBTSxDQUFDO0dBQzNDLFdBQVcsSUFBSSxFQUFFO0dBQ2pCLFNBQVMsSUFBSSxFQUFFO0VBQ2hCO0NBQ0Q7Q0FDQSxJQUFJLElBQUksRUFBRSxNQUFNLElBQUksQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQy9FLE9BQU87RUFDTixXQUFXLEdBQUcsSUFBSSxJQUFJO0VBQ3RCLFdBQVc7RUFDWCxTQUFTLElBQUksRUFBRTtDQUNoQjtBQUNEO0FBQ0EsU0FBUyxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDdEIsSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsa0JBQWtCLEdBQUcsSUFBSSxFQUFFLGdCQUFnQixHQUFHLElBQUksTUFBTSxJQUFJLElBQUksRUFBRSxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLElBQUk7Q0FDckgsT0FBTztFQUNOLFdBQVcsR0FBRyxFQUFFLE1BQU0sR0FBRyxDQUFDLElBQUksSUFBSSxFQUFFLE1BQU0sQ0FBQztFQUMzQyxXQUFXLElBQUksRUFBRTtFQUNqQixTQUFTLElBQUksRUFBRSxTQUFTLEVBQUU7Q0FDM0I7QUFDRDtBQUNBLFNBQVMsRUFBRSxHQUFHO0NBQ2IsSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsa0JBQWtCLEdBQUcsSUFBSSxFQUFFLGdCQUFnQixHQUFHLElBQUksTUFBTSxJQUFJLGNBQWMsRUFBRSxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksSUFBSSxFQUFFO0NBQzFILE9BQU87RUFDTixXQUFXLEdBQUcsRUFBRSxNQUFNLEdBQUcsQ0FBQyxJQUFJLElBQUksRUFBRSxNQUFNLENBQUM7RUFDM0MsV0FBVyxJQUFJLEVBQUUsU0FBUztFQUMxQixTQUFTLElBQUksRUFBRSxTQUFTLElBQUk7Q0FDN0I7QUFDRDtBQUdBLFNBQVMsRUFBRSxFQUFFLE9BQU8sSUFBSSxZQUFZLFlBQVksSUFBSSxpRkFBaUYsYUFBYSxJQUFJLDBCQUEwQixPQUFPLElBQUksSUFBSSxVQUFVLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxrQkFBa0IsSUFBSSxJQUFJLGVBQWUsSUFBSSxJQUFJLElBQUksR0FBRyxNQUFNLElBQUksSUFBSSxVQUFVLEdBQUcsaUJBQWlCLEdBQUcsR0FBRyxLQUFLO0NBQ3JZLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLG9CQUFvQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssS0FBQSxHQUFJQyxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQyxhQUFBQSxTQUFBQSxDQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBQSxHQUFLQSxhQUFBQSxTQUFBQSxDQUFFLE1BQU07Q0FDOUcsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFRO0VBQ1AsRUFBRSxDQUFDO0NBQ0osR0FBRyxDQUFDLENBQUMsQ0FBQztDQUNOLElBQUksSUFBSSxFQUFFLENBQUMsR0FBRyxJQUFJO0VBQ2pCO0VBQ0E7RUFDQSxJQUFJLCtCQUErQjtFQUNuQztDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJO0VBQzVSO0dBQ0MsSUFBSTtHQUNKLE1BQU1QO0dBQ04sT0FBTyxNQUFNLFNBQVMsWUFBWTtFQUNuQztFQUNBO0dBQ0MsSUFBSTtHQUNKLE1BQU1FO0dBQ04sT0FBTztFQUNSO0VBQ0E7R0FDQyxJQUFJO0dBQ0osTUFBTUo7R0FDTixPQUFPO0VBQ1I7RUFDQTtHQUNDLElBQUk7R0FDSixNQUFNO0dBQ04sT0FBTztFQUNSO0VBQ0E7R0FDQyxJQUFJO0dBQ0osTUFBTUo7R0FDTixPQUFPO0VBQ1I7RUFDQTtHQUNDLElBQUk7R0FDSixNQUFNO0dBQ04sT0FBTztFQUNSO0VBQ0E7R0FDQyxJQUFJO0dBQ0osTUFBTTtHQUNOLE9BQU87RUFDUjtFQUNBO0dBQ0MsSUFBSTtHQUNKLE1BQU1FO0dBQ04sT0FBTztFQUNSO0VBQ0E7R0FDQyxJQUFJO0dBQ0osTUFBTU87R0FDTixPQUFPO0VBQ1I7Q0FDRCxHQUFHLEtBQUssR0FBRyxNQUFNO0VBQ2hCLElBQUksR0FBRztFQUNQLElBQUksSUFBSSxFQUFFO0VBQ1YsSUFBSSxDQUFDLEdBQUc7RUFDUixJQUFJLElBQUksRUFBRSxDQUFDO0VBQ1gsTUFBTSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsa0JBQWtCLEVBQUUsV0FBVyxFQUFFLE9BQU8sR0FBRyxFQUFFLEVBQUUsU0FBUyxHQUFHLElBQUksRUFBRSxTQUFTLEdBQUcsSUFBSSxDQUFDO0NBQ2xILEdBQUcsS0FBSyxNQUFNO0VBQ2IsSUFBSSxJQUFJLEVBQUUsY0FBYztFQUN4QixFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7Q0FDWixHQUFHLEtBQUssTUFBTTtFQUNiLElBQUksTUFBTSxlQUFlO0dBQ3hCLElBQUksSUFBSSxNQUFNLFNBQVMsWUFBWTtHQUNuQyxFQUFFLENBQUMsR0FBRyxJQUFJLFFBQVEsR0FBRztHQUNyQjtFQUNEO0VBQ0EsUUFBUSxHQUFSO0dBQ0MsS0FBSztJQUNKLEVBQUUsWUFBWSxNQUFNLEVBQUUsR0FBRyxNQUFNLFNBQVMsQ0FBQztJQUN6QztHQUNELEtBQUs7SUFDSixFQUFFLFNBQVMsTUFBTSxFQUFFLEdBQUcsTUFBTSxNQUFNLFdBQVcsQ0FBQztJQUM5QztHQUNELEtBQUs7SUFDSixFQUFFLFdBQVcsTUFBTSxFQUFFLEdBQUcsS0FBSyxLQUFLLGFBQWEsQ0FBQztJQUNoRDtHQUNELEtBQUs7SUFDSixFQUFFLFVBQVUsTUFBTSxFQUFFLEdBQUcsTUFBTSxPQUFPLENBQUM7SUFDckM7R0FDRCxLQUFLO0lBQ0osRUFBRSxnQkFBZ0IsTUFBTSxFQUFFLEdBQUcsTUFBTSxXQUFXLENBQUM7SUFDL0M7R0FDRCxLQUFLO0lBQ0osRUFBRSxrQkFBa0IsTUFBTSxFQUFFLEdBQUcsT0FBTyxXQUFXLENBQUM7SUFDbEQ7R0FDRCxLQUFLO0lBQ0osRUFBRSxTQUFTLE1BQU0sRUFBRSxHQUFHLEtBQUssS0FBSyxNQUFNLENBQUM7SUFDdkM7R0FDRCxLQUFLLFFBQ0osRUFBRSxRQUFRLENBQUM7RUFHYjtDQUNEO0NBQ0EsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsR0FBRztFQUNILFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztHQUNuQyxXQUFXO0dBQ1gsVUFBVTtJQUNPLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7S0FDMUIsV0FBVztLQUNYLFNBQVM7S0FDVCxVQUFVO0lBQ1gsQ0FBQztJQUNELElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDNUIsV0FBVztLQUNYLFVBQVU7SUFDWCxDQUFDLElBQUk7SUFDVyxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRVosS0FBRztLQUNwQixXQUFXO0tBQ1gsY0FBYztLQUNkLE9BQU8sRUFBRSxLQUFLLE1BQU07TUFDbkIsSUFBSSxJQUFJLEVBQUUsT0FBTztNQUNqQixPQUFPO09BQ04sR0FBRztPQUNILE9BQU8sSUFBSSxNQUFNLFNBQVMsWUFBWSxTQUFTLEtBQUs7T0FDcEQsVUFBVSxLQUFLLENBQUMsS0FBSyxNQUFNO09BQzNCLFNBQVMsSUFBSSxNQUFNLFlBQVksS0FBSztNQUNyQztLQUNELENBQUM7S0FDRCxjQUFjLE1BQU07TUFDbkIsRUFBRSxRQUFRLFFBQVEsUUFBUSxLQUFLLEVBQUUsZUFBZTtLQUNqRDtLQUNBLGVBQWUsRUFBRSxRQUFRLFFBQVEsRUFBRSxDQUFDO0lBQ3JDLENBQUM7SUFDRCxNQUFNLFNBQXlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFlBQVk7S0FDNUMsSUFBSTtLQUNKLEtBQUs7S0FDTCxXQUFXO0tBQ1gsTUFBTTtLQUNOLGFBQWE7S0FDYixPQUFPO0tBQ1AsVUFBVTtLQUNWLFVBQVU7SUFDWCxDQUFDLElBQUk7R0FDTjtFQUNELENBQUMsR0FBRyxNQUFNLFlBQTRCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87R0FDOUMsV0FBVztHQUNYLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNuQyxXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUM1QixXQUFXO0lBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztLQUNsQyxXQUFXO0tBQ1gseUJBQXlCLEVBQUUsUUFBUSxLQUFLLCtCQUErQjtJQUN4RSxDQUFDO0dBQ0YsQ0FBQyxDQUFDO0VBQ0gsQ0FBQyxJQUFJLElBQUk7Q0FDVixDQUFDO0FBQ0Y7OztBQzlmQSxJQUFJaUIsTUFBSTtDQUNQLFVBQVU7Q0FDVixZQUFZO0FBQ2I7QUFDQSxTQUFTQyxLQUFFLEdBQUc7Q0FDYixPQUFPO0VBQ047RUFDQSxNQUFNLFdBQVcsNENBQTRDO0VBQzdELE1BQU0sVUFBVSwyQ0FBMkM7Q0FDNUQsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0FBQzNCO0FBR0EsU0FBU0MsS0FBRSxFQUFFLE1BQU0sR0FBRyxjQUFjLEdBQUcsZUFBZSxHQUFHLGVBQWUsR0FBRyxjQUFjLEtBQUs7Q0FDN0YsSUFBSSxJQUFJO0VBQ1A7RUFDQSxFQUFFLE9BQU8sSUFBSSxxQ0FBcUM7RUFDbEQsRUFBRSxXQUFXLHVDQUF1QztFQUNwRDtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEtBQUssTUFBTTtFQUN2QyxJQUFJLEVBQUUsVUFBVTtHQUNmLEVBQUUsZUFBZTtHQUNqQjtFQUNEO0VBQ0EsSUFBSSxFQUFFLElBQUksR0FBRyxDQUFDO0NBQ2Y7Q0FDQSxPQUFPLFVBQVUsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsTUFBTSxFQUFFLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLEtBQUs7RUFDL0UsV0FBVztFQUNYLE1BQU0sRUFBRTtFQUNSLGdCQUFnQixFQUFFLE9BQU8sSUFBSSxTQUFTLEtBQUs7RUFDM0MsU0FBUztFQUNULFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7R0FDbkMsV0FBV0QsS0FBRSxDQUFDO0dBQ2QsVUFBVSxFQUFFO0VBQ2IsQ0FBQztDQUNGLENBQUMsRUFBRSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE1BQU0sRUFBRSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0VBQ3ZFLE1BQU07RUFDTixXQUFXO0VBQ1gsVUFBVSxFQUFFO0VBQ1osZ0JBQWdCLEVBQUUsT0FBTyxJQUFJLFNBQVMsS0FBSztFQUMzQyxTQUFTO0VBQ1QsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtHQUNuQyxXQUFXQSxLQUFFLENBQUM7R0FDZCxVQUFVLEVBQUU7RUFDYixDQUFDO0NBQ0YsQ0FBQyxFQUFFLENBQUM7QUFDTDtBQUNBLFNBQVNFLElBQUUsRUFBRSxPQUFPLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxZQUFZLGVBQWUsSUFBSSxRQUFRLGNBQWMsR0FBRyxXQUFXLElBQUksSUFBSSxlQUFlLElBQUksSUFBSSxjQUFjLEdBQUcsR0FBRyxLQUFLO0NBQ3JLLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztHQUNWO0dBQ0FILElBQUUsTUFBTUEsSUFBRTtHQUNWO0VBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0VBQzFCLEdBQUc7RUFDSCxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxNQUFNO0dBQ2pDLFdBQVc7R0FDWCxVQUFVLEVBQUUsS0FBSyxNQUFzQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUUsTUFBRztJQUMzQyxNQUFNO0lBQ04sY0FBYztJQUNkLGVBQWU7SUFDZixlQUFlO0lBQ2YsY0FBYztHQUNmLEdBQUcsRUFBRSxFQUFFLENBQUM7RUFDVCxDQUFDO0NBQ0YsQ0FBQztBQUNGOzs7QUNqRUEsSUFBSUUsT0FBQUEsR0FBSUMsYUFBQUEsV0FBQUEsRUFBRyxFQUFFLFFBQVEsSUFBSSxTQUFTLFFBQVEsR0FBRyxZQUFZLElBQUksQ0FBQyxHQUFHLFlBQVksSUFBSSxDQUFDLEdBQUcsVUFBVSxHQUFHLFdBQVcsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksa0JBQWtCLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLEdBQUcsS0FBSyxNQUFNO0NBQzlNLElBQUksSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUMxTyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxXQUFXO0VBQ25DLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQVU7R0FDVCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0lBQy9CLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxJQUFJO0dBQ1csaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUN4QixXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUM7R0FDRCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0lBQy9CLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxJQUFJO0VBQ047Q0FDRCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYzs7O0FDdEJoQixJQUFJQyxPQUFJO0NBQ1AsT0FBTztDQUNQLE1BQU07Q0FDTixLQUFLO0NBQ0wsUUFBUTtBQUNUO0FBR0EsU0FBU0MsSUFBRSxFQUFFLE9BQU8sSUFBSSxnQkFBZ0IsZUFBZSxJQUFJLFNBQVMsV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksR0FBRyxHQUFHLEtBQUs7Q0FDckosSUFBSSxJQUFJLEVBQUUsYUFBYSxDQUFDLEdBQUcsS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLHVCQUF1QixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUM5RjtFQUNBLElBQUksa0NBQWtDO0VBQ3RDRixLQUFFLE1BQU1BLEtBQUU7RUFDVjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQzVKLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLFNBQVM7RUFDakMsV0FBVztFQUNYLFNBQVM7RUFDVCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDckMsSUFBSTtHQUNKLFdBQVc7R0FDWCxNQUFNO0dBQ04sR0FBRztFQUNKLENBQUMsR0FBbUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtHQUM3QixXQUFXO0dBQ1gsVUFBVTtFQUNYLENBQUMsQ0FBQztDQUNILENBQUM7QUFDRjs7O0FDNUJBLFNBQVNHLElBQUUsR0FBRyxHQUFHO0NBQ2hCLElBQUksSUFBSSxFQUFFLHNCQUFzQjtDQUNoQyxPQUFPO0VBQ04sR0FBRyxFQUFFLFVBQVUsRUFBRTtFQUNqQixHQUFHLEVBQUUsVUFBVSxFQUFFO0NBQ2xCO0FBQ0Q7QUFDQSxTQUFTQyxJQUFFLEdBQUcsR0FBRztDQUNoQixJQUFJLEVBQUUsV0FBVyxHQUFHO0VBQ25CLEVBQUUsVUFBVSxHQUFHLEVBQUUsT0FBTyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7RUFDdEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLEdBQUcsRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztFQUM3RCxFQUFFLE9BQU87Q0FDVjtBQUNEO0FBQ0EsU0FBU0MsSUFBRSxHQUFHLEdBQUcsR0FBRztDQUNuQixFQUFFLFlBQVksR0FBRyxFQUFFLFNBQVMsR0FBRyxHQUFHLEVBQUUsT0FBTyxFQUFFLE1BQU07QUFDcEQ7QUFHQSxTQUFTQyxJQUFFLEVBQUUsT0FBTyxJQUFJLGFBQWEsWUFBWSxJQUFJLDBDQUEwQyxPQUFPLElBQUksSUFBSSxVQUFVLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUkscUJBQXFCLElBQUksSUFBSSxjQUFjLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLElBQUksR0FBRyxPQUFPLElBQUksS0FBSyxRQUFRLElBQUksS0FBSyxpQkFBaUIsSUFBSSxXQUFXLFVBQVUsSUFBSSxXQUFXLFVBQVUsSUFBSSxLQUFLLFVBQVUsR0FBRyxlQUFlLEdBQUcsYUFBYSxHQUFHLFNBQVMsS0FBSztDQUN2YSxJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxxQkFBcUIsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLEtBQUEsR0FBSUMsYUFBQUEsT0FBQUEsQ0FBRSxJQUFJLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxPQUFBQSxDQUFFLElBQUksR0FBRyxLQUFBLEdBQUlBLGFBQUFBLE9BQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsS0FBQSxHQUFJQSxhQUFBQSxPQUFBQSxDQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFBLEdBQUtDLGFBQUFBLFNBQUFBLENBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSTtFQUNySTtFQUNBLElBQUksZ0NBQWdDO0VBQ3BDO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUN0UixDQUFBLEdBQUEsYUFBQSxVQUFBLE9BQVE7RUFDUCxJQUFJLElBQUksRUFBRTtFQUNWLElBQUksQ0FBQyxHQUFHO0VBQ1IsSUFBSSxJQUFJLEVBQUUsV0FBVyxJQUFJO0VBQ3pCLElBQUksQ0FBQyxHQUFHO0VBQ1IsSUFBSSxJQUFJLE9BQU8sb0JBQW9CLEdBQUcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUM7RUFDekUsSUFBSSxFQUFFLFFBQVEsS0FBSyxNQUFNLElBQUksQ0FBQyxHQUFHLEVBQUUsU0FBUyxLQUFLLE1BQU0sSUFBSSxDQUFDLEdBQUcsRUFBRSxNQUFNLFFBQVEsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLFNBQVMsR0FBRyxFQUFFLEtBQUssRUFBRSxVQUFVLEdBQUcsRUFBRSxVQUFVLFNBQVMsRUFBRSxXQUFXLFNBQVMsRUFBRSxZQUFZLElBQUksR0FBRyxFQUFFLGNBQWMsR0FBRyxFQUFFLE1BQU0sR0FBRyxDQUFDLEdBQUdKLElBQUUsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHO0dBQ25QLElBQUksSUFBSSxJQUFJLE1BQU07R0FDbEIsRUFBRSxlQUFlO0lBQ2hCLEVBQUUsVUFBVSxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxZQUFZLEdBQUcsRUFBRSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLFVBQVUsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7R0FDbkcsR0FBRyxFQUFFLE1BQU07RUFDWjtFQUNBLGFBQWE7R0FDWixFQUFFLFVBQVU7RUFDYjtDQUNELEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsSUFBSSxLQUFLLE1BQU07RUFDZCxJQUFJLEVBQUUsVUFBVSxXQUFXLENBQUM7Q0FDN0IsR0FBRyxLQUFLLE1BQU07RUFDYixJQUFJLEtBQUssRUFBRSxTQUFTO0VBQ3BCLElBQUksSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFO0VBQ3pCLENBQUMsS0FBSyxDQUFDLE1BQU0sZUFBZSxLQUFLLE9BQU8sRUFBRSxhQUFhLFlBQVksRUFBRSxxQkFBcUIsRUFBRSxrQkFBa0IsRUFBRSxTQUFTLEdBQUcsRUFBRSxVQUFVLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQ0YsSUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsVUFBVSxHQUFHLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSTtDQUNqTyxHQUFHLEtBQUssTUFBTTtFQUNiLElBQUksS0FBSyxDQUFDLEVBQUUsU0FBUztFQUNyQixJQUFJLElBQUksRUFBRSxTQUFTLElBQUksRUFBRTtFQUN6QixJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUc7RUFDZCxJQUFJLElBQUlBLElBQUUsR0FBRyxDQUFDO0VBQ2QsRUFBRSxRQUFRLEtBQUssQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxPQUFPLEdBQUcsRUFBRSxDQUFDLENBQUM7Q0FDeEQsR0FBRyxLQUFLLE1BQU07RUFDYixJQUFJLElBQUksRUFBRSxTQUFTLElBQUksRUFBRTtFQUN6QixJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUUsVUFBVTtHQUM5QixJQUFJLEtBQUssZUFBZSxLQUFLLE9BQU8sRUFBRSxhQUFhLFlBQVksRUFBRSx1QkFBdUIsSUFBSTtJQUMzRixFQUFFLHNCQUFzQixFQUFFLFNBQVM7R0FDcEMsUUFBUSxDQUFDO0dBQ1QsRUFBRSxVQUFVLENBQUMsR0FBR0MsSUFBRSxHQUFHLEVBQUUsT0FBTyxHQUFHLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsSUFBSTtFQUM1RDtDQUNEO0NBQ0EsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsVUFBVTtHQUNPLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87SUFDeEIsV0FBVztJQUNYLElBQUksR0FBRyxFQUFFO0lBQ1QsVUFBVTtHQUNYLENBQUM7R0FDRCxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxPQUFPO0lBQzVCLFdBQVc7SUFDWCxVQUFVO0dBQ1gsQ0FBQyxJQUFJO0dBQ1csaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztJQUN4QixXQUFXO0lBQ1gsVUFBVSxDQUFpQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0tBQ3RDLElBQUk7S0FDSixLQUFLO0tBQ0wsV0FBVztLQUNYLE1BQU07S0FDTixtQkFBbUIsR0FBRyxFQUFFO0tBQ3hCLGNBQWM7S0FDZCxlQUFlO0tBQ2YsZUFBZTtLQUNmLGFBQWE7S0FDYixpQkFBaUI7S0FDakIsZ0JBQWdCO0tBQ2hCLGFBQWE7S0FDYixhQUFhO0tBQ2IsV0FBVztLQUNYLGNBQWM7SUFDZixDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87S0FDNUIsV0FBVztLQUNYLGVBQWU7S0FDZixVQUFVLElBQUksY0FBYztJQUM3QixDQUFDLENBQUM7R0FDSCxDQUFDO0dBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUN4QixXQUFXO0lBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtLQUNyQyxNQUFNO0tBQ04sV0FBVztLQUNYLGVBQWU7TUFDZCxJQUFJLElBQUksRUFBRSxTQUFTLElBQUksRUFBRTtNQUN6QixDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBVSxHQUFHLEdBQUcsRUFBRSxPQUFPLEVBQUUsTUFBTSxHQUFHQyxJQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsR0FBRyxJQUFJO0tBQ3BGO0tBQ0EsVUFBVSxLQUFLO0tBQ2YsVUFBVTtJQUNYLENBQUM7R0FDRixDQUFDO0VBQ0Y7Q0FDRCxDQUFDO0FBQ0Y7OztBQ3hIQSxJQUFJSyxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxFQUFHLEVBQUUsT0FBTyxJQUFJLFVBQVUsT0FBTyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxJQUFJLEdBQUcsVUFBVSxJQUFJLENBQUMsR0FBRyxXQUFXLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsVUFBVSxHQUFHLEdBQUcsS0FBSyxNQUFNO0NBQ3JPLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLGtCQUFrQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUNsRTtFQUNBLElBQUksNkJBQTZCO0VBQ2pDO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQzlNLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87RUFDL0IsV0FBVztFQUNYLFVBQVU7R0FDTyxpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0lBQ3hCLFdBQVc7SUFDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7S0FDckMsV0FBVztLQUNYLFNBQVM7S0FDVCxVQUFVO0lBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxVQUFVO0tBQy9CLFdBQVc7S0FDWCxTQUFTO0tBQ1QsVUFBVTtJQUNYLENBQUMsQ0FBQztHQUNILENBQUM7R0FDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxTQUFTO0lBQzFCLEtBQUs7SUFDTCxJQUFJO0lBQ0osV0FBVztJQUNYLE1BQU07SUFDTixPQUFPO0lBQ1AsS0FBSztJQUNMLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLFVBQVU7SUFDVixHQUFHO0dBQ0osQ0FBQztHQUNlLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFFLE9BQU87SUFDeEIsV0FBVztJQUNYLGVBQWU7SUFDZixVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQztHQUNsRyxDQUFDO0VBQ0Y7Q0FDRCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYzs7O0FDMUNoQixTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPLE1BQU0sU0FBUyxNQUFNLFdBQVcsZUFBZTtBQUN2RDtBQUNBLFNBQVNDLElBQUUsR0FBRyxHQUFHO0NBQ2hCLE9BQU87RUFDTjtFQUNBLG9CQUFvQjtFQUNwQjtDQUNELENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztBQUMzQjtBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLE9BQU8sQ0FBQywwQkFBMEIsMkJBQTJCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0FBQzNGO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxDQUFDLDRCQUE0Qiw2QkFBNkIsR0FBRyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFDL0Y7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPQyxhQUFBQSxTQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxNQUFNO0VBQ2xDLElBQUksRUFBQSxHQUFDQyxhQUFBQSxlQUFBQSxDQUFFLENBQUMsR0FBRyxPQUFPLENBQUM7RUFDbkIsSUFBSSxJQUFJLE9BQU8sRUFBRSxNQUFNLEtBQUs7RUFDNUIsT0FBTyxPQUFPLFNBQVMsQ0FBQyxJQUFJLENBQUM7R0FDNUIsT0FBTztHQUNQLE9BQU8sRUFBRSxNQUFNLFNBQVMsRUFBRSxNQUFNLFlBQVksUUFBUTtHQUNwRCxNQUFNLEVBQUUsTUFBTTtHQUNkLFVBQVUsQ0FBQyxDQUFDLEVBQUUsTUFBTTtFQUNyQixDQUFDLElBQUksQ0FBQztDQUNQLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsUUFBUSxFQUFFLEtBQUs7QUFDcEM7QUFDQSxTQUFTQyxJQUFFLEdBQUc7Q0FDYixPQUFPRixhQUFBQSxTQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxNQUFNO0VBQ2xDLElBQUksRUFBQSxHQUFDQyxhQUFBQSxlQUFBQSxDQUFFLENBQUMsR0FBRyxPQUFPLENBQUM7RUFDbkIsSUFBSSxJQUFJLE9BQU8sRUFBRSxNQUFNLEtBQUs7RUFDNUIsT0FBTyxPQUFPLFNBQVMsQ0FBQyxJQUFJLENBQUM7R0FDNUIsT0FBTztHQUNQLFNBQVMsRUFBRSxNQUFNO0VBQ2xCLENBQUMsSUFBSSxDQUFDO0NBQ1AsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSztBQUNwQztBQUdBLFNBQVMsRUFBRSxFQUFFLFVBQVUsS0FBSztDQUMzQixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUUsbUJBQUFBLFVBQUcsRUFBRSxVQUFVLEVBQUUsQ0FBQztBQUM1QztBQUNBLFNBQVNDLElBQUUsR0FBRztDQUNiLE9BQU87QUFDUjtBQUNBLFNBQVMsRUFBRSxFQUFFLFVBQVUsS0FBSztDQUMzQixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRUQsbUJBQUFBLFVBQUcsRUFBRSxVQUFVLEVBQUUsQ0FBQztBQUM1QztBQUNBLFNBQVMsRUFBRSxHQUFHO0NBQ2IsT0FBTztBQUNSO0FBQ0EsSUFBSSxJQUFJO0FBQUcsSUFBQSxJQUFJO0FBQUdFLElBQUFBLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxVQUFVLEdBQUcsV0FBVyxJQUFJLElBQUksZUFBZSxJQUFJLE9BQU8sZ0JBQWdCLElBQUksUUFBUSxvQkFBb0IsSUFBSSxTQUFTLGdCQUFnQixJQUFJLENBQUMsR0FBRyxhQUFhLEdBQUcsb0JBQW9CLEdBQUcsY0FBYyxHQUFHLEdBQUcsS0FBSyxNQUFNO0NBQy9PLElBQUksQ0FBQyxHQUFHLE1BQUEsR0FBS0MsYUFBQUEsU0FBQUEsQ0FBRSxDQUFDLEdBQUcsRUFBRSxhQUFhLEdBQUcsb0JBQW9CLE9BQUEsR0FBTUMsYUFBQUEsUUFBQUEsT0FBUTtFQUN0RSxJQUFJLElBQUlSLGFBQUFBLFNBQUUsUUFBUSxDQUFDLEdBQUcsSUFBSSxFQUFFLE1BQU0sT0FBQSxHQUFNQyxhQUFBQSxlQUFBQSxDQUFFLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxHQUFHLElBQUksRUFBRSxNQUFNLE9BQUEsR0FBTUEsYUFBQUEsZUFBQUEsQ0FBRSxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUM7RUFDckcsT0FBTztHQUNOLGFBQWFGLElBQUUsR0FBRyxNQUFNLFFBQVE7R0FDaEMsb0JBQW9CRyxJQUFFLEdBQUcsTUFBTSxRQUFRO0VBQ3hDO0NBQ0QsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxTQUFTLEdBQUcsSUFBSSxLQUFLLEtBQUssR0FBRyxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsVUFBVSxDQUFDLEdBQUcsSUFBSVAsSUFBRSxDQUFDLEdBQUcsSUFBSTtFQUM5R0MsSUFBRSxHQUFHLENBQUM7RUFDTiwwQkFBMEI7RUFDMUIsMEJBQTBCO0VBQzFCLElBQUksc0NBQXNDO0NBQzNDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUlDLElBQUUsQ0FBQyxHQUFHLElBQUlDLElBQUUsQ0FBQztDQUM5QyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxXQUFXO0VBQ25DLEtBQUs7RUFDTCxXQUFXO0VBQ1gsR0FBRztFQUNILFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztHQUNuQyxXQUFXO0dBQ1gsTUFBTTtHQUNOLG9CQUFvQjtHQUNwQixVQUFVLEVBQUUsS0FBSyxNQUFNO0lBQ3RCLElBQUksSUFBSSxFQUFFLFVBQVU7SUFDcEIsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztLQUMvQixNQUFNO0tBQ04saUJBQWlCO0tBQ2pCLGlCQUFpQixFQUFFO0tBQ25CLFVBQVUsRUFBRSxXQUFXLEtBQUs7S0FDNUIsV0FBVztNQUNWO01BQ0EsSUFBSSxrQ0FBa0M7TUFDdEMsRUFBRSxXQUFXLG9DQUFvQztLQUNsRCxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7S0FDMUIsVUFBVSxNQUFNO01BQ2YsRUFBRSxhQUFhLE1BQU0sS0FBSyxLQUFLLEVBQUUsRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFFLE9BQU8sQ0FBQztLQUMxRDtLQUNBLFVBQVUsQ0FBQyxFQUFFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDN0MsV0FBVztNQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7T0FDbkMsV0FBVztPQUNYLFVBQVUsRUFBRTtNQUNiLENBQUM7S0FDRixDQUFDLElBQUksTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsUUFBUTtNQUNwQyxXQUFXO01BQ1gsVUFBVSxFQUFFO0tBQ2IsQ0FBQyxDQUFDO0lBQ0gsR0FBRyxFQUFFLEtBQUs7R0FDWCxDQUFDO0VBQ0YsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBRSxXQUFXO0dBQ2hDLFdBQVc7R0FDWCxNQUFNO0dBQ04sVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNsQyxXQUFXO0lBQ1gsVUFBVSxHQUFHLFdBQVc7R0FDekIsQ0FBQztFQUNGLENBQUMsQ0FBQztDQUNILENBQUM7QUFDRixDQUFDO0FBQ0QsSUFBRSxjQUFjLFdBQVcsRUFBRSxjQUFjLGlCQUFpQixJQUFFLGNBQWMsZ0JBQWdCLEVBQUUsY0FBYyx3QkFBd0IsRUFBRSxjQUFjLHVCQUF1QixJQUFFLFFBQVEsR0FBRyxJQUFFLE9BQU9NLEtBQUcsSUFBRSxlQUFlLEdBQUcsSUFBRSxjQUFjOzs7QUM5R3hPLElBQUlLLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxPQUFPLElBQUksT0FBTyxVQUFVLEdBQUcsWUFBWSxJQUFJLENBQUMsR0FBRyxXQUFXLElBQUksSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLEdBQUcsR0FBRyxLQUFLLE1BQU07Q0FDbEwsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUNqTyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxXQUFXO0VBQ25DLEtBQUs7RUFDTCxJQUFJO0VBQ0osV0FBVztFQUNYLEdBQUc7RUFDSCxVQUFVLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztHQUN2QyxXQUFXO0dBQ1gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztJQUNsQyxXQUFXO0lBQ1gsVUFBVTtHQUNYLENBQUM7RUFDRixDQUFDLElBQUksTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztHQUNuQyxXQUFXO0dBQ1gsVUFBVTtFQUNYLENBQUMsQ0FBQztDQUNILENBQUM7QUFDRixDQUFDO0FBQ0QsSUFBRSxjQUFjOzs7QUNuQmhCLElBQUlDLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxPQUFPLEdBQUcsV0FBVyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksR0FBRyxNQUFNLElBQUksR0FBRyxRQUFRLElBQUksWUFBWSxHQUFHLEtBQUssTUFBTTtDQUNuSixJQUFJLEtBQUEsR0FBSUMsYUFBQUEsTUFBQUEsQ0FBRSxHQUFHLElBQUksS0FBSyxvQkFBb0IsRUFBRSxRQUFRLE1BQU0sRUFBRSxLQUFLLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUNqUCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLFdBQVc7RUFDWCxVQUFVLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsU0FBUztHQUN6QyxXQUFXO0dBQ1gsU0FBUztHQUNULFVBQVU7RUFDWCxDQUFDLElBQUksTUFBc0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsWUFBWTtHQUN4QyxLQUFLO0dBQ0wsSUFBSTtHQUNKLFdBQVc7R0FDWCxNQUFNO0dBQ04sZUFBZTtHQUNmLEdBQUc7RUFDSixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYzs7O0FDbEJoQixJQUFJQyxNQUFJO0NBQ1AsTUFBTTtDQUNOLEtBQUs7Q0FDTCxNQUFNO0FBQ1A7QUFBR0MsSUFBQUEsT0FBQUEsR0FBSUMsYUFBQUEsV0FBQUEsRUFBRyxFQUFFLE9BQU8sR0FBRyxlQUFlLElBQUksT0FBTyxXQUFXLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksSUFBSSxHQUFHLE1BQU0sSUFBSSxRQUFRLEdBQUcsS0FBSyxNQUFNO0NBQ3pKLElBQUksS0FBQSxHQUFJQyxhQUFBQSxNQUFBQSxDQUFFLEdBQUcsSUFBSSxLQUFLLG1CQUFtQixFQUFFLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSTtFQUNuRTtFQUNBLElBQUlILElBQUUsTUFBTUEsSUFBRSxNQUFNO0VBQ3BCO0NBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDcEosT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUUsT0FBTztFQUMvQixXQUFXO0VBQ1gsVUFBVSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDekMsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0VBQ1gsQ0FBQyxJQUFJLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFNBQVM7R0FDckMsS0FBSztHQUNMLElBQUk7R0FDSixXQUFXO0dBQ1gsTUFBTTtHQUNOLEdBQUc7RUFDSixDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELElBQUUsY0FBYzs7O0FDekJoQixJQUFJSSxNQUFJO0NBQ1AsTUFBTTtDQUNOLE9BQU87Q0FDUCxLQUFLO0NBQ0wsUUFBUTtBQUNUO0FBQ0EsU0FBU0MsSUFBRSxHQUFHO0NBQ2IsT0FBTyxLQUFLO0FBQ2I7QUFHQSxJQUFJQyxPQUFBQSxHQUFJQyxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUcsY0FBYyxHQUFHLFdBQVcsSUFBSSxJQUFJLGlCQUFpQixJQUFJLElBQUksZUFBZSxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxjQUFjLEdBQUcsR0FBRyxLQUFLLEdBQUc7Q0FDdEssT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsT0FBTztFQUMvQixLQUFLO0VBQ0wsV0FBVyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztFQUMxRCxNQUFNO0VBQ04sR0FBRztFQUNILFVBQVUsRUFBRSxLQUFLLE1BQU07R0FDdEIsSUFBSSxJQUFJLEVBQUUsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFFLE9BQU8sSUFBSSxFQUFFLE9BQU8sS0FBSyxFQUFFLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQyw0QkFBNEJILElBQUVDLElBQUUsRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSTtJQUN6SjtJQUNBLElBQUksb0NBQW9DO0lBQ3hDLElBQUksS0FBSztJQUNUO0dBQ0QsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLE9BQU8sRUFBRSxTQUFTLFdBQVcsRUFBRSxRQUFRLEVBQUU7R0FDbk0sT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsVUFBVTtJQUNsQyxNQUFNO0lBQ04sV0FBVztJQUNYLFVBQVUsRUFBRTtJQUNaLE9BQU8sRUFBRTtJQUNULGNBQWM7SUFDZCxnQkFBZ0IsT0FBTyxFQUFFLFdBQVcsWUFBWSxFQUFFLFVBQVUsS0FBSztJQUNqRSxVQUFVLE1BQU07S0FDZixJQUFJO01BQ0gsUUFBUSxFQUFFO01BQ1YsTUFBTTtNQUNOLE9BQU87S0FDUixDQUFDO0lBQ0Y7SUFDQSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxRQUFRO0tBQ25DLFdBQVc7S0FDWCxVQUFVLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUUsR0FBRztNQUNuQyxXQUFXO01BQ1gsZUFBZTtNQUNmLFdBQVc7S0FDWixDQUFDLElBQUksTUFBTSxFQUFFLFFBQXdCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7TUFDOUMsV0FBVztNQUNYLFVBQVUsRUFBRTtLQUNiLENBQUMsSUFBSSxJQUFJO0lBQ1YsQ0FBQztHQUNGLEdBQUcsRUFBRSxFQUFFO0VBQ1IsQ0FBQztDQUNGLENBQUM7QUFDRixDQUFDO0FBQ0QsSUFBRSxjQUFjOzs7QUN6QmhCLElBQUlHLE9BQUFBLEdBQUlDLGFBQUFBLFdBQUFBLEVBQUcsRUFBRSxRQUFRLEdBQUcsWUFBWSxHQUFHLFFBQVEsR0FBRyxVQUFVLEdBQUcsV0FBVyxJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxxQkFBcUIsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxHQUFHLEtBQUssTUFBTTtDQUN4TSxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQzFTLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87RUFDL0IsS0FBSztFQUNMLFdBQVc7RUFDWCxHQUFHO0VBQ0gsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUVDLEtBQUc7R0FDOUIsV0FBVztHQUNYLFFBQVE7R0FDUixRQUFRO0dBQ1IsZUFBZTtHQUNmLGlCQUFpQjtHQUNqQixpQkFBaUI7R0FDakIsd0JBQXdCO0dBQ3hCLGtCQUFrQjtHQUNsQixVQUFVO0VBQ1gsQ0FBQztDQUNGLENBQUM7QUFDRixDQUFDO0FBQ0QsSUFBRSxjQUFjO0FBR2hCLElBQUksS0FBQSxHQUFJRCxhQUFBQSxXQUFBQSxDQUFFLFNBQVMsRUFBRSxNQUFNLEdBQUcsT0FBTyxHQUFHLFFBQVEsR0FBRyxXQUFXLElBQUksSUFBSSxHQUFHLEtBQUssR0FBRztDQUNoRixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0VBQy9CLEtBQUs7RUFDTCxXQUFXLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHO0VBQzNELEdBQUc7RUFDSCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLE9BQU87R0FDbkMsV0FBVztHQUNYLGVBQWU7R0FDZixVQUFVO0VBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBRSxPQUFPO0dBQzVCLFdBQVc7R0FDWCxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFVBQVU7SUFDdEMsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFFLFFBQVE7SUFDN0IsV0FBVztJQUNYLFVBQVU7R0FDWCxDQUFDLENBQUM7RUFDSCxDQUFDLENBQUM7Q0FDSCxDQUFDO0FBQ0YsQ0FBQztBQUNELEVBQUUsY0FBYyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3XX0=