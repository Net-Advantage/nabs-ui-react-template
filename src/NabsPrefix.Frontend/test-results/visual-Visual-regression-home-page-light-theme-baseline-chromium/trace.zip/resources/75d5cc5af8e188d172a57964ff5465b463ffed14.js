import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pages/Home/HomePage.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Panel } from "/node_modules/.vite/deps/@net-advantage_nabs-ui-shell.js?v=5bd21436";
var _jsxFileName = "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Home/HomePage.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5bd21436";
export function HomePage() {
	return /* @__PURE__ */ _jsxDEV(Panel, {
		header: "Welcome",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: "This is a clean Nabs UI starter. The Shell is the root layout and the official light/dark themes are already wired up." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
			"Build all new UI using components imported from ",
			/* @__PURE__ */ _jsxDEV("code", { children: "@net-advantage/nabs-ui-shell" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 57
			}, this),
			"."
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
}
_c = HomePage;
var _c;
$RefreshReg$(_c, "HomePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/Pages/Home/HomePage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Home/HomePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Home/HomePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Home/HomePage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhOzs7QUFFdEIsT0FBTyxTQUFTLFdBQVc7Q0FDekIsT0FDRSx3QkFBQyxPQUFEO0VBQU8sUUFBTztZQUFkLENBQ0Usd0JBQUMsS0FBRCxZQUFHLHlIQUdBOzs7O1lBQ0gsd0JBQUMsS0FBRDtHQUFHO0dBQytDLHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7O0dBQUM7RUFDeEY7Ozs7VUFDRTs7Ozs7O0FBRVgiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG9tZVBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhbmVsIH0gZnJvbSBcIkBuZXQtYWR2YW50YWdlL25hYnMtdWktc2hlbGxcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBIb21lUGFnZSgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFBhbmVsIGhlYWRlcj1cIldlbGNvbWVcIj5cclxuICAgICAgPHA+XHJcbiAgICAgICAgVGhpcyBpcyBhIGNsZWFuIE5hYnMgVUkgc3RhcnRlci4gVGhlIFNoZWxsIGlzIHRoZSByb290IGxheW91dCBhbmQgdGhlXHJcbiAgICAgICAgb2ZmaWNpYWwgbGlnaHQvZGFyayB0aGVtZXMgYXJlIGFscmVhZHkgd2lyZWQgdXAuXHJcbiAgICAgIDwvcD5cclxuICAgICAgPHA+XHJcbiAgICAgICAgQnVpbGQgYWxsIG5ldyBVSSB1c2luZyBjb21wb25lbnRzIGltcG9ydGVkIGZyb20gPGNvZGU+QG5ldC1hZHZhbnRhZ2UvbmFicy11aS1zaGVsbDwvY29kZT4uXHJcbiAgICAgIDwvcD5cclxuICAgIDwvUGFuZWw+XHJcbiAgKTtcclxufVxyXG4iXX0=