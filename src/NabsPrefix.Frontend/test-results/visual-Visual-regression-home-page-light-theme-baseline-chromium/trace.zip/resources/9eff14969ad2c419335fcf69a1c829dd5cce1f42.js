import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pages/Weather/WeatherPage.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Cards, Panel } from "/node_modules/.vite/deps/@net-advantage_nabs-ui-shell.js?v=5bd21436";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5bd21436";
import { WeatherPageViewModel } from "/src/Pages/Weather/WeatherPage.view-model.ts";
var _jsxFileName = "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Weather/WeatherPage.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5bd21436";
var _s = $RefreshSig$();
const weatherPageViewModel = new WeatherPageViewModel();
export function WeatherPage() {
	_s();
	const [model, setModel] = useState([]);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState(null);
	useEffect(() => {
		let isMounted = true;
		weatherPageViewModel.loadWeather().then((data) => {
			if (!isMounted) {
				return;
			}
			setModel(data);
		}).catch((err) => {
			if (!isMounted) {
				return;
			}
			if (err instanceof Error) {
				setError(err.message);
				return;
			}
			setError("Unable to load weather data.");
		}).finally(() => {
			if (isMounted) {
				setIsLoading(false);
			}
		});
		return () => {
			isMounted = false;
		};
	}, []);
	const cards = useMemo(() => model.map((forecast) => ({
		id: forecast.id,
		header: new Date(forecast.date).toLocaleDateString(),
		content: /* @__PURE__ */ _jsxDEV("ul", { children: [
			/* @__PURE__ */ _jsxDEV("li", { children: ["Summary: ", forecast.summary] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("li", { children: [
				"Temp C: ",
				forecast.temperatureC,
				"°C"
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("li", { children: [
				"Temp F: ",
				forecast.temperatureF,
				"°F"
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 13
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 11
		}, this),
		actions: "From /api/weather"
	})), [model]);
	return /* @__PURE__ */ _jsxDEV(Panel, {
		header: "Weather",
		children: [
			/* @__PURE__ */ _jsxDEV("p", { children: weatherPageViewModel.topicPrompt }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 7
			}, this),
			isLoading && /* @__PURE__ */ _jsxDEV("p", { children: "Loading weather forecast..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 21
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 17
			}, this),
			!isLoading && !error && /* @__PURE__ */ _jsxDEV(Cards, {
				"aria-label": "Weather forecast card list",
				columns: 2,
				layout: "N",
				items: cards
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 66,
		columnNumber: 5
	}, this);
}
_s(WeatherPage, "VeVgtrnygRilDg3+5nqEKS3PCCA=");
_c = WeatherPage;
var _c;
$RefreshReg$(_c, "WeatherPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/Pages/Weather/WeatherPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Weather/WeatherPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Weather/WeatherPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Dev/Nabs/nabs-ui-react-template/src/NabsPrefix.Frontend/src/Pages/Weather/WeatherPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxPQUFPLGFBQWE7QUFDN0IsU0FBUyxXQUFXLFNBQVMsZ0JBQWdCO0FBQzdDLFNBQVMsNEJBQTRCOzs7O0FBR3JDLE1BQU0sdUJBQXVCLElBQUkscUJBQXFCO0FBRXRELE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQWlDLENBQUMsQ0FBQztDQUM3RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxJQUFJO0NBQy9DLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUV0RCxnQkFBZ0I7RUFDZCxJQUFJLFlBQVk7RUFFaEIscUJBQ0csWUFBWSxDQUFDLENBQ2IsTUFBTSxTQUFTO0dBQ2QsSUFBSSxDQUFDLFdBQVc7SUFDZDtHQUNGO0dBRUEsU0FBUyxJQUFJO0VBQ2YsQ0FBQyxDQUFDLENBQ0QsT0FBTyxRQUFpQjtHQUN2QixJQUFJLENBQUMsV0FBVztJQUNkO0dBQ0Y7R0FFQSxJQUFJLGVBQWUsT0FBTztJQUN4QixTQUFTLElBQUksT0FBTztJQUNwQjtHQUNGO0dBRUEsU0FBUyw4QkFBOEI7RUFDekMsQ0FBQyxDQUFDLENBQ0QsY0FBYztHQUNiLElBQUksV0FBVztJQUNiLGFBQWEsS0FBSztHQUNwQjtFQUNGLENBQUM7RUFFSCxhQUFhO0dBQ1gsWUFBWTtFQUNkO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLFFBQVEsY0FFVixNQUFNLEtBQUssY0FBYztFQUN2QixJQUFJLFNBQVM7RUFDYixRQUFRLElBQUksS0FBSyxTQUFTLElBQUksQ0FBQyxDQUFDLG1CQUFtQjtFQUNuRCxTQUNFLHdCQUFDLE1BQUQ7R0FDRSx3QkFBQyxNQUFELGFBQUksYUFBVSxTQUFTLE9BQVk7Ozs7O0dBQ25DLHdCQUFDLE1BQUQ7SUFBSTtJQUFTLFNBQVM7SUFBYTtHQUFNOzs7OztHQUN6Qyx3QkFBQyxNQUFEO0lBQUk7SUFBUyxTQUFTO0lBQWE7R0FBTTs7Ozs7RUFDdkM7Ozs7O0VBRU4sU0FBUztDQUNYLEVBQUUsR0FDSixDQUFDLEtBQUssQ0FDUjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFPLFFBQU87WUFBZDtHQUNFLHdCQUFDLEtBQUQsWUFBSSxxQkFBcUIsWUFBZTs7Ozs7R0FDdkMsYUFBYSx3QkFBQyxLQUFELFlBQUcsOEJBQThCOzs7OztHQUM5QyxTQUFTLHdCQUFDLEtBQUQsWUFBSSxNQUFTOzs7OztHQUN0QixDQUFDLGFBQWEsQ0FBQyxTQUNkLHdCQUFDLE9BQUQ7SUFBTyxjQUFXO0lBQTZCLFNBQVM7SUFBRyxRQUFPO0lBQUksT0FBTztHQUFROzs7OztFQUVsRjs7Ozs7O0FBRVgiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiV2VhdGhlclBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENhcmRzLCBQYW5lbCB9IGZyb20gXCJAbmV0LWFkdmFudGFnZS9uYWJzLXVpLXNoZWxsXCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgV2VhdGhlclBhZ2VWaWV3TW9kZWwgfSBmcm9tIFwiLi9XZWF0aGVyUGFnZS52aWV3LW1vZGVsXCI7XHJcbmltcG9ydCB0eXBlIHsgV2VhdGhlckZvcmVjYXN0TW9kZWwgfSBmcm9tIFwiLi9XZWF0aGVyUGFnZS52aWV3LW1vZGVsXCI7XHJcblxyXG5jb25zdCB3ZWF0aGVyUGFnZVZpZXdNb2RlbCA9IG5ldyBXZWF0aGVyUGFnZVZpZXdNb2RlbCgpO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFdlYXRoZXJQYWdlKCkge1xyXG4gIGNvbnN0IFttb2RlbCwgc2V0TW9kZWxdID0gdXNlU3RhdGU8V2VhdGhlckZvcmVjYXN0TW9kZWxbXT4oW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWU7XHJcblxyXG4gICAgd2VhdGhlclBhZ2VWaWV3TW9kZWxcclxuICAgICAgLmxvYWRXZWF0aGVyKClcclxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICBpZiAoIWlzTW91bnRlZCkge1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0TW9kZWwoZGF0YSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyOiB1bmtub3duKSA9PiB7XHJcbiAgICAgICAgaWYgKCFpc01vdW50ZWQpIHtcclxuICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpO1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0RXJyb3IoXCJVbmFibGUgdG8gbG9hZCB3ZWF0aGVyIGRhdGEuXCIpO1xyXG4gICAgICB9KVxyXG4gICAgICAuZmluYWxseSgoKSA9PiB7XHJcbiAgICAgICAgaWYgKGlzTW91bnRlZCkge1xyXG4gICAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGlzTW91bnRlZCA9IGZhbHNlO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGNhcmRzID0gdXNlTWVtbyhcclxuICAgICgpID0+XHJcbiAgICAgIG1vZGVsLm1hcCgoZm9yZWNhc3QpID0+ICh7XHJcbiAgICAgICAgaWQ6IGZvcmVjYXN0LmlkLFxyXG4gICAgICAgIGhlYWRlcjogbmV3IERhdGUoZm9yZWNhc3QuZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCksXHJcbiAgICAgICAgY29udGVudDogKFxyXG4gICAgICAgICAgPHVsPlxyXG4gICAgICAgICAgICA8bGk+U3VtbWFyeToge2ZvcmVjYXN0LnN1bW1hcnl9PC9saT5cclxuICAgICAgICAgICAgPGxpPlRlbXAgQzoge2ZvcmVjYXN0LnRlbXBlcmF0dXJlQ33CsEM8L2xpPlxyXG4gICAgICAgICAgICA8bGk+VGVtcCBGOiB7Zm9yZWNhc3QudGVtcGVyYXR1cmVGfcKwRjwvbGk+XHJcbiAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICksXHJcbiAgICAgICAgYWN0aW9uczogXCJGcm9tIC9hcGkvd2VhdGhlclwiLFxyXG4gICAgICB9KSksXHJcbiAgICBbbW9kZWxdLFxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8UGFuZWwgaGVhZGVyPVwiV2VhdGhlclwiPlxyXG4gICAgICA8cD57d2VhdGhlclBhZ2VWaWV3TW9kZWwudG9waWNQcm9tcHR9PC9wPlxyXG4gICAgICB7aXNMb2FkaW5nICYmIDxwPkxvYWRpbmcgd2VhdGhlciBmb3JlY2FzdC4uLjwvcD59XHJcbiAgICAgIHtlcnJvciAmJiA8cD57ZXJyb3J9PC9wPn1cclxuICAgICAgeyFpc0xvYWRpbmcgJiYgIWVycm9yICYmIChcclxuICAgICAgICA8Q2FyZHMgYXJpYS1sYWJlbD1cIldlYXRoZXIgZm9yZWNhc3QgY2FyZCBsaXN0XCIgY29sdW1ucz17Mn0gbGF5b3V0PVwiTlwiIGl0ZW1zPXtjYXJkc30gLz5cclxuICAgICAgKX1cclxuICAgIDwvUGFuZWw+XHJcbiAgKTtcclxufVxyXG4iXX0=